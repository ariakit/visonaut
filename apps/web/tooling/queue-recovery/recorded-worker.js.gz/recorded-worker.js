var __defProp = Object.defineProperty;
var __name = (target, value) => __defProp(target, "name", { value, configurable: true });

// worker.mjs
import { timingSafeEqual } from "node:crypto";

// implementation/service/database.ts
var ConflictError = class extends Error {
  constructor(message, current) {
    super(message);
    this.current = current;
    this.name = "ConflictError";
  }
  current;
  static {
    __name(this, "ConflictError");
  }
  code = "CONFLICT";
};
var IncompleteError = class extends Error {
  static {
    __name(this, "IncompleteError");
  }
  code = "INCOMPLETE";
  constructor(message) {
    super(message);
    this.name = "IncompleteError";
  }
};
function statement(database, sql, values = []) {
  return database.prepare(sql).bind(...values);
}
__name(statement, "statement");
function assertion(database, predicate, values = []) {
  return statement(
    database,
    `INSERT INTO ariviso_assertions (valid) VALUES (CASE WHEN (${predicate}) THEN 1 ELSE 0 END)`,
    values
  );
}
__name(assertion, "assertion");
async function atomic(database, statements) {
  try {
    return await database.batch([
      ...statements,
      statement(database, "DELETE FROM ariviso_assertions")
    ]);
  } catch (error) {
    if (error instanceof Error && /CHECK constraint failed.*valid|ariviso_assertions/.test(error.message)) {
      throw new ConflictError("State changed. Refresh the comparison before trying again.");
    }
    throw error;
  }
}
__name(atomic, "atomic");

// implementation/service/work.ts
function positiveInteger(value, name) {
  if (!Number.isSafeInteger(value) || value < 1) {
    throw new Error(`${name} must be a positive safe integer`);
  }
}
__name(positiveInteger, "positiveInteger");
function validateLease(params) {
  positiveInteger(params.leaseMs, "leaseMs");
  if (!params.token) {
    throw new Error("A unique lease token is required");
  }
}
__name(validateLease, "validateLease");
function enqueueWorkStatement(database, input) {
  positiveInteger(input.maxAttempts, "maxAttempts");
  return database.prepare(`
    INSERT INTO work_tasks (id, kind, payload, max_attempts, available_at, created_at, updated_at)
    VALUES (?, ?, ?, ?, ?, ?, ?)
    ON CONFLICT(id) DO UPDATE SET kind = excluded.kind,
      payload = excluded.payload, max_attempts = excluded.max_attempts
  `).bind(input.id, input.kind, input.payload, input.maxAttempts, input.now, input.now, input.now);
}
__name(enqueueWorkStatement, "enqueueWorkStatement");
async function enqueueWork(database, input) {
  await enqueueWorkStatement(database, input).run();
}
__name(enqueueWork, "enqueueWork");
async function getWork(database, id) {
  return database.prepare("SELECT * FROM work_tasks WHERE id = ?").bind(id).first();
}
__name(getWork, "getWork");
async function claimWork(database, params) {
  validateLease(params);
  await database.prepare(`
    UPDATE work_tasks SET state = 'dead', lease_token = NULL, lease_until = NULL,
      last_error = 'Lease expired after final attempt', updated_at = ?
    WHERE id = ? AND state = 'leased' AND lease_until <= ? AND attempts >= max_attempts
  `).bind(params.now, params.id, params.now).run();
  return database.prepare(`
    UPDATE work_tasks SET state = 'leased', attempts = attempts + 1,
      lease_token = ?, lease_until = ?, updated_at = ?
    WHERE id = ? AND attempts < max_attempts AND (
      (state = 'queued' AND available_at <= ?) OR
      (state = 'leased' AND lease_until <= ?)
    ) RETURNING *
  `).bind(params.token, params.now + params.leaseMs, params.now, params.id, params.now, params.now).first();
}
__name(claimWork, "claimWork");
function workLeaseAssertion(database, params) {
  return assertion(
    database,
    `EXISTS (SELECT 1 FROM work_tasks WHERE id = ?
    AND state = 'leased' AND lease_token = ? AND lease_until > ?)`,
    [params.id, params.token, params.now]
  );
}
__name(workLeaseAssertion, "workLeaseAssertion");
function completeWorkStatement(database, params) {
  return database.prepare(`
    UPDATE work_tasks SET state = 'complete', result = ?, lease_until = NULL,
      updated_at = ? WHERE id = ? AND state = 'leased' AND lease_token = ? AND lease_until > ?
    RETURNING id
  `).bind(params.result, params.now, params.id, params.token, params.now);
}
__name(completeWorkStatement, "completeWorkStatement");
async function completeWork(database, params) {
  const result = await completeWorkStatement(database, params).first();
  if (result) return true;
  const previous = await database.prepare(`
    SELECT id FROM work_tasks WHERE id = ? AND state = 'complete' AND lease_token = ? AND result = ?
  `).bind(params.id, params.token, params.result).first();
  return previous !== null;
}
__name(completeWork, "completeWork");
async function failWork(database, params) {
  const result = await database.prepare(`
    UPDATE work_tasks SET state = CASE WHEN attempts >= max_attempts THEN 'dead' ELSE 'queued' END,
      available_at = ?, last_error = ?, lease_token = NULL, lease_until = NULL, updated_at = ?
    WHERE id = ? AND state = 'leased' AND lease_token = ? AND lease_until > ? RETURNING id
  `).bind(
    Math.max(params.now, params.retryAt),
    params.error.slice(0, 4096),
    params.now,
    params.id,
    params.token,
    params.now
  ).first();
  return result !== null;
}
__name(failWork, "failWork");
async function reconcileWork(database, params) {
  positiveInteger(params.limit, "limit");
  await database.prepare(`
    UPDATE work_tasks SET state = 'dead', lease_token = NULL, lease_until = NULL,
      last_error = 'Lease expired after final attempt', updated_at = ?
    WHERE id IN (SELECT id FROM work_tasks WHERE state = 'leased'
      AND lease_until <= ? AND attempts >= max_attempts AND (? IS NULL OR kind = ?)
      ORDER BY lease_until, id LIMIT ?)
  `).bind(params.now, params.now, params.kind ?? null, params.kind ?? null, params.limit).run();
  const due = await database.prepare(`
    SELECT id FROM work_tasks WHERE attempts < max_attempts AND
      ((state = 'queued' AND available_at <= ?) OR (state = 'leased' AND lease_until <= ?))
      AND (? IS NULL OR kind = ?)
    ORDER BY available_at, id LIMIT ?
  `).bind(params.now, params.now, params.kind ?? null, params.kind ?? null, params.limit).all();
  const published = [];
  const failed = [];
  for (const task of due.results ?? []) {
    try {
      await params.publish(task.id);
      published.push(task.id);
    } catch {
      failed.push(task.id);
    }
  }
  return { published, failed };
}
__name(reconcileWork, "reconcileWork");
function statusIntentStatements(database, input) {
  positiveInteger(input.revision, "revision");
  positiveInteger(input.maxAttempts, "maxAttempts");
  return [
    database.prepare(`
      INSERT INTO work_checks (id, desired_revision) VALUES (?, ?)
      ON CONFLICT(id) DO UPDATE SET desired_revision = excluded.desired_revision
      WHERE excluded.desired_revision > work_checks.desired_revision
    `).bind(input.checkId, input.revision),
    database.prepare(`
      INSERT INTO work_status_outbox (check_id, revision, run_id, attempt,
        comparison_revision, source_revision, conclusion, details_url, max_attempts, available_at)
      SELECT ?, ?, ?, ?, ?, ?, ?, ?, ?, ?
      WHERE EXISTS (SELECT 1 FROM work_checks WHERE id = ? AND desired_revision = ?)
      ON CONFLICT(check_id, revision) DO UPDATE SET run_id = excluded.run_id,
        attempt = excluded.attempt, comparison_revision = excluded.comparison_revision,
        source_revision = excluded.source_revision, conclusion = excluded.conclusion,
        details_url = excluded.details_url, max_attempts = excluded.max_attempts
    `).bind(
      input.checkId,
      input.revision,
      input.runId,
      input.attempt,
      input.comparisonRevision,
      input.sourceRevision,
      input.conclusion,
      input.detailsUrl,
      input.maxAttempts,
      input.now,
      input.checkId,
      input.revision
    )
  ];
}
__name(statusIntentStatements, "statusIntentStatements");
var closedRunRetentionMs = 30 * 24 * 60 * 60 * 1e3;

// implementation/service/service.ts
async function captureProfilesDigest(captures) {
  const profiles = captures.map((capture) => [capture.itemKey, capture.variantKey, capture.profileDigest]).sort(
    (left, right) => JSON.stringify(left) < JSON.stringify(right) ? -1 : JSON.stringify(left) > JSON.stringify(right) ? 1 : 0
  );
  const digest = await crypto.subtle.digest(
    "SHA-256",
    new TextEncoder().encode(JSON.stringify(profiles))
  );
  return Array.from(new Uint8Array(digest), (value) => value.toString(16).padStart(2, "0")).join(
    ""
  );
}
__name(captureProfilesDigest, "captureProfilesDigest");
function identity(itemKey, variantKey) {
  return JSON.stringify([itemKey, variantKey]);
}
__name(identity, "identity");
function requestJson(input) {
  const { now: _now, ...request } = input;
  return JSON.stringify(request);
}
__name(requestJson, "requestJson");
function parseCommandResult(json2) {
  return JSON.parse(json2);
}
__name(parseCommandResult, "parseCommandResult");
var Service = class {
  constructor(database) {
    this.database = database;
  }
  database;
  static {
    __name(this, "Service");
  }
  sql(sql, values = []) {
    return statement(this.database, sql, values);
  }
  guard(sql, values = []) {
    return assertion(this.database, sql, values);
  }
  async one(sql, values = []) {
    const row = await this.sql(sql, values).first();
    if (!row) {
      throw new IncompleteError("The requested record does not exist.");
    }
    return row;
  }
  async rows(sql, values = []) {
    return (await this.sql(sql, values).all()).results ?? [];
  }
  async project(id) {
    return this.one("SELECT * FROM ariviso_projects WHERE id = ?", [id]);
  }
  async run(id) {
    return this.one("SELECT * FROM ariviso_runs WHERE id = ?", [id]);
  }
  async comparison(id) {
    return this.one("SELECT * FROM ariviso_comparisons WHERE id = ?", [id]);
  }
  async comparisonRows(id) {
    return this.rows(
      "SELECT * FROM ariviso_comparison_rows WHERE comparison_id = ? ORDER BY ordinal, id",
      [id]
    );
  }
  async createPolicy(input) {
    const policy = input.policy;
    if (!policy.id || !Number.isFinite(policy.channelThreshold) || policy.channelThreshold < 0 || policy.channelThreshold > 255 || !Number.isSafeInteger(policy.maxChangedPixels) || policy.maxChangedPixels < 0 || !Number.isFinite(policy.maxChangedRatio) || policy.maxChangedRatio < 0 || policy.maxChangedRatio > 1) {
      throw new IncompleteError("Invalid trusted comparison policy.");
    }
    await atomic(this.database, [
      this.sql(
        "INSERT INTO ariviso_policies (digest, policy_json) VALUES (?, ?) ON CONFLICT(digest) DO NOTHING",
        [input.digest, JSON.stringify(policy)]
      ),
      this.guard("EXISTS (SELECT 1 FROM ariviso_policies WHERE digest = ? AND policy_json = ?)", [
        input.digest,
        JSON.stringify(policy)
      ])
    ]);
  }
  async createProject(input) {
    await this.sql(
      "INSERT INTO ariviso_projects (id, repository_id, policy_digest) VALUES (?, ?, ?)",
      [input.id, input.repositoryId, input.policyDigest]
    ).run();
  }
  projectGuard(project) {
    return this.guard("EXISTS (SELECT 1 FROM ariviso_projects WHERE id = ? AND revision = ?)", [
      project.id,
      project.revision
    ]);
  }
  activeGuard(run) {
    return this.guard(
      "EXISTS (SELECT 1 FROM ariviso_runs WHERE id = ? AND active = 1 AND revision = ?)",
      [run.id, run.revision]
    );
  }
  reviewGuard(run, comparisonId) {
    return this.guard(
      "EXISTS (SELECT 1 FROM ariviso_runs run JOIN ariviso_comparisons comparison ON comparison.id = run.comparison_id WHERE run.id = ? AND run.active = 1 AND run.revision = ? AND run.sealed_at IS NOT NULL AND comparison.id = ? AND comparison.state = 'ready')",
      [run.id, run.revision, comparisonId]
    );
  }
  touch(run, now) {
    return [
      this.sql("UPDATE ariviso_projects SET revision = revision + 1 WHERE id = ?", [
        run.project_id
      ]),
      this.sql("UPDATE ariviso_runs SET revision = revision + 1 WHERE id = ?", [run.id]),
      this.sql(
        "UPDATE work_checks SET desired_revision = (SELECT revision FROM ariviso_projects WHERE id = ?) WHERE id IN (SELECT id FROM ariviso_checks WHERE project_id = ?)",
        [run.project_id, run.project_id]
      ),
      this.sql(
        "INSERT INTO ariviso_status_outbox (id, run_id, run_revision, created_at) SELECT ?, id, revision, ? FROM ariviso_runs WHERE id = ?",
        [crypto.randomUUID(), now, run.id]
      )
    ];
  }
  audit(run, action, detail, now, actorId = null) {
    return this.sql(
      "INSERT INTO ariviso_audit (id, project_id, run_id, actor_id, action, detail_json, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)",
      [crypto.randomUUID(), run.project_id, run.id, actorId, action, JSON.stringify(detail), now]
    );
  }
  async reserveRun(input) {
    if (!input.verificationDigest || !input.lineageKey || input.plan.shards.length === 0) {
      throw new IncompleteError("A verified full plan and lineage are required.");
    }
    const existing = await this.sql(
      "SELECT * FROM ariviso_runs WHERE project_id = ? AND external_run_id = ? AND attempt = ?",
      [input.projectId, input.externalRunId, input.attempt]
    ).first();
    if (existing) {
      if (existing.tested_sha !== input.testedSha || existing.plan_digest !== input.plan.digest || existing.lineage_key !== input.lineageKey) {
        throw new ConflictError(
          "The run identity already has different trusted metadata.",
          existing
        );
      }
      return existing;
    }
    const project = await this.project(input.projectId);
    if (new TextEncoder().encode(JSON.stringify(input.plan)).byteLength > 15e5) {
      throw new IncompleteError("The trusted plan is too large for one run record.");
    }
    const keys = /* @__PURE__ */ new Set();
    const identities = /* @__PURE__ */ new Set();
    for (const shard of input.plan.shards) {
      if (keys.has(shard.key) || !shard.discovery && (shard.tests.length === 0 || shard.captures.length === 0) || shard.discovery && (!shard.discovery.executorDigest || !shard.discovery.configurationDigest)) {
        throw new IncompleteError("Each trusted shard needs unique identity, tests, and captures.");
      }
      keys.add(shard.key);
      for (const capture of shard.captures) {
        const key = identity(capture.itemKey, capture.variantKey);
        if (identities.has(key) || !shard.tests.includes(capture.testId)) {
          throw new IncompleteError(
            "The trusted plan contains a duplicate or unaccounted capture."
          );
        }
        identities.add(key);
      }
    }
    for (const key of input.rerunShardKeys) {
      if (!keys.has(key)) {
        throw new IncompleteError("An unknown shard was marked as rerun.");
      }
    }
    const statements = [
      this.projectGuard(project),
      this.guard(
        "NOT EXISTS (SELECT 1 FROM ariviso_runs WHERE project_id = ? AND external_run_id = ? AND attempt >= ?)",
        [input.projectId, input.externalRunId, input.attempt]
      ),
      this.sql(
        "UPDATE ariviso_runs SET active = 0, state = 'superseded', revision = revision + 1 WHERE project_id = ? AND external_run_id = ? AND active = 1",
        [input.projectId, input.externalRunId]
      ),
      this.sql(
        "INSERT INTO ariviso_runs (id, project_id, external_run_id, attempt, kind, tested_sha, lineage_key, plan_digest, plan_json, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
        [
          input.id,
          input.projectId,
          input.externalRunId,
          input.attempt,
          input.kind,
          input.testedSha,
          input.lineageKey,
          input.plan.digest,
          JSON.stringify(input.plan),
          input.now
        ]
      ),
      this.sql("INSERT INTO work_retained_runs (id, object_prefix) VALUES (?, ?)", [
        input.id,
        `runs/${input.id}/`
      ]),
      this.sql("INSERT INTO work_retention_pins (run_id, owner, reason) VALUES (?, ?, 'review')", [
        input.id,
        `review:${input.id}`
      ])
    ];
    if (input.maximumActiveRuns !== void 0) {
      if (!Number.isSafeInteger(input.maximumActiveRuns) || input.maximumActiveRuns < 1)
        throw new IncompleteError("The active run admission limit is invalid.");
      statements.push(
        this.guard(
          "(SELECT COUNT(*) FROM ariviso_runs WHERE active=1 AND state IN ('uploading','comparing')) <= ?",
          [input.maximumActiveRuns]
        )
      );
    }
    for (const sourceId of new Set(input.verifiedRelatedRunIds)) {
      statements.push(
        this.guard("EXISTS (SELECT 1 FROM ariviso_runs WHERE id = ? AND project_id = ?)", [
          sourceId,
          input.projectId
        ])
      );
      statements.push(
        this.sql(
          "INSERT INTO ariviso_lineage (source_run_id, target_run_id, proof_digest) VALUES (?, ?, ?)",
          [sourceId, input.id, input.verificationDigest]
        )
      );
    }
    for (const sha of new Set(input.verifiedAncestorShas)) {
      statements.push(
        this.sql(
          "INSERT INTO ariviso_ancestry (run_id, ancestor_sha, proof_digest) VALUES (?, ?, ?)",
          [input.id, sha, input.verificationDigest]
        )
      );
    }
    for (const shard of input.plan.shards) {
      statements.push(
        this.sql(
          "INSERT INTO ariviso_shards (run_id, key, profile_digest, expected_json) VALUES (?, ?, ?, ?)",
          [input.id, shard.key, shard.profileDigest, JSON.stringify(shard)]
        )
      );
    }
    if (input.inheritFromRunId) {
      statements.push(
        this.guard(
          "EXISTS (SELECT 1 FROM ariviso_runs WHERE id = ? AND project_id = ? AND external_run_id = ? AND tested_sha = ? AND plan_digest = ? AND attempt < ?)",
          [
            input.inheritFromRunId,
            input.projectId,
            input.externalRunId,
            input.testedSha,
            input.plan.digest,
            input.attempt
          ]
        )
      );
      for (const shard of input.plan.shards) {
        if (input.rerunShardKeys.includes(shard.key)) continue;
        const inherited = input.verifiedInheritedShards?.find((entry) => entry.key === shard.key);
        if (!inherited) {
          throw new IncompleteError(
            "Each inherited shard requires verified manifest and full capture-profile identity."
          );
        }
        statements.push(
          this.guard(
            "EXISTS (SELECT 1 FROM ariviso_shards WHERE run_id = ? AND key = ? AND manifest_digest = ? AND full_profile_digest = ?)",
            [
              input.inheritFromRunId,
              shard.key,
              inherited.manifestDigest,
              inherited.captureProfileDigest
            ]
          )
        );
        statements.push(
          this.guard(
            "EXISTS (SELECT 1 FROM ariviso_shards WHERE run_id = ? AND key = ? AND state = 'complete' AND profile_digest = ?)",
            [input.inheritFromRunId, shard.key, shard.profileDigest]
          )
        );
        statements.push(
          this.sql(
            "UPDATE ariviso_shards SET state = 'complete', manifest_digest = (SELECT manifest_digest FROM ariviso_shards WHERE run_id = ? AND key = ?), full_profile_digest = ?, expected_json = (SELECT expected_json FROM ariviso_shards WHERE run_id = ? AND key = ?), discovery_json = (SELECT discovery_json FROM ariviso_shards WHERE run_id = ? AND key = ?), source_run_id = ?, source_attempt = (SELECT COALESCE(shard.source_attempt, source.attempt) FROM ariviso_shards shard JOIN ariviso_runs source ON source.id = shard.run_id WHERE shard.run_id = ? AND shard.key = ?) WHERE run_id = ? AND key = ?",
            [
              input.inheritFromRunId,
              shard.key,
              inherited.captureProfileDigest,
              input.inheritFromRunId,
              shard.key,
              input.inheritFromRunId,
              shard.key,
              input.inheritFromRunId,
              input.inheritFromRunId,
              shard.key,
              input.id,
              shard.key
            ]
          )
        );
        statements.push(
          this.sql(
            "INSERT INTO ariviso_captures (id, run_id, shard_key, item_key, variant_key, ordinal, image_id, profile_digest, test_id, test_retry, metadata_json) SELECT ? || ':' || id, ?, shard_key, item_key, variant_key, ordinal, image_id, profile_digest, test_id, test_retry, metadata_json FROM ariviso_captures WHERE run_id = ? AND shard_key = ?",
            [input.id, input.id, input.inheritFromRunId, shard.key]
          )
        );
      }
    }
    statements.push(
      this.sql(
        "INSERT INTO work_retention_pins (run_id, owner, reason) SELECT DISTINCT image.run_id, ?, 'comparison' FROM ariviso_captures capture JOIN ariviso_images image ON image.id = capture.image_id WHERE capture.run_id = ? AND image.run_id != ? ON CONFLICT(run_id, owner) DO NOTHING",
        [`inherited-by:${input.id}`, input.id, input.id]
      )
    );
    statements.push(
      this.sql("UPDATE ariviso_projects SET revision = revision + 1 WHERE id = ?", [project.id])
    );
    statements.push(
      this.sql(
        "UPDATE work_checks SET desired_revision = (SELECT revision FROM ariviso_projects WHERE id = ?) WHERE id IN (SELECT id FROM ariviso_checks WHERE project_id = ?)",
        [project.id, project.id]
      )
    );
    await atomic(this.database, statements);
    return this.run(input.id);
  }
  /** Call only after the trusted decoder and R2 write have both succeeded. */
  async registerImage(image) {
    const run = await this.run(image.runId);
    await atomic(this.database, [
      this.activeGuard(run),
      this.guard(
        "EXISTS (SELECT 1 FROM ariviso_runs WHERE id = ? AND sealed_at IS NULL AND state = 'uploading')",
        [run.id]
      ),
      this.guard("EXISTS (SELECT 1 FROM work_retained_runs WHERE id = ? AND byte_state = 'live')", [
        run.id
      ]),
      this.sql(
        "INSERT INTO ariviso_images (id, run_id, digest, object_key, content_type, bytes, width, height) VALUES (?, ?, ?, ?, ?, ?, ?, ?) ON CONFLICT(id) DO NOTHING",
        [
          image.id,
          image.runId,
          image.digest,
          image.objectKey,
          image.contentType,
          image.bytes,
          image.width,
          image.height
        ]
      ),
      this.guard(
        "EXISTS (SELECT 1 FROM ariviso_images WHERE id = ? AND run_id = ? AND digest = ? AND object_key = ? AND bytes = ? AND width = ? AND height = ? AND content_type = ?)",
        [
          image.id,
          image.runId,
          image.digest,
          image.objectKey,
          image.bytes,
          image.width,
          image.height,
          image.contentType
        ]
      )
    ]);
  }
  async commitShard(input) {
    const run = await this.run(input.runId);
    const shard = await this.one("SELECT * FROM ariviso_shards WHERE run_id = ? AND key = ?", [run.id, input.key]);
    if (shard.state === "complete") {
      if (shard.manifest_digest !== input.manifestDigest) {
        throw new ConflictError("The sealed shard has a different manifest.");
      }
      return;
    }
    let expected = JSON.parse(shard.expected_json);
    if (expected.discovery) {
      const proof = input.verifiedDiscovery;
      if (!proof || proof.executorDigest !== expected.discovery.executorDigest || proof.configurationDigest !== expected.discovery.configurationDigest || proof.externalRunId !== run.external_run_id || proof.attempt !== run.attempt || proof.testedSha !== run.tested_sha || !proof.verificationDigest || !proof.inventoryDigest || !proof.jobId) {
        throw new IncompleteError(
          "Candidate discovery needs verified successful-job evidence from the trusted executor and configuration."
        );
      }
      const identities = new Set(
        proof.captures.map((capture) => identity(capture.itemKey, capture.variantKey))
      );
      if (proof.tests.length === 0 || proof.captures.length === 0 || new Set(proof.tests).size !== proof.tests.length || identities.size !== proof.captures.length || proof.captures.some((capture) => !proof.tests.includes(capture.testId))) {
        throw new IncompleteError(
          "The verified candidate inventory is empty, duplicated, or incomplete."
        );
      }
      expected = { ...expected, tests: proof.tests, captures: proof.captures };
    } else if (input.verifiedDiscovery) {
      throw new IncompleteError("This trusted shard does not permit candidate discovery.");
    }
    const outcomes = new Map(input.finalTestOutcomes.map((outcome) => [outcome.testId, outcome]));
    if (outcomes.size !== expected.tests.length || outcomes.size !== input.finalTestOutcomes.length) {
      throw new IncompleteError("The shard must report every required test exactly once.");
    }
    for (const testId of expected.tests) {
      if (outcomes.get(testId)?.status !== "passed") {
        throw new IncompleteError("A required test did not pass its final attempt.");
      }
    }
    const captures = new Map(
      input.captures.map((capture) => [identity(capture.itemKey, capture.variantKey), capture])
    );
    if (captures.size !== expected.captures.length || captures.size !== input.captures.length) {
      throw new IncompleteError("The shard must contain every required capture exactly once.");
    }
    for (const required of expected.captures) {
      const capture = captures.get(identity(required.itemKey, required.variantKey));
      if (!capture || capture.testId !== required.testId || !(expected.environmentProfileDigests ?? [expected.profileDigest]).includes(
        capture.environmentProfileDigest
      ) || capture.testRetry !== outcomes.get(required.testId)?.retry) {
        throw new IncompleteError(
          "A capture does not match the trusted plan or final successful test attempt."
        );
      }
    }
    for (let offset = 0; offset < input.captures.length; offset += 100) {
      const captures2 = JSON.stringify(
        input.captures.slice(offset, offset + 100).map((capture) => ({ ...capture, metadataJson: JSON.stringify(capture.metadata) }))
      );
      await atomic(this.database, [
        this.activeGuard(run),
        this.guard("EXISTS (SELECT 1 FROM ariviso_runs WHERE id = ? AND sealed_at IS NULL)", [
          run.id
        ]),
        this.guard(
          "EXISTS (SELECT 1 FROM work_retained_runs WHERE id = ? AND byte_state = 'live')",
          [run.id]
        ),
        this.guard(
          "NOT EXISTS (SELECT 1 FROM json_each(?) staged WHERE NOT EXISTS (SELECT 1 FROM ariviso_images image WHERE image.id = json_extract(staged.value, '$.imageId') AND image.run_id = ? AND image.bytes_present = 1))",
          [captures2, run.id]
        ),
        this.sql(
          "INSERT INTO ariviso_captures (id, run_id, shard_key, item_key, variant_key, ordinal, image_id, profile_digest, test_id, test_retry, metadata_json) SELECT json_extract(value, '$.id'), ?, ?, json_extract(value, '$.itemKey'), json_extract(value, '$.variantKey'), json_extract(value, '$.ordinal'), json_extract(value, '$.imageId'), json_extract(value, '$.profileDigest'), json_extract(value, '$.testId'), json_extract(value, '$.testRetry'), json_extract(value, '$.metadataJson') FROM json_each(?) WHERE true ON CONFLICT(id) DO NOTHING",
          [run.id, input.key, captures2]
        ),
        this.guard(
          "NOT EXISTS (SELECT 1 FROM json_each(?) staged WHERE NOT EXISTS (SELECT 1 FROM ariviso_captures capture WHERE capture.id = json_extract(staged.value, '$.id') AND capture.run_id = ? AND capture.shard_key = ? AND capture.item_key = json_extract(staged.value, '$.itemKey') AND capture.variant_key = json_extract(staged.value, '$.variantKey') AND capture.ordinal = json_extract(staged.value, '$.ordinal') AND capture.image_id = json_extract(staged.value, '$.imageId') AND capture.profile_digest = json_extract(staged.value, '$.profileDigest') AND capture.test_id = json_extract(staged.value, '$.testId') AND capture.test_retry = json_extract(staged.value, '$.testRetry') AND capture.metadata_json = json_extract(staged.value, '$.metadataJson')))",
          [captures2, run.id, input.key]
        )
      ]);
    }
    const profileDigest = await captureProfilesDigest(input.captures);
    await atomic(this.database, [
      this.activeGuard(run),
      this.guard("(SELECT count(*) FROM ariviso_captures WHERE run_id = ? AND shard_key = ?) = ?", [
        run.id,
        input.key,
        input.captures.length
      ]),
      this.sql(
        "UPDATE ariviso_shards SET state = 'complete', manifest_digest = ?, full_profile_digest = ?, expected_json = ?, discovery_json = ?, source_run_id = ?, source_attempt = ? WHERE run_id = ? AND key = ? AND state = 'pending'",
        [
          input.manifestDigest,
          profileDigest,
          JSON.stringify(expected),
          input.verifiedDiscovery ? JSON.stringify(input.verifiedDiscovery) : null,
          run.id,
          run.attempt,
          run.id,
          input.key
        ]
      ),
      this.guard(
        "EXISTS (SELECT 1 FROM ariviso_shards WHERE run_id = ? AND key = ? AND manifest_digest = ? AND state = 'complete')",
        [run.id, input.key, input.manifestDigest]
      )
    ]);
  }
  async failRun(input) {
    const run = await this.run(input.runId);
    if (run.state === "failed") {
      return this.status(run.id);
    }
    const project = await this.project(run.project_id);
    await atomic(this.database, [
      this.projectGuard(project),
      this.activeGuard(run),
      this.guard(
        "EXISTS (SELECT 1 FROM ariviso_runs WHERE id = ? AND sealed_at IS NULL AND state = 'uploading')",
        [run.id]
      ),
      this.sql("UPDATE ariviso_runs SET state = 'failed' WHERE id = ?", [run.id]),
      this.audit(run, "capture-failed", { reason: input.reason.slice(0, 4096) }, input.now),
      ...this.touch(run, input.now)
    ]);
    return this.status(run.id);
  }
  async sealRun(input) {
    const run = await this.run(input.runId);
    if (run.sealed_at !== null) {
      return run;
    }
    await atomic(this.database, [
      this.activeGuard(run),
      this.guard("EXISTS (SELECT 1 FROM ariviso_runs WHERE id = ? AND state = 'uploading')", [
        run.id
      ]),
      this.guard(
        "NOT EXISTS (SELECT 1 FROM ariviso_shards WHERE run_id = ? AND state != 'complete') AND EXISTS (SELECT 1 FROM ariviso_captures WHERE run_id = ?)",
        [run.id, run.id]
      ),
      this.guard(
        "NOT EXISTS (SELECT 1 FROM ariviso_captures c JOIN ariviso_images i ON i.id = c.image_id WHERE c.run_id = ? AND i.bytes_present != 1)",
        [run.id]
      ),
      this.sql("UPDATE ariviso_runs SET sealed_at = ?, state = 'comparing' WHERE id = ?", [
        input.now,
        run.id
      ]),
      this.audit(run, "seal", {}, input.now),
      ...this.touch(run, input.now)
    ]);
    return this.run(run.id);
  }
  async referenceCandidates(projectId) {
    return this.rows(
      "SELECT snapshot.* FROM ariviso_snapshots snapshot WHERE snapshot.project_id = ? AND snapshot.reference_eligible = 1 AND NOT EXISTS (SELECT 1 FROM ariviso_snapshot_images image WHERE image.snapshot_id = snapshot.id AND image.copied != 1) ORDER BY snapshot.created_at DESC, snapshot.id",
      [projectId]
    );
  }
  async selectReferenceSnapshot(runId) {
    const run = await this.run(runId);
    const project = await this.project(run.project_id);
    if (project.fresh_setup && project.snapshot_id === null) return null;
    const snapshot = await this.sql(
      "SELECT snapshot.* FROM ariviso_snapshots snapshot JOIN ariviso_ancestry ancestry ON ancestry.ancestor_sha = snapshot.tested_sha AND ancestry.run_id = ? WHERE snapshot.project_id = ? AND snapshot.reference_eligible = 1 AND (? != 'main' OR snapshot.id = ?) AND NOT EXISTS (SELECT 1 FROM ariviso_snapshot_images image WHERE image.snapshot_id = snapshot.id AND image.copied != 1) ORDER BY (snapshot.id = ?) DESC, snapshot.created_at DESC, snapshot.id LIMIT 1",
      [run.id, project.id, run.kind, project.snapshot_id, project.snapshot_id]
    ).first();
    if (!snapshot) {
      throw new IncompleteError(
        "No retained accepted ancestor is eligible. Verify ancestry or capture current main."
      );
    }
    return snapshot.id;
  }
  async createComparison(input) {
    const run = await this.run(input.runId);
    const project = await this.project(run.project_id);
    const guards = [
      this.projectGuard(project),
      this.guard("EXISTS (SELECT 1 FROM ariviso_projects WHERE id = ? AND baseline_revision = ?)", [
        project.id,
        input.expectedBaselineRevision ?? project.baseline_revision
      ]),
      this.activeGuard(run),
      this.guard("EXISTS (SELECT 1 FROM ariviso_runs WHERE id = ? AND sealed_at IS NOT NULL)", [
        run.id
      ])
    ];
    if (input.referenceSnapshotId) {
      guards.push(
        this.guard(
          "EXISTS (SELECT 1 FROM ariviso_snapshots s JOIN ariviso_ancestry a ON a.ancestor_sha = s.tested_sha AND a.run_id = ? WHERE s.id = ? AND s.project_id = ? AND s.reference_eligible = 1)",
          [run.id, input.referenceSnapshotId, project.id]
        )
      );
      guards.push(
        this.guard(
          "NOT EXISTS (SELECT 1 FROM ariviso_snapshot_images WHERE snapshot_id = ? AND copied != 1)",
          [input.referenceSnapshotId]
        )
      );
      guards.push(
        this.sql(
          "INSERT INTO ariviso_pins (snapshot_id, reason, owner_id) VALUES (?, 'comparison', ?)",
          [input.referenceSnapshotId, input.id]
        )
      );
      guards.push(
        this.sql(
          "INSERT INTO work_retention_pins (run_id, owner, reason) SELECT run_id, ?, 'comparison' FROM ariviso_snapshots WHERE id = ?",
          [`comparison:${input.id}`, input.referenceSnapshotId]
        )
      );
    } else {
      guards.push(
        this.guard(
          "EXISTS (SELECT 1 FROM ariviso_projects WHERE id = ? AND fresh_setup = 1 AND snapshot_id IS NULL)",
          [project.id]
        )
      );
    }
    if (run.kind === "main") {
      guards.push(
        this.guard("EXISTS (SELECT 1 FROM ariviso_projects WHERE id = ? AND snapshot_id IS ?)", [
          project.id,
          input.referenceSnapshotId
        ])
      );
    }
    const tuple = `json_object('projectId', ?, 'itemKey', c.item_key, 'variantKey', c.variant_key, 'referenceDigest', ri.digest, 'candidateDigest', ci.digest, 'referenceProfileDigest', r.profile_digest, 'candidateProfileDigest', c.profile_digest, 'comparisonPolicyDigest', ?)`;
    const removalTuple = `json_object('projectId', ?, 'itemKey', r.item_key, 'variantKey', r.variant_key, 'referenceDigest', ri.digest, 'candidateDigest', NULL, 'referenceProfileDigest', r.profile_digest, 'candidateProfileDigest', NULL, 'comparisonPolicyDigest', ?)`;
    await atomic(this.database, [
      ...guards,
      this.sql(
        "INSERT INTO ariviso_comparisons (id, run_id, reference_snapshot_id, baseline_revision, policy_digest, ordinal, created_at) SELECT ?, ?, ?, ?, ?, COALESCE(MAX(ordinal), 0) + 1, ? FROM ariviso_comparisons WHERE run_id = ?",
        [
          input.id,
          run.id,
          input.referenceSnapshotId,
          project.baseline_revision,
          project.policy_digest,
          input.now,
          run.id
        ]
      ),
      this.sql(
        `INSERT INTO ariviso_comparison_rows (id, comparison_id, item_key, variant_key, ordinal, reference_capture_id, candidate_capture_id, tuple_json, outcome) SELECT ? || ':' || c.id, ?, c.item_key, c.variant_key, c.ordinal, r.id, c.id, ${tuple}, CASE WHEN r.id IS NULL THEN 'changed' ELSE 'pending' END FROM ariviso_captures c JOIN ariviso_images ci ON ci.id = c.image_id LEFT JOIN (SELECT capture.* FROM ariviso_snapshot_images si JOIN ariviso_captures capture ON capture.id = si.capture_id WHERE si.snapshot_id = ?) r ON r.item_key = c.item_key AND r.variant_key = c.variant_key LEFT JOIN ariviso_images ri ON ri.id = r.image_id WHERE c.run_id = ?`,
        [input.id, input.id, project.id, project.policy_digest, input.referenceSnapshotId, run.id]
      ),
      this.sql(
        `INSERT INTO ariviso_comparison_rows (id, comparison_id, item_key, variant_key, ordinal, reference_capture_id, candidate_capture_id, tuple_json, outcome) SELECT ? || ':removed:' || r.id, ?, r.item_key, r.variant_key, (SELECT COALESCE(MAX(ordinal), 0) + 1 FROM ariviso_captures WHERE run_id = ?) + r.ordinal, r.id, NULL, ${removalTuple}, 'changed' FROM ariviso_snapshot_images si JOIN ariviso_captures r ON r.id = si.capture_id JOIN ariviso_images ri ON ri.id = r.image_id WHERE si.snapshot_id = ? AND NOT EXISTS (SELECT 1 FROM ariviso_captures c WHERE c.run_id = ? AND c.item_key = r.item_key AND c.variant_key = r.variant_key)`,
        [
          input.id,
          input.id,
          run.id,
          project.id,
          project.policy_digest,
          input.referenceSnapshotId,
          run.id
        ]
      ),
      this.sql(
        "INSERT INTO work_tasks (id, kind, payload, max_attempts, available_at, created_at, updated_at) SELECT id, 'compare', json_object('taskId', id), ?, ?, ?, ? FROM ariviso_comparison_rows WHERE comparison_id = ? AND outcome = 'pending'",
        [input.maxAttempts, input.now, input.now, input.now, input.id]
      ),
      this.sql("UPDATE ariviso_runs SET comparison_id = ?, state = 'comparing' WHERE id = ?", [
        input.id,
        run.id
      ]),
      this.audit(
        run,
        "compare",
        { comparisonId: input.id, referenceSnapshotId: input.referenceSnapshotId },
        input.now
      ),
      ...this.touch(run, input.now)
    ]);
    return this.comparison(input.id);
  }
  async getComparisonTask(taskId) {
    const row = await this.one("SELECT * FROM ariviso_comparison_rows WHERE id = ?", [
      taskId
    ]);
    const comparison = await this.comparison(row.comparison_id);
    const readImage = /* @__PURE__ */ __name(async (captureId, reference) => {
      if (!captureId) return null;
      const image = reference ? await this.one(
        "SELECT i.id, si.object_key, i.digest, i.width, i.height, i.bytes, i.content_type FROM ariviso_snapshot_images si JOIN ariviso_images i ON i.id = si.image_id WHERE si.snapshot_id = ? AND si.capture_id = ? AND si.copied = 1",
        [comparison.reference_snapshot_id, captureId]
      ) : await this.one(
        "SELECT i.* FROM ariviso_images i JOIN ariviso_captures c ON c.image_id = i.id WHERE c.id = ? AND i.bytes_present = 1",
        [captureId]
      );
      return {
        imageId: image.id,
        objectKey: image.object_key,
        digest: image.digest,
        width: image.width,
        height: image.height,
        bytes: image.bytes,
        contentType: image.content_type
      };
    }, "readImage");
    const policyRecord = await this.one(
      "SELECT policy_json FROM ariviso_policies WHERE digest = ?",
      [comparison.policy_digest]
    );
    const policy = JSON.parse(policyRecord.policy_json);
    return {
      id: row.id,
      comparisonId: comparison.id,
      runId: comparison.run_id,
      policyDigest: comparison.policy_digest,
      policy,
      reference: await readImage(row.reference_capture_id, true),
      candidate: await readImage(row.candidate_capture_id, false)
    };
  }
  async getComparisonTaskState(taskId) {
    const state = await this.one(
      "SELECT run.active, run.comparison_id, row.comparison_id AS row_comparison_id FROM ariviso_comparison_rows row JOIN ariviso_comparisons comparison ON comparison.id = row.comparison_id JOIN ariviso_runs run ON run.id = comparison.run_id WHERE row.id = ?",
      [taskId]
    );
    if (!state.active || state.comparison_id !== state.row_comparison_id) {
      return { state: "superseded" };
    }
    const task = await getWork(this.database, taskId);
    if (!task) {
      throw new IncompleteError("The comparison task has not been scheduled.");
    }
    return task;
  }
  async claimComparisonTask(input) {
    const claimed = await claimWork(this.database, {
      id: input.taskId,
      token: input.owner,
      now: input.now,
      leaseMs: input.leaseMilliseconds
    });
    if (!claimed) return null;
    return this.getComparisonTask(input.taskId);
  }
  async failComparisonTask(input) {
    return failWork(this.database, {
      id: input.taskId,
      token: input.owner,
      now: input.now,
      retryAt: input.retryAt,
      error: input.error
    });
  }
  async commitComparisonResult(input) {
    const row = await this.one("SELECT * FROM ariviso_comparison_rows WHERE id = ?", [
      input.taskId
    ]);
    const tuple = JSON.parse(row.tuple_json);
    const result = tuple.referenceProfileDigest !== tuple.candidateProfileDigest ? { ...input.result, outcome: "changed" } : input.result;
    const comparison = await this.comparison(row.comparison_id);
    const run = await this.run(comparison.run_id);
    if (row.result_json) {
      if (row.result_json !== JSON.stringify(result)) {
        throw new ConflictError("A comparison result is immutable.");
      }
      return;
    }
    if (!Number.isFinite(input.result.ratio) || input.result.ratio < 0 || input.result.ratio > 1 || !Number.isSafeInteger(input.result.changedPixels) || input.result.changedPixels < 0) {
      throw new IncompleteError("The comparison result is invalid.");
    }
    const artifactStatements = [];
    for (const artifact of input.artifacts ?? []) {
      if (artifact.runId !== run.id) {
        throw new IncompleteError("Derived images belong to the comparison run.");
      }
      artifactStatements.push(
        this.sql(
          "INSERT INTO ariviso_images (id, run_id, digest, object_key, content_type, bytes, width, height, role) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?) ON CONFLICT(id) DO NOTHING",
          [
            artifact.id,
            artifact.runId,
            artifact.digest,
            artifact.objectKey,
            artifact.contentType,
            artifact.bytes,
            artifact.width,
            artifact.height,
            artifact.role
          ]
        )
      );
      artifactStatements.push(
        this.guard(
          "EXISTS (SELECT 1 FROM ariviso_images WHERE id = ? AND run_id = ? AND digest = ? AND object_key = ? AND content_type = ? AND bytes = ? AND width = ? AND height = ? AND role = ? AND bytes_present = 1)",
          [
            artifact.id,
            artifact.runId,
            artifact.digest,
            artifact.objectKey,
            artifact.contentType,
            artifact.bytes,
            artifact.width,
            artifact.height,
            artifact.role
          ]
        )
      );
    }
    if (input.result.maskImageId) {
      artifactStatements.push(
        this.guard(
          "EXISTS (SELECT 1 FROM ariviso_images WHERE id = ? AND run_id = ? AND role = 'mask' AND bytes_present = 1)",
          [input.result.maskImageId, run.id]
        )
      );
    }
    if (input.result.thumbnailImageId) {
      artifactStatements.push(
        this.guard(
          "EXISTS (SELECT 1 FROM ariviso_images WHERE id = ? AND run_id = ? AND role = 'thumbnail' AND bytes_present = 1)",
          [input.result.thumbnailImageId, run.id]
        )
      );
    }
    await atomic(this.database, [
      workLeaseAssertion(this.database, {
        id: input.taskId,
        token: input.leaseOwner,
        now: input.now
      }),
      this.activeGuard(run),
      this.guard("EXISTS (SELECT 1 FROM ariviso_runs WHERE id = ? AND comparison_id = ?)", [
        run.id,
        comparison.id
      ]),
      this.guard(
        "EXISTS (SELECT 1 FROM ariviso_comparisons WHERE id = ? AND state = 'comparing')",
        [comparison.id]
      ),
      this.guard(
        "EXISTS (SELECT 1 FROM ariviso_comparison_rows WHERE id = ? AND result_json IS NULL)",
        [row.id]
      ),
      ...artifactStatements,
      this.sql("UPDATE ariviso_comparison_rows SET outcome = ?, result_json = ? WHERE id = ?", [
        result.outcome,
        JSON.stringify(result),
        row.id
      ]),
      completeWorkStatement(this.database, {
        id: input.taskId,
        token: input.leaseOwner,
        now: input.now,
        result: JSON.stringify(result)
      })
    ]);
  }
  acceptanceValiditySql() {
    return `decision.verdict = 'approved' AND decision.revoked = 0
      AND decision.tuple_json = row.tuple_json
      AND EXISTS (SELECT 1 FROM ariviso_comparison_rows source_row
        JOIN ariviso_comparisons source_comparison ON source_comparison.id = source_row.comparison_id
        JOIN ariviso_runs source_run ON source_run.id = source_comparison.run_id
        JOIN ariviso_comparisons target_comparison ON target_comparison.id = row.comparison_id
        JOIN ariviso_runs target_run ON target_run.id = target_comparison.run_id
        WHERE source_row.id = decision.row_id AND source_row.decision_id = decision.id
        AND source_run.project_id = target_run.project_id
        AND (source_run.id = target_run.id OR EXISTS (SELECT 1 FROM ariviso_lineage lineage
          WHERE lineage.source_run_id = source_run.id AND lineage.target_run_id = target_run.id))
        AND NOT EXISTS (SELECT 1 FROM ariviso_decision_replacements replacement
          JOIN ariviso_decisions successor ON successor.id = replacement.replacement_decision_id
          WHERE replacement.source_decision_id = decision.id AND successor.revoked = 0
          AND (replacement.scope = 'shared' OR replacement.scope_run_id = target_run.id
            OR EXISTS (SELECT 1 FROM ariviso_lineage lineage
              WHERE lineage.source_run_id = replacement.scope_run_id AND lineage.target_run_id = target_run.id))))`;
  }
  eligibleAcceptanceSql() {
    return `EXISTS (SELECT 1 FROM ariviso_decisions decision
      WHERE decision.id = COALESCE(row.source_decision_id, row.decision_id)
      AND ${this.acceptanceValiditySql()})`;
  }
  async eligibleApprovalRowIds(comparisonId) {
    const rows = await this.rows(
      `SELECT row.id FROM ariviso_comparison_rows row WHERE row.comparison_id = ? AND row.outcome = 'changed' AND ${this.eligibleAcceptanceSql()} ORDER BY row.ordinal, row.id`,
      [comparisonId]
    );
    return rows.map((row) => row.id);
  }
  readyGuard(comparisonId) {
    return this.guard(
      `NOT EXISTS (SELECT 1 FROM ariviso_comparison_rows row WHERE row.comparison_id = ? AND (row.outcome NOT IN ('unchanged', 'changed') OR (row.outcome = 'changed' AND NOT ${this.eligibleAcceptanceSql()})))`,
      [comparisonId]
    );
  }
  currentBaselineGuard(projectId) {
    return this.guard(
      `NOT EXISTS (SELECT 1 FROM ariviso_projects project
        JOIN ariviso_snapshots snapshot ON snapshot.id = project.snapshot_id
        JOIN ariviso_comparison_rows row ON row.comparison_id = snapshot.comparison_id
        WHERE project.id = ? AND row.outcome = 'changed'
        AND NOT ${this.eligibleAcceptanceSql()})`,
      [projectId]
    );
  }
  async finalizeComparison(input) {
    const comparison = await this.comparison(input.comparisonId);
    const run = await this.run(comparison.run_id);
    const project = await this.project(run.project_id);
    if (comparison.state === "ready") {
      return this.status(run.id);
    }
    const pending = await this.sql(
      "SELECT 1 AS found FROM ariviso_comparison_rows WHERE comparison_id = ? AND outcome IN ('pending', 'error') LIMIT 1",
      [comparison.id]
    ).first();
    if (pending) {
      throw new IncompleteError("Required comparisons have not completed.");
    }
    const reuse = `SELECT decision.id FROM ariviso_decisions decision WHERE ${this.acceptanceValiditySql()} ORDER BY decision.created_at, decision.id LIMIT 1`;
    const automaticKind = `CASE WHEN row.reference_capture_id IS NULL THEN 'introduction' ELSE 'removal' END`;
    const eligibleAutomatic = `row.comparison_id = ? AND row.outcome = 'changed' AND row.source_decision_id IS NULL AND row.decision_id IS NULL AND (row.reference_capture_id IS NULL OR row.candidate_capture_id IS NULL) AND NOT EXISTS (SELECT 1 FROM ariviso_reservations reservation JOIN ariviso_decisions decision ON decision.id = reservation.decision_id JOIN ariviso_comparison_rows reserved_row ON reserved_row.id = decision.row_id JOIN ariviso_comparisons reserved_comparison ON reserved_comparison.id = reserved_row.comparison_id WHERE reservation.project_id = ? AND reservation.item_key = row.item_key AND reservation.variant_key = row.variant_key AND reservation.kind = ${automaticKind} AND (reservation.lineage_key = ? OR EXISTS (SELECT 1 FROM ariviso_lineage l WHERE l.source_run_id = reserved_comparison.run_id AND l.target_run_id = ?))) AND (row.reference_capture_id IS NOT NULL OR NOT EXISTS (SELECT 1 FROM ariviso_identity_history h WHERE h.project_id = ? AND h.item_key = row.item_key AND h.variant_key = row.variant_key AND (h.lineage_key = ? OR h.lineage_key = 'main')))`;
    const statements = [
      this.projectGuard(project),
      this.activeGuard(run),
      this.guard("EXISTS (SELECT 1 FROM ariviso_runs WHERE id = ? AND comparison_id = ?)", [
        run.id,
        comparison.id
      ]),
      this.guard(
        "EXISTS (SELECT 1 FROM ariviso_comparisons WHERE id = ? AND state = 'comparing')",
        [comparison.id]
      ),
      this.guard(
        "NOT EXISTS (SELECT 1 FROM ariviso_comparison_rows WHERE comparison_id = ? AND outcome IN ('pending', 'error'))",
        [comparison.id]
      ),
      this.sql(
        `UPDATE ariviso_comparison_rows AS row SET source_decision_id = (${reuse}) WHERE row.comparison_id = ? AND row.outcome = 'changed'`,
        [comparison.id]
      ),
      this.sql(
        `INSERT INTO ariviso_decisions (id, row_id, revision, verdict, kind, tuple_json, created_at) SELECT 'automatic:' || row.id, row.id, 1, 'approved', 'automatic', row.tuple_json, ? FROM ariviso_comparison_rows row WHERE ${eligibleAutomatic}`,
        [
          input.now,
          comparison.id,
          project.id,
          run.lineage_key,
          run.id,
          project.id,
          run.lineage_key
        ]
      ),
      this.sql(
        "UPDATE ariviso_comparison_rows SET decision_id = 'automatic:' || id, decision_revision = 1 WHERE comparison_id = ? AND EXISTS (SELECT 1 FROM ariviso_decisions WHERE id = 'automatic:' || ariviso_comparison_rows.id)",
        [comparison.id]
      ),
      this.sql(
        `INSERT INTO ariviso_reservations (project_id, lineage_key, item_key, variant_key, kind, decision_id) SELECT ?, ?, row.item_key, row.variant_key, ${automaticKind}, row.decision_id FROM ariviso_comparison_rows row WHERE row.comparison_id = ? AND row.decision_id IS NOT NULL`,
        [project.id, run.lineage_key, comparison.id]
      )
    ];
    statements.push(
      this.sql(
        "INSERT OR IGNORE INTO ariviso_identity_history (project_id, lineage_key, item_key, variant_key) SELECT ?, ?, item_key, variant_key FROM ariviso_captures WHERE run_id = ?",
        [project.id, run.lineage_key, run.id]
      )
    );
    statements.push(
      this.sql("UPDATE ariviso_comparisons SET state = 'ready' WHERE id = ?", [comparison.id])
    );
    statements.push(this.sql("UPDATE ariviso_runs SET state = 'reviewing' WHERE id = ?", [run.id]));
    statements.push(
      this.audit(run, "comparison-ready", { comparisonId: comparison.id }, input.now)
    );
    statements.push(...this.touch(run, input.now));
    await atomic(this.database, statements);
    return this.status(run.id);
  }
  async reconcileComparisons(input) {
    const candidates = await this.rows(
      "SELECT c.id FROM ariviso_comparisons c JOIN ariviso_runs r ON r.comparison_id = c.id WHERE r.active = 1 AND c.state = 'comparing' AND NOT EXISTS (SELECT 1 FROM ariviso_comparison_rows row WHERE row.comparison_id = c.id AND row.outcome IN ('pending', 'error')) ORDER BY c.created_at, c.id LIMIT ?",
      [input.limit]
    );
    const completed = [];
    const errors = [];
    for (const candidate of candidates) {
      try {
        await this.finalizeComparison({ comparisonId: candidate.id, now: input.now });
        completed.push(candidate.id);
      } catch (error) {
        errors.push({
          comparisonId: candidate.id,
          message: error instanceof Error ? error.message : "Comparison reconciliation failed"
        });
      }
    }
    return { completed, errors };
  }
  async status(runId) {
    const run = await this.run(runId);
    if (!run.active) {
      return { run, status: "superseded", pending: 0, rejected: 0 };
    }
    if (run.state === "failed") {
      const failures2 = await this.rows(
        "SELECT id, json_extract(detail_json, '$.reason') AS last_error FROM ariviso_audit WHERE run_id = ? AND action = 'capture-failed' ORDER BY created_at DESC, id LIMIT 1",
        [run.id]
      );
      return { run, status: "failed", pending: 0, rejected: 0, failures: failures2 };
    }
    if (!run.comparison_id || run.sealed_at === null) {
      return { run, status: "incomplete", pending: 0, rejected: 0 };
    }
    const comparison = await this.comparison(run.comparison_id);
    if (comparison.state === "invalidated") {
      return { run, comparison, status: "needs-recompare", pending: 0, rejected: 0 };
    }
    const failures = await this.rows(
      "SELECT task.id, task.last_error FROM work_tasks task JOIN ariviso_comparison_rows row ON row.id = task.id WHERE row.comparison_id = ? AND task.state = 'dead' ORDER BY task.id LIMIT 20",
      [comparison.id]
    );
    if (failures.length > 0) {
      return { run, comparison, status: "failed", pending: 0, rejected: 0, failures };
    }
    if (comparison.state !== "ready") {
      return { run, comparison, status: "comparing", pending: 0, rejected: 0 };
    }
    const counts = await this.one(
      `SELECT COALESCE(SUM(CASE WHEN row.outcome NOT IN ('changed', 'unchanged') OR (row.outcome = 'changed' AND NOT ${this.eligibleAcceptanceSql()}) THEN 1 ELSE 0 END), 0) AS pending, COALESCE(SUM(CASE WHEN decision.verdict = 'rejected' AND decision.revoked = 0 THEN 1 ELSE 0 END), 0) AS rejected FROM ariviso_comparison_rows row LEFT JOIN ariviso_decisions decision ON decision.id = row.decision_id WHERE row.comparison_id = ?`,
      [comparison.id]
    );
    const project = await this.project(run.project_id);
    const currentPromotion = project.promotion_id ? await this.sql(
      "SELECT 1 AS found FROM ariviso_promotions WHERE id = ? AND comparison_id = ? AND revoked = 0",
      [project.promotion_id, comparison.id]
    ).first() : null;
    if (counts.pending === 0 && !currentPromotion && comparison.baseline_revision !== project.baseline_revision) {
      return { run, comparison, status: "needs-recompare", ...counts };
    }
    return {
      run,
      comparison,
      status: counts.pending === 0 ? "passed" : counts.rejected > 0 ? "rejected" : "needs-review",
      ...counts
    };
  }
  async prepareStatusIntent(input) {
    const run = await this.run(input.runId);
    const project = await this.project(run.project_id);
    const status = await this.status(run.id);
    if (status.status === "superseded") {
      throw new ConflictError("A superseded attempt cannot publish a check.");
    }
    const conclusion = status.status === "passed" ? "success" : status.status === "needs-review" || status.status === "rejected" || status.status === "failed" ? "failure" : "pending";
    const comparison = run.comparison_id ? await this.comparison(run.comparison_id) : null;
    await atomic(this.database, [
      this.projectGuard(project),
      this.activeGuard(run),
      this.sql(
        "INSERT INTO ariviso_checks (id, project_id, external_run_id) VALUES (?, ?, ?) ON CONFLICT(id) DO NOTHING",
        [input.checkId, project.id, run.external_run_id]
      ),
      this.guard(
        "EXISTS (SELECT 1 FROM ariviso_checks WHERE id = ? AND project_id = ? AND external_run_id = ?)",
        [input.checkId, project.id, run.external_run_id]
      ),
      ...statusIntentStatements(this.database, {
        checkId: input.checkId,
        revision: project.revision,
        runId: run.id,
        attempt: run.attempt,
        comparisonRevision: comparison?.ordinal ?? 0,
        sourceRevision: project.revision,
        conclusion,
        detailsUrl: input.detailsUrl,
        maxAttempts: input.maxAttempts,
        now: input.now
      }),
      this.sql(
        "UPDATE ariviso_status_outbox SET delivered_at = ? WHERE run_id = ? AND run_revision <= ?",
        [input.now, run.id, run.revision]
      )
    ]);
    return { revision: project.revision, conclusion };
  }
  /** Use alongside the delivery lease check immediately before sending to GitHub. */
  async isStatusIntentCurrent(intent) {
    const current = await this.sql(
      "SELECT 1 AS found FROM ariviso_runs run JOIN ariviso_projects project ON project.id = run.project_id LEFT JOIN ariviso_comparisons comparison ON comparison.id = run.comparison_id WHERE run.id = ? AND run.active = 1 AND run.attempt = ? AND project.revision = ? AND COALESCE(comparison.ordinal, 0) = ?",
      [intent.run_id, intent.attempt, intent.source_revision, intent.comparison_revision]
    ).first();
    return current !== null;
  }
  /** Retire only work that no longer owns the current promotion. */
  async retireRun(input) {
    const run = await this.run(input.runId);
    const project = await this.project(run.project_id);
    await atomic(this.database, [
      this.projectGuard(project),
      this.guard(
        "NOT EXISTS (SELECT 1 FROM ariviso_projects project JOIN ariviso_snapshots snapshot ON snapshot.id = project.snapshot_id WHERE snapshot.run_id = ?)",
        [run.id]
      ),
      this.sql(
        "UPDATE ariviso_runs SET active = 0, state = 'superseded', closed_at = ? WHERE id = ?",
        [input.now, run.id]
      ),
      this.sql("UPDATE work_retained_runs SET closed_at = ? WHERE id = ?", [input.now, run.id]),
      this.sql(
        "DELETE FROM work_retention_pins WHERE owner IN (?, ?) OR owner IN (SELECT 'comparison:' || id FROM ariviso_comparisons WHERE run_id = ?)",
        [`review:${run.id}`, `inherited-by:${run.id}`, run.id]
      ),
      ...this.touch(run, input.now),
      this.audit(run, "retire", {}, input.now)
    ]);
  }
  async commandReplay(commandId, request) {
    const command = await this.sql("SELECT * FROM ariviso_commands WHERE id = ?", [
      commandId
    ]).first();
    if (!command) return null;
    if (command.request_json !== request) {
      throw new ConflictError("The command ID already belongs to another request.");
    }
    return parseCommandResult(command.result_json);
  }
  invalidateDependents(project, now) {
    return [
      this.sql(
        "UPDATE ariviso_runs SET revision = revision + 1 WHERE project_id = ? AND active = 1",
        [project.id]
      ),
      this.sql(
        "INSERT INTO ariviso_status_outbox (id, run_id, run_revision, created_at) SELECT ? || ':' || id, id, revision, ? FROM ariviso_runs WHERE project_id = ? AND active = 1",
        [crypto.randomUUID(), now, project.id]
      )
    ];
  }
  rollbackStatements(project, promotion, now) {
    return [
      this.guard(
        "EXISTS (SELECT 1 FROM ariviso_projects WHERE id = ? AND promotion_id = ? AND baseline_revision = ? AND snapshot_id = ?)",
        [project.id, promotion.id, project.baseline_revision, promotion.snapshot_id]
      ),
      this.guard(
        "NOT EXISTS (SELECT 1 FROM ariviso_snapshot_images WHERE snapshot_id IN (?, ?) AND copied != 1)",
        [promotion.snapshot_id, promotion.previous_snapshot_id]
      ),
      this.sql(
        "UPDATE ariviso_projects SET snapshot_id = ?, promotion_id = NULL, baseline_revision = baseline_revision + 1, fresh_setup = CASE WHEN ? IS NULL THEN 1 ELSE 0 END WHERE id = ?",
        [promotion.previous_snapshot_id, promotion.previous_snapshot_id, project.id]
      ),
      this.sql(
        "UPDATE ariviso_snapshots SET reference_eligible = 0, state = 'revoked' WHERE id = ?",
        [promotion.snapshot_id]
      ),
      this.sql("UPDATE ariviso_promotions SET revoked = 1 WHERE id = ?", [promotion.id]),
      this.sql(
        "UPDATE ariviso_comparisons SET state = 'invalidated' WHERE reference_snapshot_id = ? AND id != ?",
        [promotion.snapshot_id, promotion.comparison_id]
      ),
      this.sql("UPDATE ariviso_runs SET state = 'reviewing' WHERE comparison_id = ?", [
        promotion.comparison_id
      ]),
      this.sql(
        "INSERT INTO ariviso_status_outbox (id, run_id, run_revision, created_at) SELECT ? || ':' || id, id, revision, ? FROM ariviso_runs WHERE project_id = ? AND active = 1",
        [crypto.randomUUID(), now, project.id]
      )
    ];
  }
  async review(input) {
    const request = requestJson({ ...input });
    const replay = await this.commandReplay(input.commandId, request);
    if (replay) {
      return replay;
    }
    if (!input.actorId || !input.sessionId || input.targets.length === 0 || new Set(input.targets.map((target) => target.id)).size !== input.targets.length) {
      throw new IncompleteError(
        "A review command requires a maintainer, session, and unique targets."
      );
    }
    const comparison = await this.comparison(input.comparisonId);
    const run = await this.run(comparison.run_id);
    const project = await this.project(run.project_id);
    const rows = await this.comparisonRows(comparison.id);
    const selected = input.targets.map((target) => {
      const row = rows.find((entry) => entry.id === target.id);
      if (!row || row.outcome !== "changed" || row.decision_revision !== target.expectedRevision) {
        throw new ConflictError("A target changed or belongs to another comparison.", row);
      }
      return row;
    });
    if (input.wholeItemKey) {
      const itemRows = rows.filter(
        (row) => row.item_key === input.wholeItemKey && row.outcome === "changed"
      );
      if (itemRows.length !== selected.length || selected.some((row) => row.item_key !== input.wholeItemKey)) {
        throw new ConflictError("The whole-item target list must include every changed variant.");
      }
    }
    const acceptedHistory = await this.sql(
      "SELECT * FROM ariviso_promotions WHERE comparison_id = ? ORDER BY created_at DESC LIMIT 1",
      [comparison.id]
    ).first();
    if (acceptedHistory && !acceptedHistory.revoked && input.verdict === "approved") {
      return {
        commandId: input.commandId,
        revisions: input.targets,
        selection: input.selection,
        baselineRevision: project.baseline_revision,
        promotionId: project.promotion_id,
        noop: true
      };
    }
    let rollback = null;
    if (acceptedHistory && !acceptedHistory.revoked) {
      if (project.promotion_id !== acceptedHistory.id || input.expectedPromotionId !== acceptedHistory.id || input.expectedBaselineRevision !== project.baseline_revision) {
        throw new ConflictError(
          "This promotion is no longer current. Use explicit recovery.",
          project
        );
      }
      rollback = acceptedHistory;
    }
    if (comparison.state !== "ready" || !run.active || run.comparison_id !== comparison.id) {
      throw new ConflictError("Only the active complete comparison can be reviewed.", run);
    }
    const statements = [this.projectGuard(project), this.reviewGuard(run, comparison.id)];
    const previous = { decisions: [], rollback };
    const result = {
      commandId: input.commandId,
      revisions: [],
      selection: input.selection,
      baselineRevision: project.baseline_revision + (rollback ? 1 : 0),
      promotionId: rollback ? null : project.promotion_id
    };
    for (const row of selected) {
      const effectiveId = row.source_decision_id ?? row.decision_id;
      const effective = effectiveId ? await this.one("SELECT * FROM ariviso_decisions WHERE id = ?", [effectiveId]) : null;
      if (rollback && effective?.kind === "automatic") {
        throw new ConflictError(
          "Automatically accepted promoted history is protected. Capture a correction in a new main run.",
          row
        );
      }
      statements.push(
        this.guard(
          "EXISTS (SELECT 1 FROM ariviso_comparison_rows WHERE id = ? AND comparison_id = ? AND decision_revision = ?)",
          [row.id, comparison.id, row.decision_revision]
        )
      );
      previous.decisions.push({
        id: row.id,
        decisionId: row.decision_id,
        sourceDecisionId: row.source_decision_id,
        revision: row.decision_revision
      });
      const decisionId = crypto.randomUUID();
      statements.push(
        this.sql("UPDATE ariviso_decisions SET revoked = 1 WHERE id = ?", [row.decision_id])
      );
      statements.push(
        this.sql(
          "INSERT INTO ariviso_decisions (id, row_id, revision, verdict, kind, actor_id, command_id, tuple_json, created_at) VALUES (?, ?, ?, ?, 'human', ?, ?, ?, ?)",
          [
            decisionId,
            row.id,
            row.decision_revision + 1,
            input.verdict,
            input.actorId,
            input.commandId,
            row.tuple_json,
            input.now
          ]
        )
      );
      if (row.source_decision_id) {
        statements.push(
          this.sql(
            "INSERT INTO ariviso_decision_replacements (source_decision_id, replacement_decision_id, scope, scope_run_id) VALUES (?, ?, ?, ?)",
            [
              row.source_decision_id,
              decisionId,
              rollback || input.verdict === "approved" ? "descendants" : "shared",
              run.id
            ]
          )
        );
      }
      statements.push(
        this.sql(
          "INSERT INTO ariviso_decision_replacements (source_decision_id, replacement_decision_id, scope, scope_run_id) SELECT source_decision_id, ?, scope, scope_run_id FROM ariviso_decision_replacements WHERE replacement_decision_id = ?",
          [decisionId, effectiveId]
        )
      );
      statements.push(
        this.sql(
          "UPDATE ariviso_comparison_rows SET decision_revision = decision_revision + 1, decision_id = ?, source_decision_id = NULL WHERE id = ?",
          [decisionId, row.id]
        )
      );
      result.revisions.push({ id: row.id, expectedRevision: row.decision_revision + 1 });
    }
    if (rollback) {
      statements.push(...this.rollbackStatements(project, rollback, input.now));
    }
    statements.push(
      this.sql(
        "INSERT INTO ariviso_commands (id, request_json, actor_id, session_id, kind, comparison_id, previous_json, result_json, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
        [
          input.commandId,
          request,
          input.actorId,
          input.sessionId,
          input.verdict === "approved" ? "approve" : "reject",
          comparison.id,
          JSON.stringify(previous),
          JSON.stringify(result),
          input.now
        ]
      )
    );
    statements.push(
      this.audit(
        run,
        input.verdict === "approved" ? "approve" : "reject",
        { commandId: input.commandId, targets: input.targets },
        input.now,
        input.actorId
      )
    );
    statements.push(
      this.currentBaselineGuard(project.id),
      ...this.invalidateDependents(project, input.now),
      ...this.touch(run, input.now)
    );
    try {
      await atomic(this.database, statements);
    } catch (error) {
      const replay2 = await this.commandReplay(result.commandId, request);
      if (replay2) {
        return replay2;
      }
      throw error;
    }
    return result;
  }
  async undo(input) {
    const request = requestJson({ ...input });
    const replay = await this.commandReplay(input.undoCommandId, request);
    if (replay) {
      return replay;
    }
    const command = await this.one("SELECT * FROM ariviso_commands WHERE id = ?", [
      input.commandId
    ]);
    if (command.actor_id !== input.actorId || command.session_id !== input.sessionId || command.undone_by || command.kind === "undo") {
      throw new ConflictError("Only your saved command in this review session can be undone.");
    }
    const saved = parseCommandResult(command.result_json);
    const previous = JSON.parse(command.previous_json);
    const comparison = await this.comparison(command.comparison_id);
    const run = await this.run(comparison.run_id);
    const project = await this.project(run.project_id);
    if (project.baseline_revision !== input.expectedBaselineRevision) {
      throw new ConflictError("The baseline changed after this command.", project);
    }
    if (!run.active || run.comparison_id !== comparison.id || comparison.state !== "ready") {
      throw new ConflictError("The command no longer targets the active comparison.");
    }
    const promotion = project.promotion_id ? await this.one("SELECT * FROM ariviso_promotions WHERE id = ?", [
      project.promotion_id
    ]) : null;
    const historical = await this.sql(
      "SELECT 1 AS found FROM ariviso_promotions WHERE comparison_id = ? LIMIT 1",
      [comparison.id]
    ).first();
    if (historical && !previous.rollback && promotion?.comparison_id !== comparison.id) {
      throw new ConflictError("A later promotion prevents Undo. Use explicit recovery.");
    }
    const rollingBack = command.kind === "approve" && promotion?.comparison_id === comparison.id ? promotion : null;
    const restoring = previous.rollback;
    if (restoring && (project.baseline_revision !== saved.baselineRevision || project.snapshot_id !== restoring.previous_snapshot_id || project.promotion_id !== null)) {
      throw new ConflictError("The rejection rollback has changed. Its Undo is stale.");
    }
    const statements = [
      this.projectGuard(project),
      this.reviewGuard(run, comparison.id),
      this.guard("EXISTS (SELECT 1 FROM ariviso_commands WHERE id = ? AND undone_by IS NULL)", [
        command.id
      ])
    ];
    const result = {
      commandId: input.undoCommandId,
      revisions: [],
      selection: saved.selection,
      baselineRevision: project.baseline_revision + (rollingBack || restoring ? 1 : 0),
      promotionId: restoring ? crypto.randomUUID() : rollingBack ? null : project.promotion_id
    };
    for (const target of saved.revisions) {
      const prior = previous.decisions.find((entry) => entry.id === target.id);
      if (!prior) {
        throw new IncompleteError("The saved command does not contain its prior verdict.");
      }
      statements.push(
        this.guard(
          "EXISTS (SELECT 1 FROM ariviso_comparison_rows WHERE id = ? AND decision_revision = ?)",
          [target.id, target.expectedRevision]
        )
      );
      statements.push(
        this.sql(
          "UPDATE ariviso_decisions SET revoked = 1 WHERE id = (SELECT decision_id FROM ariviso_comparison_rows WHERE id = ?)",
          [target.id]
        )
      );
      statements.push(
        this.sql("UPDATE ariviso_decisions SET revoked = 0 WHERE id = ?", [prior.decisionId])
      );
      statements.push(
        this.sql(
          "UPDATE ariviso_comparison_rows SET decision_revision = decision_revision + 1, decision_id = ?, source_decision_id = ? WHERE id = ?",
          [prior.decisionId, prior.sourceDecisionId, target.id]
        )
      );
      result.revisions.push({ id: target.id, expectedRevision: target.expectedRevision + 1 });
    }
    if (rollingBack) {
      statements.push(...this.rollbackStatements(project, rollingBack, input.now));
    }
    if (restoring) {
      statements.push(this.readyGuard(comparison.id));
      statements.push(
        this.guard(
          "NOT EXISTS (SELECT 1 FROM ariviso_snapshot_images WHERE snapshot_id IN (?, ?) AND copied != 1)",
          [restoring.snapshot_id, restoring.previous_snapshot_id]
        )
      );
      statements.push(
        this.sql(
          "UPDATE ariviso_snapshots SET reference_eligible = 1, state = 'accepted' WHERE id = ?",
          [restoring.snapshot_id]
        )
      );
      statements.push(
        this.sql(
          "INSERT INTO ariviso_promotions (id, project_id, snapshot_id, previous_snapshot_id, comparison_id, baseline_revision, command_id, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
          [
            result.promotionId,
            project.id,
            restoring.snapshot_id,
            restoring.previous_snapshot_id,
            comparison.id,
            result.baselineRevision,
            input.undoCommandId,
            input.now
          ]
        )
      );
      statements.push(
        this.sql(
          "UPDATE ariviso_projects SET snapshot_id = ?, promotion_id = ?, baseline_revision = baseline_revision + 1, fresh_setup = 0 WHERE id = ?",
          [restoring.snapshot_id, result.promotionId, project.id]
        )
      );
      statements.push(
        this.sql("UPDATE ariviso_runs SET state = 'accepted' WHERE id = ?", [run.id])
      );
    }
    statements.push(
      this.sql("UPDATE ariviso_commands SET undone_by = ? WHERE id = ?", [
        input.undoCommandId,
        command.id
      ])
    );
    statements.push(
      this.sql(
        "INSERT INTO ariviso_commands (id, request_json, actor_id, session_id, kind, comparison_id, previous_json, result_json, created_at) VALUES (?, ?, ?, ?, 'undo', ?, ?, ?, ?)",
        [
          input.undoCommandId,
          request,
          input.actorId,
          input.sessionId,
          comparison.id,
          JSON.stringify({ decisions: [], rollback: null }),
          JSON.stringify(result),
          input.now
        ]
      )
    );
    statements.push(
      this.audit(
        run,
        "undo",
        { commandId: command.id, undoCommandId: input.undoCommandId },
        input.now,
        input.actorId
      )
    );
    statements.push(
      this.currentBaselineGuard(project.id),
      ...this.invalidateDependents(project, input.now),
      ...this.touch(run, input.now)
    );
    try {
      await atomic(this.database, statements);
    } catch (error) {
      const replay2 = await this.commandReplay(result.commandId, request);
      if (replay2) {
        return replay2;
      }
      throw error;
    }
    return result;
  }
  async preparePromotion(input) {
    const existing = await this.sql("SELECT * FROM ariviso_snapshots WHERE id = ?", [
      input.snapshotId
    ]).first();
    if (existing) {
      if (existing.comparison_id !== input.comparisonId || existing.prefix !== input.prefix || existing.state === "revoked") {
        throw new ConflictError("The snapshot ID belongs to another or revoked promotion.");
      }
      return this.pendingSnapshotCopies(existing.id, input.copyLimit ?? 100);
    }
    const comparison = await this.comparison(input.comparisonId);
    const run = await this.run(comparison.run_id);
    const project = await this.project(run.project_id);
    if (run.kind !== "main" || !input.prefix.startsWith("baselines/")) {
      throw new IncompleteError("Only a complete main run can use a protected baseline prefix.");
    }
    await atomic(this.database, [
      this.projectGuard(project),
      this.activeGuard(run),
      this.readyGuard(comparison.id),
      this.guard(
        "EXISTS (SELECT 1 FROM ariviso_comparisons WHERE id = ? AND state = 'ready' AND baseline_revision = ? AND reference_snapshot_id IS ?)",
        [comparison.id, project.baseline_revision, project.snapshot_id]
      ),
      this.guard(
        "EXISTS (SELECT 1 FROM ariviso_runs WHERE id = ? AND comparison_id = ? AND sealed_at IS NOT NULL)",
        [run.id, comparison.id]
      ),
      this.sql(
        "INSERT INTO ariviso_snapshots (id, project_id, run_id, comparison_id, tested_sha, prefix, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)",
        [
          input.snapshotId,
          project.id,
          run.id,
          comparison.id,
          run.tested_sha,
          input.prefix,
          input.now
        ]
      ),
      this.sql(
        "INSERT INTO ariviso_snapshot_images (snapshot_id, capture_id, image_id, object_key, digest) SELECT ?, c.id, i.id, ? || '/' || i.id, i.digest FROM ariviso_captures c JOIN ariviso_images i ON i.id = c.image_id WHERE c.run_id = ?",
        [input.snapshotId, input.prefix, run.id]
      ),
      this.sql(
        "INSERT INTO ariviso_pins (snapshot_id, reason, owner_id) VALUES (?, 'promotion', ?)",
        [input.snapshotId, input.snapshotId]
      ),
      this.sql(
        "INSERT INTO work_retention_pins (run_id, owner, reason) VALUES (?, ?, 'promotion')",
        [run.id, `promotion:${input.snapshotId}`]
      )
    ]);
    return this.pendingSnapshotCopies(input.snapshotId, input.copyLimit ?? 100);
  }
  async cancelPreparedPromotion(input) {
    const snapshot = await this.one("SELECT * FROM ariviso_snapshots WHERE id = ?", [
      input.snapshotId
    ]);
    if (snapshot.state === "revoked") return;
    const run = await this.run(snapshot.run_id);
    const project = await this.project(run.project_id);
    await atomic(this.database, [
      this.projectGuard(project),
      this.guard(
        "EXISTS (SELECT 1 FROM ariviso_snapshots WHERE id = ? AND state = 'copying' AND reference_eligible = 0)",
        [snapshot.id]
      ),
      this.guard("NOT EXISTS (SELECT 1 FROM ariviso_promotions WHERE snapshot_id = ?)", [
        snapshot.id
      ]),
      this.sql("UPDATE ariviso_snapshots SET state = 'revoked' WHERE id = ?", [snapshot.id]),
      this.sql(
        "DELETE FROM ariviso_pins WHERE snapshot_id = ? AND reason = 'promotion' AND owner_id = ?",
        [snapshot.id, snapshot.id]
      ),
      this.sql(
        "DELETE FROM work_retention_pins WHERE run_id = ? AND owner = ? AND reason = 'promotion'",
        [run.id, `promotion:${snapshot.id}`]
      ),
      this.audit(run, "cancel-prepared-promotion", { snapshotId: snapshot.id }, input.now),
      ...this.touch(run, input.now)
    ]);
  }
  async pendingSnapshotCopies(snapshotId, limit) {
    if (!Number.isSafeInteger(limit) || limit < 1) {
      throw new IncompleteError("A positive copy-page limit is required.");
    }
    return this.rows(
      "SELECT si.*, i.object_key AS source_object_key, i.bytes, i.content_type FROM ariviso_snapshot_images si JOIN ariviso_images i ON i.id = si.image_id WHERE si.snapshot_id = ? AND si.copied = 0 ORDER BY si.capture_id LIMIT ?",
      [snapshotId, limit]
    );
  }
  async snapshotCopies(snapshotId) {
    return this.rows(
      "SELECT si.*, i.object_key AS source_object_key FROM ariviso_snapshot_images si JOIN ariviso_images i ON i.id = si.image_id WHERE si.snapshot_id = ?",
      [snapshotId]
    );
  }
  /** Mark a copy only after an R2 read verifies its digest at the protected key. */
  async recordSnapshotCopy(input) {
    await atomic(this.database, [
      this.guard("EXISTS (SELECT 1 FROM ariviso_snapshots WHERE id = ? AND state = 'copying')", [
        input.snapshotId
      ]),
      this.guard(
        "EXISTS (SELECT 1 FROM ariviso_snapshot_images WHERE snapshot_id = ? AND capture_id = ? AND object_key = ? AND digest = ?)",
        [input.snapshotId, input.captureId, input.objectKey, input.digest]
      ),
      this.sql(
        "UPDATE ariviso_snapshot_images SET copied = 1 WHERE snapshot_id = ? AND capture_id = ?",
        [input.snapshotId, input.captureId]
      )
    ]);
  }
  async promote(input) {
    const snapshot = await this.one("SELECT * FROM ariviso_snapshots WHERE id = ?", [
      input.snapshotId
    ]);
    const comparison = await this.comparison(snapshot.comparison_id);
    const run = await this.run(snapshot.run_id);
    const project = await this.project(run.project_id);
    if (project.promotion_id === input.promotionId && project.snapshot_id === snapshot.id) {
      return project;
    }
    const statements = [
      this.projectGuard(project),
      this.activeGuard(run),
      this.readyGuard(comparison.id),
      this.guard(
        "EXISTS (SELECT 1 FROM ariviso_projects WHERE id = ? AND baseline_revision = ? AND snapshot_id IS ?)",
        [project.id, input.expectedBaselineRevision, comparison.reference_snapshot_id]
      ),
      this.guard(
        "EXISTS (SELECT 1 FROM ariviso_runs WHERE id = ? AND kind = 'main' AND comparison_id = ? AND sealed_at IS NOT NULL)",
        [run.id, comparison.id]
      ),
      this.guard(
        "EXISTS (SELECT 1 FROM ariviso_comparisons WHERE id = ? AND state = 'ready' AND baseline_revision = ?)",
        [comparison.id, project.baseline_revision]
      ),
      this.guard("EXISTS (SELECT 1 FROM ariviso_snapshots WHERE id = ? AND state = 'copying')", [
        snapshot.id
      ]),
      this.guard(
        "NOT EXISTS (SELECT 1 FROM ariviso_snapshot_images WHERE snapshot_id = ? AND copied != 1) AND (SELECT count(*) FROM ariviso_snapshot_images WHERE snapshot_id = ?) = (SELECT count(*) FROM ariviso_captures WHERE run_id = ?)",
        [snapshot.id, snapshot.id, run.id]
      )
    ];
    if (project.snapshot_id) {
      statements.push(
        this.guard(
          "EXISTS (SELECT 1 FROM ariviso_snapshots s JOIN ariviso_ancestry a ON a.ancestor_sha = s.tested_sha AND a.run_id = ? WHERE s.id = ? AND s.reference_eligible = 1)",
          [run.id, project.snapshot_id]
        )
      );
      statements.push(
        this.sql(
          "INSERT OR IGNORE INTO ariviso_pins (snapshot_id, reason, owner_id) VALUES (?, 'rollback', ?)",
          [project.snapshot_id, input.promotionId]
        )
      );
    }
    statements.push(
      this.sql(
        "INSERT INTO ariviso_promotions (id, project_id, snapshot_id, previous_snapshot_id, comparison_id, baseline_revision, command_id, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
        [
          input.promotionId,
          project.id,
          snapshot.id,
          project.snapshot_id,
          comparison.id,
          project.baseline_revision + 1,
          input.commandId ?? null,
          input.now
        ]
      )
    );
    statements.push(
      this.sql(
        "UPDATE ariviso_snapshots SET state = 'accepted', reference_eligible = 1 WHERE id = ?",
        [snapshot.id]
      )
    );
    statements.push(
      this.sql(
        "UPDATE work_retention_pins SET reason = 'baseline' WHERE run_id = ? AND owner = ?",
        [run.id, `promotion:${snapshot.id}`]
      )
    );
    statements.push(
      this.sql(
        "UPDATE ariviso_projects SET snapshot_id = ?, promotion_id = ?, baseline_revision = baseline_revision + 1, fresh_setup = 0 WHERE id = ?",
        [snapshot.id, input.promotionId, project.id]
      )
    );
    statements.push(this.sql("UPDATE ariviso_runs SET state = 'accepted' WHERE id = ?", [run.id]));
    statements.push(
      this.sql(
        "INSERT OR IGNORE INTO ariviso_identity_history (project_id, lineage_key, item_key, variant_key) SELECT ?, 'main', item_key, variant_key FROM ariviso_captures WHERE run_id = ?",
        [project.id, run.id]
      )
    );
    statements.push(
      this.sql(
        "UPDATE ariviso_comparisons SET state = 'invalidated' WHERE id != ? AND run_id IN (SELECT id FROM ariviso_runs WHERE project_id = ? AND active = 1 AND state != 'accepted')",
        [comparison.id, project.id]
      )
    );
    statements.push(
      this.audit(
        run,
        "promote",
        { snapshotId: snapshot.id, promotionId: input.promotionId },
        input.now
      )
    );
    statements.push(
      ...this.invalidateDependents(project, input.now),
      ...this.touch(run, input.now)
    );
    await atomic(this.database, statements);
    return this.project(project.id);
  }
};

// implementation/operations/common.ts
import { createHash } from "node:crypto";
async function recordEvent(database, input) {
  const id = `${input.kind}:${input.subject}:${input.code}`;
  await database.prepare(`INSERT INTO operations_events(id,kind,subject_id,code,first_seen_at,last_seen_at)
    VALUES(?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET last_seen_at=excluded.last_seen_at,
    occurrences=operations_events.occurrences+1,resolved_at=NULL`).bind(id, input.kind, input.subject, input.code, input.now, input.now).run();
}
__name(recordEvent, "recordEvent");
async function resolveEvents(database, kind, subject, now) {
  await database.prepare(
    "UPDATE operations_events SET resolved_at=? WHERE kind=? AND subject_id=? AND resolved_at IS NULL"
  ).bind(now, kind, subject).run();
}
__name(resolveEvents, "resolveEvents");

// implementation/operations/comparison-alerts.ts
async function reportComparisonRecovery(context2, publication, finalization) {
  const database = context2.database;
  const now = context2.now();
  const historicalRecovered = `EXISTS(SELECT 1 FROM ariviso_comparisons recovered
    WHERE recovered.run_id=comparison.run_id AND recovered.purpose='historical'
      AND recovered.ordinal>comparison.ordinal AND recovered.state='ready'
      AND recovered.reference_snapshot_id IS comparison.reference_snapshot_id
      AND recovered.policy_digest=comparison.policy_digest)`;
  for (const subject of publication.failed) {
    await recordEvent(database, {
      kind: "comparison-publication",
      subject,
      code: "publication-failed",
      now
    });
  }
  for (const subject of publication.published) {
    await resolveEvents(database, "comparison-publication", subject, now);
  }
  for (const failure of finalization.errors) {
    await recordEvent(database, {
      kind: "comparison-finalization",
      subject: failure.comparisonId,
      code: "finalization-failed",
      now
    });
  }
  for (const subject of finalization.completed) {
    await resolveEvents(database, "comparison-finalization", subject, now);
  }
  await database.prepare(`UPDATE operations_events SET resolved_at=? WHERE id IN (
    SELECT event.id FROM operations_events event JOIN work_tasks task ON task.id=event.subject_id
    WHERE event.kind='comparison-publication' AND event.resolved_at IS NULL
      AND task.state IN ('leased','complete','dead') AND task.attempts>0 AND task.updated_at>=event.last_seen_at
    ORDER BY event.last_seen_at,event.id LIMIT ?)`).bind(now, context2.budget.tasksPerStep).run();
  await database.prepare(`UPDATE operations_events SET resolved_at=? WHERE id IN (
    SELECT event.id FROM operations_events event JOIN ariviso_comparisons comparison ON comparison.id=event.subject_id
    JOIN ariviso_runs run ON run.id=comparison.run_id
    WHERE event.kind IN ('comparison-finalization','comparison-task') AND event.resolved_at IS NULL
      AND (comparison.state='ready'
        OR (comparison.purpose='review' AND (run.active=0 OR run.comparison_id!=comparison.id))
        OR (comparison.purpose='historical' AND ${historicalRecovered}))
    ORDER BY event.last_seen_at,event.id LIMIT ?)`).bind(now, context2.budget.tasksPerStep).run();
  const exhausted = await database.prepare(`SELECT DISTINCT comparison.id FROM work_tasks task
    JOIN ariviso_comparison_rows row ON row.id=task.id
    JOIN ariviso_comparisons comparison ON comparison.id=row.comparison_id
    JOIN ariviso_runs run ON run.id=comparison.run_id
    WHERE task.kind='compare' AND task.state='dead'
      AND ((comparison.purpose='review' AND run.active=1 AND run.comparison_id=comparison.id)
        OR (comparison.purpose='historical' AND NOT ${historicalRecovered}))
      AND comparison.state!='ready' AND NOT EXISTS(SELECT 1 FROM operations_events event
        WHERE event.kind='comparison-task' AND event.subject_id=comparison.id AND event.code='attempts-exhausted')
    ORDER BY comparison.id LIMIT ?`).bind(context2.budget.tasksPerStep).all();
  for (const { id: subject } of exhausted.results ?? []) {
    await recordEvent(database, {
      kind: "comparison-task",
      subject,
      code: "attempts-exhausted",
      now
    });
  }
}
__name(reportComparisonRecovery, "reportComparisonRecovery");

// ../../../../../../Users/diegohaz/Developer/ariviso/packages/security/src/errors.ts
var SecurityError = class extends Error {
  constructor(code, status, message) {
    super(message);
    this.code = code;
    this.status = status;
    this.name = "SecurityError";
  }
  code;
  status;
  static {
    __name(this, "SecurityError");
  }
};

// implementation/operations-api.ts
async function operationsStatus({
  database,
  projectId,
  repositoryId
}) {
  const projects = await database.prepare("SELECT id,repository_id FROM ariviso_projects ORDER BY id LIMIT 2").all();
  if (projects.results?.length !== 1 || projects.results[0]?.id !== projectId || projects.results[0]?.repository_id !== repositoryId) {
    throw new SecurityError(
      "operations_configuration",
      503,
      "Operation alerts require one matching configured project and repository."
    );
  }
  const rows = await database.prepare(`SELECT kind,code,subject_id AS subject,first_seen_at AS firstSeenAt,last_seen_at AS lastSeenAt
      FROM operations_events WHERE resolved_at IS NULL ORDER BY last_seen_at DESC,id ASC LIMIT 51`).all();
  const events = rows.results ?? [];
  const capacity = await database.prepare("SELECT value FROM operations_cursors WHERE id='database-capacity'").first();
  return {
    events: events.slice(0, 50),
    hasMore: events.length > 50,
    checkedAt: Date.now(),
    capacity: capacity ? JSON.parse(capacity.value) : null
  };
}
__name(operationsStatus, "operationsStatus");

// worker.mjs
var noPublication = { published: [], failed: [] };
var noFinalization = { completed: [], errors: [] };
var context = /* @__PURE__ */ __name((env) => ({ database: env.DB, now: Date.now, budget: { tasksPerStep: 20 } }), "context");
var json = /* @__PURE__ */ __name((body, status = 200) => Response.json(body, { status, headers: { "cache-control": "no-store" } }), "json");
async function createFixture(env, id, mode = "success") {
  const now = Date.now();
  await env.DB.batch([
    env.DB.prepare("INSERT INTO ariviso_runs(id,project_id,external_run_id,attempt,kind,tested_sha,lineage_key,plan_digest,plan_json,state,sealed_at,comparison_id,created_at) VALUES(?,'probe',?,1,'pull_request','probe-sha',?,'probe-plan','{}','comparing',?,?,?)").bind(id, id, id, now, id, now),
    env.DB.prepare("INSERT INTO ariviso_comparisons(id,run_id,baseline_revision,policy_digest,ordinal,created_at) VALUES(?,?,0,'probe-policy',1,?)").bind(id, id, now),
    env.DB.prepare("INSERT INTO ariviso_comparison_rows(id,comparison_id,item_key,variant_key,ordinal,tuple_json) VALUES(?,?,'queue-control','default',0,'{}')").bind(`${id}:row`, id)
  ]);
  await enqueueWork(env.DB, { id: `${id}:row`, kind: "compare", payload: JSON.stringify({ mode }), maxAttempts: 3, now });
}
__name(createFixture, "createFixture");
async function delivery(env, message, action) {
  await env.DB.prepare("INSERT INTO probe_deliveries(task_id,message_id,transport_attempt,action,at) VALUES(?,?,?,?,?)").bind(message.body?.taskId ?? null, message.id, message.attempts, action, Date.now()).run();
}
__name(delivery, "delivery");
var worker_default = {
  async fetch(request, env) {
    if (typeof env.PROBE_TOKEN !== "string" || env.PROBE_TOKEN.length < 64) return json({ error: "unconfigured" }, 503);
    const provided = Buffer.from(request.headers.get("authorization") ?? "");
    const expected = Buffer.from(`Bearer ${env.PROBE_TOKEN}`);
    if (provided.length !== expected.length || !timingSafeEqual(provided, expected)) return json({ error: "unauthorized" }, 401);
    const url = new URL(request.url);
    try {
      if (url.pathname === "/prepare" && request.method === "POST") {
        if (await env.DB.prepare("SELECT id FROM ariviso_projects LIMIT 1").first()) throw new Error("Probe already prepared");
        await env.DB.prepare("INSERT INTO ariviso_projects(id,repository_id,policy_digest) VALUES('probe','disposable-probe','probe-policy')").run();
        for (const [id, mode] of [["lost", "success"], ["expired", "success"], ["bounded", "fail"], ["duplicate", "success"]]) await createFixture(env, id, mode);
        const abandoned = await claimWork(env.DB, { id: "expired:row", token: "abandoned-owner", now: Date.now(), leaseMs: 1e3 });
        if (!abandoned || abandoned.attempts !== 1) throw new Error("Expired-lease control was not claimed");
        await env.DB.batch([
          env.DB.prepare("INSERT INTO ariviso_runs(id,project_id,external_run_id,attempt,kind,tested_sha,lineage_key,plan_digest,plan_json,state,sealed_at,comparison_id,created_at) VALUES('finalization','probe','finalization',1,'pull_request','probe-sha','finalization','probe-plan','{}','comparing',?,'finalization',?)").bind(Date.now(), Date.now()),
          env.DB.prepare("INSERT INTO ariviso_comparisons(id,run_id,baseline_revision,policy_digest,ordinal,created_at) VALUES('finalization','finalization',0,'probe-policy',1,?)").bind(Date.now())
        ]);
        return json({ prepared: true, workloads: 4, abandonedLeaseUntil: abandoned.lease_until, finalizationControl: "empty synthetic inventory; no image correctness claim" });
      }
      if (url.pathname === "/reconcile" && request.method === "POST") {
        const input = await request.json();
        const publication = await reconcileWork(env.DB, { now: Date.now(), limit: 20, kind: "compare", publish: /* @__PURE__ */ __name(async (taskId) => {
          if (input.failPublication) throw new Error("Injected publisher outage before Queue send");
          await env.WORK.send({ taskId });
        }, "publish") });
        await reportComparisonRecovery(context(env), publication, noFinalization);
        return json({ publication, alerts: await operationsStatus({ database: env.DB, projectId: "probe", repositoryId: "disposable-probe" }) });
      }
      if (url.pathname === "/finalize" && request.method === "POST") {
        const input = await request.json();
        const database = { prepare: env.DB.prepare.bind(env.DB), batch: input.failCommit ? async () => {
          throw new Error("Injected finalization batch outage before commit");
        } : env.DB.batch.bind(env.DB) };
        const finalization = await new Service(database).reconcileComparisons({ now: Date.now(), limit: 20 });
        await reportComparisonRecovery(context(env), noPublication, finalization);
        return json({ finalization, alerts: await operationsStatus({ database: env.DB, projectId: "probe", repositoryId: "disposable-probe" }) });
      }
      if (url.pathname === "/duplicates" && request.method === "POST") {
        await env.WORK.sendBatch(Array.from({ length: 8 }, () => ({ body: { taskId: "duplicate:row" } })));
        return json({ sent: 8 });
      }
      if (url.pathname === "/poison" && request.method === "POST") {
        await env.WORK.send({ poison: true, id: "transport-poison" });
        return json({ sent: true });
      }
      if (url.pathname === "/recover" && request.method === "POST") {
        await env.DB.prepare("UPDATE ariviso_runs SET active=0,state='superseded' WHERE id='bounded'").run();
        await createFixture(env, "bounded-replacement", "success");
        await env.WORK.send({ taskId: "bounded-replacement:row" });
        await reportComparisonRecovery(context(env), noPublication, noFinalization);
        return json({ replacement: "bounded-replacement:row" });
      }
      if (url.pathname === "/stale" && request.method === "POST") {
        const accepted = await completeWork(env.DB, { id: "expired:row", token: "abandoned-owner", now: Date.now(), result: "stale-overwrite" });
        return json({ accepted, task: await getWork(env.DB, "expired:row") });
      }
      if (url.pathname === "/report") {
        await reportComparisonRecovery(context(env), noPublication, noFinalization);
        return json({
          tasks: (await env.DB.prepare("SELECT id,kind,state,attempts,max_attempts,result,last_error FROM work_tasks ORDER BY id").all()).results,
          deliveries: (await env.DB.prepare("SELECT * FROM probe_deliveries ORDER BY id").all()).results,
          deadLetters: (await env.DB.prepare("SELECT * FROM probe_dlq ORDER BY id").all()).results,
          events: (await env.DB.prepare("SELECT * FROM operations_events ORDER BY id").all()).results,
          privateStatus: await operationsStatus({ database: env.DB, projectId: "probe", repositoryId: "disposable-probe" }),
          foreignKeys: (await env.DB.prepare("PRAGMA foreign_key_check").all()).results,
          checkedAt: Date.now()
        });
      }
      return json({ error: "unknown" }, 404);
    } catch (error) {
      return json({ error: error instanceof Error ? error.message : String(error) }, 500);
    }
  },
  async queue(batch, env) {
    for (const message of batch.messages) {
      if (batch.queue === "ariviso-e08-dead-20260922") {
        await env.DB.prepare("INSERT INTO probe_dlq(id,transport_attempt,body_json,received_at) VALUES(?,?,?,?) ON CONFLICT(id) DO NOTHING").bind(message.body.id ?? message.id, message.attempts, JSON.stringify(message.body), Date.now()).run();
        message.ack();
        continue;
      }
      if (message.body?.poison) {
        await delivery(env, message, "transport-retry");
        message.retry({ delaySeconds: 1 });
        continue;
      }
      const taskId = message.body?.taskId;
      const owner = crypto.randomUUID();
      const task = await claimWork(env.DB, { id: taskId, token: owner, now: Date.now(), leaseMs: 3e4 });
      if (!task) {
        const state = await getWork(env.DB, taskId);
        if (state?.state === "complete" || state?.state === "dead") {
          await delivery(env, message, "terminal-duplicate");
          message.ack();
        } else {
          await delivery(env, message, "lease-busy");
          message.retry({ delaySeconds: 1 });
        }
        continue;
      }
      if (JSON.parse(task.payload).mode === "fail") {
        await failWork(env.DB, { id: taskId, token: owner, now: Date.now(), retryAt: Date.now() + 1e3, error: "injected-recoverable-storage-outage" });
        const failed = await getWork(env.DB, taskId);
        await delivery(env, message, failed.state === "dead" ? "durable-dead" : "durable-retry");
        await reportComparisonRecovery(context(env), noPublication, noFinalization);
        if (failed.state === "dead") message.ack();
        else message.retry({ delaySeconds: 1 });
      } else {
        const committed = await completeWork(env.DB, { id: taskId, token: owner, now: Date.now(), result: "queue-control-success" });
        if (!committed) throw new Error("Completion lost its lease");
        await delivery(env, message, "committed");
        message.ack();
      }
    }
  }
};
export {
  worker_default as default
};
//# sourceMappingURL=worker.js.map
