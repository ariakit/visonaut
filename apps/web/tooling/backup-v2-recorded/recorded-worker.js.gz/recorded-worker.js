var __defProp = Object.defineProperty;
var __name = (target, value) => __defProp(target, "name", { value, configurable: true });

// ../../packages/service/src/database.ts
var ConflictError = class extends Error {
  constructor(message2, current) {
    super(message2);
    this.current = current;
    this.name = "ConflictError";
  }
  current;
  static {
    __name(this, "ConflictError");
  }
  code = "CONFLICT";
};
var IncompleteError = class extends Error {
  static {
    __name(this, "IncompleteError");
  }
  code = "INCOMPLETE";
  constructor(message2) {
    super(message2);
    this.name = "IncompleteError";
  }
};
function statement(database, sql, values = []) {
  return database.prepare(sql).bind(...values);
}
__name(statement, "statement");
function assertion(database, predicate, values = []) {
  return statement(
    database,
    `INSERT INTO ariviso_assertions (valid) VALUES (CASE WHEN (${predicate}) THEN 1 ELSE 0 END)`,
    values
  );
}
__name(assertion, "assertion");
async function atomic(database, statements) {
  try {
    return await database.batch([
      ...statements,
      statement(database, "DELETE FROM ariviso_assertions")
    ]);
  } catch (error) {
    if (error instanceof Error && /CHECK constraint failed.*valid|ariviso_assertions/.test(error.message)) {
      throw new ConflictError("State changed. Refresh the comparison before trying again.");
    }
    throw error;
  }
}
__name(atomic, "atomic");

// ../../packages/service/src/work.ts
function positiveInteger(value, name) {
  if (!Number.isSafeInteger(value) || value < 1) {
    throw new Error(`${name} must be a positive safe integer`);
  }
}
__name(positiveInteger, "positiveInteger");
function validateLease(params) {
  positiveInteger(params.leaseMs, "leaseMs");
  if (!params.token) {
    throw new Error("A unique lease token is required");
  }
}
__name(validateLease, "validateLease");
async function getWork(database, id) {
  return database.prepare("SELECT * FROM work_tasks WHERE id = ?").bind(id).first();
}
__name(getWork, "getWork");
async function claimWork(database, params) {
  validateLease(params);
  await database.prepare(`
    UPDATE work_tasks SET state = 'dead', lease_token = NULL, lease_until = NULL,
      last_error = 'Lease expired after final attempt', updated_at = ?
    WHERE id = ? AND state = 'leased' AND lease_until <= ? AND attempts >= max_attempts
  `).bind(params.now, params.id, params.now).run();
  return database.prepare(`
    UPDATE work_tasks SET state = 'leased', attempts = attempts + 1,
      lease_token = ?, lease_until = ?, updated_at = ?
    WHERE id = ? AND attempts < max_attempts AND (
      (state = 'queued' AND available_at <= ?) OR
      (state = 'leased' AND lease_until <= ?)
    ) RETURNING *
  `).bind(params.token, params.now + params.leaseMs, params.now, params.id, params.now, params.now).first();
}
__name(claimWork, "claimWork");
function workLeaseAssertion(database, params) {
  return assertion(
    database,
    `EXISTS (SELECT 1 FROM work_tasks WHERE id = ?
    AND state = 'leased' AND lease_token = ? AND lease_until > ?)`,
    [params.id, params.token, params.now]
  );
}
__name(workLeaseAssertion, "workLeaseAssertion");
function completeWorkStatement(database, params) {
  return database.prepare(`
    UPDATE work_tasks SET state = 'complete', result = ?, lease_until = NULL,
      updated_at = ? WHERE id = ? AND state = 'leased' AND lease_token = ? AND lease_until > ?
    RETURNING id
  `).bind(params.result, params.now, params.id, params.token, params.now);
}
__name(completeWorkStatement, "completeWorkStatement");
async function failWork(database, params) {
  const result = await database.prepare(`
    UPDATE work_tasks SET state = CASE WHEN attempts >= max_attempts THEN 'dead' ELSE 'queued' END,
      available_at = ?, last_error = ?, lease_token = NULL, lease_until = NULL, updated_at = ?
    WHERE id = ? AND state = 'leased' AND lease_token = ? AND lease_until > ? RETURNING id
  `).bind(
    Math.max(params.now, params.retryAt),
    params.error.slice(0, 4096),
    params.now,
    params.id,
    params.token,
    params.now
  ).first();
  return result !== null;
}
__name(failWork, "failWork");
function statusIntentStatements(database, input) {
  positiveInteger(input.revision, "revision");
  positiveInteger(input.maxAttempts, "maxAttempts");
  return [
    database.prepare(`
      INSERT INTO work_checks (id, desired_revision) VALUES (?, ?)
      ON CONFLICT(id) DO UPDATE SET desired_revision = excluded.desired_revision
      WHERE excluded.desired_revision > work_checks.desired_revision
    `).bind(input.checkId, input.revision),
    database.prepare(`
      INSERT INTO work_status_outbox (check_id, revision, run_id, attempt,
        comparison_revision, source_revision, conclusion, details_url, max_attempts, available_at)
      SELECT ?, ?, ?, ?, ?, ?, ?, ?, ?, ?
      WHERE EXISTS (SELECT 1 FROM work_checks WHERE id = ? AND desired_revision = ?)
      ON CONFLICT(check_id, revision) DO UPDATE SET run_id = excluded.run_id,
        attempt = excluded.attempt, comparison_revision = excluded.comparison_revision,
        source_revision = excluded.source_revision, conclusion = excluded.conclusion,
        details_url = excluded.details_url, max_attempts = excluded.max_attempts
    `).bind(
      input.checkId,
      input.revision,
      input.runId,
      input.attempt,
      input.comparisonRevision,
      input.sourceRevision,
      input.conclusion,
      input.detailsUrl,
      input.maxAttempts,
      input.now,
      input.checkId,
      input.revision
    )
  ];
}
__name(statusIntentStatements, "statusIntentStatements");
var closedRunRetentionMs = 30 * 24 * 60 * 60 * 1e3;

// ../../packages/service/src/service.ts
async function captureProfilesDigest(captures) {
  const profiles = captures.map((capture) => [capture.itemKey, capture.variantKey, capture.profileDigest]).sort(
    (left, right) => JSON.stringify(left) < JSON.stringify(right) ? -1 : JSON.stringify(left) > JSON.stringify(right) ? 1 : 0
  );
  const digest = await crypto.subtle.digest(
    "SHA-256",
    new TextEncoder().encode(JSON.stringify(profiles))
  );
  return Array.from(new Uint8Array(digest), (value) => value.toString(16).padStart(2, "0")).join(
    ""
  );
}
__name(captureProfilesDigest, "captureProfilesDigest");
function identity(itemKey, variantKey) {
  return JSON.stringify([itemKey, variantKey]);
}
__name(identity, "identity");
function requestJson(input) {
  const { now: _now, ...request } = input;
  return JSON.stringify(request);
}
__name(requestJson, "requestJson");
function parseCommandResult(json2) {
  return JSON.parse(json2);
}
__name(parseCommandResult, "parseCommandResult");
var Service = class {
  constructor(database) {
    this.database = database;
  }
  database;
  static {
    __name(this, "Service");
  }
  sql(sql, values = []) {
    return statement(this.database, sql, values);
  }
  guard(sql, values = []) {
    return assertion(this.database, sql, values);
  }
  async one(sql, values = []) {
    const row = await this.sql(sql, values).first();
    if (!row) {
      throw new IncompleteError("The requested record does not exist.");
    }
    return row;
  }
  async rows(sql, values = []) {
    return (await this.sql(sql, values).all()).results ?? [];
  }
  async project(id) {
    return this.one("SELECT * FROM ariviso_projects WHERE id = ?", [id]);
  }
  async run(id) {
    return this.one("SELECT * FROM ariviso_runs WHERE id = ?", [id]);
  }
  async comparison(id) {
    return this.one("SELECT * FROM ariviso_comparisons WHERE id = ?", [id]);
  }
  async comparisonRows(id) {
    return this.rows(
      "SELECT * FROM ariviso_comparison_rows WHERE comparison_id = ? ORDER BY ordinal, id",
      [id]
    );
  }
  async createPolicy(input) {
    const policy = input.policy;
    if (!policy.id || !Number.isFinite(policy.channelThreshold) || policy.channelThreshold < 0 || policy.channelThreshold > 255 || !Number.isSafeInteger(policy.maxChangedPixels) || policy.maxChangedPixels < 0 || !Number.isFinite(policy.maxChangedRatio) || policy.maxChangedRatio < 0 || policy.maxChangedRatio > 1) {
      throw new IncompleteError("Invalid trusted comparison policy.");
    }
    await atomic(this.database, [
      this.sql(
        "INSERT INTO ariviso_policies (digest, policy_json) VALUES (?, ?) ON CONFLICT(digest) DO NOTHING",
        [input.digest, JSON.stringify(policy)]
      ),
      this.guard("EXISTS (SELECT 1 FROM ariviso_policies WHERE digest = ? AND policy_json = ?)", [
        input.digest,
        JSON.stringify(policy)
      ])
    ]);
  }
  async createProject(input) {
    await this.sql(
      "INSERT INTO ariviso_projects (id, repository_id, policy_digest) VALUES (?, ?, ?)",
      [input.id, input.repositoryId, input.policyDigest]
    ).run();
  }
  projectGuard(project) {
    return this.guard("EXISTS (SELECT 1 FROM ariviso_projects WHERE id = ? AND revision = ?)", [
      project.id,
      project.revision
    ]);
  }
  activeGuard(run) {
    return this.guard(
      "EXISTS (SELECT 1 FROM ariviso_runs WHERE id = ? AND active = 1 AND revision = ?)",
      [run.id, run.revision]
    );
  }
  reviewGuard(run, comparisonId) {
    return this.guard(
      "EXISTS (SELECT 1 FROM ariviso_runs run JOIN ariviso_comparisons comparison ON comparison.id = run.comparison_id WHERE run.id = ? AND run.active = 1 AND run.revision = ? AND run.sealed_at IS NOT NULL AND comparison.id = ? AND comparison.state = 'ready')",
      [run.id, run.revision, comparisonId]
    );
  }
  touch(run, now) {
    return [
      this.sql("UPDATE ariviso_projects SET revision = revision + 1 WHERE id = ?", [
        run.project_id
      ]),
      this.sql("UPDATE ariviso_runs SET revision = revision + 1 WHERE id = ?", [run.id]),
      this.sql(
        "UPDATE work_checks SET desired_revision = (SELECT revision FROM ariviso_projects WHERE id = ?) WHERE id IN (SELECT id FROM ariviso_checks WHERE project_id = ?)",
        [run.project_id, run.project_id]
      ),
      this.sql(
        "INSERT INTO ariviso_status_outbox (id, run_id, run_revision, created_at) SELECT ?, id, revision, ? FROM ariviso_runs WHERE id = ?",
        [crypto.randomUUID(), now, run.id]
      )
    ];
  }
  audit(run, action, detail, now, actorId = null) {
    return this.sql(
      "INSERT INTO ariviso_audit (id, project_id, run_id, actor_id, action, detail_json, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)",
      [crypto.randomUUID(), run.project_id, run.id, actorId, action, JSON.stringify(detail), now]
    );
  }
  async reserveRun(input) {
    if (!input.verificationDigest || !input.lineageKey || input.plan.shards.length === 0) {
      throw new IncompleteError("A verified full plan and lineage are required.");
    }
    const existing = await this.sql(
      "SELECT * FROM ariviso_runs WHERE project_id = ? AND external_run_id = ? AND attempt = ?",
      [input.projectId, input.externalRunId, input.attempt]
    ).first();
    if (existing) {
      if (existing.tested_sha !== input.testedSha || existing.plan_digest !== input.plan.digest || existing.lineage_key !== input.lineageKey) {
        throw new ConflictError(
          "The run identity already has different trusted metadata.",
          existing
        );
      }
      return existing;
    }
    const project = await this.project(input.projectId);
    if (new TextEncoder().encode(JSON.stringify(input.plan)).byteLength > 15e5) {
      throw new IncompleteError("The trusted plan is too large for one run record.");
    }
    const keys = /* @__PURE__ */ new Set();
    const identities = /* @__PURE__ */ new Set();
    for (const shard of input.plan.shards) {
      if (keys.has(shard.key) || !shard.discovery && (shard.tests.length === 0 || shard.captures.length === 0) || shard.discovery && (!shard.discovery.executorDigest || !shard.discovery.configurationDigest)) {
        throw new IncompleteError("Each trusted shard needs unique identity, tests, and captures.");
      }
      keys.add(shard.key);
      for (const capture of shard.captures) {
        const key = identity(capture.itemKey, capture.variantKey);
        if (identities.has(key) || !shard.tests.includes(capture.testId)) {
          throw new IncompleteError(
            "The trusted plan contains a duplicate or unaccounted capture."
          );
        }
        identities.add(key);
      }
    }
    for (const key of input.rerunShardKeys) {
      if (!keys.has(key)) {
        throw new IncompleteError("An unknown shard was marked as rerun.");
      }
    }
    const statements = [
      this.projectGuard(project),
      this.guard(
        "NOT EXISTS (SELECT 1 FROM ariviso_runs WHERE project_id = ? AND external_run_id = ? AND attempt >= ?)",
        [input.projectId, input.externalRunId, input.attempt]
      ),
      this.sql(
        "UPDATE ariviso_runs SET active = 0, state = 'superseded', revision = revision + 1 WHERE project_id = ? AND external_run_id = ? AND active = 1",
        [input.projectId, input.externalRunId]
      ),
      this.sql(
        "INSERT INTO ariviso_runs (id, project_id, external_run_id, attempt, kind, tested_sha, lineage_key, plan_digest, plan_json, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
        [
          input.id,
          input.projectId,
          input.externalRunId,
          input.attempt,
          input.kind,
          input.testedSha,
          input.lineageKey,
          input.plan.digest,
          JSON.stringify(input.plan),
          input.now
        ]
      ),
      this.sql("INSERT INTO work_retained_runs (id, object_prefix) VALUES (?, ?)", [
        input.id,
        `runs/${input.id}/`
      ]),
      this.sql("INSERT INTO work_retention_pins (run_id, owner, reason) VALUES (?, ?, 'review')", [
        input.id,
        `review:${input.id}`
      ])
    ];
    for (const sourceId of new Set(input.verifiedRelatedRunIds)) {
      statements.push(
        this.guard("EXISTS (SELECT 1 FROM ariviso_runs WHERE id = ? AND project_id = ?)", [
          sourceId,
          input.projectId
        ])
      );
      statements.push(
        this.sql(
          "INSERT INTO ariviso_lineage (source_run_id, target_run_id, proof_digest) VALUES (?, ?, ?)",
          [sourceId, input.id, input.verificationDigest]
        )
      );
    }
    for (const sha of new Set(input.verifiedAncestorShas)) {
      statements.push(
        this.sql(
          "INSERT INTO ariviso_ancestry (run_id, ancestor_sha, proof_digest) VALUES (?, ?, ?)",
          [input.id, sha, input.verificationDigest]
        )
      );
    }
    for (const shard of input.plan.shards) {
      statements.push(
        this.sql(
          "INSERT INTO ariviso_shards (run_id, key, profile_digest, expected_json) VALUES (?, ?, ?, ?)",
          [input.id, shard.key, shard.profileDigest, JSON.stringify(shard)]
        )
      );
    }
    if (input.inheritFromRunId) {
      statements.push(
        this.guard(
          "EXISTS (SELECT 1 FROM ariviso_runs WHERE id = ? AND project_id = ? AND external_run_id = ? AND tested_sha = ? AND plan_digest = ? AND attempt < ?)",
          [
            input.inheritFromRunId,
            input.projectId,
            input.externalRunId,
            input.testedSha,
            input.plan.digest,
            input.attempt
          ]
        )
      );
      for (const shard of input.plan.shards) {
        if (input.rerunShardKeys.includes(shard.key)) continue;
        const inherited = input.verifiedInheritedShards?.find((entry) => entry.key === shard.key);
        if (!inherited) {
          throw new IncompleteError(
            "Each inherited shard requires verified manifest and full capture-profile identity."
          );
        }
        statements.push(
          this.guard(
            "EXISTS (SELECT 1 FROM ariviso_shards WHERE run_id = ? AND key = ? AND manifest_digest = ? AND full_profile_digest = ?)",
            [
              input.inheritFromRunId,
              shard.key,
              inherited.manifestDigest,
              inherited.captureProfileDigest
            ]
          )
        );
        statements.push(
          this.guard(
            "EXISTS (SELECT 1 FROM ariviso_shards WHERE run_id = ? AND key = ? AND state = 'complete' AND profile_digest = ?)",
            [input.inheritFromRunId, shard.key, shard.profileDigest]
          )
        );
        statements.push(
          this.sql(
            "UPDATE ariviso_shards SET state = 'complete', manifest_digest = (SELECT manifest_digest FROM ariviso_shards WHERE run_id = ? AND key = ?), full_profile_digest = ?, expected_json = (SELECT expected_json FROM ariviso_shards WHERE run_id = ? AND key = ?), discovery_json = (SELECT discovery_json FROM ariviso_shards WHERE run_id = ? AND key = ?), source_run_id = ?, source_attempt = (SELECT COALESCE(shard.source_attempt, source.attempt) FROM ariviso_shards shard JOIN ariviso_runs source ON source.id = shard.run_id WHERE shard.run_id = ? AND shard.key = ?) WHERE run_id = ? AND key = ?",
            [
              input.inheritFromRunId,
              shard.key,
              inherited.captureProfileDigest,
              input.inheritFromRunId,
              shard.key,
              input.inheritFromRunId,
              shard.key,
              input.inheritFromRunId,
              input.inheritFromRunId,
              shard.key,
              input.id,
              shard.key
            ]
          )
        );
        statements.push(
          this.sql(
            "INSERT INTO ariviso_captures (id, run_id, shard_key, item_key, variant_key, ordinal, image_id, profile_digest, test_id, test_retry, metadata_json) SELECT ? || ':' || id, ?, shard_key, item_key, variant_key, ordinal, image_id, profile_digest, test_id, test_retry, metadata_json FROM ariviso_captures WHERE run_id = ? AND shard_key = ?",
            [input.id, input.id, input.inheritFromRunId, shard.key]
          )
        );
      }
    }
    statements.push(
      this.sql(
        "INSERT INTO work_retention_pins (run_id, owner, reason) SELECT DISTINCT image.run_id, ?, 'comparison' FROM ariviso_captures capture JOIN ariviso_images image ON image.id = capture.image_id WHERE capture.run_id = ? AND image.run_id != ? ON CONFLICT(run_id, owner) DO NOTHING",
        [`inherited-by:${input.id}`, input.id, input.id]
      )
    );
    statements.push(
      this.sql("UPDATE ariviso_projects SET revision = revision + 1 WHERE id = ?", [project.id])
    );
    statements.push(
      this.sql(
        "UPDATE work_checks SET desired_revision = (SELECT revision FROM ariviso_projects WHERE id = ?) WHERE id IN (SELECT id FROM ariviso_checks WHERE project_id = ?)",
        [project.id, project.id]
      )
    );
    await atomic(this.database, statements);
    return this.run(input.id);
  }
  /** Call only after the trusted decoder and R2 write have both succeeded. */
  async registerImage(image) {
    const run = await this.run(image.runId);
    await atomic(this.database, [
      this.activeGuard(run),
      this.guard(
        "EXISTS (SELECT 1 FROM ariviso_runs WHERE id = ? AND sealed_at IS NULL AND state = 'uploading')",
        [run.id]
      ),
      this.guard("EXISTS (SELECT 1 FROM work_retained_runs WHERE id = ? AND byte_state = 'live')", [
        run.id
      ]),
      this.sql(
        "INSERT INTO ariviso_images (id, run_id, digest, object_key, content_type, bytes, width, height) VALUES (?, ?, ?, ?, ?, ?, ?, ?) ON CONFLICT(id) DO NOTHING",
        [
          image.id,
          image.runId,
          image.digest,
          image.objectKey,
          image.contentType,
          image.bytes,
          image.width,
          image.height
        ]
      ),
      this.guard(
        "EXISTS (SELECT 1 FROM ariviso_images WHERE id = ? AND run_id = ? AND digest = ? AND object_key = ? AND bytes = ? AND width = ? AND height = ? AND content_type = ?)",
        [
          image.id,
          image.runId,
          image.digest,
          image.objectKey,
          image.bytes,
          image.width,
          image.height,
          image.contentType
        ]
      )
    ]);
  }
  async commitShard(input) {
    const run = await this.run(input.runId);
    const shard = await this.one("SELECT * FROM ariviso_shards WHERE run_id = ? AND key = ?", [run.id, input.key]);
    if (shard.state === "complete") {
      if (shard.manifest_digest !== input.manifestDigest) {
        throw new ConflictError("The sealed shard has a different manifest.");
      }
      return;
    }
    let expected = JSON.parse(shard.expected_json);
    if (expected.discovery) {
      const proof = input.verifiedDiscovery;
      if (!proof || proof.executorDigest !== expected.discovery.executorDigest || proof.configurationDigest !== expected.discovery.configurationDigest || proof.externalRunId !== run.external_run_id || proof.attempt !== run.attempt || proof.testedSha !== run.tested_sha || !proof.verificationDigest || !proof.inventoryDigest || !proof.jobId) {
        throw new IncompleteError(
          "Candidate discovery needs verified successful-job evidence from the trusted executor and configuration."
        );
      }
      const identities = new Set(
        proof.captures.map((capture) => identity(capture.itemKey, capture.variantKey))
      );
      if (proof.tests.length === 0 || proof.captures.length === 0 || new Set(proof.tests).size !== proof.tests.length || identities.size !== proof.captures.length || proof.captures.some((capture) => !proof.tests.includes(capture.testId))) {
        throw new IncompleteError(
          "The verified candidate inventory is empty, duplicated, or incomplete."
        );
      }
      expected = { ...expected, tests: proof.tests, captures: proof.captures };
    } else if (input.verifiedDiscovery) {
      throw new IncompleteError("This trusted shard does not permit candidate discovery.");
    }
    const outcomes = new Map(input.finalTestOutcomes.map((outcome) => [outcome.testId, outcome]));
    if (outcomes.size !== expected.tests.length || outcomes.size !== input.finalTestOutcomes.length) {
      throw new IncompleteError("The shard must report every required test exactly once.");
    }
    for (const testId of expected.tests) {
      if (outcomes.get(testId)?.status !== "passed") {
        throw new IncompleteError("A required test did not pass its final attempt.");
      }
    }
    const captures = new Map(
      input.captures.map((capture) => [identity(capture.itemKey, capture.variantKey), capture])
    );
    if (captures.size !== expected.captures.length || captures.size !== input.captures.length) {
      throw new IncompleteError("The shard must contain every required capture exactly once.");
    }
    for (const required of expected.captures) {
      const capture = captures.get(identity(required.itemKey, required.variantKey));
      if (!capture || capture.testId !== required.testId || !(expected.environmentProfileDigests ?? [expected.profileDigest]).includes(
        capture.environmentProfileDigest
      ) || capture.testRetry !== outcomes.get(required.testId)?.retry) {
        throw new IncompleteError(
          "A capture does not match the trusted plan or final successful test attempt."
        );
      }
    }
    for (let offset = 0; offset < input.captures.length; offset += 100) {
      const captures2 = JSON.stringify(
        input.captures.slice(offset, offset + 100).map((capture) => ({ ...capture, metadataJson: JSON.stringify(capture.metadata) }))
      );
      await atomic(this.database, [
        this.activeGuard(run),
        this.guard("EXISTS (SELECT 1 FROM ariviso_runs WHERE id = ? AND sealed_at IS NULL)", [
          run.id
        ]),
        this.guard(
          "EXISTS (SELECT 1 FROM work_retained_runs WHERE id = ? AND byte_state = 'live')",
          [run.id]
        ),
        this.guard(
          "NOT EXISTS (SELECT 1 FROM json_each(?) staged WHERE NOT EXISTS (SELECT 1 FROM ariviso_images image WHERE image.id = json_extract(staged.value, '$.imageId') AND image.run_id = ? AND image.bytes_present = 1))",
          [captures2, run.id]
        ),
        this.sql(
          "INSERT INTO ariviso_captures (id, run_id, shard_key, item_key, variant_key, ordinal, image_id, profile_digest, test_id, test_retry, metadata_json) SELECT json_extract(value, '$.id'), ?, ?, json_extract(value, '$.itemKey'), json_extract(value, '$.variantKey'), json_extract(value, '$.ordinal'), json_extract(value, '$.imageId'), json_extract(value, '$.profileDigest'), json_extract(value, '$.testId'), json_extract(value, '$.testRetry'), json_extract(value, '$.metadataJson') FROM json_each(?) WHERE true ON CONFLICT(id) DO NOTHING",
          [run.id, input.key, captures2]
        ),
        this.guard(
          "NOT EXISTS (SELECT 1 FROM json_each(?) staged WHERE NOT EXISTS (SELECT 1 FROM ariviso_captures capture WHERE capture.id = json_extract(staged.value, '$.id') AND capture.run_id = ? AND capture.shard_key = ? AND capture.item_key = json_extract(staged.value, '$.itemKey') AND capture.variant_key = json_extract(staged.value, '$.variantKey') AND capture.ordinal = json_extract(staged.value, '$.ordinal') AND capture.image_id = json_extract(staged.value, '$.imageId') AND capture.profile_digest = json_extract(staged.value, '$.profileDigest') AND capture.test_id = json_extract(staged.value, '$.testId') AND capture.test_retry = json_extract(staged.value, '$.testRetry') AND capture.metadata_json = json_extract(staged.value, '$.metadataJson')))",
          [captures2, run.id, input.key]
        )
      ]);
    }
    const profileDigest = await captureProfilesDigest(input.captures);
    await atomic(this.database, [
      this.activeGuard(run),
      this.guard("(SELECT count(*) FROM ariviso_captures WHERE run_id = ? AND shard_key = ?) = ?", [
        run.id,
        input.key,
        input.captures.length
      ]),
      this.sql(
        "UPDATE ariviso_shards SET state = 'complete', manifest_digest = ?, full_profile_digest = ?, expected_json = ?, discovery_json = ?, source_run_id = ?, source_attempt = ? WHERE run_id = ? AND key = ? AND state = 'pending'",
        [
          input.manifestDigest,
          profileDigest,
          JSON.stringify(expected),
          input.verifiedDiscovery ? JSON.stringify(input.verifiedDiscovery) : null,
          run.id,
          run.attempt,
          run.id,
          input.key
        ]
      ),
      this.guard(
        "EXISTS (SELECT 1 FROM ariviso_shards WHERE run_id = ? AND key = ? AND manifest_digest = ? AND state = 'complete')",
        [run.id, input.key, input.manifestDigest]
      )
    ]);
  }
  async failRun(input) {
    const run = await this.run(input.runId);
    if (run.state === "failed") {
      return this.status(run.id);
    }
    const project = await this.project(run.project_id);
    await atomic(this.database, [
      this.projectGuard(project),
      this.activeGuard(run),
      this.guard(
        "EXISTS (SELECT 1 FROM ariviso_runs WHERE id = ? AND sealed_at IS NULL AND state = 'uploading')",
        [run.id]
      ),
      this.sql("UPDATE ariviso_runs SET state = 'failed' WHERE id = ?", [run.id]),
      this.audit(run, "capture-failed", { reason: input.reason.slice(0, 4096) }, input.now),
      ...this.touch(run, input.now)
    ]);
    return this.status(run.id);
  }
  async sealRun(input) {
    const run = await this.run(input.runId);
    if (run.sealed_at !== null) {
      return run;
    }
    await atomic(this.database, [
      this.activeGuard(run),
      this.guard("EXISTS (SELECT 1 FROM ariviso_runs WHERE id = ? AND state = 'uploading')", [
        run.id
      ]),
      this.guard(
        "NOT EXISTS (SELECT 1 FROM ariviso_shards WHERE run_id = ? AND state != 'complete') AND EXISTS (SELECT 1 FROM ariviso_captures WHERE run_id = ?)",
        [run.id, run.id]
      ),
      this.guard(
        "NOT EXISTS (SELECT 1 FROM ariviso_captures c JOIN ariviso_images i ON i.id = c.image_id WHERE c.run_id = ? AND i.bytes_present != 1)",
        [run.id]
      ),
      this.sql("UPDATE ariviso_runs SET sealed_at = ?, state = 'comparing' WHERE id = ?", [
        input.now,
        run.id
      ]),
      this.audit(run, "seal", {}, input.now),
      ...this.touch(run, input.now)
    ]);
    return this.run(run.id);
  }
  async referenceCandidates(projectId) {
    return this.rows(
      "SELECT snapshot.* FROM ariviso_snapshots snapshot WHERE snapshot.project_id = ? AND snapshot.reference_eligible = 1 AND NOT EXISTS (SELECT 1 FROM ariviso_snapshot_images image WHERE image.snapshot_id = snapshot.id AND image.copied != 1) ORDER BY snapshot.created_at DESC, snapshot.id",
      [projectId]
    );
  }
  async selectReferenceSnapshot(runId) {
    const run = await this.run(runId);
    const project = await this.project(run.project_id);
    if (project.fresh_setup && project.snapshot_id === null) return null;
    const snapshot = await this.sql(
      "SELECT snapshot.* FROM ariviso_snapshots snapshot JOIN ariviso_ancestry ancestry ON ancestry.ancestor_sha = snapshot.tested_sha AND ancestry.run_id = ? WHERE snapshot.project_id = ? AND snapshot.reference_eligible = 1 AND (? != 'main' OR snapshot.id = ?) AND NOT EXISTS (SELECT 1 FROM ariviso_snapshot_images image WHERE image.snapshot_id = snapshot.id AND image.copied != 1) ORDER BY (snapshot.id = ?) DESC, snapshot.created_at DESC, snapshot.id LIMIT 1",
      [run.id, project.id, run.kind, project.snapshot_id, project.snapshot_id]
    ).first();
    if (!snapshot) {
      throw new IncompleteError(
        "No retained accepted ancestor is eligible. Verify ancestry or capture current main."
      );
    }
    return snapshot.id;
  }
  async createComparison(input) {
    const run = await this.run(input.runId);
    const project = await this.project(run.project_id);
    const guards = [
      this.projectGuard(project),
      this.guard("EXISTS (SELECT 1 FROM ariviso_projects WHERE id = ? AND baseline_revision = ?)", [
        project.id,
        input.expectedBaselineRevision ?? project.baseline_revision
      ]),
      this.activeGuard(run),
      this.guard("EXISTS (SELECT 1 FROM ariviso_runs WHERE id = ? AND sealed_at IS NOT NULL)", [
        run.id
      ])
    ];
    if (input.referenceSnapshotId) {
      guards.push(
        this.guard(
          "EXISTS (SELECT 1 FROM ariviso_snapshots s JOIN ariviso_ancestry a ON a.ancestor_sha = s.tested_sha AND a.run_id = ? WHERE s.id = ? AND s.project_id = ? AND s.reference_eligible = 1)",
          [run.id, input.referenceSnapshotId, project.id]
        )
      );
      guards.push(
        this.guard(
          "NOT EXISTS (SELECT 1 FROM ariviso_snapshot_images WHERE snapshot_id = ? AND copied != 1)",
          [input.referenceSnapshotId]
        )
      );
      guards.push(
        this.sql(
          "INSERT INTO ariviso_pins (snapshot_id, reason, owner_id) VALUES (?, 'comparison', ?)",
          [input.referenceSnapshotId, input.id]
        )
      );
      guards.push(
        this.sql(
          "INSERT INTO work_retention_pins (run_id, owner, reason) SELECT run_id, ?, 'comparison' FROM ariviso_snapshots WHERE id = ?",
          [`comparison:${input.id}`, input.referenceSnapshotId]
        )
      );
    } else {
      guards.push(
        this.guard(
          "EXISTS (SELECT 1 FROM ariviso_projects WHERE id = ? AND fresh_setup = 1 AND snapshot_id IS NULL)",
          [project.id]
        )
      );
    }
    if (run.kind === "main") {
      guards.push(
        this.guard("EXISTS (SELECT 1 FROM ariviso_projects WHERE id = ? AND snapshot_id IS ?)", [
          project.id,
          input.referenceSnapshotId
        ])
      );
    }
    const tuple = `json_object('projectId', ?, 'itemKey', c.item_key, 'variantKey', c.variant_key, 'referenceDigest', ri.digest, 'candidateDigest', ci.digest, 'referenceProfileDigest', r.profile_digest, 'candidateProfileDigest', c.profile_digest, 'comparisonPolicyDigest', ?)`;
    const removalTuple = `json_object('projectId', ?, 'itemKey', r.item_key, 'variantKey', r.variant_key, 'referenceDigest', ri.digest, 'candidateDigest', NULL, 'referenceProfileDigest', r.profile_digest, 'candidateProfileDigest', NULL, 'comparisonPolicyDigest', ?)`;
    await atomic(this.database, [
      ...guards,
      this.sql(
        "INSERT INTO ariviso_comparisons (id, run_id, reference_snapshot_id, baseline_revision, policy_digest, ordinal, created_at) SELECT ?, ?, ?, ?, ?, COALESCE(MAX(ordinal), 0) + 1, ? FROM ariviso_comparisons WHERE run_id = ?",
        [
          input.id,
          run.id,
          input.referenceSnapshotId,
          project.baseline_revision,
          project.policy_digest,
          input.now,
          run.id
        ]
      ),
      this.sql(
        `INSERT INTO ariviso_comparison_rows (id, comparison_id, item_key, variant_key, ordinal, reference_capture_id, candidate_capture_id, tuple_json, outcome) SELECT ? || ':' || c.id, ?, c.item_key, c.variant_key, c.ordinal, r.id, c.id, ${tuple}, CASE WHEN r.id IS NULL THEN 'changed' ELSE 'pending' END FROM ariviso_captures c JOIN ariviso_images ci ON ci.id = c.image_id LEFT JOIN (SELECT capture.* FROM ariviso_snapshot_images si JOIN ariviso_captures capture ON capture.id = si.capture_id WHERE si.snapshot_id = ?) r ON r.item_key = c.item_key AND r.variant_key = c.variant_key LEFT JOIN ariviso_images ri ON ri.id = r.image_id WHERE c.run_id = ?`,
        [input.id, input.id, project.id, project.policy_digest, input.referenceSnapshotId, run.id]
      ),
      this.sql(
        `INSERT INTO ariviso_comparison_rows (id, comparison_id, item_key, variant_key, ordinal, reference_capture_id, candidate_capture_id, tuple_json, outcome) SELECT ? || ':removed:' || r.id, ?, r.item_key, r.variant_key, (SELECT COALESCE(MAX(ordinal), 0) + 1 FROM ariviso_captures WHERE run_id = ?) + r.ordinal, r.id, NULL, ${removalTuple}, 'changed' FROM ariviso_snapshot_images si JOIN ariviso_captures r ON r.id = si.capture_id JOIN ariviso_images ri ON ri.id = r.image_id WHERE si.snapshot_id = ? AND NOT EXISTS (SELECT 1 FROM ariviso_captures c WHERE c.run_id = ? AND c.item_key = r.item_key AND c.variant_key = r.variant_key)`,
        [
          input.id,
          input.id,
          run.id,
          project.id,
          project.policy_digest,
          input.referenceSnapshotId,
          run.id
        ]
      ),
      this.sql(
        "INSERT INTO work_tasks (id, kind, payload, max_attempts, available_at, created_at, updated_at) SELECT id, 'compare', json_object('taskId', id), ?, ?, ?, ? FROM ariviso_comparison_rows WHERE comparison_id = ? AND outcome = 'pending'",
        [input.maxAttempts, input.now, input.now, input.now, input.id]
      ),
      this.sql("UPDATE ariviso_runs SET comparison_id = ?, state = 'comparing' WHERE id = ?", [
        input.id,
        run.id
      ]),
      this.audit(
        run,
        "compare",
        { comparisonId: input.id, referenceSnapshotId: input.referenceSnapshotId },
        input.now
      ),
      ...this.touch(run, input.now)
    ]);
    return this.comparison(input.id);
  }
  async getComparisonTask(taskId) {
    const row = await this.one("SELECT * FROM ariviso_comparison_rows WHERE id = ?", [
      taskId
    ]);
    const comparison = await this.comparison(row.comparison_id);
    const readImage = /* @__PURE__ */ __name(async (captureId, reference) => {
      if (!captureId) return null;
      const image = reference ? await this.one(
        "SELECT i.id, si.object_key, i.digest, i.width, i.height, i.bytes, i.content_type FROM ariviso_snapshot_images si JOIN ariviso_images i ON i.id = si.image_id WHERE si.snapshot_id = ? AND si.capture_id = ? AND si.copied = 1",
        [comparison.reference_snapshot_id, captureId]
      ) : await this.one(
        "SELECT i.* FROM ariviso_images i JOIN ariviso_captures c ON c.image_id = i.id WHERE c.id = ? AND i.bytes_present = 1",
        [captureId]
      );
      return {
        imageId: image.id,
        objectKey: image.object_key,
        digest: image.digest,
        width: image.width,
        height: image.height,
        bytes: image.bytes,
        contentType: image.content_type
      };
    }, "readImage");
    const policyRecord = await this.one(
      "SELECT policy_json FROM ariviso_policies WHERE digest = ?",
      [comparison.policy_digest]
    );
    const policy = JSON.parse(policyRecord.policy_json);
    return {
      id: row.id,
      comparisonId: comparison.id,
      runId: comparison.run_id,
      policyDigest: comparison.policy_digest,
      policy,
      reference: await readImage(row.reference_capture_id, true),
      candidate: await readImage(row.candidate_capture_id, false)
    };
  }
  async getComparisonTaskState(taskId) {
    const state = await this.one(
      "SELECT run.active, run.comparison_id, row.comparison_id AS row_comparison_id FROM ariviso_comparison_rows row JOIN ariviso_comparisons comparison ON comparison.id = row.comparison_id JOIN ariviso_runs run ON run.id = comparison.run_id WHERE row.id = ?",
      [taskId]
    );
    if (!state.active || state.comparison_id !== state.row_comparison_id) {
      return { state: "superseded" };
    }
    const task = await getWork(this.database, taskId);
    if (!task) {
      throw new IncompleteError("The comparison task has not been scheduled.");
    }
    return task;
  }
  async claimComparisonTask(input) {
    const claimed = await claimWork(this.database, {
      id: input.taskId,
      token: input.owner,
      now: input.now,
      leaseMs: input.leaseMilliseconds
    });
    if (!claimed) return null;
    return this.getComparisonTask(input.taskId);
  }
  async failComparisonTask(input) {
    return failWork(this.database, {
      id: input.taskId,
      token: input.owner,
      now: input.now,
      retryAt: input.retryAt,
      error: input.error
    });
  }
  async commitComparisonResult(input) {
    const row = await this.one("SELECT * FROM ariviso_comparison_rows WHERE id = ?", [
      input.taskId
    ]);
    const tuple = JSON.parse(row.tuple_json);
    const result = tuple.referenceProfileDigest !== tuple.candidateProfileDigest ? { ...input.result, outcome: "changed" } : input.result;
    const comparison = await this.comparison(row.comparison_id);
    const run = await this.run(comparison.run_id);
    if (row.result_json) {
      if (row.result_json !== JSON.stringify(result)) {
        throw new ConflictError("A comparison result is immutable.");
      }
      return;
    }
    if (!Number.isFinite(input.result.ratio) || input.result.ratio < 0 || input.result.ratio > 1 || !Number.isSafeInteger(input.result.changedPixels) || input.result.changedPixels < 0) {
      throw new IncompleteError("The comparison result is invalid.");
    }
    const artifactStatements = [];
    for (const artifact of input.artifacts ?? []) {
      if (artifact.runId !== run.id) {
        throw new IncompleteError("Derived images belong to the comparison run.");
      }
      artifactStatements.push(
        this.sql(
          "INSERT INTO ariviso_images (id, run_id, digest, object_key, content_type, bytes, width, height, role) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?) ON CONFLICT(id) DO NOTHING",
          [
            artifact.id,
            artifact.runId,
            artifact.digest,
            artifact.objectKey,
            artifact.contentType,
            artifact.bytes,
            artifact.width,
            artifact.height,
            artifact.role
          ]
        )
      );
      artifactStatements.push(
        this.guard(
          "EXISTS (SELECT 1 FROM ariviso_images WHERE id = ? AND run_id = ? AND digest = ? AND object_key = ? AND content_type = ? AND bytes = ? AND width = ? AND height = ? AND role = ? AND bytes_present = 1)",
          [
            artifact.id,
            artifact.runId,
            artifact.digest,
            artifact.objectKey,
            artifact.contentType,
            artifact.bytes,
            artifact.width,
            artifact.height,
            artifact.role
          ]
        )
      );
    }
    if (input.result.maskImageId) {
      artifactStatements.push(
        this.guard(
          "EXISTS (SELECT 1 FROM ariviso_images WHERE id = ? AND run_id = ? AND role = 'mask' AND bytes_present = 1)",
          [input.result.maskImageId, run.id]
        )
      );
    }
    if (input.result.thumbnailImageId) {
      artifactStatements.push(
        this.guard(
          "EXISTS (SELECT 1 FROM ariviso_images WHERE id = ? AND run_id = ? AND role = 'thumbnail' AND bytes_present = 1)",
          [input.result.thumbnailImageId, run.id]
        )
      );
    }
    await atomic(this.database, [
      workLeaseAssertion(this.database, {
        id: input.taskId,
        token: input.leaseOwner,
        now: input.now
      }),
      this.activeGuard(run),
      this.guard("EXISTS (SELECT 1 FROM ariviso_runs WHERE id = ? AND comparison_id = ?)", [
        run.id,
        comparison.id
      ]),
      this.guard(
        "EXISTS (SELECT 1 FROM ariviso_comparisons WHERE id = ? AND state = 'comparing')",
        [comparison.id]
      ),
      this.guard(
        "EXISTS (SELECT 1 FROM ariviso_comparison_rows WHERE id = ? AND result_json IS NULL)",
        [row.id]
      ),
      ...artifactStatements,
      this.sql("UPDATE ariviso_comparison_rows SET outcome = ?, result_json = ? WHERE id = ?", [
        result.outcome,
        JSON.stringify(result),
        row.id
      ]),
      completeWorkStatement(this.database, {
        id: input.taskId,
        token: input.leaseOwner,
        now: input.now,
        result: JSON.stringify(result)
      })
    ]);
  }
  acceptanceValiditySql() {
    return `decision.verdict = 'approved' AND decision.revoked = 0
      AND decision.tuple_json = row.tuple_json
      AND EXISTS (SELECT 1 FROM ariviso_comparison_rows source_row
        JOIN ariviso_comparisons source_comparison ON source_comparison.id = source_row.comparison_id
        JOIN ariviso_runs source_run ON source_run.id = source_comparison.run_id
        JOIN ariviso_comparisons target_comparison ON target_comparison.id = row.comparison_id
        JOIN ariviso_runs target_run ON target_run.id = target_comparison.run_id
        WHERE source_row.id = decision.row_id AND source_row.decision_id = decision.id
        AND source_run.project_id = target_run.project_id
        AND (source_run.id = target_run.id OR EXISTS (SELECT 1 FROM ariviso_lineage lineage
          WHERE lineage.source_run_id = source_run.id AND lineage.target_run_id = target_run.id))
        AND NOT EXISTS (SELECT 1 FROM ariviso_decision_replacements replacement
          JOIN ariviso_decisions successor ON successor.id = replacement.replacement_decision_id
          WHERE replacement.source_decision_id = decision.id AND successor.revoked = 0
          AND (replacement.scope = 'shared' OR replacement.scope_run_id = target_run.id
            OR EXISTS (SELECT 1 FROM ariviso_lineage lineage
              WHERE lineage.source_run_id = replacement.scope_run_id AND lineage.target_run_id = target_run.id))))`;
  }
  eligibleAcceptanceSql() {
    return `EXISTS (SELECT 1 FROM ariviso_decisions decision
      WHERE decision.id = COALESCE(row.source_decision_id, row.decision_id)
      AND ${this.acceptanceValiditySql()})`;
  }
  async eligibleApprovalRowIds(comparisonId) {
    const rows = await this.rows(
      `SELECT row.id FROM ariviso_comparison_rows row WHERE row.comparison_id = ? AND row.outcome = 'changed' AND ${this.eligibleAcceptanceSql()} ORDER BY row.ordinal, row.id`,
      [comparisonId]
    );
    return rows.map((row) => row.id);
  }
  readyGuard(comparisonId) {
    return this.guard(
      `NOT EXISTS (SELECT 1 FROM ariviso_comparison_rows row WHERE row.comparison_id = ? AND (row.outcome NOT IN ('unchanged', 'changed') OR (row.outcome = 'changed' AND NOT ${this.eligibleAcceptanceSql()})))`,
      [comparisonId]
    );
  }
  currentBaselineGuard(projectId) {
    return this.guard(
      `NOT EXISTS (SELECT 1 FROM ariviso_projects project
        JOIN ariviso_snapshots snapshot ON snapshot.id = project.snapshot_id
        JOIN ariviso_comparison_rows row ON row.comparison_id = snapshot.comparison_id
        WHERE project.id = ? AND row.outcome = 'changed'
        AND NOT ${this.eligibleAcceptanceSql()})`,
      [projectId]
    );
  }
  async finalizeComparison(input) {
    const comparison = await this.comparison(input.comparisonId);
    const run = await this.run(comparison.run_id);
    const project = await this.project(run.project_id);
    if (comparison.state === "ready") {
      return this.status(run.id);
    }
    const pending = await this.sql(
      "SELECT 1 AS found FROM ariviso_comparison_rows WHERE comparison_id = ? AND outcome IN ('pending', 'error') LIMIT 1",
      [comparison.id]
    ).first();
    if (pending) {
      throw new IncompleteError("Required comparisons have not completed.");
    }
    const reuse = `SELECT decision.id FROM ariviso_decisions decision WHERE ${this.acceptanceValiditySql()} ORDER BY decision.created_at, decision.id LIMIT 1`;
    const automaticKind = `CASE WHEN row.reference_capture_id IS NULL THEN 'introduction' ELSE 'removal' END`;
    const eligibleAutomatic = `row.comparison_id = ? AND row.outcome = 'changed' AND row.source_decision_id IS NULL AND row.decision_id IS NULL AND (row.reference_capture_id IS NULL OR row.candidate_capture_id IS NULL) AND NOT EXISTS (SELECT 1 FROM ariviso_reservations reservation JOIN ariviso_decisions decision ON decision.id = reservation.decision_id JOIN ariviso_comparison_rows reserved_row ON reserved_row.id = decision.row_id JOIN ariviso_comparisons reserved_comparison ON reserved_comparison.id = reserved_row.comparison_id WHERE reservation.project_id = ? AND reservation.item_key = row.item_key AND reservation.variant_key = row.variant_key AND reservation.kind = ${automaticKind} AND (reservation.lineage_key = ? OR EXISTS (SELECT 1 FROM ariviso_lineage l WHERE l.source_run_id = reserved_comparison.run_id AND l.target_run_id = ?))) AND (row.reference_capture_id IS NOT NULL OR NOT EXISTS (SELECT 1 FROM ariviso_identity_history h WHERE h.project_id = ? AND h.item_key = row.item_key AND h.variant_key = row.variant_key AND (h.lineage_key = ? OR h.lineage_key = 'main')))`;
    const statements = [
      this.projectGuard(project),
      this.activeGuard(run),
      this.guard("EXISTS (SELECT 1 FROM ariviso_runs WHERE id = ? AND comparison_id = ?)", [
        run.id,
        comparison.id
      ]),
      this.guard(
        "EXISTS (SELECT 1 FROM ariviso_comparisons WHERE id = ? AND state = 'comparing')",
        [comparison.id]
      ),
      this.guard(
        "NOT EXISTS (SELECT 1 FROM ariviso_comparison_rows WHERE comparison_id = ? AND outcome IN ('pending', 'error'))",
        [comparison.id]
      ),
      this.sql(
        `UPDATE ariviso_comparison_rows AS row SET source_decision_id = (${reuse}) WHERE row.comparison_id = ? AND row.outcome = 'changed'`,
        [comparison.id]
      ),
      this.sql(
        `INSERT INTO ariviso_decisions (id, row_id, revision, verdict, kind, tuple_json, created_at) SELECT 'automatic:' || row.id, row.id, 1, 'approved', 'automatic', row.tuple_json, ? FROM ariviso_comparison_rows row WHERE ${eligibleAutomatic}`,
        [
          input.now,
          comparison.id,
          project.id,
          run.lineage_key,
          run.id,
          project.id,
          run.lineage_key
        ]
      ),
      this.sql(
        "UPDATE ariviso_comparison_rows SET decision_id = 'automatic:' || id, decision_revision = 1 WHERE comparison_id = ? AND EXISTS (SELECT 1 FROM ariviso_decisions WHERE id = 'automatic:' || ariviso_comparison_rows.id)",
        [comparison.id]
      ),
      this.sql(
        `INSERT INTO ariviso_reservations (project_id, lineage_key, item_key, variant_key, kind, decision_id) SELECT ?, ?, row.item_key, row.variant_key, ${automaticKind}, row.decision_id FROM ariviso_comparison_rows row WHERE row.comparison_id = ? AND row.decision_id IS NOT NULL`,
        [project.id, run.lineage_key, comparison.id]
      )
    ];
    statements.push(
      this.sql(
        "INSERT OR IGNORE INTO ariviso_identity_history (project_id, lineage_key, item_key, variant_key) SELECT ?, ?, item_key, variant_key FROM ariviso_captures WHERE run_id = ?",
        [project.id, run.lineage_key, run.id]
      )
    );
    statements.push(
      this.sql("UPDATE ariviso_comparisons SET state = 'ready' WHERE id = ?", [comparison.id])
    );
    statements.push(this.sql("UPDATE ariviso_runs SET state = 'reviewing' WHERE id = ?", [run.id]));
    statements.push(
      this.audit(run, "comparison-ready", { comparisonId: comparison.id }, input.now)
    );
    statements.push(...this.touch(run, input.now));
    await atomic(this.database, statements);
    return this.status(run.id);
  }
  async reconcileComparisons(input) {
    const candidates = await this.rows(
      "SELECT c.id FROM ariviso_comparisons c JOIN ariviso_runs r ON r.comparison_id = c.id WHERE r.active = 1 AND c.state = 'comparing' AND NOT EXISTS (SELECT 1 FROM ariviso_comparison_rows row WHERE row.comparison_id = c.id AND row.outcome IN ('pending', 'error')) ORDER BY c.created_at, c.id LIMIT ?",
      [input.limit]
    );
    const completed = [];
    const errors = [];
    for (const candidate of candidates) {
      try {
        await this.finalizeComparison({ comparisonId: candidate.id, now: input.now });
        completed.push(candidate.id);
      } catch (error) {
        errors.push({
          comparisonId: candidate.id,
          message: error instanceof Error ? error.message : "Comparison reconciliation failed"
        });
      }
    }
    return { completed, errors };
  }
  async status(runId) {
    const run = await this.run(runId);
    if (!run.active) {
      return { run, status: "superseded", pending: 0, rejected: 0 };
    }
    if (run.state === "failed") {
      const failures2 = await this.rows(
        "SELECT id, json_extract(detail_json, '$.reason') AS last_error FROM ariviso_audit WHERE run_id = ? AND action = 'capture-failed' ORDER BY created_at DESC, id LIMIT 1",
        [run.id]
      );
      return { run, status: "failed", pending: 0, rejected: 0, failures: failures2 };
    }
    if (!run.comparison_id || run.sealed_at === null) {
      return { run, status: "incomplete", pending: 0, rejected: 0 };
    }
    const comparison = await this.comparison(run.comparison_id);
    if (comparison.state === "invalidated") {
      return { run, comparison, status: "needs-recompare", pending: 0, rejected: 0 };
    }
    const failures = await this.rows(
      "SELECT task.id, task.last_error FROM work_tasks task JOIN ariviso_comparison_rows row ON row.id = task.id WHERE row.comparison_id = ? AND task.state = 'dead' ORDER BY task.id LIMIT 20",
      [comparison.id]
    );
    if (failures.length > 0) {
      return { run, comparison, status: "failed", pending: 0, rejected: 0, failures };
    }
    if (comparison.state !== "ready") {
      return { run, comparison, status: "comparing", pending: 0, rejected: 0 };
    }
    const counts = await this.one(
      `SELECT COALESCE(SUM(CASE WHEN row.outcome NOT IN ('changed', 'unchanged') OR (row.outcome = 'changed' AND NOT ${this.eligibleAcceptanceSql()}) THEN 1 ELSE 0 END), 0) AS pending, COALESCE(SUM(CASE WHEN decision.verdict = 'rejected' AND decision.revoked = 0 THEN 1 ELSE 0 END), 0) AS rejected FROM ariviso_comparison_rows row LEFT JOIN ariviso_decisions decision ON decision.id = row.decision_id WHERE row.comparison_id = ?`,
      [comparison.id]
    );
    const project = await this.project(run.project_id);
    const currentPromotion = project.promotion_id ? await this.sql(
      "SELECT 1 AS found FROM ariviso_promotions WHERE id = ? AND comparison_id = ? AND revoked = 0",
      [project.promotion_id, comparison.id]
    ).first() : null;
    if (counts.pending === 0 && !currentPromotion && comparison.baseline_revision !== project.baseline_revision) {
      return { run, comparison, status: "needs-recompare", ...counts };
    }
    return {
      run,
      comparison,
      status: counts.pending === 0 ? "passed" : counts.rejected > 0 ? "rejected" : "needs-review",
      ...counts
    };
  }
  async prepareStatusIntent(input) {
    const run = await this.run(input.runId);
    const project = await this.project(run.project_id);
    const status = await this.status(run.id);
    if (status.status === "superseded") {
      throw new ConflictError("A superseded attempt cannot publish a check.");
    }
    const conclusion = status.status === "passed" ? "success" : status.status === "needs-review" || status.status === "rejected" || status.status === "failed" ? "failure" : "pending";
    const comparison = run.comparison_id ? await this.comparison(run.comparison_id) : null;
    await atomic(this.database, [
      this.projectGuard(project),
      this.activeGuard(run),
      this.sql(
        "INSERT INTO ariviso_checks (id, project_id, external_run_id) VALUES (?, ?, ?) ON CONFLICT(id) DO NOTHING",
        [input.checkId, project.id, run.external_run_id]
      ),
      this.guard(
        "EXISTS (SELECT 1 FROM ariviso_checks WHERE id = ? AND project_id = ? AND external_run_id = ?)",
        [input.checkId, project.id, run.external_run_id]
      ),
      ...statusIntentStatements(this.database, {
        checkId: input.checkId,
        revision: project.revision,
        runId: run.id,
        attempt: run.attempt,
        comparisonRevision: comparison?.ordinal ?? 0,
        sourceRevision: project.revision,
        conclusion,
        detailsUrl: input.detailsUrl,
        maxAttempts: input.maxAttempts,
        now: input.now
      }),
      this.sql(
        "UPDATE ariviso_status_outbox SET delivered_at = ? WHERE run_id = ? AND run_revision <= ?",
        [input.now, run.id, run.revision]
      )
    ]);
    return { revision: project.revision, conclusion };
  }
  /** Use alongside the delivery lease check immediately before sending to GitHub. */
  async isStatusIntentCurrent(intent) {
    const current = await this.sql(
      "SELECT 1 AS found FROM ariviso_runs run JOIN ariviso_projects project ON project.id = run.project_id LEFT JOIN ariviso_comparisons comparison ON comparison.id = run.comparison_id WHERE run.id = ? AND run.active = 1 AND run.attempt = ? AND project.revision = ? AND COALESCE(comparison.ordinal, 0) = ?",
      [intent.run_id, intent.attempt, intent.source_revision, intent.comparison_revision]
    ).first();
    return current !== null;
  }
  /** Retire only work that no longer owns the current promotion. */
  async retireRun(input) {
    const run = await this.run(input.runId);
    const project = await this.project(run.project_id);
    await atomic(this.database, [
      this.projectGuard(project),
      this.guard(
        "NOT EXISTS (SELECT 1 FROM ariviso_projects project JOIN ariviso_snapshots snapshot ON snapshot.id = project.snapshot_id WHERE snapshot.run_id = ?)",
        [run.id]
      ),
      this.sql(
        "UPDATE ariviso_runs SET active = 0, state = 'superseded', closed_at = ? WHERE id = ?",
        [input.now, run.id]
      ),
      this.sql("UPDATE work_retained_runs SET closed_at = ? WHERE id = ?", [input.now, run.id]),
      this.sql(
        "DELETE FROM work_retention_pins WHERE owner IN (?, ?) OR owner IN (SELECT 'comparison:' || id FROM ariviso_comparisons WHERE run_id = ?)",
        [`review:${run.id}`, `inherited-by:${run.id}`, run.id]
      ),
      ...this.touch(run, input.now),
      this.audit(run, "retire", {}, input.now)
    ]);
  }
  async commandReplay(commandId, request) {
    const command = await this.sql("SELECT * FROM ariviso_commands WHERE id = ?", [
      commandId
    ]).first();
    if (!command) return null;
    if (command.request_json !== request) {
      throw new ConflictError("The command ID already belongs to another request.");
    }
    return parseCommandResult(command.result_json);
  }
  invalidateDependents(project, now) {
    return [
      this.sql(
        "UPDATE ariviso_runs SET revision = revision + 1 WHERE project_id = ? AND active = 1",
        [project.id]
      ),
      this.sql(
        "INSERT INTO ariviso_status_outbox (id, run_id, run_revision, created_at) SELECT ? || ':' || id, id, revision, ? FROM ariviso_runs WHERE project_id = ? AND active = 1",
        [crypto.randomUUID(), now, project.id]
      )
    ];
  }
  rollbackStatements(project, promotion, now) {
    return [
      this.guard(
        "EXISTS (SELECT 1 FROM ariviso_projects WHERE id = ? AND promotion_id = ? AND baseline_revision = ? AND snapshot_id = ?)",
        [project.id, promotion.id, project.baseline_revision, promotion.snapshot_id]
      ),
      this.guard(
        "NOT EXISTS (SELECT 1 FROM ariviso_snapshot_images WHERE snapshot_id IN (?, ?) AND copied != 1)",
        [promotion.snapshot_id, promotion.previous_snapshot_id]
      ),
      this.sql(
        "UPDATE ariviso_projects SET snapshot_id = ?, promotion_id = NULL, baseline_revision = baseline_revision + 1, fresh_setup = CASE WHEN ? IS NULL THEN 1 ELSE 0 END WHERE id = ?",
        [promotion.previous_snapshot_id, promotion.previous_snapshot_id, project.id]
      ),
      this.sql(
        "UPDATE ariviso_snapshots SET reference_eligible = 0, state = 'revoked' WHERE id = ?",
        [promotion.snapshot_id]
      ),
      this.sql("UPDATE ariviso_promotions SET revoked = 1 WHERE id = ?", [promotion.id]),
      this.sql(
        "UPDATE ariviso_comparisons SET state = 'invalidated' WHERE reference_snapshot_id = ? AND id != ?",
        [promotion.snapshot_id, promotion.comparison_id]
      ),
      this.sql("UPDATE ariviso_runs SET state = 'reviewing' WHERE comparison_id = ?", [
        promotion.comparison_id
      ]),
      this.sql(
        "INSERT INTO ariviso_status_outbox (id, run_id, run_revision, created_at) SELECT ? || ':' || id, id, revision, ? FROM ariviso_runs WHERE project_id = ? AND active = 1",
        [crypto.randomUUID(), now, project.id]
      )
    ];
  }
  async review(input) {
    const request = requestJson({ ...input });
    const replay = await this.commandReplay(input.commandId, request);
    if (replay) {
      return replay;
    }
    if (!input.actorId || !input.sessionId || input.targets.length === 0 || new Set(input.targets.map((target) => target.id)).size !== input.targets.length) {
      throw new IncompleteError(
        "A review command requires a maintainer, session, and unique targets."
      );
    }
    const comparison = await this.comparison(input.comparisonId);
    const run = await this.run(comparison.run_id);
    const project = await this.project(run.project_id);
    const rows = await this.comparisonRows(comparison.id);
    const selected = input.targets.map((target) => {
      const row = rows.find((entry) => entry.id === target.id);
      if (!row || row.outcome !== "changed" || row.decision_revision !== target.expectedRevision) {
        throw new ConflictError("A target changed or belongs to another comparison.", row);
      }
      return row;
    });
    if (input.wholeItemKey) {
      const itemRows = rows.filter(
        (row) => row.item_key === input.wholeItemKey && row.outcome === "changed"
      );
      if (itemRows.length !== selected.length || selected.some((row) => row.item_key !== input.wholeItemKey)) {
        throw new ConflictError("The whole-item target list must include every changed variant.");
      }
    }
    const acceptedHistory = await this.sql(
      "SELECT * FROM ariviso_promotions WHERE comparison_id = ? ORDER BY created_at DESC LIMIT 1",
      [comparison.id]
    ).first();
    if (acceptedHistory && !acceptedHistory.revoked && input.verdict === "approved") {
      return {
        commandId: input.commandId,
        revisions: input.targets,
        selection: input.selection,
        baselineRevision: project.baseline_revision,
        promotionId: project.promotion_id,
        noop: true
      };
    }
    let rollback = null;
    if (acceptedHistory && !acceptedHistory.revoked) {
      if (project.promotion_id !== acceptedHistory.id || input.expectedPromotionId !== acceptedHistory.id || input.expectedBaselineRevision !== project.baseline_revision) {
        throw new ConflictError(
          "This promotion is no longer current. Use explicit recovery.",
          project
        );
      }
      rollback = acceptedHistory;
    }
    if (comparison.state !== "ready" || !run.active || run.comparison_id !== comparison.id) {
      throw new ConflictError("Only the active complete comparison can be reviewed.", run);
    }
    const statements = [this.projectGuard(project), this.reviewGuard(run, comparison.id)];
    const previous = { decisions: [], rollback };
    const result = {
      commandId: input.commandId,
      revisions: [],
      selection: input.selection,
      baselineRevision: project.baseline_revision + (rollback ? 1 : 0),
      promotionId: rollback ? null : project.promotion_id
    };
    for (const row of selected) {
      const effectiveId = row.source_decision_id ?? row.decision_id;
      const effective = effectiveId ? await this.one("SELECT * FROM ariviso_decisions WHERE id = ?", [effectiveId]) : null;
      if (rollback && effective?.kind === "automatic") {
        throw new ConflictError(
          "Automatically accepted promoted history is protected. Capture a correction in a new main run.",
          row
        );
      }
      statements.push(
        this.guard(
          "EXISTS (SELECT 1 FROM ariviso_comparison_rows WHERE id = ? AND comparison_id = ? AND decision_revision = ?)",
          [row.id, comparison.id, row.decision_revision]
        )
      );
      previous.decisions.push({
        id: row.id,
        decisionId: row.decision_id,
        sourceDecisionId: row.source_decision_id,
        revision: row.decision_revision
      });
      const decisionId = crypto.randomUUID();
      statements.push(
        this.sql("UPDATE ariviso_decisions SET revoked = 1 WHERE id = ?", [row.decision_id])
      );
      statements.push(
        this.sql(
          "INSERT INTO ariviso_decisions (id, row_id, revision, verdict, kind, actor_id, command_id, tuple_json, created_at) VALUES (?, ?, ?, ?, 'human', ?, ?, ?, ?)",
          [
            decisionId,
            row.id,
            row.decision_revision + 1,
            input.verdict,
            input.actorId,
            input.commandId,
            row.tuple_json,
            input.now
          ]
        )
      );
      if (row.source_decision_id) {
        statements.push(
          this.sql(
            "INSERT INTO ariviso_decision_replacements (source_decision_id, replacement_decision_id, scope, scope_run_id) VALUES (?, ?, ?, ?)",
            [
              row.source_decision_id,
              decisionId,
              rollback || input.verdict === "approved" ? "descendants" : "shared",
              run.id
            ]
          )
        );
      }
      statements.push(
        this.sql(
          "INSERT INTO ariviso_decision_replacements (source_decision_id, replacement_decision_id, scope, scope_run_id) SELECT source_decision_id, ?, scope, scope_run_id FROM ariviso_decision_replacements WHERE replacement_decision_id = ?",
          [decisionId, effectiveId]
        )
      );
      statements.push(
        this.sql(
          "UPDATE ariviso_comparison_rows SET decision_revision = decision_revision + 1, decision_id = ?, source_decision_id = NULL WHERE id = ?",
          [decisionId, row.id]
        )
      );
      result.revisions.push({ id: row.id, expectedRevision: row.decision_revision + 1 });
    }
    if (rollback) {
      statements.push(...this.rollbackStatements(project, rollback, input.now));
    }
    statements.push(
      this.sql(
        "INSERT INTO ariviso_commands (id, request_json, actor_id, session_id, kind, comparison_id, previous_json, result_json, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
        [
          input.commandId,
          request,
          input.actorId,
          input.sessionId,
          input.verdict === "approved" ? "approve" : "reject",
          comparison.id,
          JSON.stringify(previous),
          JSON.stringify(result),
          input.now
        ]
      )
    );
    statements.push(
      this.audit(
        run,
        input.verdict === "approved" ? "approve" : "reject",
        { commandId: input.commandId, targets: input.targets },
        input.now,
        input.actorId
      )
    );
    statements.push(
      this.currentBaselineGuard(project.id),
      ...this.invalidateDependents(project, input.now),
      ...this.touch(run, input.now)
    );
    try {
      await atomic(this.database, statements);
    } catch (error) {
      const replay2 = await this.commandReplay(result.commandId, request);
      if (replay2) {
        return replay2;
      }
      throw error;
    }
    return result;
  }
  async undo(input) {
    const request = requestJson({ ...input });
    const replay = await this.commandReplay(input.undoCommandId, request);
    if (replay) {
      return replay;
    }
    const command = await this.one("SELECT * FROM ariviso_commands WHERE id = ?", [
      input.commandId
    ]);
    if (command.actor_id !== input.actorId || command.session_id !== input.sessionId || command.undone_by || command.kind === "undo") {
      throw new ConflictError("Only your saved command in this review session can be undone.");
    }
    const saved = parseCommandResult(command.result_json);
    const previous = JSON.parse(command.previous_json);
    const comparison = await this.comparison(command.comparison_id);
    const run = await this.run(comparison.run_id);
    const project = await this.project(run.project_id);
    if (project.baseline_revision !== input.expectedBaselineRevision) {
      throw new ConflictError("The baseline changed after this command.", project);
    }
    if (!run.active || run.comparison_id !== comparison.id || comparison.state !== "ready") {
      throw new ConflictError("The command no longer targets the active comparison.");
    }
    const promotion = project.promotion_id ? await this.one("SELECT * FROM ariviso_promotions WHERE id = ?", [
      project.promotion_id
    ]) : null;
    const historical = await this.sql(
      "SELECT 1 AS found FROM ariviso_promotions WHERE comparison_id = ? LIMIT 1",
      [comparison.id]
    ).first();
    if (historical && !previous.rollback && promotion?.comparison_id !== comparison.id) {
      throw new ConflictError("A later promotion prevents Undo. Use explicit recovery.");
    }
    const rollingBack = command.kind === "approve" && promotion?.comparison_id === comparison.id ? promotion : null;
    const restoring = previous.rollback;
    if (restoring && (project.baseline_revision !== saved.baselineRevision || project.snapshot_id !== restoring.previous_snapshot_id || project.promotion_id !== null)) {
      throw new ConflictError("The rejection rollback has changed. Its Undo is stale.");
    }
    const statements = [
      this.projectGuard(project),
      this.reviewGuard(run, comparison.id),
      this.guard("EXISTS (SELECT 1 FROM ariviso_commands WHERE id = ? AND undone_by IS NULL)", [
        command.id
      ])
    ];
    const result = {
      commandId: input.undoCommandId,
      revisions: [],
      selection: saved.selection,
      baselineRevision: project.baseline_revision + (rollingBack || restoring ? 1 : 0),
      promotionId: restoring ? crypto.randomUUID() : rollingBack ? null : project.promotion_id
    };
    for (const target of saved.revisions) {
      const prior = previous.decisions.find((entry) => entry.id === target.id);
      if (!prior) {
        throw new IncompleteError("The saved command does not contain its prior verdict.");
      }
      statements.push(
        this.guard(
          "EXISTS (SELECT 1 FROM ariviso_comparison_rows WHERE id = ? AND decision_revision = ?)",
          [target.id, target.expectedRevision]
        )
      );
      statements.push(
        this.sql(
          "UPDATE ariviso_decisions SET revoked = 1 WHERE id = (SELECT decision_id FROM ariviso_comparison_rows WHERE id = ?)",
          [target.id]
        )
      );
      statements.push(
        this.sql("UPDATE ariviso_decisions SET revoked = 0 WHERE id = ?", [prior.decisionId])
      );
      statements.push(
        this.sql(
          "UPDATE ariviso_comparison_rows SET decision_revision = decision_revision + 1, decision_id = ?, source_decision_id = ? WHERE id = ?",
          [prior.decisionId, prior.sourceDecisionId, target.id]
        )
      );
      result.revisions.push({ id: target.id, expectedRevision: target.expectedRevision + 1 });
    }
    if (rollingBack) {
      statements.push(...this.rollbackStatements(project, rollingBack, input.now));
    }
    if (restoring) {
      statements.push(this.readyGuard(comparison.id));
      statements.push(
        this.guard(
          "NOT EXISTS (SELECT 1 FROM ariviso_snapshot_images WHERE snapshot_id IN (?, ?) AND copied != 1)",
          [restoring.snapshot_id, restoring.previous_snapshot_id]
        )
      );
      statements.push(
        this.sql(
          "UPDATE ariviso_snapshots SET reference_eligible = 1, state = 'accepted' WHERE id = ?",
          [restoring.snapshot_id]
        )
      );
      statements.push(
        this.sql(
          "INSERT INTO ariviso_promotions (id, project_id, snapshot_id, previous_snapshot_id, comparison_id, baseline_revision, command_id, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
          [
            result.promotionId,
            project.id,
            restoring.snapshot_id,
            restoring.previous_snapshot_id,
            comparison.id,
            result.baselineRevision,
            input.undoCommandId,
            input.now
          ]
        )
      );
      statements.push(
        this.sql(
          "UPDATE ariviso_projects SET snapshot_id = ?, promotion_id = ?, baseline_revision = baseline_revision + 1, fresh_setup = 0 WHERE id = ?",
          [restoring.snapshot_id, result.promotionId, project.id]
        )
      );
      statements.push(
        this.sql("UPDATE ariviso_runs SET state = 'accepted' WHERE id = ?", [run.id])
      );
    }
    statements.push(
      this.sql("UPDATE ariviso_commands SET undone_by = ? WHERE id = ?", [
        input.undoCommandId,
        command.id
      ])
    );
    statements.push(
      this.sql(
        "INSERT INTO ariviso_commands (id, request_json, actor_id, session_id, kind, comparison_id, previous_json, result_json, created_at) VALUES (?, ?, ?, ?, 'undo', ?, ?, ?, ?)",
        [
          input.undoCommandId,
          request,
          input.actorId,
          input.sessionId,
          comparison.id,
          JSON.stringify({ decisions: [], rollback: null }),
          JSON.stringify(result),
          input.now
        ]
      )
    );
    statements.push(
      this.audit(
        run,
        "undo",
        { commandId: command.id, undoCommandId: input.undoCommandId },
        input.now,
        input.actorId
      )
    );
    statements.push(
      this.currentBaselineGuard(project.id),
      ...this.invalidateDependents(project, input.now),
      ...this.touch(run, input.now)
    );
    try {
      await atomic(this.database, statements);
    } catch (error) {
      const replay2 = await this.commandReplay(result.commandId, request);
      if (replay2) {
        return replay2;
      }
      throw error;
    }
    return result;
  }
  async preparePromotion(input) {
    const existing = await this.sql("SELECT * FROM ariviso_snapshots WHERE id = ?", [
      input.snapshotId
    ]).first();
    if (existing) {
      if (existing.comparison_id !== input.comparisonId || existing.prefix !== input.prefix || existing.state === "revoked") {
        throw new ConflictError("The snapshot ID belongs to another or revoked promotion.");
      }
      return this.pendingSnapshotCopies(existing.id, input.copyLimit ?? 100);
    }
    const comparison = await this.comparison(input.comparisonId);
    const run = await this.run(comparison.run_id);
    const project = await this.project(run.project_id);
    if (run.kind !== "main" || !input.prefix.startsWith("baselines/")) {
      throw new IncompleteError("Only a complete main run can use a protected baseline prefix.");
    }
    await atomic(this.database, [
      this.projectGuard(project),
      this.activeGuard(run),
      this.readyGuard(comparison.id),
      this.guard(
        "EXISTS (SELECT 1 FROM ariviso_comparisons WHERE id = ? AND state = 'ready' AND baseline_revision = ? AND reference_snapshot_id IS ?)",
        [comparison.id, project.baseline_revision, project.snapshot_id]
      ),
      this.guard(
        "EXISTS (SELECT 1 FROM ariviso_runs WHERE id = ? AND comparison_id = ? AND sealed_at IS NOT NULL)",
        [run.id, comparison.id]
      ),
      this.sql(
        "INSERT INTO ariviso_snapshots (id, project_id, run_id, comparison_id, tested_sha, prefix, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)",
        [
          input.snapshotId,
          project.id,
          run.id,
          comparison.id,
          run.tested_sha,
          input.prefix,
          input.now
        ]
      ),
      this.sql(
        "INSERT INTO ariviso_snapshot_images (snapshot_id, capture_id, image_id, object_key, digest) SELECT ?, c.id, i.id, ? || '/' || i.id, i.digest FROM ariviso_captures c JOIN ariviso_images i ON i.id = c.image_id WHERE c.run_id = ?",
        [input.snapshotId, input.prefix, run.id]
      ),
      this.sql(
        "INSERT INTO ariviso_pins (snapshot_id, reason, owner_id) VALUES (?, 'promotion', ?)",
        [input.snapshotId, input.snapshotId]
      ),
      this.sql(
        "INSERT INTO work_retention_pins (run_id, owner, reason) VALUES (?, ?, 'promotion')",
        [run.id, `promotion:${input.snapshotId}`]
      )
    ]);
    return this.pendingSnapshotCopies(input.snapshotId, input.copyLimit ?? 100);
  }
  async cancelPreparedPromotion(input) {
    const snapshot = await this.one("SELECT * FROM ariviso_snapshots WHERE id = ?", [
      input.snapshotId
    ]);
    if (snapshot.state === "revoked") return;
    const run = await this.run(snapshot.run_id);
    const project = await this.project(run.project_id);
    await atomic(this.database, [
      this.projectGuard(project),
      this.guard(
        "EXISTS (SELECT 1 FROM ariviso_snapshots WHERE id = ? AND state = 'copying' AND reference_eligible = 0)",
        [snapshot.id]
      ),
      this.guard("NOT EXISTS (SELECT 1 FROM ariviso_promotions WHERE snapshot_id = ?)", [
        snapshot.id
      ]),
      this.sql("UPDATE ariviso_snapshots SET state = 'revoked' WHERE id = ?", [snapshot.id]),
      this.sql(
        "DELETE FROM ariviso_pins WHERE snapshot_id = ? AND reason = 'promotion' AND owner_id = ?",
        [snapshot.id, snapshot.id]
      ),
      this.sql(
        "DELETE FROM work_retention_pins WHERE run_id = ? AND owner = ? AND reason = 'promotion'",
        [run.id, `promotion:${snapshot.id}`]
      ),
      this.audit(run, "cancel-prepared-promotion", { snapshotId: snapshot.id }, input.now),
      ...this.touch(run, input.now)
    ]);
  }
  async pendingSnapshotCopies(snapshotId, limit) {
    if (!Number.isSafeInteger(limit) || limit < 1) {
      throw new IncompleteError("A positive copy-page limit is required.");
    }
    return this.rows(
      "SELECT si.*, i.object_key AS source_object_key, i.bytes, i.content_type FROM ariviso_snapshot_images si JOIN ariviso_images i ON i.id = si.image_id WHERE si.snapshot_id = ? AND si.copied = 0 ORDER BY si.capture_id LIMIT ?",
      [snapshotId, limit]
    );
  }
  async snapshotCopies(snapshotId) {
    return this.rows(
      "SELECT si.*, i.object_key AS source_object_key FROM ariviso_snapshot_images si JOIN ariviso_images i ON i.id = si.image_id WHERE si.snapshot_id = ?",
      [snapshotId]
    );
  }
  /** Mark a copy only after an R2 read verifies its digest at the protected key. */
  async recordSnapshotCopy(input) {
    await atomic(this.database, [
      this.guard("EXISTS (SELECT 1 FROM ariviso_snapshots WHERE id = ? AND state = 'copying')", [
        input.snapshotId
      ]),
      this.guard(
        "EXISTS (SELECT 1 FROM ariviso_snapshot_images WHERE snapshot_id = ? AND capture_id = ? AND object_key = ? AND digest = ?)",
        [input.snapshotId, input.captureId, input.objectKey, input.digest]
      ),
      this.sql(
        "UPDATE ariviso_snapshot_images SET copied = 1 WHERE snapshot_id = ? AND capture_id = ?",
        [input.snapshotId, input.captureId]
      )
    ]);
  }
  async promote(input) {
    const snapshot = await this.one("SELECT * FROM ariviso_snapshots WHERE id = ?", [
      input.snapshotId
    ]);
    const comparison = await this.comparison(snapshot.comparison_id);
    const run = await this.run(snapshot.run_id);
    const project = await this.project(run.project_id);
    if (project.promotion_id === input.promotionId && project.snapshot_id === snapshot.id) {
      return project;
    }
    const statements = [
      this.projectGuard(project),
      this.activeGuard(run),
      this.readyGuard(comparison.id),
      this.guard(
        "EXISTS (SELECT 1 FROM ariviso_projects WHERE id = ? AND baseline_revision = ? AND snapshot_id IS ?)",
        [project.id, input.expectedBaselineRevision, comparison.reference_snapshot_id]
      ),
      this.guard(
        "EXISTS (SELECT 1 FROM ariviso_runs WHERE id = ? AND kind = 'main' AND comparison_id = ? AND sealed_at IS NOT NULL)",
        [run.id, comparison.id]
      ),
      this.guard(
        "EXISTS (SELECT 1 FROM ariviso_comparisons WHERE id = ? AND state = 'ready' AND baseline_revision = ?)",
        [comparison.id, project.baseline_revision]
      ),
      this.guard("EXISTS (SELECT 1 FROM ariviso_snapshots WHERE id = ? AND state = 'copying')", [
        snapshot.id
      ]),
      this.guard(
        "NOT EXISTS (SELECT 1 FROM ariviso_snapshot_images WHERE snapshot_id = ? AND copied != 1) AND (SELECT count(*) FROM ariviso_snapshot_images WHERE snapshot_id = ?) = (SELECT count(*) FROM ariviso_captures WHERE run_id = ?)",
        [snapshot.id, snapshot.id, run.id]
      )
    ];
    if (project.snapshot_id) {
      statements.push(
        this.guard(
          "EXISTS (SELECT 1 FROM ariviso_snapshots s JOIN ariviso_ancestry a ON a.ancestor_sha = s.tested_sha AND a.run_id = ? WHERE s.id = ? AND s.reference_eligible = 1)",
          [run.id, project.snapshot_id]
        )
      );
      statements.push(
        this.sql(
          "INSERT OR IGNORE INTO ariviso_pins (snapshot_id, reason, owner_id) VALUES (?, 'rollback', ?)",
          [project.snapshot_id, input.promotionId]
        )
      );
    }
    statements.push(
      this.sql(
        "INSERT INTO ariviso_promotions (id, project_id, snapshot_id, previous_snapshot_id, comparison_id, baseline_revision, command_id, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
        [
          input.promotionId,
          project.id,
          snapshot.id,
          project.snapshot_id,
          comparison.id,
          project.baseline_revision + 1,
          input.commandId ?? null,
          input.now
        ]
      )
    );
    statements.push(
      this.sql(
        "UPDATE ariviso_snapshots SET state = 'accepted', reference_eligible = 1 WHERE id = ?",
        [snapshot.id]
      )
    );
    statements.push(
      this.sql(
        "UPDATE work_retention_pins SET reason = 'baseline' WHERE run_id = ? AND owner = ?",
        [run.id, `promotion:${snapshot.id}`]
      )
    );
    statements.push(
      this.sql(
        "UPDATE ariviso_projects SET snapshot_id = ?, promotion_id = ?, baseline_revision = baseline_revision + 1, fresh_setup = 0 WHERE id = ?",
        [snapshot.id, input.promotionId, project.id]
      )
    );
    statements.push(this.sql("UPDATE ariviso_runs SET state = 'accepted' WHERE id = ?", [run.id]));
    statements.push(
      this.sql(
        "INSERT OR IGNORE INTO ariviso_identity_history (project_id, lineage_key, item_key, variant_key) SELECT ?, 'main', item_key, variant_key FROM ariviso_captures WHERE run_id = ?",
        [project.id, run.id]
      )
    );
    statements.push(
      this.sql(
        "UPDATE ariviso_comparisons SET state = 'invalidated' WHERE id != ? AND run_id IN (SELECT id FROM ariviso_runs WHERE project_id = ? AND active = 1 AND state != 'accepted')",
        [comparison.id, project.id]
      )
    );
    statements.push(
      this.audit(
        run,
        "promote",
        { snapshotId: snapshot.id, promotionId: input.promotionId },
        input.now
      )
    );
    statements.push(
      ...this.invalidateDependents(project, input.now),
      ...this.touch(run, input.now)
    );
    await atomic(this.database, statements);
    return this.project(project.id);
  }
};

// implementation-snapshot/object-stream.ts
import { createHash as createHash2 } from "node:crypto";

// implementation-snapshot/common.ts
import { createHash } from "node:crypto";
async function recordEvent(database, input) {
  const id = `${input.kind}:${input.subject}:${input.code}`;
  await database.prepare(`INSERT INTO operations_events(id,kind,subject_id,code,first_seen_at,last_seen_at)
    VALUES(?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET last_seen_at=excluded.last_seen_at,
    occurrences=operations_events.occurrences+1,resolved_at=NULL`).bind(id, input.kind, input.subject, input.code, input.now, input.now).run();
}
__name(recordEvent, "recordEvent");
async function resolveEvents(database, kind, subject, now) {
  await database.prepare(
    "UPDATE operations_events SET resolved_at=? WHERE kind=? AND subject_id=? AND resolved_at IS NULL"
  ).bind(now, kind, subject).run();
}
__name(resolveEvents, "resolveEvents");
async function digestStream(stream, maximum) {
  const hash = createHash("sha256");
  const reader = stream.getReader();
  let bytes = 0;
  try {
    while (true) {
      const chunk = await reader.read();
      if (chunk.done) break;
      bytes += chunk.value.byteLength;
      if (bytes > maximum) {
        await reader.cancel();
        throw new Error("Object exceeds the configured operations limit.");
      }
      hash.update(chunk.value);
    }
  } finally {
    reader.releaseLock();
  }
  return { digest: hash.digest("hex"), bytes };
}
__name(digestStream, "digestStream");
async function putKnownLength(store, key, body, bytes, options) {
  if (!Number.isSafeInteger(bytes) || bytes < 0) {
    await body.cancel();
    throw new Error("Object length must be a nonnegative safe integer.");
  }
  const fixed = new FixedLengthStream(bytes);
  const controller = new AbortController();
  const transfer = body.pipeTo(fixed.writable, { signal: controller.signal });
  void transfer.catch(() => {
  });
  try {
    const saved = await store.put(key, fixed.readable, options);
    if (saved === null) throw new Error("Object changed during its conditional copy.");
    await transfer;
  } finally {
    controller.abort();
    if (!fixed.readable.locked) await fixed.readable.cancel().catch(() => {
    });
    await transfer.catch(() => {
    });
  }
}
__name(putKnownLength, "putKnownLength");
async function copyVerifiedObject(params) {
  const source = await params.source.get(params.sourceKey);
  if (!source || source.size > params.maximum || params.expectedBytes !== void 0 && source.size !== params.expectedBytes) {
    await source?.body.cancel();
    throw new Error("Required source object is missing or has an invalid size.");
  }
  const hash = createHash("sha256");
  let bytes = 0;
  const verifying = source.body.pipeThrough(
    new TransformStream({
      transform(chunk, controller) {
        bytes += chunk.byteLength;
        if (bytes > params.maximum)
          throw new Error("Object exceeds the configured operations limit.");
        hash.update(chunk);
        controller.enqueue(chunk);
      }
    })
  );
  try {
    const existing = await params.destination.get(params.destinationKey);
    if (existing) {
      await existing.body.cancel();
      await digestStream(verifying, params.maximum);
    } else {
      await putKnownLength(params.destination, params.destinationKey, verifying, source.size, {
        onlyIf: { etagDoesNotMatch: "*" },
        httpMetadata: { contentType: source.httpMetadata?.contentType ?? "application/octet-stream" },
        customMetadata: source.customMetadata
      });
    }
  } finally {
    if (!verifying.locked) await verifying.cancel().catch(() => {
    });
  }
  const verified = { bytes, digest: hash.digest("hex") };
  if (verified.bytes !== source.size || params.expectedDigest && verified.digest !== params.expectedDigest) {
    throw new Error("Source object digest or length does not match its record.");
  }
  const stored = await params.destination.get(params.destinationKey);
  if (!stored || stored.size !== verified.bytes) {
    await stored?.body.cancel();
    throw new Error("Destination object was not stored in full.");
  }
  const confirmed = await digestStream(stored.body, params.maximum);
  if (confirmed.digest !== verified.digest || confirmed.bytes !== verified.bytes) {
    throw new Error("Destination object failed integrity verification.");
  }
  return {
    ...confirmed,
    contentType: source.httpMetadata?.contentType ?? "application/octet-stream"
  };
}
__name(copyVerifiedObject, "copyVerifiedObject");
function safeKey(key) {
  if (!key || key.startsWith("/") || key.includes("\\") || key.split("/").some((part) => !part || part === "." || part === "..") || new TextEncoder().encode(key).length > 900) {
    throw new Error("Object key is outside the supported private namespace.");
  }
  return key;
}
__name(safeKey, "safeKey");
async function mapConcurrent(values, concurrency, operation) {
  const results = [];
  let cursor = 0;
  const workers = await Promise.allSettled(Array.from({ length: Math.min(concurrency, values.length) }, async () => {
    while (cursor < values.length) {
      const index = cursor++;
      const value = values[index];
      if (value === void 0) throw new Error("Missing concurrent operation input.");
      results[index] = await operation(value);
    }
  }));
  for (const worker of workers) {
    if (worker.status === "rejected") throw worker.reason;
  }
  return results;
}
__name(mapConcurrent, "mapConcurrent");

// implementation-snapshot/object-stream.ts
async function putBoundedStream(store, key, source, maximum) {
  if (!Number.isSafeInteger(maximum) || maximum < 1 || source.bytes !== void 0 && (!Number.isSafeInteger(source.bytes) || source.bytes < 1 || source.bytes > maximum)) {
    await source.body.cancel();
    throw new Error("Database export has an invalid declared length.");
  }
  const hash = createHash2("sha256");
  let bytes = 0;
  function observe(chunk) {
    bytes += chunk.byteLength;
    if (bytes > maximum) throw new Error("Database export exceeds configured bound.");
    hash.update(chunk);
  }
  __name(observe, "observe");
  if (source.bytes !== void 0) {
    const bounded = source.body.pipeThrough(new TransformStream({
      transform(chunk, controller) {
        observe(chunk);
        controller.enqueue(chunk);
      }
    }));
    await putKnownLength(store, key, bounded, source.bytes, {
      httpMetadata: { contentType: "application/sql" }
    });
  } else {
    const reader = source.body.getReader();
    let upload;
    const buffer = new Uint8Array(Math.min(8 * 1024 * 1024, maximum));
    const parts = [];
    let buffered = 0;
    let complete = false;
    try {
      upload = await store.createMultipartUpload(key, { httpMetadata: { contentType: "application/sql" } });
      while (true) {
        const next = await reader.read();
        if (next.done) break;
        observe(next.value);
        for (let offset = 0; offset < next.value.byteLength; ) {
          const take = Math.min(buffer.byteLength - buffered, next.value.byteLength - offset);
          buffer.set(next.value.subarray(offset, offset + take), buffered);
          buffered += take;
          offset += take;
          if (buffered === buffer.byteLength) {
            if (parts.length >= 1e4) throw new Error("Database export has too many parts.");
            parts.push(await upload.uploadPart(parts.length + 1, buffer));
            buffered = 0;
          }
        }
      }
      if (!bytes) throw new Error("Database export is empty.");
      if (buffered) {
        if (parts.length >= 1e4) throw new Error("Database export has too many parts.");
        parts.push(await upload.uploadPart(parts.length + 1, buffer.subarray(0, buffered)));
      }
      await upload.complete(parts);
      complete = true;
    } finally {
      await reader.cancel().catch(() => {
      });
      reader.releaseLock();
      if (!complete) await upload?.abort();
    }
  }
  return { bytes, digest: hash.digest("hex") };
}
__name(putBoundedStream, "putBoundedStream");

// implementation-snapshot/backups.ts
import { createHash as createHash3 } from "node:crypto";

// implementation-snapshot/backup-objects.ts
var BACKUP_RETENTION = 30 * 24 * 60 * 60 * 1e3;
function noBackupDeletion(context2) {
  return assertion(context2.database, "NOT EXISTS(SELECT 1 FROM operations_backup_objects WHERE state='deleting')");
}
__name(noBackupDeletion, "noBackupDeletion");

// implementation-snapshot/backups.ts
function backupGuard(context2, id, token) {
  return assertion(
    context2.database,
    "EXISTS(SELECT 1 FROM operations_backups WHERE id=? AND lease_token=? AND lease_until>?)",
    [id, token, context2.now()]
  );
}
__name(backupGuard, "backupGuard");
async function backupDaily(context2, exporter) {
  const { database, budget } = context2;
  const report = { completed: [], deferred: [], attention: [], hasMore: false };
  const day = new Date(context2.now()).toISOString().slice(0, 10);
  const unfinished = await database.prepare(
    "SELECT * FROM operations_backups WHERE state IN ('exporting','copying') ORDER BY created_at LIMIT 1"
  ).first();
  const id = unfinished?.id ?? day;
  const existing = unfinished ?? await database.prepare("SELECT * FROM operations_backups WHERE id=?").bind(id).first();
  if (existing && !["exporting", "copying"].includes(existing.state)) return report;
  if (!existing) {
    await atomic(database, [
      noBackupDeletion(context2),
      assertion(
        database,
        "NOT EXISTS(SELECT 1 FROM work_retained_runs WHERE byte_state='deleting')"
      ),
      database.prepare("INSERT INTO operations_backups(id,state,created_at) VALUES(?,'exporting',?)").bind(id, context2.now()),
      database.prepare(
        `INSERT INTO work_retention_pins(run_id,owner,reason) SELECT id,?,'recovery' FROM work_retained_runs WHERE byte_state='live'`
      ).bind(`backup:${id}`)
    ]);
  }
  const token = crypto.randomUUID();
  const row = await database.prepare(`UPDATE operations_backups SET lease_token=?,lease_until=? WHERE id=? AND state IN ('exporting','copying')
    AND (lease_token IS NULL OR lease_until<=?) RETURNING *`).bind(token, context2.now() + budget.leaseMilliseconds, id, context2.now()).first();
  if (!row) {
    report.deferred.push(id);
    return report;
  }
  const prefix = `backups/${id}/`;
  try {
    if (row.state === "exporting") {
      const key = `${prefix}database-${token}.sql`;
      const source = await exporter.export();
      const { bytes, digest } = await putBoundedStream(context2.backups, key, source, budget.maximumDatabaseBytes);
      const saved = await context2.backups.get(key);
      if (!saved) throw new Error("Database export was not saved.");
      const verified = await digestStream(saved.body, budget.maximumDatabaseBytes);
      if (!bytes || verified.bytes !== bytes || verified.digest !== digest)
        throw new Error("Database export integrity failed.");
      await atomic(database, [
        backupGuard(context2, id, token),
        assertion(
          database,
          "NOT EXISTS(SELECT 1 FROM work_retained_runs WHERE byte_state='deleting')"
        ),
        database.prepare(
          "INSERT INTO work_retention_pins(run_id,owner,reason) SELECT id,?,'recovery' FROM work_retained_runs WHERE byte_state='live' ON CONFLICT(run_id,owner) DO NOTHING"
        ).bind(`backup:${id}`),
        // Freeze the required superset once while recovery pins protect the SQL snapshot.
        database.prepare(`INSERT OR IGNORE INTO operations_backup_inventory(backup_id,source,object_key,digest,bytes)
          SELECT ?,'images',object_key,digest,bytes FROM ariviso_images WHERE bytes_present=1`).bind(id),
        database.prepare(`INSERT OR IGNORE INTO operations_backup_inventory(backup_id,source,object_key,digest,bytes)
          SELECT ?,'images',copy.object_key,copy.digest,image.bytes FROM ariviso_snapshot_images copy
          JOIN ariviso_images image ON image.id=copy.image_id WHERE copy.copied=1`).bind(id),
        database.prepare(`INSERT OR IGNORE INTO operations_backup_inventory(backup_id,source,object_key)
          SELECT ?,'quarantine',provenance.plan_object_key FROM ingest_run_provenance provenance
          JOIN work_retention_pins pin ON pin.run_id=provenance.run_id WHERE pin.owner=?`).bind(id, `backup:${id}`),
        database.prepare(`INSERT OR IGNORE INTO operations_backup_inventory(backup_id,source,object_key)
          SELECT ?,'quarantine',manifest.object_key FROM ingest_manifests manifest
          JOIN work_retention_pins pin ON pin.run_id=manifest.run_id WHERE pin.owner=?`).bind(id, `backup:${id}`),
        database.prepare(
          `UPDATE operations_backups SET state='copying',database_key=?,database_digest=?,database_bytes=? WHERE id=?`
        ).bind(key, digest, bytes, id)
      ]);
      report.hasMore = true;
      report.deferred.push(id);
      return report;
    }
    if (row.source_kind !== 4) {
      const cursor = row.cursor ? JSON.parse(row.cursor) : ["", ""];
      if (!Array.isArray(cursor) || cursor.length !== 2 || cursor.some((value) => typeof value !== "string"))
        throw new Error("Backup inventory cursor is invalid.");
      await atomic(database, [
        backupGuard(context2, id, token),
        database.prepare(`INSERT OR IGNORE INTO operations_backup_objects(source,object_key,backup_key,state,retire_after)
          SELECT source,object_key,'backup-objects/'||source||'/'||lower(hex(randomblob(16))),'pending',?
          FROM operations_backup_inventory WHERE backup_id=? AND (source,object_key)>(?,?)
          ORDER BY source,object_key LIMIT ?`).bind(context2.now() + BACKUP_RETENTION, id, cursor[0], cursor[1], budget.objectsPerStep)
      ]);
      const required2 = await database.prepare(`SELECT inventory.source,inventory.object_key AS key,
        inventory.digest,inventory.bytes,copy.backup_key,copy.state,copy.digest AS copied_digest,
        copy.bytes AS copied_bytes,copy.content_type
        FROM operations_backup_inventory inventory JOIN operations_backup_objects copy
          ON copy.source=inventory.source AND copy.object_key=inventory.object_key
        WHERE inventory.backup_id=? AND (inventory.source,inventory.object_key)>(?,?)
        ORDER BY inventory.source,inventory.object_key LIMIT ?`).bind(id, cursor[0], cursor[1], budget.objectsPerStep).all();
      const objects = await mapConcurrent(required2.results ?? [], 6, async (object) => {
        safeKey(object.key);
        const backupKey = object.backup_key;
        if (object.state === "ready") {
          if (!object.copied_digest || !object.copied_bytes || !object.content_type || object.digest !== null && object.digest !== object.copied_digest || object.bytes !== null && object.bytes !== object.copied_bytes)
            throw new Error("Immutable backup reference changed.");
          return { source: object.source, key: object.key, backupKey, digest: object.copied_digest, bytes: object.copied_bytes, contentType: object.content_type };
        }
        if (object.state !== "pending") throw new Error("Backup object is being deleted.");
        const copy = await copyVerifiedObject({
          source: object.source === "images" ? context2.images : context2.quarantine,
          destination: context2.backups,
          sourceKey: object.key,
          destinationKey: backupKey,
          maximum: budget.maximumObjectBytes,
          expectedDigest: object.digest ?? void 0,
          expectedBytes: object.bytes ?? void 0
        });
        return { source: object.source, key: object.key, backupKey, ...copy };
      });
      const encoded2 = JSON.stringify(objects);
      const digest = createHash3("sha256").update(encoded2).digest("hex");
      const key = `${prefix}pages/${digest}.json`;
      await context2.backups.put(key, encoded2, { httpMetadata: { contentType: "application/json" } });
      const saved = await context2.backups.get(key);
      if (!saved || (await digestStream(saved.body, 4 * 1024 * 1024)).digest !== digest)
        throw new Error("Backup inventory was not stored intact.");
      const last = objects.at(-1);
      await atomic(database, [
        backupGuard(context2, id, token),
        database.prepare(`INSERT INTO operations_backup_objects(source,object_key,backup_key,state,digest,bytes,content_type,retire_after)
          SELECT json_extract(value,'$.source'),json_extract(value,'$.key'),json_extract(value,'$.backupKey'),'ready',
            json_extract(value,'$.digest'),json_extract(value,'$.bytes'),json_extract(value,'$.contentType'),?
          FROM json_each(?) WHERE true ON CONFLICT(source,object_key) DO UPDATE SET
            state='ready',digest=excluded.digest,bytes=excluded.bytes,content_type=excluded.content_type
          WHERE operations_backup_objects.state='pending'`).bind(context2.now() + BACKUP_RETENTION, encoded2),
        database.prepare("INSERT INTO operations_backup_pages(backup_id,ordinal,object_key,digest,objects) VALUES(?,?,?,?,?)").bind(id, row.page_count, key, digest, objects.length),
        database.prepare(`UPDATE operations_backups SET cursor=?,source_kind=?,page_count=page_count+1,
          object_count=object_count+?,image_bytes=image_bytes+? WHERE id=?`).bind(
          last ? JSON.stringify([last.source, last.key]) : row.cursor,
          objects.length === budget.objectsPerStep ? 0 : 4,
          objects.length,
          objects.reduce((sum, item) => sum + item.bytes, 0),
          id
        )
      ]);
      report.hasMore = true;
      report.deferred.push(id);
      return report;
    }
    if (!row.database_key || !row.database_digest || !row.database_bytes)
      throw new Error("Backup database record is incomplete.");
    const pages = await database.prepare(
      "SELECT object_key AS key,digest,objects FROM operations_backup_pages WHERE backup_id=? ORDER BY ordinal"
    ).bind(id).all();
    const required = await database.prepare(
      "SELECT object_key AS key,digest,objects FROM operations_backup_required WHERE backup_id=? ORDER BY ordinal"
    ).bind(id).all();
    const manifest = {
      version: 2,
      id,
      createdAt: row.created_at,
      completedAt: context2.now(),
      database: { key: row.database_key, digest: row.database_digest, bytes: row.database_bytes },
      pages: pages.results ?? [],
      required: required.results ?? [],
      objects: row.object_count,
      bytes: row.image_bytes
    };
    const encoded = JSON.stringify(manifest);
    if (encoded.length > 4 * 1024 * 1024)
      throw new Error("Backup inventory exceeds supported bounds.");
    await context2.backups.put(`${prefix}complete.json`, encoded, {
      httpMetadata: { contentType: "application/json" }
    });
    await atomic(database, [
      backupGuard(context2, id, token),
      database.prepare("UPDATE operations_backups SET state='complete',completed_at=? WHERE id=?").bind(context2.now(), id),
      database.prepare(`UPDATE operations_backup_objects SET last_completed_at=?,retire_after=?
        WHERE (source,object_key) IN (SELECT source,object_key FROM operations_backup_inventory WHERE backup_id=?)`).bind(context2.now(), context2.now() + BACKUP_RETENTION, id),
      database.prepare("DELETE FROM operations_backup_inventory WHERE backup_id=?").bind(id),
      database.prepare("DELETE FROM work_retention_pins WHERE owner=? AND reason='recovery'").bind(`backup:${id}`)
    ]);
    await resolveEvents(database, "backup", id, context2.now());
    report.completed.push(id);
  } catch {
    await recordEvent(database, {
      kind: "backup",
      subject: id,
      code: "backup-failed",
      now: context2.now()
    });
    report.attention.push(id);
  } finally {
    await database.prepare(
      "UPDATE operations_backups SET lease_token=NULL,lease_until=NULL WHERE id=? AND lease_token=?"
    ).bind(id, token).run();
  }
  return report;
}
__name(backupDaily, "backupDaily");

// implementation-snapshot/recovery.ts
async function sanitizeRestoredDatabase(database, now) {
  const tables = await database.prepare("SELECT name FROM sqlite_master WHERE type='table'").all();
  const names = new Set((tables.results ?? []).map((row) => row.name));
  const commands = [];
  for (const table2 of ["session", "verification", "ingest_review_sessions", "rateLimit"]) {
    if (names.has(table2)) commands.push(`DELETE FROM "${table2}"`);
  }
  if (names.has("account"))
    commands.push(
      "UPDATE account SET accessToken=NULL,refreshToken=NULL,idToken=NULL,accessTokenExpiresAt=NULL,refreshTokenExpiresAt=NULL"
    );
  commands.push(
    // Old external writes cannot be proven settled by reading a backup. Keep them fenced.
    "UPDATE work_checks SET ambiguous=1",
    "UPDATE work_status_outbox SET state='obsolete' WHERE state!='complete'",
    "UPDATE operations_check_creations SET state='dead',last_error='restored-environment' WHERE state!='complete'",
    "UPDATE work_tasks SET state='dead',lease_token=NULL,lease_until=NULL,last_error='restored-environment' WHERE state!='complete'",
    "UPDATE ariviso_runs SET active=0,state=CASE WHEN state='accepted' THEN state ELSE 'failed' END",
    "UPDATE ariviso_snapshots SET state='revoked',reference_eligible=0 WHERE state='copying'",
    "DELETE FROM work_retention_pins WHERE reason IN ('recovery','promotion')",
    "DELETE FROM operations_backup_inventory",
    "DELETE FROM operations_backup_objects",
    "DELETE FROM operations_backup_pages",
    "DELETE FROM operations_backup_required",
    "DELETE FROM operations_backups",
    "DELETE FROM operations_exports",
    "DELETE FROM operations_cursors"
  );
  await database.batch(commands.map((sql) => database.prepare(sql)));
  await database.prepare(
    "INSERT INTO operations_events(id,kind,subject_id,code,first_seen_at,last_seen_at) VALUES('restore:activation:secrets-required','restore','activation','secrets-required',?,?) ON CONFLICT(id) DO UPDATE SET resolved_at=NULL,last_seen_at=excluded.last_seen_at"
  ).bind(now, now).run();
  const violations = await database.prepare("PRAGMA foreign_key_check").all();
  if (violations.results?.length) throw new Error("Restored database contains broken references.");
}
__name(sanitizeRestoredDatabase, "sanitizeRestoredDatabase");

// ../../../../../Users/diegohaz/Developer/ariviso/node_modules/.pnpm/jose@6.2.12/node_modules/jose/dist/webapi/lib/buffer_utils.js
var encoder = new TextEncoder();
var decoder = new TextDecoder();
var strictDecoder = new TextDecoder("utf-8", { fatal: true });
var MAX_INT32 = 2 ** 32;
function concat(...buffers) {
  const size = buffers.reduce((acc, { length }) => acc + length, 0), buf = new Uint8Array(size);
  let i = 0;
  for (const buffer of buffers)
    buf.set(buffer, i), i += buffer.length;
  return buf;
}
__name(concat, "concat");
var NON_ASCII = /[^\x00-\x7f]/;
function encode(string) {
  if (typeof string == "string" && string.length >= 128) {
    if (NON_ASCII.test(string))
      throw new TypeError("non-ASCII string encountered in encode()");
    return encoder.encode(string);
  }
  const bytes = new Uint8Array(string.length);
  for (let i = 0; i < string.length; i++) {
    const code = string.charCodeAt(i);
    if (code > 127)
      throw new TypeError("non-ASCII string encountered in encode()");
    bytes[i] = code;
  }
  return bytes;
}
__name(encode, "encode");
function encodeBase64(input, url = false) {
  if (Uint8Array.prototype.toBase64)
    return input.toBase64({ alphabet: url ? "base64url" : "base64", omitPadding: url });
  const CHUNK_SIZE = 32768, arr = [];
  for (let i = 0; i < input.length; i += CHUNK_SIZE)
    arr.push(String.fromCharCode.apply(null, input.subarray(i, i + CHUNK_SIZE)));
  const encoded = btoa(arr.join(""));
  return url ? encoded.replace(/=/g, "").replace(/\+/g, "-").replace(/\//g, "_") : encoded;
}
__name(encodeBase64, "encodeBase64");
function decodeBase64(encoded, url = false) {
  if (Uint8Array.fromBase64)
    return Uint8Array.fromBase64(encoded, { alphabet: url ? "base64url" : "base64" });
  if (url) {
    if (encoded.includes("+") || encoded.includes("/"))
      throw new TypeError("Invalid base64url");
    encoded = encoded.replace(/-/g, "+").replace(/_/g, "/");
  }
  const binary = atob(encoded), bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++)
    bytes[i] = binary.charCodeAt(i);
  return bytes;
}
__name(decodeBase64, "decodeBase64");

// ../../../../../Users/diegohaz/Developer/ariviso/node_modules/.pnpm/jose@6.2.12/node_modules/jose/dist/webapi/util/errors.js
var JOSEError = class extends Error {
  static {
    __name(this, "JOSEError");
  }
  static code = "ERR_JOSE_GENERIC";
  code = "ERR_JOSE_GENERIC";
  constructor(message2, options) {
    super(message2, options), this.name = this.constructor.name, Error.captureStackTrace?.(this, this.constructor);
  }
};
var JWTClaimValidationFailed = class extends JOSEError {
  static {
    __name(this, "JWTClaimValidationFailed");
  }
  static code = "ERR_JWT_CLAIM_VALIDATION_FAILED";
  code = "ERR_JWT_CLAIM_VALIDATION_FAILED";
  claim;
  reason;
  payload;
  constructor(message2, payload, claim = "unspecified", reason = "unspecified") {
    super(message2, { cause: { claim, reason, payload } }), this.claim = claim, this.reason = reason, this.payload = payload;
  }
};
var JWTExpired = class extends JOSEError {
  static {
    __name(this, "JWTExpired");
  }
  static code = "ERR_JWT_EXPIRED";
  code = "ERR_JWT_EXPIRED";
  claim;
  reason;
  payload;
  constructor(message2, payload, claim = "unspecified", reason = "unspecified") {
    super(message2, { cause: { claim, reason, payload } }), this.claim = claim, this.reason = reason, this.payload = payload;
  }
};
var JOSEAlgNotAllowed = class extends JOSEError {
  static {
    __name(this, "JOSEAlgNotAllowed");
  }
  static code = "ERR_JOSE_ALG_NOT_ALLOWED";
  code = "ERR_JOSE_ALG_NOT_ALLOWED";
};
var JOSENotSupported = class extends JOSEError {
  static {
    __name(this, "JOSENotSupported");
  }
  static code = "ERR_JOSE_NOT_SUPPORTED";
  code = "ERR_JOSE_NOT_SUPPORTED";
};
var JWSInvalid = class extends JOSEError {
  static {
    __name(this, "JWSInvalid");
  }
  static code = "ERR_JWS_INVALID";
  code = "ERR_JWS_INVALID";
};
var JWTInvalid = class extends JOSEError {
  static {
    __name(this, "JWTInvalid");
  }
  static code = "ERR_JWT_INVALID";
  code = "ERR_JWT_INVALID";
};
var JWSSignatureVerificationFailed = class extends JOSEError {
  static {
    __name(this, "JWSSignatureVerificationFailed");
  }
  static code = "ERR_JWS_SIGNATURE_VERIFICATION_FAILED";
  code = "ERR_JWS_SIGNATURE_VERIFICATION_FAILED";
  constructor(message2 = "signature verification failed", options) {
    super(message2, options);
  }
};

// ../../../../../Users/diegohaz/Developer/ariviso/node_modules/.pnpm/jose@6.2.12/node_modules/jose/dist/webapi/util/base64url.js
var invalid = "The input to be decoded is not correctly encoded.";
function decode(input) {
  try {
    return decodeBase64(typeof input == "string" ? input : decoder.decode(input), true);
  } catch (cause) {
    throw new TypeError(invalid, { cause });
  }
}
__name(decode, "decode");
function encode2(input) {
  return encodeBase64(typeof input == "string" ? encoder.encode(input) : input, true);
}
__name(encode2, "encode");

// ../../../../../Users/diegohaz/Developer/ariviso/node_modules/.pnpm/jose@6.2.12/node_modules/jose/dist/webapi/lib/validate.js
function isObject(input) {
  if (typeof input != "object" || input === null || Object.prototype.toString.call(input) !== "[object Object]")
    return false;
  const prototype = Object.getPrototypeOf(input);
  return prototype === null || Object.getPrototypeOf(prototype) === null;
}
__name(isObject, "isObject");
function isDisjoint(...headers) {
  const parameters = /* @__PURE__ */ new Set();
  for (const header of headers)
    if (header)
      for (const parameter of Object.keys(header)) {
        if (parameters.has(parameter))
          return false;
        parameters.add(parameter);
      }
  return true;
}
__name(isDisjoint, "isDisjoint");
function assertNotSet(value, name) {
  if (value !== void 0)
    throw new TypeError(`${name} can only be called once`);
}
__name(assertNotSet, "assertNotSet");
function decodeBase64url(value, label, ErrorClass) {
  try {
    return decode(value);
  } catch {
    throw new ErrorClass(`Failed to base64url decode the ${label}`);
  }
}
__name(decodeBase64url, "decodeBase64url");
function encodeBase64url(value, label, ErrorClass) {
  try {
    return encode(value);
  } catch {
    throw new ErrorClass(`The ${label} is not a valid base64url string`);
  }
}
__name(encodeBase64url, "encodeBase64url");
function parseJoseHeader(b64, ErrorClass, message2) {
  let parsed;
  try {
    parsed = JSON.parse(strictDecoder.decode(decode(b64)));
  } catch {
    throw new ErrorClass(message2);
  }
  if (!isObject(parsed))
    throw new ErrorClass(message2);
  return parsed;
}
__name(parseJoseHeader, "parseJoseHeader");
var JWS_RECOGNIZED = { __proto__: null, b64: true };
function validateAlgorithms(option, algorithms) {
  if (algorithms !== void 0 && (!Array.isArray(algorithms) || algorithms.some((s) => typeof s != "string")))
    throw new TypeError(`"${option}" option must be an array of strings`);
  return algorithms === void 0 ? void 0 : new Set(algorithms);
}
__name(validateAlgorithms, "validateAlgorithms");
function validateCritDuplicates(Err, protectedHeader) {
  const { crit } = protectedHeader ?? {};
  if (Array.isArray(crit) && new Set(crit).size !== crit.length)
    throw new Err('"crit" (Critical) Header Parameter MUST NOT contain duplicate values');
}
__name(validateCritDuplicates, "validateCritDuplicates");
function validateCrit(Err, recognizedDefault, recognizedOption, protectedHeader, joseHeader) {
  if (joseHeader.crit !== void 0 && protectedHeader?.crit === void 0)
    throw new Err('"crit" (Critical) Header Parameter MUST be integrity protected');
  if (!protectedHeader || protectedHeader.crit === void 0)
    return [];
  if (!Array.isArray(protectedHeader.crit) || protectedHeader.crit.length === 0 || protectedHeader.crit.some((input) => typeof input != "string" || input.length === 0))
    throw new Err('"crit" (Critical) Header Parameter MUST be an array of non-empty strings when present');
  const recognized = recognizedOption === void 0 ? recognizedDefault : { __proto__: null, ...recognizedOption, ...recognizedDefault };
  for (const parameter of protectedHeader.crit) {
    if (!(parameter in recognized))
      throw new JOSENotSupported(`Extension Header Parameter "${parameter}" is not recognized`);
    if (!Object.hasOwn(joseHeader, parameter) || joseHeader[parameter] === void 0)
      throw new Err(`Extension Header Parameter "${parameter}" is missing`);
    if (recognized[parameter] && (!Object.hasOwn(protectedHeader, parameter) || protectedHeader[parameter] === void 0))
      throw new Err(`Extension Header Parameter "${parameter}" MUST be integrity protected`);
  }
  return protectedHeader.crit;
}
__name(validateCrit, "validateCrit");
function validateB64(protectedHeader, extensions) {
  if (extensions.includes("b64")) {
    const b64 = protectedHeader.b64;
    if (typeof b64 != "boolean")
      throw new JWSInvalid('The "b64" (base64url-encode payload) Header Parameter must be a boolean');
    return b64;
  }
  return true;
}
__name(validateB64, "validateB64");
function serializeJoseHeader(Err, header) {
  let serialized, parsed;
  try {
    serialized = JSON.stringify(header), parsed = JSON.parse(serialized);
  } catch (cause) {
    throw new Err("JOSE Header is not valid JSON", { cause });
  }
  if (!isObject(parsed))
    throw new Err("JOSE Header is not a JSON object");
  return [parsed, serialized];
}
__name(serializeJoseHeader, "serializeJoseHeader");

// ../../../../../Users/diegohaz/Developer/ariviso/node_modules/.pnpm/jose@6.2.12/node_modules/jose/dist/webapi/lib/key.js
var tag = /* @__PURE__ */ __name((key) => key[Symbol.toStringTag], "tag");
var jwkMatchesOp = /* @__PURE__ */ __name((entry, key, usage) => {
  const { alg } = entry;
  if (key.use !== void 0) {
    const expected = usage === "sign" || usage === "verify" ? "sig" : "enc";
    if (key.use !== expected)
      throw new TypeError(`Invalid key for this operation, its "use" must be "${expected}" when present`);
  }
  if (key.alg !== void 0 && key.alg !== alg)
    throw new TypeError(`Invalid key for this operation, its "alg" must be "${alg}" when present`);
  if (Array.isArray(key.key_ops)) {
    const expectedKeyOp = usage === "encrypt" || usage === "decrypt" ? entry.ops?.[usage === "encrypt" ? 0 : 1] : usage;
    if (expectedKeyOp && !key.key_ops.includes(expectedKeyOp))
      throw new TypeError(`Invalid key for this operation, its "key_ops" must include "${expectedKeyOp}" when present`);
  }
}, "jwkMatchesOp");
async function prepareKey(entry, key, usage) {
  const { alg, secret } = entry, privateKey = usage === "decrypt" || usage === "sign";
  if (secret && key instanceof Uint8Array)
    return key;
  let normalized, keyObject;
  if (isObject(key)) {
    if (normalized = normalizeJwk(key), typeof normalized.kty != "string")
      throw invalidKeyType(alg, key, secret);
    if (!(secret ? normalized.kty === "oct" && typeof normalized.k == "string" : normalized.kty !== "oct" && (privateKey ? normalized.kty === "AKP" && typeof normalized.priv == "string" || typeof normalized.d == "string" : normalized.d === void 0 && normalized.priv === void 0)))
      throw new TypeError(secret ? 'JSON Web Key for symmetric algorithms must have JWK "kty" (Key Type) equal to "oct" and the JWK "k" (Key Value) present' : `JSON Web Key for this operation must be a ${privateKey ? "private" : "public"} JWK`);
    if (jwkMatchesOp(entry, normalized, usage), normalized.kty === "oct")
      return decode(normalized.k);
    if (!Object.isFrozen(key)) {
      const { key_ops } = key;
      Array.isArray(key_ops) && Object.freeze(key_ops), Object.freeze(key);
    }
  } else {
    if (!isKeyLike(key))
      throw invalidKeyType(alg, key, secret);
    const expectedType = secret ? "secret" : privateKey ? "private" : "public";
    if (key.type !== expectedType && (secret || ["secret", "public", "private"].includes(key.type)))
      throw new TypeError(`${tag(key)} instances must be of type "${expectedType}" for the ${alg} algorithm`);
    if (isCryptoKey(key))
      return key;
    if (keyObject = key, keyObject.type === "secret")
      return keyObject.export();
  }
  cache ||= /* @__PURE__ */ new WeakMap();
  const cacheKey = key;
  let cached = cache.get(cacheKey);
  if (cached?.[alg])
    return cached[alg];
  if (cached || cache.set(cacheKey, cached = {}), keyObject && typeof keyObject.toCryptoKey == "function") {
    const isPublic = keyObject.type === "public", crv = nist[keyObject.asymmetricKeyDetails?.namedCurve], params = entry.resolve?.({ crv, asymmetricKeyType: keyObject.asymmetricKeyType }) ?? entry.subtle;
    return cached[alg] = keyObject.toCryptoKey(params, isPublic, entry.usages[isPublic ? 0 : 1]);
  }
  return normalized ??= keyObject.export({ format: "jwk" }), normalized.alg = alg, cached[alg] = await jwkToKey(entry, normalized);
}
__name(prepareKey, "prepareKey");
var cache;
var nist = {
  __proto__: null,
  prime256v1: "P-256",
  secp384r1: "P-384",
  secp521r1: "P-521"
};
var isCryptoKey = /* @__PURE__ */ __name((key) => {
  if (key?.[Symbol.toStringTag] === "CryptoKey")
    return true;
  try {
    return key instanceof CryptoKey;
  } catch {
    return false;
  }
}, "isCryptoKey");
var isKeyObject = /* @__PURE__ */ __name((key) => key?.[Symbol.toStringTag] === "KeyObject", "isKeyObject");
var isKeyLike = /* @__PURE__ */ __name((key) => isCryptoKey(key) || isKeyObject(key), "isKeyLike");
function message(msg, actual, ...types) {
  if (types.length > 2) {
    const last = types.pop();
    msg += `one of type ${types.join(", ")}, or ${last}.`;
  } else types.length === 2 ? msg += `one of type ${types[0]} or ${types[1]}.` : msg += `of type ${types[0]}.`;
  return actual == null ? msg += ` Received ${actual}` : typeof actual == "function" && actual.name ? msg += ` Received function ${actual.name}` : typeof actual == "object" && actual != null && actual.constructor?.name && (msg += ` Received an instance of ${actual.constructor.name}`), msg;
}
__name(message, "message");
function invalidKeyType(alg, actual, secret) {
  const types = ["CryptoKey", "KeyObject", "JSON Web Key"];
  return secret && types.push("Uint8Array"), new TypeError(message(`Key for the ${alg} algorithm must be `, actual, ...types));
}
__name(invalidKeyType, "invalidKeyType");
var unusable = /* @__PURE__ */ __name((name, prop = "algorithm.name") => new TypeError(`CryptoKey does not support this operation, its ${prop} must be ${name}`), "unusable");
function checkUsage(key, usage) {
  if (usage && !key.usages.includes(usage))
    throw new TypeError(`CryptoKey does not support this operation, its usages must include ${usage}.`);
}
__name(checkUsage, "checkUsage");
function checkModulusLength(alg, key) {
  const { modulusLength } = key.algorithm;
  if (typeof modulusLength != "number" || modulusLength < 2048)
    throw new TypeError(`${alg} requires key modulusLength to be 2048 bits or larger`);
}
__name(checkModulusLength, "checkModulusLength");
function checkCryptoKey(key, expected, usage) {
  const algorithm = key.algorithm;
  if (algorithm.name !== expected.name)
    throw unusable(expected.name);
  if (expected.hash && algorithm.hash?.name !== expected.hash)
    throw unusable(expected.hash, "algorithm.hash");
  if (expected.namedCurve && algorithm.namedCurve !== expected.namedCurve)
    throw unusable(expected.namedCurve, "algorithm.namedCurve");
  if (expected.length !== void 0 && algorithm.length !== expected.length)
    throw unusable(expected.length, "algorithm.length");
  checkUsage(key, usage);
}
__name(checkCryptoKey, "checkCryptoKey");
function snapshotJwk(jwk) {
  return { __proto__: null, ...jwk };
}
__name(snapshotJwk, "snapshotJwk");
function normalizeJwk(jwk) {
  const normalized = snapshotJwk(jwk);
  if (normalized.ext !== void 0 && typeof normalized.ext != "boolean")
    throw new TypeError('"ext" (Extractable) Parameter must be a boolean');
  if (normalized.key_ops !== void 0) {
    const value = normalized.key_ops, keyOps = Array.isArray(value) ? [...value] : void 0;
    if (!keyOps || keyOps.some((operation) => typeof operation != "string") || new Set(keyOps).size !== keyOps.length)
      throw new TypeError('"key_ops" (Key Operations) Parameter must be an array of unique strings');
    normalized.key_ops = keyOps;
  }
  return normalized;
}
__name(normalizeJwk, "normalizeJwk");
async function jwkToKey(entry, jwk, extractable) {
  if (!entry.kty.includes(jwk.kty))
    throw new JOSENotSupported('Invalid or unsupported JWK "alg" (Algorithm) Parameter value');
  const algorithm = entry.resolve?.({ kty: jwk.kty, crv: jwk.crv }) ?? entry.subtle, isPrivate = !!(jwk.d || jwk.priv), keyData = { ...jwk, ext: extractable ?? jwk.ext };
  return keyData.kty !== "AKP" && delete keyData.alg, delete keyData.use, crypto.subtle.importKey("jwk", keyData, algorithm, keyData.ext ?? !isPrivate, jwk.key_ops ?? entry.usages[isPrivate ? 1 : 0]);
}
__name(jwkToKey, "jwkToKey");
async function rawKey(key, expected, usage, extractable = false) {
  return key instanceof Uint8Array && (key = await crypto.subtle.importKey("raw", key, expected, extractable, [usage])), checkCryptoKey(key, expected, usage), key;
}
__name(rawKey, "rawKey");

// ../../../../../Users/diegohaz/Developer/ariviso/node_modules/.pnpm/jose@6.2.12/node_modules/jose/dist/webapi/lib/key_descriptor.js
function table(entries) {
  const out = { __proto__: null };
  for (const alg in entries)
    out[alg] = { ...entries[alg], alg };
  return out;
}
__name(table, "table");

// ../../../../../Users/diegohaz/Developer/ariviso/node_modules/.pnpm/jose@6.2.12/node_modules/jose/dist/webapi/lib/jws_algorithms.js
var sig = [["verify"], ["sign"]];
function hmac(bits) {
  const subtle = { name: "HMAC", hash: `SHA-${bits}` };
  return { kty: ["oct"], secret: true, subtle, signing: subtle, usages: sig };
}
__name(hmac, "hmac");
function rsa(bits, saltLength) {
  const subtle = { name: saltLength ? "RSA-PSS" : "RSASSA-PKCS1-v1_5", hash: `SHA-${bits}` };
  return {
    kty: ["RSA"],
    subtle,
    signing: saltLength ? { ...subtle, saltLength } : subtle,
    usages: sig,
    minRsaBits: 2048
  };
}
__name(rsa, "rsa");
function ecdsa(crv, bits) {
  return {
    kty: ["EC"],
    crv,
    subtle: { name: "ECDSA", namedCurve: crv },
    signing: { name: "ECDSA", hash: `SHA-${bits}` },
    usages: sig
  };
}
__name(ecdsa, "ecdsa");
function eddsa() {
  const subtle = { name: "Ed25519" };
  return {
    kty: ["OKP"],
    crv: "Ed25519",
    subtle,
    signing: subtle,
    usages: sig
  };
}
__name(eddsa, "eddsa");
function mldsa(bits) {
  const subtle = { name: `ML-DSA-${bits}` };
  return {
    kty: ["AKP"],
    subtle,
    signing: subtle,
    usages: sig
  };
}
__name(mldsa, "mldsa");
var JWS = table({
  HS256: hmac(256),
  HS384: hmac(384),
  HS512: hmac(512),
  RS256: rsa(256),
  RS384: rsa(384),
  RS512: rsa(512),
  PS256: rsa(256, 32),
  PS384: rsa(384, 48),
  PS512: rsa(512, 64),
  ES256: ecdsa("P-256", 256),
  ES384: ecdsa("P-384", 384),
  ES512: ecdsa("P-521", 512),
  EdDSA: eddsa(),
  Ed25519: eddsa(),
  "ML-DSA-44": mldsa(44),
  "ML-DSA-65": mldsa(65),
  "ML-DSA-87": mldsa(87)
});
function jwsAlgorithm(alg) {
  const entry = typeof alg == "string" ? JWS[alg] : void 0;
  if (!entry)
    throw new JOSENotSupported(`alg ${alg} is not supported either by JOSE or your javascript runtime`);
  return entry;
}
__name(jwsAlgorithm, "jwsAlgorithm");

// ../../../../../Users/diegohaz/Developer/ariviso/node_modules/.pnpm/jose@6.2.12/node_modules/jose/dist/webapi/lib/jws_verify.js
function prepareVerify(options) {
  return [options && validateAlgorithms("algorithms", options.algorithms), options?.crit];
}
__name(prepareVerify, "prepareVerify");
function parseProtectedHeader(encodedProtected) {
  return encodedProtected === void 0 ? {} : parseJoseHeader(encodedProtected, JWSInvalid, "JWS Protected Header is invalid");
}
__name(parseProtectedHeader, "parseProtectedHeader");
function encodeCompactUnencodedPayload(payload) {
  try {
    return encode(payload);
  } catch {
    throw new JWSInvalid("JWS Compact Serialization payload must use only ASCII characters");
  }
}
__name(encodeCompactUnencodedPayload, "encodeCompactUnencodedPayload");
async function verifySignature(jws, shared, key, encodeUnencodedPayload, parsedProtected) {
  const { protected: encodedProtected, header, payload: inputPayload } = jws, parsedProt = parsedProtected ?? parseProtectedHeader(encodedProtected);
  if (!isDisjoint(parsedProt, header))
    throw new JWSInvalid("JWS Protected and JWS Unprotected Header Parameter names must be disjoint");
  const joseHeader = { ...parsedProt, ...header }, b64 = validateB64(parsedProt, validateCrit(JWSInvalid, JWS_RECOGNIZED, shared[1], parsedProt, joseHeader)), { alg } = joseHeader;
  if (typeof alg != "string" || !alg)
    throw new JWSInvalid('JWS "alg" (Algorithm) Header Parameter missing or invalid');
  if (shared[0] && !shared[0].has(alg))
    throw new JOSEAlgNotAllowed('"alg" (Algorithm) Header Parameter value not allowed');
  if (b64) {
    if (typeof inputPayload != "string")
      throw new JWSInvalid("JWS Payload must be a string");
  } else if (typeof inputPayload != "string" && !(inputPayload instanceof Uint8Array))
    throw new JWSInvalid("JWS Payload must be a string or an Uint8Array instance");
  const signingPayload = b64 || typeof inputPayload != "string" ? inputPayload : encodeUnencodedPayload(inputPayload);
  let resolvedKey = false;
  typeof key == "function" && (key = await key(parsedProt, jws), resolvedKey = true);
  const entry = jwsAlgorithm(alg), data = concat(encodedProtected !== void 0 ? encode(encodedProtected) : new Uint8Array(), encode("."), typeof signingPayload == "string" ? shared[2] ??= encodeBase64url(signingPayload, "payload", JWSInvalid) : signingPayload), signature = decodeBase64url(jws.signature, "signature", JWSInvalid), k = await prepareKey(entry, key, "verify"), cryptoKey = await rawKey(k, entry.subtle, "verify");
  entry.minRsaBits && checkModulusLength(entry.alg, cryptoKey);
  let verified = false;
  try {
    verified = await crypto.subtle.verify(entry.signing, cryptoKey, signature, data);
  } catch {
  }
  if (!verified)
    throw new JWSSignatureVerificationFailed();
  const result = { payload: typeof signingPayload == "string" ? decodeBase64url(signingPayload, "payload", JWSInvalid) : signingPayload };
  return encodedProtected !== void 0 && (result.protectedHeader = parsedProt), header !== void 0 && (result.unprotectedHeader = header), resolvedKey ? [{ ...result, key: k }, b64] : [result, b64];
}
__name(verifySignature, "verifySignature");
async function verifyCompact(jws, shared, key) {
  if (jws instanceof Uint8Array && (jws = decoder.decode(jws)), typeof jws != "string")
    throw new JWSInvalid("Compact JWS must be a string or Uint8Array");
  const { 0: protectedHeader, 1: payload, 2: signature, length } = jws.split(".");
  if (length !== 3)
    throw new JWSInvalid("Invalid Compact JWS");
  return verifySignature({ payload, protected: protectedHeader, signature }, shared, key, encodeCompactUnencodedPayload);
}
__name(verifyCompact, "verifyCompact");

// ../../../../../Users/diegohaz/Developer/ariviso/node_modules/.pnpm/jose@6.2.12/node_modules/jose/dist/webapi/lib/jwt_claims_set.js
var epoch = /* @__PURE__ */ __name((date) => Math.floor(date.getTime() / 1e3), "epoch");
var multipliers = {
  s: 1,
  m: 60,
  h: 3600,
  d: 86400,
  w: 604800,
  y: 31557600
};
var REGEX = /^(\+|\-)? ?(\d+|\d+\.\d+) ?(seconds?|secs?|s|minutes?|mins?|m|hours?|hrs?|h|days?|d|weeks?|w|years?|yrs?|y)(?: (ago|from now))?$/i;
var checkFailed = "check_failed";
function invalidDuration() {
  throw new TypeError("Invalid time period format");
}
__name(invalidDuration, "invalidDuration");
function secs(str) {
  typeof str != "string" && invalidDuration();
  const matched = REGEX.exec(str);
  (!matched || matched[4] && matched[1]) && invalidDuration();
  const value = parseFloat(matched[2]), numericDate2 = Math.round(value * multipliers[matched[3][0].toLowerCase()]);
  return Number.isFinite(numericDate2) || invalidDuration(), matched[1] === "-" || matched[4] === "ago" ? -numericDate2 : numericDate2;
}
__name(secs, "secs");
function validateInput(label, input) {
  if (!Number.isFinite(input))
    throw new TypeError(`Invalid ${label} input`);
  return input;
}
__name(validateInput, "validateInput");
function validateStringClaim(claim, value) {
  if (typeof value != "string")
    throw new TypeError(`"${claim}" claim must be a string`);
}
__name(validateStringClaim, "validateStringClaim");
function validateAudienceClaim(value) {
  if (typeof value != "string" && (!Array.isArray(value) || Array.from(value).some((member) => typeof member != "string")))
    throw new TypeError('"aud" claim must be a string or an array of strings');
}
__name(validateAudienceClaim, "validateAudienceClaim");
function numericDate(value, label) {
  return typeof value == "number" ? validateInput(label, value) : value instanceof Date ? validateInput(label, epoch(value)) : epoch(/* @__PURE__ */ new Date()) + secs(value);
}
__name(numericDate, "numericDate");
var normalizeTyp = /* @__PURE__ */ __name((value) => {
  const normalized = value.toLowerCase();
  return value.includes("/") ? normalized : `application/${normalized}`;
}, "normalizeTyp");
var checkAudiencePresence = /* @__PURE__ */ __name((audPayload, audOption) => typeof audPayload == "string" ? audOption.includes(audPayload) : Array.isArray(audPayload) ? audOption.some((aud) => audPayload.includes(aud)) : false, "checkAudiencePresence");
function validateNumericDate(payload, claim, required = false) {
  const value = payload[claim];
  if (!(value === void 0 && !required)) {
    if (typeof value != "number")
      throw new JWTClaimValidationFailed(`"${claim}" claim must be a number`, payload, claim, "invalid");
    return value;
  }
}
__name(validateNumericDate, "validateNumericDate");
function unexpectedClaim(payload, claim) {
  throw new JWTClaimValidationFailed(`unexpected "${claim}" claim value`, payload, claim, checkFailed);
}
__name(unexpectedClaim, "unexpectedClaim");
function validateClaimsSet(protectedHeader, encodedPayload, options = {}) {
  let payload;
  try {
    payload = JSON.parse(strictDecoder.decode(encodedPayload));
  } catch {
  }
  if (!isObject(payload))
    throw new JWTInvalid("JWT Claims Set must be a top-level JSON object");
  const { typ } = options;
  if (typ !== void 0 && (typeof protectedHeader.typ != "string" || normalizeTyp(protectedHeader.typ) !== normalizeTyp(typ)))
    throw new JWTClaimValidationFailed('unexpected "typ" JWT header value', payload, "typ", checkFailed);
  const { requiredClaims = [], issuer, subject, audience, maxTokenAge } = options, presenceCheck = [...requiredClaims];
  maxTokenAge !== void 0 && presenceCheck.push("iat"), audience !== void 0 && presenceCheck.push("aud"), subject !== void 0 && presenceCheck.push("sub"), issuer !== void 0 && presenceCheck.push("iss");
  for (const claim of new Set(presenceCheck.reverse()))
    if (!Object.hasOwn(payload, claim))
      throw new JWTClaimValidationFailed(`missing required "${claim}" claim`, payload, claim, "missing");
  issuer !== void 0 && !(Array.isArray(issuer) ? issuer : [issuer]).includes(payload.iss) && unexpectedClaim(payload, "iss"), subject !== void 0 && payload.sub !== subject && unexpectedClaim(payload, "sub"), audience !== void 0 && !checkAudiencePresence(payload.aud, typeof audience == "string" ? [audience] : audience) && unexpectedClaim(payload, "aud");
  const { clockTolerance } = options;
  let tolerance = 0;
  if (typeof clockTolerance == "string")
    tolerance = secs(clockTolerance);
  else if (clockTolerance !== void 0) {
    if (typeof clockTolerance != "number")
      throw new TypeError("Invalid clockTolerance option type");
    tolerance = clockTolerance;
  }
  validateInput("clockTolerance option", tolerance);
  const { currentDate } = options, now = validateInput("currentDate option", epoch(currentDate === void 0 ? /* @__PURE__ */ new Date() : currentDate)), iat = validateNumericDate(payload, "iat", maxTokenAge !== void 0), nbf = validateNumericDate(payload, "nbf");
  if (nbf !== void 0 && nbf > now + tolerance)
    throw new JWTClaimValidationFailed('"nbf" claim timestamp check failed', payload, "nbf", checkFailed);
  const exp = validateNumericDate(payload, "exp");
  if (exp !== void 0 && exp <= now - tolerance)
    throw new JWTExpired('"exp" claim timestamp check failed', payload, "exp", checkFailed);
  if (maxTokenAge !== void 0) {
    const age = now - iat, max = validateInput("maxTokenAge option", typeof maxTokenAge == "number" ? maxTokenAge : secs(maxTokenAge));
    if (age - tolerance > max)
      throw new JWTExpired('"iat" claim timestamp check failed (too far in the past)', payload, "iat", checkFailed);
    if (age < -tolerance)
      throw new JWTClaimValidationFailed('"iat" claim timestamp check failed (it should be in the past)', payload, "iat", checkFailed);
  }
  return payload;
}
__name(validateClaimsSet, "validateClaimsSet");
var producerPayloads;
function producerPayload(producer) {
  return producerPayloads.get(producer);
}
__name(producerPayload, "producerPayload");
function jwtData(producer) {
  const payload = producerPayload(producer);
  for (const claim of ["iat", "nbf", "exp"]) {
    const value = payload[claim];
    if (typeof value == "number" && !Number.isFinite(value))
      throw new TypeError(`"${claim}" claim must be a finite number`);
  }
  return encoder.encode(JSON.stringify(payload));
}
__name(jwtData, "jwtData");
var JWTClaimsBuilder = class {
  static {
    __name(this, "JWTClaimsBuilder");
  }
  constructor(payload = {}) {
    if (!isObject(payload))
      throw new TypeError("JWT Claims Set MUST be an object");
    (producerPayloads ||= /* @__PURE__ */ new WeakMap()).set(this, structuredClone(payload));
  }
  setIssuer(value) {
    return validateStringClaim("iss", value), producerPayload(this).iss = value, this;
  }
  setSubject(value) {
    return validateStringClaim("sub", value), producerPayload(this).sub = value, this;
  }
  setAudience(value) {
    return validateAudienceClaim(value), producerPayload(this).aud = value, this;
  }
  setJti(value) {
    return validateStringClaim("jti", value), producerPayload(this).jti = value, this;
  }
  setNotBefore(value) {
    return producerPayload(this).nbf = numericDate(value, "setNotBefore"), this;
  }
  setExpirationTime(value) {
    return producerPayload(this).exp = numericDate(value, "setExpirationTime"), this;
  }
  setIssuedAt(value) {
    const payload = producerPayload(this);
    return value === void 0 ? payload.iat = epoch(/* @__PURE__ */ new Date()) : typeof value == "string" ? payload.iat = validateInput("setIssuedAt", epoch(/* @__PURE__ */ new Date()) + secs(value)) : payload.iat = numericDate(value, "setIssuedAt"), this;
  }
};

// ../../../../../Users/diegohaz/Developer/ariviso/node_modules/.pnpm/jose@6.2.12/node_modules/jose/dist/webapi/jwt/verify.js
async function jwtVerify(jwt, key, options) {
  const [verified, b64] = await verifyCompact(jwt, prepareVerify(options), key);
  if (!b64)
    throw new JWTInvalid("JWTs MUST NOT use unencoded payload");
  const payload = validateClaimsSet(verified.protectedHeader, verified.payload, options);
  return { ...verified, payload };
}
__name(jwtVerify, "jwtVerify");

// ../../../../../Users/diegohaz/Developer/ariviso/node_modules/.pnpm/jose@6.2.12/node_modules/jose/dist/webapi/lib/jws_sign.js
async function createSignature(input, key, rejectUnencoded) {
  let [payload, protectedHeader, unprotectedHeader, crit] = input, protectedHeaderString = "";
  if (protectedHeader !== void 0) {
    const normalized = serializeJoseHeader(JWSInvalid, protectedHeader);
    protectedHeader = normalized[0], protectedHeaderString = encode2(normalized[1]);
  }
  if (unprotectedHeader !== void 0 && (unprotectedHeader = serializeJoseHeader(JWSInvalid, unprotectedHeader)[0]), !protectedHeader && !unprotectedHeader)
    throw new JWSInvalid("either setProtectedHeader or setUnprotectedHeader must be called before #sign()");
  if (!isDisjoint(protectedHeader, unprotectedHeader))
    throw new JWSInvalid("JWS Protected and JWS Unprotected Header Parameter names must be disjoint");
  const joseHeader = { ...protectedHeader, ...unprotectedHeader };
  validateCritDuplicates(JWSInvalid, protectedHeader);
  const b64 = validateB64(protectedHeader, validateCrit(JWSInvalid, JWS_RECOGNIZED, crit, protectedHeader, joseHeader));
  b64 || rejectUnencoded?.();
  const { alg } = joseHeader;
  if (typeof alg != "string" || !alg)
    throw new JWSInvalid('JWS "alg" (Algorithm) Header Parameter missing or invalid');
  const entry = jwsAlgorithm(alg);
  let payloadS = "", payloadB = payload, data;
  if (b64) {
    const encoded = input[4];
    encoded ? (payloadS = encoded[0] ??= encode2(payload), payloadB = encoded[1] ??= encode(payloadS)) : (payloadS = encode2(payload), data = encoder.encode(`${protectedHeaderString}.${payloadS}`));
  }
  data ??= concat(encode(protectedHeaderString), encode("."), payloadB);
  const k = await rawKey(await prepareKey(entry, key, "sign"), entry.subtle, "sign");
  entry.minRsaBits && checkModulusLength(entry.alg, k);
  const jws = {
    signature: encode2(new Uint8Array(await crypto.subtle.sign(entry.signing, k, data))),
    payload: payloadS
  };
  return protectedHeader && (jws.protected = protectedHeaderString), unprotectedHeader && (jws.header = unprotectedHeader), [jws, b64];
}
__name(createSignature, "createSignature");
async function createCompactSignature(payload, protectedHeader, crit, key, rejectUnencoded) {
  const [jws] = await createSignature([payload, protectedHeader, void 0, crit], key, rejectUnencoded);
  return `${jws.protected}.${jws.payload}.${jws.signature}`;
}
__name(createCompactSignature, "createCompactSignature");

// ../../../../../Users/diegohaz/Developer/ariviso/node_modules/.pnpm/jose@6.2.12/node_modules/jose/dist/webapi/jwt/sign.js
var SignJWT_base = JWTClaimsBuilder;
var SignJWT = class extends SignJWT_base {
  static {
    __name(this, "SignJWT");
  }
  #protectedHeader;
  setProtectedHeader(protectedHeader) {
    return assertNotSet(this.#protectedHeader, "setProtectedHeader"), this.#protectedHeader = protectedHeader, this;
  }
  async sign(key, options) {
    return createCompactSignature(jwtData(this), this.#protectedHeader, options?.crit, key, () => {
      throw new JWTInvalid("JWTs MUST NOT use unencoded payload");
    });
  }
};

// ../../../../../Users/diegohaz/Developer/ariviso/packages/security/src/errors.ts
var SecurityError = class extends Error {
  constructor(code, status, message2) {
    super(message2);
    this.code = code;
    this.status = status;
    this.name = "SecurityError";
  }
  code;
  status;
  static {
    __name(this, "SecurityError");
  }
};
function record(value) {
  if (!value || typeof value !== "object" || Array.isArray(value)) {
    throw new SecurityError("invalid_metadata", 503, "Trusted metadata is unavailable.");
  }
  return value;
}
__name(record, "record");
function textField(value) {
  if (typeof value !== "string" || value.length === 0) {
    throw new SecurityError("invalid_metadata", 503, "Trusted metadata is unavailable.");
  }
  return value;
}
__name(textField, "textField");
function numericId(value) {
  if (typeof value === "number" && Number.isSafeInteger(value) && value > 0) {
    return String(value);
  }
  if (typeof value === "string" && /^[1-9]\d*$/.test(value)) {
    return value;
  }
  throw new SecurityError("invalid_metadata", 503, "Trusted metadata is unavailable.");
}
__name(numericId, "numericId");

// ../../../../../Users/diegohaz/Developer/ariviso/packages/security/src/capabilities.ts
function signingKey(configuration) {
  if (configuration.secret.length < 32) {
    throw new Error("A capability secret must contain at least 32 characters.");
  }
  return new TextEncoder().encode(configuration.secret);
}
__name(signingKey, "signingKey");
function positiveInteger2(value) {
  if (typeof value !== "number" || !Number.isSafeInteger(value) || value < 1) {
    throw new SecurityError("invalid_capability", 401, "The ingest credential is invalid.");
  }
  return value;
}
__name(positiveInteger2, "positiveInteger");
function parseCapability(value) {
  const data = record(value);
  return {
    runId: textField(data.runId),
    repositoryId: numericId(data.repositoryId),
    workflowRunId: numericId(data.workflowRunId),
    workflowAttempt: positiveInteger2(data.workflowAttempt),
    testedSha: textField(data.testedSha),
    planDigest: textField(data.planDigest),
    shardKey: textField(data.shardKey),
    jobId: numericId(data.jobId),
    maximumBytes: positiveInteger2(data.maximumBytes),
    maximumImages: positiveInteger2(data.maximumImages)
  };
}
__name(parseCapability, "parseCapability");
async function issueToken(configuration, kind, claims, expiresIn) {
  if (!Number.isSafeInteger(expiresIn) || expiresIn < 1 || expiresIn > 900) {
    throw new Error("Ingest credentials must expire within 15 minutes.");
  }
  return new SignJWT({ ...claims, kind, environment: configuration.environment }).setProtectedHeader({ alg: "HS256", typ: "JWT" }).setIssuer(configuration.issuer).setAudience(`ariviso:${kind}:${configuration.environment}`).setJti(crypto.randomUUID()).setIssuedAt().setExpirationTime(`${expiresIn}s`).sign(signingKey(configuration));
}
__name(issueToken, "issueToken");
async function verifyToken(configuration, kind, token) {
  try {
    const result = await jwtVerify(token, signingKey(configuration), {
      algorithms: ["HS256"],
      issuer: configuration.issuer,
      audience: `ariviso:${kind}:${configuration.environment}`,
      typ: "JWT",
      requiredClaims: ["exp", "iat", "jti"],
      maxTokenAge: "15m"
    });
    if (result.payload.kind !== kind || result.payload.environment !== configuration.environment) {
      throw new Error("Wrong credential kind.");
    }
    return result.payload;
  } catch {
    throw new SecurityError(
      "invalid_capability",
      401,
      "The ingest credential is invalid or expired."
    );
  }
}
__name(verifyToken, "verifyToken");
function issueIngestCapability(configuration, capability, expiresIn = 600) {
  return issueToken(configuration, "ingest", parseCapability(capability), expiresIn);
}
__name(issueIngestCapability, "issueIngestCapability");
async function verifyIngestCapability(configuration, token) {
  return parseCapability(await verifyToken(configuration, "ingest", token));
}
__name(verifyIngestCapability, "verifyIngestCapability");

// drill-worker.mjs
var maximumObjectBytes = 16 * 1024 * 1024;
var maximumDatabaseBytes = 512 * 1024 * 1024;
var json = /* @__PURE__ */ __name((value, status = 200) => Response.json(value, { status, headers: { "cache-control": "no-store" } }), "json");
async function parallel(items, operation, concurrency = 6) {
  let index = 0;
  const results = Array.from({ length: items.length });
  await Promise.all(
    Array.from({ length: concurrency }, async () => {
      while (index < items.length) {
        const current = index++;
        results[current] = await operation(items[current]);
      }
    })
  );
  return results;
}
__name(parallel, "parallel");
function measuredDatabase(database, measurements) {
  const record2 = /* @__PURE__ */ __name((sql, result, elapsed) => {
    measurements.push({ sql: sql.slice(0, 110), milliseconds: elapsed, meta: result.meta ?? null });
    return result;
  }, "record");
  const wrap = /* @__PURE__ */ __name((statement2, sql) => ({
    native: statement2,
    sql,
    bind(...values) {
      return wrap(statement2.bind(...values), sql);
    },
    async all() {
      const start = performance.now();
      return record2(sql, await statement2.all(), performance.now() - start);
    },
    async run() {
      const start = performance.now();
      return record2(sql, await statement2.run(), performance.now() - start);
    },
    async first() {
      return (await this.all()).results?.[0] ?? null;
    }
  }), "wrap");
  return {
    prepare(sql) {
      return wrap(database.prepare(sql), sql);
    },
    async batch(statements) {
      const start = performance.now();
      const results = await database.batch(statements.map((statement2) => statement2.native));
      const elapsed = performance.now() - start;
      results.forEach((result, index) => record2(statements[index].sql, result, elapsed));
      return results;
    }
  };
}
__name(measuredDatabase, "measuredDatabase");
function measuredStore(store, counts, name) {
  return Object.fromEntries(
    ["get", "put", "list", "delete", "createMultipartUpload"].map((method) => [
      method,
      async (...args) => {
        const key = `${name}.${method}`;
        counts[key] = (counts[key] ?? 0) + 1;
        const result = await store[method](...args);
        if (method !== "createMultipartUpload") return result;
        return {
          key: result.key,
          uploadId: result.uploadId,
          ...Object.fromEntries(
            ["uploadPart", "complete", "abort"].map((partMethod) => [
              partMethod,
              async (...partArgs) => {
                const partKey = `${name}.multipart.${partMethod}`;
                counts[partKey] = (counts[partKey] ?? 0) + 1;
                return result[partMethod](...partArgs);
              }
            ])
          )
        };
      }
    ])
  );
}
__name(measuredStore, "measuredStore");
async function authorization(request, secret) {
  const value = request.headers.get("authorization") ?? "";
  const [received, expected] = await Promise.all(
    [value, `Bearer ${secret}`].map(
      async (text) => new Uint8Array(await crypto.subtle.digest("SHA-256", new TextEncoder().encode(text)))
    )
  );
  return received.reduce((difference, byte, index) => difference | byte ^ expected[index], 0) === 0;
}
__name(authorization, "authorization");
function context(env, counts = {}, queries = []) {
  return {
    database: measuredDatabase(env.SOURCE_DB, queries),
    images: measuredStore(env.SOURCE_IMAGES, counts, "sourceImages"),
    quarantine: measuredStore(env.SOURCE_PRIVATE, counts, "sourcePrivate"),
    backups: measuredStore(env.BACKUPS, counts, "backups"),
    comparisons: {
      async send() {
        throw new Error("Diagnostic queue delivery is forbidden");
      }
    },
    github: {
      appId: "diagnostic",
      repository: "diagnostic/diagnostic",
      repositoryId: "diagnostic",
      async request() {
        throw new Error("Diagnostic GitHub access is forbidden");
      }
    },
    origin: "https://diagnostic.invalid",
    budget: {
      tasksPerStep: 25,
      objectsPerStep: 250,
      leaseMilliseconds: 6e5,
      maxAttempts: 3,
      maximumObjectBytes,
      maximumDatabaseBytes,
      maximumExportEntries: 2e5
    },
    now: Date.now
  };
}
__name(context, "context");
async function verifyPage(env, input) {
  const counts = {};
  const key = safeKey(input.key);
  if (!key.startsWith(`backups/${input.day}/${input.required ? "required" : "pages"}/`))
    throw new Error("Wrong inventory namespace");
  const object = await env.BACKUPS.get(key);
  if (!object || object.size > 4 * 1024 * 1024) throw new Error("Missing inventory");
  const bytes = new Uint8Array(await new Response(object.body).arrayBuffer());
  const hash = await digestStream(new Response(bytes).body, 4 * 1024 * 1024);
  if (hash.digest !== input.digest) throw new Error("Inventory checksum differs");
  const entries = JSON.parse(new TextDecoder().decode(bytes));
  if (![1, 2].includes(input.version) || !Array.isArray(entries) || entries.length !== input.objects || entries.length > 1e3)
    throw new Error("Invalid inventory");
  await parallel(entries, async (entry) => {
    safeKey(entry.key);
    if (!["images", "quarantine"].includes(entry.source) || (input.version === 1 ? entry.backupKey !== `backups/${input.day}/objects/${entry.source}/${entry.key}` : !new RegExp(`^backup-objects/${entry.source}/[a-f0-9]{32}$`, "u").test(entry.backupKey)))
      throw new Error("Invalid object namespace");
    await copyVerifiedObject({
      source: measuredStore(env.BACKUPS, counts, "backups"),
      destination: measuredStore(
        entry.source === "images" ? env.TARGET_IMAGES : env.TARGET_PRIVATE,
        counts,
        "target"
      ),
      sourceKey: entry.backupKey,
      destinationKey: entry.key,
      maximum: maximumObjectBytes,
      expectedDigest: entry.digest,
      expectedBytes: entry.bytes
    });
  });
  return {
    objects: entries.length,
    bytes: entries.reduce((total, entry) => total + entry.bytes, 0),
    counts
  };
}
__name(verifyPage, "verifyPage");
var drill_worker_default = {
  async fetch(request, env) {
    if (!env.DRILL_TOKEN || !await authorization(request, env.DRILL_TOKEN))
      return json({ error: "unauthorized" }, 401);
    const url = new URL(request.url);
    const start = Date.now();
    try {
      if (url.pathname === "/health")
        return json({
          diagnostic: true,
          secretEpoch: env.SECRET_EPOCH,
          sourceId: env.SOURCE_DATABASE_ID,
          now: start
        });
      if (url.pathname === "/probe/page" && request.method === "POST") {
        const { warm } = await request.json();
        const prefix = "drill/page-probe/";
        const store = Object.fromEntries(
          ["get", "put", "delete", "createMultipartUpload"].map((method) => [
            method,
            (key, ...args) => env.BACKUPS[method](`${prefix}${key}`, ...args)
          ])
        );
        const counts = {};
        const queries = [];
        const scope = context({ ...env, SOURCE_DB: env.PAGE_DB, BACKUPS: store }, counts, queries);
        scope.budget.objectsPerStep = 1e3;
        scope.budget.leaseMilliseconds = 18e4;
        if (warm) {
          await atomic(scope.database, [
            assertion(
              scope.database,
              "(SELECT count(*) FROM operations_backup_objects WHERE state='ready')=1000 AND NOT EXISTS(SELECT 1 FROM operations_backups WHERE lease_token IS NOT NULL AND lease_until>?)",
              [Date.now()]
            ),
            scope.database.prepare("DELETE FROM operations_backup_pages"),
            scope.database.prepare(
              "UPDATE operations_backups SET cursor=NULL,source_kind=0,page_count=0,object_count=0,image_bytes=0 WHERE id='2026-09-22' AND state='copying'"
            )
          ]);
        } else {
          const row2 = await env.PAGE_DB.prepare(
            "SELECT object_count FROM operations_backups WHERE id='2026-09-22'"
          ).first();
          if (row2?.object_count !== 0) throw new Error("Cold page probe was already run");
        }
        const operationStarted = Date.now();
        const result = await backupDaily(scope, {
          async export() {
            throw new Error("Copy-stage fixture must not claim SQL export evidence");
          }
        });
        const row = await env.PAGE_DB.prepare(
          "SELECT state,object_count,image_bytes,page_count FROM operations_backups WHERE id='2026-09-22'"
        ).first();
        return json({
          syntheticCopyStage: true,
          warm: !!warm,
          result,
          row,
          counts,
          queries,
          operationMilliseconds: Date.now() - operationStarted,
          milliseconds: Date.now() - start
        });
      }
      if (url.pathname === "/probe/streams" && request.method === "POST") {
        const results = [];
        for (const kind of ["known", "unknown", "oversize"]) {
          const counts = {};
          const store = measuredStore(env.BACKUPS, counts, "backups");
          const key = `drill/probes/${crypto.randomUUID()}`;
          const bytes = 10 * 1024 * 1024 + 123;
          let remaining = bytes;
          const body = new ReadableStream({
            pull(controller) {
              if (!remaining) {
                controller.close();
                return;
              }
              const length = Math.min(remaining, 1024 * 1024);
              remaining -= length;
              controller.enqueue(new Uint8Array(length).fill(23));
            }
          });
          let error = null;
          let written;
          try {
            written = await putBoundedStream(
              store,
              key,
              { body, ...kind === "known" ? { bytes } : {} },
              kind === "oversize" ? 9 * 1024 * 1024 : 12 * 1024 * 1024
            );
          } catch (failure) {
            error = failure instanceof Error ? failure.message : String(failure);
          }
          const object = await store.get(key);
          if (kind === "oversize") {
            if (!error || object || counts["backups.multipart.abort"] !== 1)
              throw new Error("Unknown-length overflow did not abort cleanly");
          } else {
            if (error || !object) throw new Error(error ?? "Missing stream probe output");
            const verified = await digestStream(object.body, 12 * 1024 * 1024);
            if (verified.bytes !== bytes || verified.bytes !== written.bytes || verified.digest !== written.digest)
              throw new Error("Stream probe checksum differs");
            await store.delete(key);
          }
          results.push({ kind, counts, written, error, objectPresent: !!object });
        }
        return json({ results, milliseconds: Date.now() - start });
      }
      if (url.pathname === "/rotation/proof") {
        const hash = /* @__PURE__ */ __name(async (value) => Array.from(
          new Uint8Array(await crypto.subtle.digest("SHA-256", new TextEncoder().encode(value)))
        ).map((byte) => byte.toString(16).padStart(2, "0")).join(""), "hash");
        return json({
          authSecretDigest: await hash(env.AUTH_SECRET),
          ingestSecretDigest: await hash(env.INGEST_CAPABILITY_SECRET),
          epoch: env.SECRET_EPOCH
        });
      }
      if (url.pathname === "/rotation/issue") {
        const token = await issueIngestCapability(
          {
            secret: env.INGEST_CAPABILITY_SECRET,
            issuer: "https://diagnostic.invalid",
            environment: "local"
          },
          {
            runId: "diagnostic",
            repositoryId: "1",
            workflowRunId: "1",
            workflowAttempt: 1,
            testedSha: "a".repeat(40),
            planDigest: "b".repeat(64),
            shardKey: "diagnostic",
            jobId: "1",
            maximumBytes: 1,
            maximumImages: 1
          },
          900
        );
        return json({ token });
      }
      if (url.pathname === "/rotation/verify" && request.method === "POST") {
        try {
          const { token } = await request.json();
          await verifyIngestCapability(
            {
              secret: env.INGEST_CAPABILITY_SECRET,
              issuer: "https://diagnostic.invalid",
              environment: "local"
            },
            token
          );
          return json({ valid: true });
        } catch {
          return json({ valid: false }, 401);
        }
      }
      if (url.pathname === "/source/inventory") {
        const store = url.searchParams.get("store");
        if (!["images", "quarantine"].includes(store)) throw new Error("Invalid source store");
        const page = await (store === "images" ? env.SOURCE_IMAGES : env.SOURCE_PRIVATE).list({
          limit: 1e3,
          cursor: url.searchParams.get("cursor") || void 0
        });
        return json({
          objects: page.objects.map((object) => ({ key: object.key, bytes: object.size })),
          cursor: page.truncated ? page.cursor : null
        });
      }
      if (url.pathname === "/seed/object" && request.method === "PUT") {
        const key = safeKey(url.searchParams.get("key"));
        const store = url.searchParams.get("store") === "quarantine" ? env.SOURCE_PRIVATE : env.SOURCE_IMAGES;
        const bytes = new Uint8Array(await request.arrayBuffer());
        if (!bytes.length || bytes.length > maximumObjectBytes)
          throw new Error("Object size bound");
        await store.put(key, bytes, {
          onlyIf: { etagDoesNotMatch: "*" },
          httpMetadata: {
            contentType: request.headers.get("content-type") ?? "application/octet-stream"
          }
        });
        const saved = await store.get(key);
        if (!saved) throw new Error("Seed object is missing");
        const [expected, actual] = await Promise.all([
          digestStream(new Response(bytes).body, maximumObjectBytes),
          digestStream(saved.body, maximumObjectBytes)
        ]);
        if (actual.bytes !== expected.bytes || actual.digest !== expected.digest)
          throw new Error("Existing seed object differs");
        return json({ key, ...actual });
      }
      if (url.pathname === "/seed/copy" && request.method === "POST") {
        const { entries } = await request.json();
        const counts = {};
        const images = measuredStore(env.SOURCE_IMAGES, counts, "sourceImages");
        if (!Array.isArray(entries) || entries.length > 250) throw new Error("Copy batch bound");
        await parallel(
          entries,
          async (entry) => copyVerifiedObject({
            source: images,
            destination: images,
            sourceKey: safeKey(entry.sourceKey),
            destinationKey: safeKey(entry.key),
            maximum: maximumObjectBytes,
            expectedDigest: entry.digest,
            expectedBytes: entry.bytes
          })
        );
        return json({ copied: entries.length, counts, milliseconds: Date.now() - start });
      }
      if (url.pathname === "/backup/step" && request.method === "POST") {
        const counts = {};
        const queries = [];
        const exporter = {
          async export() {
            const object = await env.BACKUPS.get("drill/staged-database.sql");
            if (!object) throw new Error("Pinned backup awaits locally authenticated D1 export");
            return { body: object.body, bytes: object.size };
          }
        };
        const result = await backupDaily(context(env, counts, queries), exporter);
        const row = await env.SOURCE_DB.prepare(
          "SELECT * FROM operations_backups ORDER BY created_at DESC LIMIT 1"
        ).first();
        return json({
          result,
          row,
          counts,
          queries,
          milliseconds: Date.now() - start,
          colo: request.cf?.colo,
          placement: request.headers.get("cf-placement")
        });
      }
      if (url.pathname === "/backup/stage-database" && request.method === "PUT") {
        const bytes = Number(request.headers.get("content-length"));
        if (!Number.isSafeInteger(bytes) || bytes < 1 || bytes > maximumDatabaseBytes)
          throw new Error("SQL export length bound");
        await env.BACKUPS.put("drill/staged-database.sql", request.body, {
          httpMetadata: { contentType: "application/sql" }
        });
        const object = await env.BACKUPS.get("drill/staged-database.sql");
        if (!object) throw new Error("SQL staging failed");
        return json(await digestStream(object.body, maximumDatabaseBytes));
      }
      if (url.pathname === "/backup/stage-start" && request.method === "POST") {
        const upload = await env.BACKUPS.createMultipartUpload("drill/staged-database.sql", {
          httpMetadata: { contentType: "application/sql" }
        });
        return json({ uploadId: upload.uploadId });
      }
      if (url.pathname === "/backup/stage-part" && request.method === "PUT") {
        const number = Number(url.searchParams.get("part"));
        if (!Number.isSafeInteger(number) || number < 1 || number > 100)
          throw new Error("Part number bound");
        const upload = env.BACKUPS.resumeMultipartUpload(
          "drill/staged-database.sql",
          url.searchParams.get("uploadId")
        );
        return json(await upload.uploadPart(number, request.body));
      }
      if (url.pathname === "/backup/stage-complete" && request.method === "POST") {
        const { uploadId, parts } = await request.json();
        if (!Array.isArray(parts) || parts.length > 100) throw new Error("Part count bound");
        await env.BACKUPS.resumeMultipartUpload("drill/staged-database.sql", uploadId).complete(
          parts
        );
        const object = await env.BACKUPS.get("drill/staged-database.sql");
        if (!object) throw new Error("Staged SQL missing");
        return json(await digestStream(object.body, maximumDatabaseBytes));
      }
      if (url.pathname === "/backup/object") {
        const key = safeKey(url.searchParams.get("key"));
        if (!key.startsWith("backups/")) throw new Error("Backup namespace required");
        const object = await env.BACKUPS.get(key);
        if (!object) return json({ error: "missing" }, 404);
        return new Response(object.body, {
          headers: {
            "content-type": object.httpMetadata?.contentType ?? "application/octet-stream",
            "cache-control": "no-store"
          }
        });
      }
      if (url.pathname === "/restore/import-state") {
        const exists = await env.TARGET_DB.prepare(
          "SELECT name FROM sqlite_master WHERE type='table' AND name='drill_restore_checkpoint'"
        ).first();
        if (!exists) return json({ imported: false });
        const marker = await env.TARGET_DB.prepare(
          "SELECT digest FROM drill_restore_checkpoint"
        ).first();
        const foreignKeys = await env.TARGET_DB.prepare("PRAGMA foreign_key_check").all();
        return json({ imported: true, digest: marker?.digest, foreignKeys: foreignKeys.results });
      }
      if (url.pathname === "/restore/empty") {
        const tables = await env.TARGET_DB.prepare(
          "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE '_cf_%' AND name NOT LIKE 'sqlite_%'"
        ).all();
        const [images, metadata] = await Promise.all([
          env.TARGET_IMAGES.list({ limit: 1 }),
          env.TARGET_PRIVATE.list({ limit: 1 })
        ]);
        if (tables.results.length || images.objects.length || metadata.objects.length)
          throw new Error("Restore target is not empty");
        return json({ empty: true, checkedAt: start });
      }
      if (url.pathname === "/restore/page" && request.method === "POST")
        return json({
          ...await verifyPage(env, await request.json()),
          milliseconds: Date.now() - start
        });
      if (url.pathname === "/restore/sanitize" && request.method === "POST") {
        await sanitizeRestoredDatabase(env.TARGET_DB, Date.now());
        return json({
          sanitized: true,
          secretEpoch: env.SECRET_EPOCH,
          milliseconds: Date.now() - start
        });
      }
      if (url.pathname === "/restore/rotation-recorded" && request.method === "POST") {
        await env.TARGET_DB.prepare(
          "UPDATE operations_events SET resolved_at=? WHERE id='restore:activation:secrets-required'"
        ).bind(Date.now()).run();
        return json({ rotationRecorded: true, activated: false });
      }
      if (url.pathname === "/restore/references") {
        const cursor = url.searchParams.get("cursor") ?? "";
        const rows = await env.TARGET_DB.prepare(`WITH refs AS (
          SELECT 'images' AS store,object_key AS key,digest,bytes FROM ariviso_images WHERE bytes_present=1
          UNION SELECT 'images',copy.object_key,copy.digest,image.bytes FROM ariviso_snapshot_images copy JOIN ariviso_images image ON image.id=copy.image_id WHERE copied=1
          UNION SELECT 'quarantine',plan_object_key,NULL,NULL FROM ingest_run_provenance
          UNION SELECT 'quarantine',object_key,digest,NULL FROM ingest_manifests)
          SELECT store,key,MAX(digest) AS digest,MAX(bytes) AS bytes FROM refs WHERE store||':'||key>? GROUP BY store,key ORDER BY store,key LIMIT 250`).bind(cursor).all();
        await parallel(rows.results, async (row) => {
          const object = await (row.store === "images" ? env.TARGET_IMAGES : env.TARGET_PRIVATE).get(row.key);
          if (!object) throw new Error(`Missing restored reference ${row.key}`);
          const verified = await digestStream(object.body, maximumObjectBytes);
          if (row.digest && row.digest !== verified.digest || row.bytes && row.bytes !== verified.bytes)
            throw new Error(`Restored reference digest differs ${row.key}`);
        });
        const last = rows.results.at(-1);
        return json({
          verified: rows.results.length,
          cursor: last ? `${last.store}:${last.key}` : null,
          milliseconds: Date.now() - start
        });
      }
      if (url.pathname === "/restore/report") {
        const foreignKeys = await env.TARGET_DB.prepare("PRAGMA foreign_key_check").all();
        const counts = await env.TARGET_DB.prepare(`SELECT
          (SELECT count(*) FROM ariviso_captures) AS captures,
          (SELECT count(*) FROM ariviso_images) AS images,
          (SELECT count(*) FROM ariviso_snapshot_images WHERE copied=1) AS baselineCopies,
          (SELECT count(*) FROM ariviso_commands) AS commands,
          (SELECT count(*) FROM session) AS sessions,
          (SELECT count(*) FROM account WHERE accessToken IS NOT NULL OR refreshToken IS NOT NULL OR idToken IS NOT NULL) AS credentials,
          (SELECT count(*) FROM ariviso_runs WHERE active=1) AS activeRuns,
          (SELECT count(*) FROM work_tasks WHERE state NOT IN ('dead','complete')) AS unfencedTasks,
          (SELECT count(*) FROM work_status_outbox WHERE state NOT IN ('obsolete','complete')) AS unfencedDeliveries`).first();
        return json({
          counts,
          foreignKeys: foreignKeys.results,
          secretEpoch: env.SECRET_EPOCH,
          now: start
        });
      }
      if (url.pathname === "/timing" && request.method === "POST") {
        const input = await request.json();
        const iterations = Math.max(1, Math.min(10, input.iterations ?? 1));
        const samples = [];
        for (let index = 0; index < iterations; index++) {
          const measurements = [];
          const service = new Service(measuredDatabase(env.SOURCE_DB, measurements));
          const target = await env.SOURCE_DB.prepare(
            "SELECT id,decision_revision FROM ariviso_comparison_rows WHERE id='e08-review-row-000000'"
          ).first();
          const project = await service.project("e08-project");
          const reviewStart = performance.now();
          const result = await service.review({
            commandId: crypto.randomUUID(),
            actorId: "e08-maintainer",
            sessionId: "e08-review-session",
            comparisonId: "e08-review-comparison",
            verdict: "approved",
            targets: [{ id: target.id, expectedRevision: target.decision_revision }],
            selection: { itemKey: "e08-item-000000", variantKey: "default" },
            now: Date.now()
          });
          const reviewMilliseconds = performance.now() - reviewStart;
          const undoStart = performance.now();
          await service.undo({
            commandId: result.commandId,
            undoCommandId: crypto.randomUUID(),
            actorId: "e08-maintainer",
            sessionId: "e08-review-session",
            expectedBaselineRevision: project.baseline_revision,
            now: Date.now()
          });
          samples.push({
            reviewMilliseconds,
            undoMilliseconds: performance.now() - undoStart,
            measurements
          });
        }
        return json({
          samples,
          milliseconds: Date.now() - start,
          colo: request.cf?.colo,
          placement: request.headers.get("cf-placement")
        });
      }
      return json({ error: "unknown_route" }, 404);
    } catch (error) {
      return json(
        {
          error: error instanceof Error ? error.message : String(error),
          milliseconds: Date.now() - start
        },
        500
      );
    }
  }
};
export {
  drill_worker_default as default
};
//# sourceMappingURL=drill-worker.js.map
