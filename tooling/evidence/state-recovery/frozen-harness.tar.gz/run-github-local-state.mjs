import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import { mkdir, mkdtemp, readFile, readdir, rm, stat, writeFile } from "node:fs/promises";
import { createRequire } from "node:module";
import { resolve } from "node:path";
import { githubStatusLocal, githubStatusScenarios } from "./github-status.mjs";
const live = process.argv.includes("--live");
assert.deepEqual(process.argv.slice(2), live ? ["--live"] : []);
const source = JSON.parse(await readFile("source-manifest.json", "utf8"));
const build = JSON.parse(await readFile("results/build-manifest.json", "utf8"));
for (const { path, sha256 } of build.files) {
  assert.equal(
    createHash("sha256")
      .update(await readFile(path))
      .digest("hex"),
    sha256,
    `Build artifact changed: ${path}`,
  );
}
for (const { path, sha256 } of source.sourceFiles) {
  assert.equal(
    createHash("sha256")
      .update(await readFile(`../../../${path}`))
      .digest("hex"),
    sha256,
    `Frozen source changed: ${path}`,
  );
}
const require = createRequire(new URL("../../../apps/web/package.json", import.meta.url));
const { Miniflare, convertV4MiniflareOptions } = await import(require.resolve("miniflare"));
const directory = await mkdtemp("/tmp/ariviso-e03-github-local-");
const options = convertV4MiniflareOptions({
  d1Persist: `${directory}/d1`,
  r2Persist: `${directory}/r2`,
  workers: [
    {
      name: "probe",
      modules: true,
      scriptPath: resolve("dist/worker.js"),
      compatibilityDate: "2026-09-22",
      compatibilityFlags: ["nodejs_compat"],
      d1Databases: ["DB"],
      r2Buckets: ["IMAGES"],
      bindings: { PROBE_TOKEN: "local-only-not-a-hosted-credential" },
    },
  ],
});
const runtime = new Miniflare(options);
const report = {
  mode: live
    ? "genuine-github-https-with-local-native-d1"
    : "local-native-d1-with-strict-http-mock",
  sourceTree: source.sourceTree,
  startedAt: new Date().toISOString(),
  passed: false,
  events: [],
  boundaries: {
    state: "Local native Miniflare D1, not hosted D1",
    transport: live
      ? "Genuine GitHub HTTPS from local Node; token never uploaded to Cloudflare"
      : "Strict HTTP mock; no GitHub token read and no outbound request",
    sender:
      "Reviewed diagnostic sender with custom check name; production sendGitHubCheck is not exercised",
    hostedEvidence:
      "Separate hosted state fixtures; this is not a combined hosted-state/actual-sender result",
    blockedUpload:
      "Automatic approval review rejected the separate GitHub credential upload command before execution. That command never read, copied, or uploaded the installation-token payload. No equivalent upload was retried.",
  },
};
const filename = live
  ? "results/live-github-local-state.json"
  : "results/local-github-controller.json";
await mkdir("results", { recursive: true });
await writeFile(filename, `${JSON.stringify(report, null, 2)}\n`, { flag: "wx" });
const save = () => writeFile(filename, `${JSON.stringify(report, null, 2)}\n`);
let credential;
const tokenPath = "/tmp/ariviso-e03-status-installation-token.json";
try {
  const database = await runtime.getD1Database("DB", "probe");
  const paths = (await readdir("../../../apps/web/migrations"))
    .filter((name) => name.endsWith(".sql"))
    .sort()
    .map((name) => `../../../apps/web/migrations/${name}`);
  for (const path of paths) {
    const sql = (await readFile(path, "utf8")).replace(/^--.*$/gmu, "");
    let statement = "";
    for (const line of sql.split("\n")) {
      statement += `${line}\n`;
      if (!line.trimEnd().endsWith(";")) continue;
      await database.prepare(statement).run();
      statement = "";
    }
  }
  const context = {
    database,
    event: (name, details) => {
      report.events.push({ name, ...details });
    },
  };
  report.localMock = await githubStatusLocal(context);
  assert.deepEqual(report.localMock.measurements.requests, { GET: 8, POST: 1, PATCH: 5 });
  assert.equal(report.localMock.measurements.assertionCount, 48);
  await save();
  if (live) {
    assert.equal((await stat(tokenPath)).mode & 0o777, 0o600);
    credential = JSON.parse(await readFile(tokenPath, "utf8"));
    assert.equal(String(credential.repositoryId), "1380792062");
    assert.deepEqual(credential.permissions, { checks: "write", metadata: "read" });
    assert.ok(
      Date.parse(credential.expiresAt) - Date.now() > 10 * 60 * 1000,
      "Scoped token needs at least ten minutes remaining",
    );
    report.credential = {
      repositoryId: credential.repositoryId,
      expiresAt: credential.expiresAt,
      permissions: credential.permissions,
      uploadedToWorker: false,
    };
    report.live = await githubStatusScenarios(context, { token: credential.token });
    assert.deepEqual(report.live.measurements.requests, { GET: 8, POST: 1, PATCH: 5 });
    assert.equal(report.live.measurements.assertionCount, 48);
  }
  report.foreignKeyCheck = (await database.prepare("PRAGMA foreign_key_check").all()).results;
  assert.deepEqual(report.foreignKeyCheck, []);
  report.passed = true;
} catch (error) {
  report.failure = { name: error.name, message: error.message };
  throw error;
} finally {
  if (credential) {
    try {
      const response = await fetch("https://api.github.com/installation/token", {
        method: "DELETE",
        redirect: "error",
        headers: {
          Authorization: `Bearer ${credential.token}`,
          Accept: "application/vnd.github+json",
          "X-GitHub-Api-Version": "2022-11-28",
          "User-Agent": "ariviso-status-race-fixture",
        },
        signal: AbortSignal.timeout(15000),
      });
      report.tokenCleanup = {
        status: response.status,
        revoked: response.status === 204,
        at: new Date().toISOString(),
        valueRecorded: false,
      };
      await response.body?.cancel();
      if (response.status === 204) {
        await rm(tokenPath);
        report.tokenCleanup.protectedFileRemoved = true;
      }
    } catch {
      report.tokenCleanup = {
        revoked: false,
        error: "Token revocation response was not confirmed",
        valueRecorded: false,
      };
    }
  }
  report.completedAt = new Date().toISOString();
  await save();
  await runtime.dispose();
  await rm(directory, { recursive: true, force: true });
  console.log(
    JSON.stringify({
      mode: report.mode,
      passed: report.passed,
      localAssertions: report.localMock?.measurements.assertionCount,
      liveRequests: report.live?.measurements.requests,
      liveCheckId: report.live?.checkId,
      tokenCleanup: report.tokenCleanup,
      failure: report.failure,
    }),
  );
}
