import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import { mkdir, readFile, writeFile } from "node:fs/promises";
import { githubStatusScenarios } from "./github-status.mjs";

// This canary is synthetic. The global transport is also disabled so a test
// cannot make an external request if an injected-fetch boundary regresses.
const canary = "local-boundary-canary-not-an-account-credential";
const originalFetch = globalThis.fetch;
let forbiddenNetworkCalls = 0;
let forbiddenDatabaseCalls = 0;
globalThis.fetch = async () => {
  forbiddenNetworkCalls += 1;
  throw new Error("External requests are disabled in this boundary test");
};
const database = {
  prepare() {
    forbiddenDatabaseCalls += 1;
    throw new Error("This boundary test must stop before D1 access");
  },
  batch() {
    forbiddenDatabaseCalls += 1;
    throw new Error("This boundary test must stop before D1 access");
  },
};
const cases = [];
const repository = { id: 1380792062, full_name: "ariakit/ariviso-diagnostics", private: false };

async function refusal(name, fetcher, options = {}) {
  const calls = [];
  const events = [];
  await assert.rejects(
    githubStatusScenarios(
      { database, event: (name, detail) => events.push({ name, ...detail }) },
      {
        token: options.token ?? canary,
        fetcher: async (url, init) => {
          calls.push({ method: init.method, path: new URL(url).pathname });
          return fetcher(url, init);
        },
      },
    ),
    (error) => {
      assert.ok(!error.message.includes(canary));
      return true;
    },
  );
  assert.ok(!JSON.stringify(events).includes(canary));
  assert.deepEqual(
    calls.map((call) => call.method),
    options.methods ?? ["GET"],
  );
  cases.push({ name, passed: true, mockHttpCalls: calls, publicEvents: events });
  return events;
}

try {
  await refusal(
    "missing-token-stops-before-http",
    async () => {
      throw new Error("This callback must not run");
    },
    { token: "", methods: [] },
  );

  await refusal("wrong-repository-stops-before-create", async () =>
    Response.json({ ...repository, id: 0 }),
  );

  await refusal(
    "wrong-app-stops-after-single-mocked-create",
    async (_url, init) => {
      if (init.method === "GET") return Response.json(repository);
      return Response.json({ ...JSON.parse(init.body), id: 123, app: { id: 1 } }, { status: 201 });
    },
    { methods: ["GET", "POST"] },
  );

  let streamSignal;
  await refusal("streamed-response-over-64kib-aborts", async (_url, init) => {
    streamSignal = init.signal;
    return new Response("x".repeat(65537));
  });
  assert.equal(streamSignal.aborted, true);

  let lengthSignal;
  await refusal("content-length-over-64kib-aborts", async (_url, init) => {
    lengthSignal = init.signal;
    return new Response("{}", { headers: { "content-length": "65537" } });
  });
  assert.equal(lengthSignal.aborted, true);

  await refusal("fetch-error-cannot-disclose-canary", async () => {
    throw new Error(canary);
  });

  await refusal("redirect-refused-without-follow-up", async () => ({ redirected: true }));

  const reflected = await refusal("request-id-cannot-disclose-canary", async () =>
    Response.json({ ...repository, id: 0 }, { headers: { "x-github-request-id": canary } }),
  );
  assert.equal(reflected[0].receipt.requestId, null);

  assert.equal(forbiddenNetworkCalls, 0);
  assert.equal(forbiddenDatabaseCalls, 0);
  const report = {
    passed: true,
    mode: "local injected HTTP boundary checks",
    runtime: process.version,
    completedAt: new Date().toISOString(),
    adapterSha256: createHash("sha256")
      .update(await readFile(new URL("./github-status.mjs", import.meta.url)))
      .digest("hex"),
    caseCount: cases.length,
    outboundRequests: 0,
    d1Calls: 0,
    boundaries:
      "No native D1 or live GitHub coverage; the separate githubStatusLocal suite supplies native D1 coverage",
    cases,
  };
  await mkdir(new URL("./results/", import.meta.url), { recursive: true });
  await writeFile(
    new URL("./results/github-status-negative.json", import.meta.url),
    `${JSON.stringify(report, null, 2)}\n`,
    { flag: "wx" },
  );
  console.log(
    JSON.stringify({ passed: true, caseCount: cases.length, outboundRequests: 0, d1Calls: 0 }),
  );
} finally {
  globalThis.fetch = originalFetch;
}
