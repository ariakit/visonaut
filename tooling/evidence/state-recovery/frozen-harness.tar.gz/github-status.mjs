import {
  claimStatus,
  deliverStatus,
  isStatusCurrent,
  reconcileStatus,
  settleStatus,
  statusIntentStatements,
} from "../../../packages/service/src/work.ts";

const origin = "https://api.github.com";
const repository = "ariakit/ariviso-diagnostics";
const repositoryId = 1380792062;
const appId = 5028451;
const headSha = "24f508cc65c91867d747a8046d4aef6348418ced";
const checkName = "Ariviso status race fixture";
const repositoryPath = `/repos/${repository}`;
const creationPath = `${repositoryPath}/check-runs`;
const requestLimits = { GET: 10, POST: 1, PATCH: 5 };
const responseByteLimit = 64 * 1024;
const requestTimeoutMs = 15000;
const genericOutput = {
  title: "Diagnostic status fixture",
  summary: "Synthetic state recovery evidence. This check is not a product review result.",
};

function requireCondition(value, message) {
  if (!value) throw new Error(message);
}

function barrier() {
  let release;
  const promise = new Promise((resolve) => {
    release = resolve;
  });
  return { promise, release };
}

async function waitForPause(entered, operation) {
  await Promise.race([
    entered.promise,
    operation.then(() => {
      throw new Error("Diagnostic delivery ended before the injected pause");
    }),
  ]);
}

async function boundedJson(response) {
  const declaredLength = response.headers.get("content-length");
  requireCondition(
    !declaredLength ||
      (/^\d+$/u.test(declaredLength) && Number(declaredLength) <= responseByteLimit),
    "GitHub response exceeds the diagnostic body limit",
  );
  requireCondition(response.body, "GitHub response body is missing");
  const reader = response.body.getReader();
  const chunks = [];
  let total = 0;
  try {
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      total += value.byteLength;
      requireCondition(
        total <= responseByteLimit,
        "GitHub response exceeds the diagnostic body limit",
      );
      chunks.push(value);
    }
  } catch {
    await reader.cancel().catch(() => {});
    throw new Error("GitHub response could not be read within the diagnostic body limit");
  } finally {
    reader.releaseLock();
  }
  const bytes = new Uint8Array(total);
  let offset = 0;
  for (const chunk of chunks) {
    bytes.set(chunk, offset);
    offset += chunk.byteLength;
  }
  let result;
  try {
    result = JSON.parse(new TextDecoder("utf-8", { fatal: true }).decode(bytes));
  } catch {
    throw new Error("GitHub response is not valid diagnostic JSON");
  }
  requireCondition(
    result && typeof result === "object" && !Array.isArray(result),
    "GitHub response shape is invalid",
  );
  return result;
}

function numericId(value) {
  return Number.isSafeInteger(value) && value > 0;
}

function selectedReceipt(method, response, data, secret) {
  const requestId = response.headers.get("x-github-request-id");
  return {
    method,
    status: response.status,
    requestId:
      requestId && /^[A-Za-z0-9:-]{1,128}$/u.test(requestId) && !requestId.includes(secret)
        ? requestId
        : null,
    checkId: data.name === checkName && numericId(data.id) ? data.id : null,
    name: data.name === checkName ? checkName : null,
    appId: data.app?.id === appId ? appId : null,
    headSha: data.head_sha === headSha ? headSha : null,
    conclusion: ["success", "failure"].includes(data.conclusion) ? data.conclusion : null,
  };
}

/**
 * Diagnostic adapter only. The production sendGitHubCheck fixes its name to
 * "Ariviso"; this sender uses a separate check and synthetic domain intents.
 * The caller must durably reserve its probe prefix before invoking this function.
 * An uncertain create is never retried, searched for, or adopted here.
 */
export async function githubStatusScenarios(context, { token, fetcher = fetch }) {
  requireCondition(
    typeof token === "string" && token.length > 0 && token.length <= 4096 && !/[\r\n]/u.test(token),
    "A diagnostic GitHub token is required",
  );
  const { database } = context;
  const invocation = crypto.randomUUID();
  const stateId = `e03:github-status:${invocation}`;
  const marker = (revision) => `e03-status:${invocation}:revision:${revision}`;
  const receipts = [];
  const assertions = [];
  const checkpoints = [];
  const scenarios = [];
  const requests = { GET: 0, POST: 0, PATCH: 0 };
  let checkId = null;
  let expectedRemoteMarker = marker(0);
  let activeHttp = 0;
  let maximumActiveHttp = 0;
  let activeCallbacks = 0;
  let maximumActiveCallbacks = 0;
  let now = 100;

  function equal(actual, expected, message) {
    requireCondition(JSON.stringify(actual) === JSON.stringify(expected), message);
    assertions.push({ message, actual, expected, passed: true });
  }

  function checkIdentity(data, externalId) {
    requireCondition(
      numericId(data.id) &&
        (checkId === null || data.id === checkId) &&
        data.name === checkName &&
        data.app?.id === appId &&
        data.head_sha === headSha &&
        data.external_id === externalId,
      "Diagnostic check identity does not match the fixed target",
    );
  }

  async function request(method, path, payload) {
    const allowed =
      (method === "GET" && path === repositoryPath) ||
      (method === "POST" && path === creationPath && checkId === null) ||
      (["GET", "PATCH"].includes(method) &&
        checkId !== null &&
        path === `${creationPath}/${checkId}`);
    requireCondition(allowed, "Diagnostic HTTP request is outside its fixed target");
    requireCondition(
      requests[method] < requestLimits[method],
      "Diagnostic HTTP request budget exceeded",
    );
    requests[method] += 1;
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), requestTimeoutMs);
    activeHttp += 1;
    maximumActiveHttp = Math.max(maximumActiveHttp, activeHttp);
    try {
      const response = await fetcher(`${origin}${path}`, {
        method,
        redirect: "error",
        signal: controller.signal,
        headers: {
          Authorization: `Bearer ${token}`,
          Accept: "application/vnd.github+json",
          "X-GitHub-Api-Version": "2022-11-28",
          "User-Agent": "ariviso-status-race-fixture",
          ...(payload ? { "Content-Type": "application/json" } : {}),
        },
        ...(payload ? { body: JSON.stringify(payload) } : {}),
      });
      requireCondition(!response.redirected, "Diagnostic HTTP redirects are refused");
      requireCondition(
        !response.url || response.url === `${origin}${path}`,
        "Diagnostic response URL changed",
      );
      const data = await boundedJson(response);
      const receipt = selectedReceipt(method, response, data, token);
      receipts.push(receipt);
      context.event?.("github-status.http", { receipt });
      requireCondition(
        response.status === (method === "POST" ? 201 : 200),
        "GitHub diagnostic HTTP status is not successful",
      );
      return { data, receipt };
    } catch {
      // Fetch errors and remote bodies can contain arbitrary text. Never copy
      // them into the public receipt or work_status_outbox.last_error.
      controller.abort();
      throw new Error(`Diagnostic GitHub ${method} failed; no automatic retry is permitted`);
    } finally {
      clearTimeout(timeout);
      activeHttp -= 1;
    }
  }

  async function remoteCheck() {
    requireCondition(checkId !== null, "A newly created diagnostic check is required");
    const response = await request("GET", `${creationPath}/${checkId}`);
    checkIdentity(response.data, expectedRemoteMarker);
    return response;
  }

  const repo = await request("GET", repositoryPath);
  requireCondition(
    repo.data.id === repositoryId &&
      repo.data.full_name === repository &&
      repo.data.private === false,
    "The fixed diagnostic repository identity is not verified",
  );
  const created = await request("POST", creationPath, {
    name: checkName,
    head_sha: headSha,
    external_id: expectedRemoteMarker,
    status: "in_progress",
    output: genericOutput,
  });
  checkIdentity(created.data, expectedRemoteMarker);
  checkId = created.data.id;
  context.event?.("github-status.created", { checkId, repository, checkName });

  async function intent(revision, conclusion) {
    await database.batch(
      statusIntentStatements(database, {
        checkId: stateId,
        revision,
        runId: `synthetic:${invocation}`,
        attempt: 1,
        comparisonRevision: revision,
        sourceRevision: revision,
        conclusion,
        detailsUrl: `https://github.com/${repository}`,
        maxAttempts: 2,
        now,
      }),
    );
  }

  async function claim(leaseToken, revision) {
    const result = await claimStatus(database, {
      id: stateId,
      token: leaseToken,
      now,
      leaseMs: 10,
    });
    equal(
      result?.revision ?? null,
      revision,
      "Status claim matches the expected revision or refusal",
    );
    return result;
  }

  async function snapshot(label) {
    const check = await database
      .prepare(
        "SELECT desired_revision, delivered_revision, lease_token, lease_until, lease_revision, request_started, ambiguous FROM work_checks WHERE id = ?",
      )
      .bind(stateId)
      .first();
    const rows = await database
      .prepare(
        "SELECT revision, conclusion, state, attempts FROM work_status_outbox WHERE check_id = ? ORDER BY revision",
      )
      .bind(stateId)
      .all();
    const value = { label, logicalNow: now, check, outbox: rows.results ?? [] };
    checkpoints.push(value);
    return value;
  }

  function deliver(leaseToken, revision, hooks = {}) {
    return deliverStatus(database, {
      id: stateId,
      token: leaseToken,
      revision,
      now: () => now,
      send: async (delivery, isCurrent) => {
        activeCallbacks += 1;
        maximumActiveCallbacks = Math.max(maximumActiveCallbacks, activeCallbacks);
        try {
          await remoteCheck();
          if (hooks.afterGet) await hooks.afterGet();
          const current = await isCurrent();
          if (hooks.observeCurrent) hooks.observeCurrent(current);
          if (!current) return "not-sent";
          const nextMarker = marker(delivery.revision);
          const response = await request("PATCH", `${creationPath}/${checkId}`, {
            name: checkName,
            external_id: nextMarker,
            status: "completed",
            conclusion: delivery.conclusion,
            completed_at: new Date().toISOString(),
            output: genericOutput,
          });
          checkIdentity(response.data, nextMarker);
          requireCondition(
            response.data.status === "completed" &&
              response.data.conclusion === delivery.conclusion,
            "Diagnostic PATCH receipt has the wrong result",
          );
          expectedRemoteMarker = nextMarker;
          if (hooks.afterReceipt) await hooks.afterReceipt(response.receipt);
        } finally {
          activeCallbacks -= 1;
        }
      },
    });
  }

  // The old callback completes its remote metadata GET before the new intent
  // is injected. The exact work.ts isCurrent callback runs after that pause.
  await intent(1, "success");
  await claim("before-get", 1);
  now = 101;
  const beforePatch = barrier();
  const resumeBeforePatch = barrier();
  let observedCurrent = null;
  const obsolete = deliver("before-get", 1, {
    afterGet: async () => {
      beforePatch.release();
      await resumeBeforePatch.promise;
    },
    observeCurrent: (current) => {
      observedCurrent = current;
    },
  });
  try {
    await waitForPause(beforePatch, obsolete);
    await intent(2, "failure");
  } finally {
    resumeBeforePatch.release();
    await obsolete;
  }
  equal(await obsolete, "stale", "Obsolete success is refused after remote metadata lookup");
  equal(observedCurrent, false, "isCurrent is false after the injected revision change");
  equal(requests.PATCH, 0, "Obsolete success made zero PATCH requests");
  await claim("revision-two", 2);
  equal(await deliver("revision-two", 2), "delivered", "Current revision two failure is delivered");
  equal(requests.PATCH, 1, "First case makes one current failure PATCH");
  await snapshot("metadata-pause-refused-obsolete-success");
  scenarios.push({
    name: "metadata-get-before-patch",
    obsoleteOutcome: "stale",
    obsoletePatches: 0,
    currentRevision: 2,
  });

  // HTTP PATCH 200 is fully received. Only its callback completion is held;
  // this is an injected delay, not a claim of real GitHub transport latency.
  now = 200;
  await intent(3, "success");
  await claim("held-response", 3);
  now = 201;
  const responseRead = barrier();
  const releaseResponse = barrier();
  let delayedReceipt = null;
  const delayed = deliver("held-response", 3, {
    afterReceipt: async (receipt) => {
      delayedReceipt = receipt;
      responseRead.release();
      await releaseResponse.promise;
    },
  });
  try {
    await waitForPause(responseRead, delayed);
    equal(delayedReceipt.status, 200, "Delayed callback already has a complete HTTP 200 receipt");
    equal(activeHttp, 0, "No HTTP request remains active at the response-withholding barrier");
    equal(activeCallbacks, 1, "Delivery callback remains pending after HTTP completion");
    await intent(4, "failure");
    now = 220;
    await reconcileStatus(database, { now, limit: 100 });
    const held = await snapshot("http-complete-callback-withheld-after-lease-expiry");
    equal(held.check.ambiguous, 1, "Expired pending callback requires explicit attention");
    equal(
      await isStatusCurrent(database, { id: stateId, token: "held-response", revision: 3, now }),
      false,
      "Expired held revision is not current",
    );
    await claim("premature-revision-four", null);
    equal(
      await deliver("held-response", 3),
      "stale",
      "Duplicate delivery is refused while callback is held",
    );
    equal(requests.PATCH, 2, "Held callback blocks all later PATCH requests");
  } finally {
    releaseResponse.release();
    await delayed;
  }
  equal(await delayed, "delivered", "Held confirmed response settles after barrier release");
  await claim("revision-four", 4);
  equal(
    await deliver("revision-four", 4),
    "delivered",
    "Revision four failure follows settled revision three success",
  );
  equal(requests.PATCH, 3, "Second case ends with the third PATCH");
  await snapshot("held-response-settled-then-current-failure");
  scenarios.push({
    name: "complete-http-response-withheld",
    injection: "HTTP 200 body fully read; only callback resolution was delayed",
    heldRevision: 3,
    currentRevision: 4,
    laterClaimBlocked: true,
    duplicateSendRefused: true,
  });

  // Deliberately lose a known complete response at the callback boundary.
  // Settlement uses the saved PATCH receipt, never a later GET as proof.
  now = 300;
  await intent(5, "success");
  await claim("response-loss", 5);
  now = 301;
  let knownReceipt = null;
  const ambiguous = await deliver("response-loss", 5, {
    afterReceipt: async (receipt) => {
      knownReceipt = receipt;
      throw new Error("Injected diagnostic response loss after verified HTTP 200");
    },
  });
  equal(ambiguous, "ambiguous", "Injected response loss marks status delivery ambiguous");
  await intent(6, "failure");
  now = 320;
  await reconcileStatus(database, { now, limit: 100 });
  await claim("premature-revision-six", null);
  const ambiguousState = await snapshot("response-loss-awaiting-receipt-based-settlement");
  equal(ambiguousState.check.ambiguous, 1, "Ambiguous lock persists after logical expiry");
  equal(knownReceipt?.method, "PATCH", "Settlement proof is the saved PATCH receipt");
  equal(knownReceipt?.status, 200, "Settlement proof confirms HTTP 200");
  equal(knownReceipt?.checkId, checkId, "Settlement receipt belongs to the created check");
  equal(knownReceipt?.conclusion, "success", "Settlement receipt confirms revision five success");
  equal(
    expectedRemoteMarker === marker(5),
    true,
    "Saved verified response belongs to revision five",
  );
  equal(activeHttp, 0, "No request remains active before explicit settlement");
  equal(activeCallbacks, 0, "No sender callback remains active before explicit settlement");
  equal(requests.PATCH, 4, "No new PATCH starts before explicit settlement");
  equal(
    await settleStatus(database, {
      id: stateId,
      token: "response-loss",
      revision: 5,
      now,
      outcome: "delivered",
    }),
    true,
    "Known completed HTTP request explicitly settles as delivered",
  );
  await claim("revision-six", 6);
  equal(
    await deliver("revision-six", 6),
    "delivered",
    "Current revision six failure follows explicit settlement",
  );
  const finalRemote = await remoteCheck();
  equal(
    finalRemote.data.external_id === marker(6),
    true,
    "Final remote state has the revision six marker",
  );
  equal(finalRemote.data.conclusion, "failure", "Final remote check conclusion is failure");
  equal(finalRemote.data.status, "completed", "Final remote check is completed");
  const final = await snapshot("final-remote-and-native-state-confirmed");
  equal(final.check.desired_revision, 6, "Final native desired revision is six");
  equal(final.check.delivered_revision, 6, "Final native delivered revision is six");
  equal(final.check.lease_token, null, "Final native status lease is released");
  equal(final.check.ambiguous, 0, "Final native ambiguity is cleared");
  equal(final.check.request_started, 0, "Final native request-started flag is cleared");
  equal(requests.POST, 1, "Exactly one new diagnostic check was created");
  equal(requests.PATCH, 5, "Exactly five PATCH requests were made");
  equal(requests.GET, 8, "Exactly eight bounded metadata GET requests were made");
  equal(maximumActiveHttp, 1, "At most one HTTP request was active");
  equal(maximumActiveCallbacks, 1, "At most one status sender callback was active");
  scenarios.push({
    name: "known-receipt-response-loss",
    injection: "Exception after a fully read and verified PATCH 200 receipt",
    ambiguousRevision: 5,
    currentRevision: 6,
    settlementProof:
      "Saved HTTP 200 receipt plus no active request or callback; no GET-based settlement inference",
    finalMarkerVerified: true,
  });

  return {
    repository,
    repositoryId,
    appId,
    headSha,
    checkName,
    checkId,
    checkUrl: `https://github.com/${repository}/runs/${checkId}`,
    transport: fetcher === fetch ? "Live GitHub HTTPS" : "Supplied HTTP fetcher",
    boundaries: {
      sender:
        "Diagnostic adapter with a custom check name; production sendGitHubCheck is not exercised",
      state: "Exact work.ts lease and status APIs on supplied native D1; synthetic domain intents",
      clocks: "Injected logical lease clocks; GitHub completed_at uses wall time",
      delay: "Known HTTP 200 is fully read before callback completion is withheld",
      ambiguity:
        "Injected callback exception after a known HTTP 200; no claim of actual network response loss",
      creation: "One new check only; no adoption of existing IDs, search, or retry",
      parent: "Caller must durably reserve its probe prefix before invoking the adapter",
    },
    limits: {
      requests: requestLimits,
      responseBytes: responseByteLimit,
      requestTimeoutMs,
      redirects: "refused",
      retries: 0,
    },
    measurements: {
      requests,
      maximumActiveHttp,
      maximumActiveCallbacks,
      assertionCount: assertions.length,
    },
    receipts,
    assertions,
    checkpoints,
    scenarios,
  };
}

/** Strict local HTTP simulation. This function never calls the global fetch. */
export async function githubStatusLocal(context) {
  const token = "local-diagnostic-token-not-an-account-credential";
  const checkId = 1_000_000_000 + crypto.getRandomValues(new Uint32Array(1))[0];
  const calls = [];
  let check = null;
  let posts = 0;
  let patches = 0;
  const fetcher = async (input, init) => {
    const url = new URL(input);
    const method = init?.method;
    requireCondition(
      url.origin === origin && !url.search && !url.hash && !url.username && !url.password,
      "Local HTTP mock refuses an unrecognized origin",
    );
    requireCondition(
      init.redirect === "error" && init.signal instanceof AbortSignal,
      "Local HTTP mock requires redirect refusal and an abort signal",
    );
    requireCondition(
      new Headers(init.headers).get("Authorization") === `Bearer ${token}`,
      "Local HTTP mock requires its synthetic credential",
    );
    requireCondition(!init.signal.aborted, "Local HTTP mock request was already aborted");
    let data;
    let status = 200;
    if (method === "GET" && url.pathname === repositoryPath) {
      data = { id: repositoryId, full_name: repository, private: false };
    } else if (method === "POST" && url.pathname === creationPath) {
      requireCondition(posts === 0 && check === null, "Local HTTP mock permits one create only");
      const body = JSON.parse(init.body);
      requireCondition(
        body.name === checkName &&
          body.head_sha === headSha &&
          body.status === "in_progress" &&
          /^e03-status:[a-f0-9-]+:revision:0$/u.test(body.external_id),
        "Local HTTP mock refuses an unexpected create payload",
      );
      requireCondition(
        JSON.stringify(body.output) === JSON.stringify(genericOutput),
        "Local HTTP mock permits generic output only",
      );
      posts += 1;
      check = { ...body, id: checkId, app: { id: appId }, conclusion: null };
      data = check;
      status = 201;
    } else if (check && url.pathname === `${creationPath}/${checkId}` && method === "GET") {
      data = check;
    } else if (check && url.pathname === `${creationPath}/${checkId}` && method === "PATCH") {
      requireCondition(patches < 5, "Local HTTP mock PATCH budget exceeded");
      const body = JSON.parse(init.body);
      const expectedRevision = [2, 3, 4, 5, 6][patches];
      const expectedConclusion = ["failure", "success", "failure", "success", "failure"][patches];
      requireCondition(
        body.name === checkName &&
          body.status === "completed" &&
          body.conclusion === expectedConclusion &&
          body.external_id ===
            check.external_id.replace(/revision:\d+$/u, `revision:${expectedRevision}`),
        "Local HTTP mock refuses an unexpected PATCH payload",
      );
      requireCondition(
        JSON.stringify(body.output) === JSON.stringify(genericOutput),
        "Local HTTP mock permits generic output only",
      );
      patches += 1;
      check = { ...check, ...body };
      data = check;
    } else {
      throw new Error("Local HTTP mock refuses an unrecognized method or path");
    }
    calls.push({ method, path: url.pathname, status });
    return Response.json(data, {
      status,
      headers: { "x-github-request-id": `LOCAL:${calls.length}` },
    });
  };
  const result = await githubStatusScenarios(context, { token, fetcher });
  requireCondition(
    posts === 1 && patches === 5,
    "Local HTTP mock did not observe exactly one POST and five PATCH requests",
  );
  requireCondition(
    calls.filter((call) => call.method === "GET").length === 8,
    "Local HTTP mock did not observe exactly eight GET requests",
  );
  return {
    ...result,
    transport: "Strict local HTTP mock; no outbound GitHub requests",
    localHttp: { posts, patches, calls },
  };
}
