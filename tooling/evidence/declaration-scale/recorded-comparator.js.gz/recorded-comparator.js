var __defProp = Object.defineProperty;
var __name = (target, value) => __defProp(target, "name", { value, configurable: true });

// source/apps/compare/src/codecs.ts
import png from "./6d921a818cf134a4de07204744d66cb6b58631e7-squoosh_png_bg.wasm";
import webp from "./4dc5c0acee09eed6aba45c06f037442c15773664-webp_dec.wasm";

// ../../../Users/diegohaz/Developer/ariviso/node_modules/.pnpm/@jsquash+png@3.1.1/node_modules/@jsquash/png/codec/pkg/squoosh_png.js
var wasm;
var heap = new Array(128).fill(void 0);
heap.push(void 0, null, true, false);
var heap_next = heap.length;
function addHeapObject(obj) {
  if (heap_next === heap.length) heap.push(heap.length + 1);
  const idx = heap_next;
  heap_next = heap[idx];
  heap[idx] = obj;
  return idx;
}
__name(addHeapObject, "addHeapObject");
function getObject(idx) {
  return heap[idx];
}
__name(getObject, "getObject");
function dropObject(idx) {
  if (idx < 132) return;
  heap[idx] = heap_next;
  heap_next = idx;
}
__name(dropObject, "dropObject");
function takeObject(idx) {
  const ret = getObject(idx);
  dropObject(idx);
  return ret;
}
__name(takeObject, "takeObject");
var cachedTextDecoder = typeof TextDecoder !== "undefined" ? new TextDecoder("utf-8", { ignoreBOM: true, fatal: true }) : { decode: /* @__PURE__ */ __name(() => {
  throw Error("TextDecoder not available");
}, "decode") };
if (typeof TextDecoder !== "undefined") {
  cachedTextDecoder.decode();
}
var cachedUint8Memory0 = null;
function getUint8Memory0() {
  if (cachedUint8Memory0 === null || cachedUint8Memory0.byteLength === 0) {
    cachedUint8Memory0 = new Uint8Array(wasm.memory.buffer);
  }
  return cachedUint8Memory0;
}
__name(getUint8Memory0, "getUint8Memory0");
function getStringFromWasm0(ptr, len) {
  ptr = ptr >>> 0;
  return cachedTextDecoder.decode(getUint8Memory0().subarray(ptr, ptr + len));
}
__name(getStringFromWasm0, "getStringFromWasm0");
var cachedUint8ClampedMemory0 = null;
function getUint8ClampedMemory0() {
  if (cachedUint8ClampedMemory0 === null || cachedUint8ClampedMemory0.byteLength === 0) {
    cachedUint8ClampedMemory0 = new Uint8ClampedArray(wasm.memory.buffer);
  }
  return cachedUint8ClampedMemory0;
}
__name(getUint8ClampedMemory0, "getUint8ClampedMemory0");
function getClampedArrayU8FromWasm0(ptr, len) {
  ptr = ptr >>> 0;
  return getUint8ClampedMemory0().subarray(ptr / 1, ptr / 1 + len);
}
__name(getClampedArrayU8FromWasm0, "getClampedArrayU8FromWasm0");
var WASM_VECTOR_LEN = 0;
function passArray8ToWasm0(arg, malloc) {
  const ptr = malloc(arg.length * 1, 1) >>> 0;
  getUint8Memory0().set(arg, ptr / 1);
  WASM_VECTOR_LEN = arg.length;
  return ptr;
}
__name(passArray8ToWasm0, "passArray8ToWasm0");
var cachedInt32Memory0 = null;
function getInt32Memory0() {
  if (cachedInt32Memory0 === null || cachedInt32Memory0.byteLength === 0) {
    cachedInt32Memory0 = new Int32Array(wasm.memory.buffer);
  }
  return cachedInt32Memory0;
}
__name(getInt32Memory0, "getInt32Memory0");
function getArrayU8FromWasm0(ptr, len) {
  ptr = ptr >>> 0;
  return getUint8Memory0().subarray(ptr / 1, ptr / 1 + len);
}
__name(getArrayU8FromWasm0, "getArrayU8FromWasm0");
function encode(data, width, height, bit_depth) {
  try {
    const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
    const ptr0 = passArray8ToWasm0(data, wasm.__wbindgen_malloc);
    const len0 = WASM_VECTOR_LEN;
    wasm.encode(retptr, ptr0, len0, width, height, bit_depth);
    var r0 = getInt32Memory0()[retptr / 4 + 0];
    var r1 = getInt32Memory0()[retptr / 4 + 1];
    var v2 = getArrayU8FromWasm0(r0, r1).slice();
    wasm.__wbindgen_free(r0, r1 * 1, 1);
    return v2;
  } finally {
    wasm.__wbindgen_add_to_stack_pointer(16);
  }
}
__name(encode, "encode");
function decode(data) {
  const ptr0 = passArray8ToWasm0(data, wasm.__wbindgen_malloc);
  const len0 = WASM_VECTOR_LEN;
  const ret = wasm.decode(ptr0, len0);
  return takeObject(ret);
}
__name(decode, "decode");
function decode_rgba16(data) {
  const ptr0 = passArray8ToWasm0(data, wasm.__wbindgen_malloc);
  const len0 = WASM_VECTOR_LEN;
  const ret = wasm.decode_rgba16(ptr0, len0);
  return ImageDataRGBA16.__wrap(ret);
}
__name(decode_rgba16, "decode_rgba16");
var ImageDataRGBA16 = class _ImageDataRGBA16 {
  static {
    __name(this, "ImageDataRGBA16");
  }
  static __wrap(ptr) {
    ptr = ptr >>> 0;
    const obj = Object.create(_ImageDataRGBA16.prototype);
    obj.__wbg_ptr = ptr;
    return obj;
  }
  __destroy_into_raw() {
    const ptr = this.__wbg_ptr;
    this.__wbg_ptr = 0;
    return ptr;
  }
  free() {
    const ptr = this.__destroy_into_raw();
    wasm.__wbg_imagedatargba16_free(ptr);
  }
  /**
  * @returns {number}
  */
  get width() {
    const ret = wasm.imagedatargba16_width(this.__wbg_ptr);
    return ret >>> 0;
  }
  /**
  * @returns {number}
  */
  get height() {
    const ret = wasm.imagedatargba16_height(this.__wbg_ptr);
    return ret >>> 0;
  }
  /**
  * @returns {Uint16Array}
  */
  get data() {
    const ret = wasm.imagedatargba16_data(this.__wbg_ptr);
    return takeObject(ret);
  }
};
async function __wbg_load(module, imports) {
  if (typeof Response === "function" && module instanceof Response) {
    if (typeof WebAssembly.instantiateStreaming === "function") {
      try {
        return await WebAssembly.instantiateStreaming(module, imports);
      } catch (e) {
        if (module.headers.get("Content-Type") != "application/wasm") {
          console.warn("`WebAssembly.instantiateStreaming` failed because your server does not serve wasm with `application/wasm` MIME type. Falling back to `WebAssembly.instantiate` which is slower. Original error:\n", e);
        } else {
          throw e;
        }
      }
    }
    const bytes = await module.arrayBuffer();
    return await WebAssembly.instantiate(bytes, imports);
  } else {
    const instance = await WebAssembly.instantiate(module, imports);
    if (instance instanceof WebAssembly.Instance) {
      return { instance, module };
    } else {
      return instance;
    }
  }
}
__name(__wbg_load, "__wbg_load");
function __wbg_get_imports() {
  const imports = {};
  imports.wbg = {};
  imports.wbg.__wbindgen_memory = function() {
    const ret = wasm.memory;
    return addHeapObject(ret);
  };
  imports.wbg.__wbg_buffer_a448f833075b71ba = function(arg0) {
    const ret = getObject(arg0).buffer;
    return addHeapObject(ret);
  };
  imports.wbg.__wbg_newwithbyteoffsetandlength_099217381c451830 = function(arg0, arg1, arg2) {
    const ret = new Uint16Array(getObject(arg0), arg1 >>> 0, arg2 >>> 0);
    return addHeapObject(ret);
  };
  imports.wbg.__wbindgen_object_drop_ref = function(arg0) {
    takeObject(arg0);
  };
  imports.wbg.__wbg_newwithownedu8clampedarrayandsh_91db5987993a08fb = function(arg0, arg1, arg2, arg3) {
    var v0 = getClampedArrayU8FromWasm0(arg0, arg1).slice();
    wasm.__wbindgen_free(arg0, arg1 * 1, 1);
    const ret = new ImageData(v0, arg2 >>> 0, arg3 >>> 0);
    return addHeapObject(ret);
  };
  imports.wbg.__wbindgen_throw = function(arg0, arg1) {
    throw new Error(getStringFromWasm0(arg0, arg1));
  };
  return imports;
}
__name(__wbg_get_imports, "__wbg_get_imports");
function __wbg_init_memory(imports, maybe_memory) {
}
__name(__wbg_init_memory, "__wbg_init_memory");
function __wbg_finalize_init(instance, module) {
  wasm = instance.exports;
  __wbg_init.__wbindgen_wasm_module = module;
  cachedInt32Memory0 = null;
  cachedUint8Memory0 = null;
  cachedUint8ClampedMemory0 = null;
  return wasm;
}
__name(__wbg_finalize_init, "__wbg_finalize_init");
async function __wbg_init(input) {
  if (wasm !== void 0) return wasm;
  if (typeof input === "undefined") {
    input = new URL("squoosh_png_bg.wasm", import.meta.url);
  }
  const imports = __wbg_get_imports();
  if (typeof input === "string" || typeof Request === "function" && input instanceof Request || typeof URL === "function" && input instanceof URL) {
    input = fetch(input);
  }
  __wbg_init_memory(imports);
  const { instance, module } = await __wbg_load(await input, imports);
  return __wbg_finalize_init(instance, module);
}
__name(__wbg_init, "__wbg_init");
var squoosh_png_default = __wbg_init;
var isServiceWorker = globalThis.ServiceWorkerGlobalScope !== void 0;
var isRunningInCloudFlareWorkers = isServiceWorker && typeof self !== "undefined" && globalThis.caches && globalThis.caches.default !== void 0;
var isRunningInNode = typeof process === "object" && process.release && process.release.name === "node";
if (isRunningInCloudFlareWorkers || isRunningInNode) {
  if (!globalThis.ImageData) {
    globalThis.ImageData = class ImageData {
      static {
        __name(this, "ImageData");
      }
      constructor(data, width, height) {
        this.data = data;
        this.width = width;
        this.height = height;
      }
    };
  }
  if (import.meta.url === void 0) {
    import.meta.url = "https://localhost";
  }
  if (typeof self !== "undefined" && self.location === void 0) {
    self.location = { href: "" };
  }
}

// ../../../Users/diegohaz/Developer/ariviso/node_modules/.pnpm/@jsquash+png@3.1.1/node_modules/@jsquash/png/decode.js
var pngModule;
async function init(moduleOrPath) {
  if (!pngModule) {
    pngModule = squoosh_png_default(moduleOrPath);
  }
  return pngModule;
}
__name(init, "init");
async function decode2(data, options = {}) {
  await init();
  const { bitDepth = 8 } = options;
  if (bitDepth === 16) {
    const imageData2 = await decode_rgba16(new Uint8Array(data));
    if (!imageData2)
      throw new Error("Encoding error.");
    return imageData2;
  }
  const imageData = await decode(new Uint8Array(data));
  if (!imageData)
    throw new Error("Encoding error.");
  return imageData;
}
__name(decode2, "decode");
var decode_default = decode2;

// ../../../Users/diegohaz/Developer/ariviso/node_modules/.pnpm/@jsquash+png@3.1.1/node_modules/@jsquash/png/encode.js
var pngModule2;
async function init2(moduleOrPath) {
  if (!pngModule2) {
    pngModule2 = squoosh_png_default(moduleOrPath);
  }
  return pngModule2;
}
__name(init2, "init");
async function encode2(data, options = {}) {
  var _a;
  await init2();
  const bitDepth = (_a = options === null || options === void 0 ? void 0 : options.bitDepth) !== null && _a !== void 0 ? _a : 8;
  if (bitDepth !== 8 && bitDepth !== 16) {
    throw new Error("Invalid bit depth. Must be either 8 or 16.");
  }
  const isUint16Array = data.data instanceof Uint16Array;
  if (isUint16Array && bitDepth !== 16) {
    throw new Error("Invalid bit depth, must be 16 for Uint16Array or manually convert to RGB8 values with Uint8Array.");
  }
  if (!isUint16Array && bitDepth === 16) {
    throw new Error("Invalid bit depth, must be 8 for Uint8Array or manually convert to RGB16 values with Uint16Array.");
  }
  const encodeData = new Uint8Array(data.data.buffer);
  const output = await encode(encodeData, data.width, data.height, bitDepth);
  if (!output)
    throw new Error("Encoding error.");
  return output.buffer;
}
__name(encode2, "encode");

// ../../../Users/diegohaz/Developer/ariviso/node_modules/.pnpm/@jsquash+webp@1.5.0/node_modules/@jsquash/webp/codec/dec/webp_dec.js
var Module = (() => {
  var _scriptDir = import.meta.url;
  return (function(Module2 = {}) {
    var Module2 = typeof Module2 != "undefined" ? Module2 : {};
    var readyPromiseResolve, readyPromiseReject;
    Module2["ready"] = new Promise(function(resolve, reject) {
      readyPromiseResolve = resolve;
      readyPromiseReject = reject;
    });
    const isServiceWorker2 = globalThis.ServiceWorkerGlobalScope !== void 0;
    const isRunningInCloudFlareWorkers2 = isServiceWorker2 && typeof self !== "undefined" && globalThis.caches && globalThis.caches.default !== void 0;
    const isRunningInNode2 = typeof process === "object" && process.release && process.release.name === "node";
    if (isRunningInCloudFlareWorkers2 || isRunningInNode2) {
      if (!globalThis.ImageData) {
        globalThis.ImageData = class ImageData {
          static {
            __name(this, "ImageData");
          }
          constructor(data, width, height) {
            this.data = data;
            this.width = width;
            this.height = height;
          }
        };
      }
      if (import.meta.url === void 0) {
        import.meta.url = "https://localhost";
      }
      if (typeof self !== "undefined" && self.location === void 0) {
        self.location = { href: "" };
      }
    }
    var moduleOverrides = Object.assign({}, Module2);
    var arguments_ = [];
    var thisProgram = "./this.program";
    var quit_ = /* @__PURE__ */ __name((status, toThrow) => {
      throw toThrow;
    }, "quit_");
    var ENVIRONMENT_IS_WEB = typeof window == "object";
    var ENVIRONMENT_IS_WORKER = typeof importScripts == "function";
    var ENVIRONMENT_IS_NODE = typeof process == "object" && typeof process.versions == "object" && typeof process.versions.node == "string";
    var scriptDirectory = "";
    function locateFile(path) {
      if (Module2["locateFile"]) {
        return Module2["locateFile"](path, scriptDirectory);
      }
      return scriptDirectory + path;
    }
    __name(locateFile, "locateFile");
    var read_, readAsync, readBinary, setWindowTitle;
    if (ENVIRONMENT_IS_WEB || ENVIRONMENT_IS_WORKER) {
      if (ENVIRONMENT_IS_WORKER) {
        scriptDirectory = self.location.href;
      } else if (typeof document != "undefined" && document.currentScript) {
        scriptDirectory = document.currentScript.src;
      }
      if (_scriptDir) {
        scriptDirectory = _scriptDir;
      }
      if (scriptDirectory.indexOf("blob:") !== 0) {
        scriptDirectory = scriptDirectory.substr(0, scriptDirectory.replace(/[?#].*/, "").lastIndexOf("/") + 1);
      } else {
        scriptDirectory = "";
      }
      {
        read_ = /* @__PURE__ */ __name((url) => {
          var xhr = new XMLHttpRequest();
          xhr.open("GET", url, false);
          xhr.send(null);
          return xhr.responseText;
        }, "read_");
        if (ENVIRONMENT_IS_WORKER) {
          readBinary = /* @__PURE__ */ __name((url) => {
            var xhr = new XMLHttpRequest();
            xhr.open("GET", url, false);
            xhr.responseType = "arraybuffer";
            xhr.send(null);
            return new Uint8Array(xhr.response);
          }, "readBinary");
        }
        readAsync = /* @__PURE__ */ __name((url, onload, onerror) => {
          var xhr = new XMLHttpRequest();
          xhr.open("GET", url, true);
          xhr.responseType = "arraybuffer";
          xhr.onload = () => {
            if (xhr.status == 200 || xhr.status == 0 && xhr.response) {
              onload(xhr.response);
              return;
            }
            onerror();
          };
          xhr.onerror = onerror;
          xhr.send(null);
        }, "readAsync");
      }
      setWindowTitle = /* @__PURE__ */ __name((title) => document.title = title, "setWindowTitle");
    } else {
    }
    var out = Module2["print"] || console.log.bind(console);
    var err = Module2["printErr"] || console.warn.bind(console);
    Object.assign(Module2, moduleOverrides);
    moduleOverrides = null;
    if (Module2["arguments"]) arguments_ = Module2["arguments"];
    if (Module2["thisProgram"]) thisProgram = Module2["thisProgram"];
    if (Module2["quit"]) quit_ = Module2["quit"];
    var wasmBinary;
    if (Module2["wasmBinary"]) wasmBinary = Module2["wasmBinary"];
    var noExitRuntime = Module2["noExitRuntime"] || true;
    if (typeof WebAssembly != "object") {
      abort("no native wasm support detected");
    }
    var wasmMemory;
    var ABORT = false;
    var EXITSTATUS;
    function UTF8ArrayToString(heapOrArray, idx, maxBytesToRead) {
      var endIdx = idx + maxBytesToRead;
      var str = "";
      while (!(idx >= endIdx)) {
        var u0 = heapOrArray[idx++];
        if (!u0) return str;
        if (!(u0 & 128)) {
          str += String.fromCharCode(u0);
          continue;
        }
        var u1 = heapOrArray[idx++] & 63;
        if ((u0 & 224) == 192) {
          str += String.fromCharCode((u0 & 31) << 6 | u1);
          continue;
        }
        var u2 = heapOrArray[idx++] & 63;
        if ((u0 & 240) == 224) {
          u0 = (u0 & 15) << 12 | u1 << 6 | u2;
        } else {
          u0 = (u0 & 7) << 18 | u1 << 12 | u2 << 6 | heapOrArray[idx++] & 63;
        }
        if (u0 < 65536) {
          str += String.fromCharCode(u0);
        } else {
          var ch = u0 - 65536;
          str += String.fromCharCode(55296 | ch >> 10, 56320 | ch & 1023);
        }
      }
      return str;
    }
    __name(UTF8ArrayToString, "UTF8ArrayToString");
    function UTF8ToString(ptr, maxBytesToRead) {
      return ptr ? UTF8ArrayToString(HEAPU8, ptr, maxBytesToRead) : "";
    }
    __name(UTF8ToString, "UTF8ToString");
    function stringToUTF8Array(str, heap2, outIdx, maxBytesToWrite) {
      if (!(maxBytesToWrite > 0)) return 0;
      var startIdx = outIdx;
      var endIdx = outIdx + maxBytesToWrite - 1;
      for (var i = 0; i < str.length; ++i) {
        var u = str.charCodeAt(i);
        if (u >= 55296 && u <= 57343) {
          var u1 = str.charCodeAt(++i);
          u = 65536 + ((u & 1023) << 10) | u1 & 1023;
        }
        if (u <= 127) {
          if (outIdx >= endIdx) break;
          heap2[outIdx++] = u;
        } else if (u <= 2047) {
          if (outIdx + 1 >= endIdx) break;
          heap2[outIdx++] = 192 | u >> 6;
          heap2[outIdx++] = 128 | u & 63;
        } else if (u <= 65535) {
          if (outIdx + 2 >= endIdx) break;
          heap2[outIdx++] = 224 | u >> 12;
          heap2[outIdx++] = 128 | u >> 6 & 63;
          heap2[outIdx++] = 128 | u & 63;
        } else {
          if (outIdx + 3 >= endIdx) break;
          heap2[outIdx++] = 240 | u >> 18;
          heap2[outIdx++] = 128 | u >> 12 & 63;
          heap2[outIdx++] = 128 | u >> 6 & 63;
          heap2[outIdx++] = 128 | u & 63;
        }
      }
      heap2[outIdx] = 0;
      return outIdx - startIdx;
    }
    __name(stringToUTF8Array, "stringToUTF8Array");
    function stringToUTF8(str, outPtr, maxBytesToWrite) {
      return stringToUTF8Array(str, HEAPU8, outPtr, maxBytesToWrite);
    }
    __name(stringToUTF8, "stringToUTF8");
    function lengthBytesUTF8(str) {
      var len = 0;
      for (var i = 0; i < str.length; ++i) {
        var c = str.charCodeAt(i);
        if (c <= 127) {
          len++;
        } else if (c <= 2047) {
          len += 2;
        } else if (c >= 55296 && c <= 57343) {
          len += 4;
          ++i;
        } else {
          len += 3;
        }
      }
      return len;
    }
    __name(lengthBytesUTF8, "lengthBytesUTF8");
    var HEAP8, HEAPU8, HEAP16, HEAPU16, HEAP32, HEAPU32, HEAPF32, HEAPF64;
    function updateMemoryViews() {
      var b = wasmMemory.buffer;
      Module2["HEAP8"] = HEAP8 = new Int8Array(b);
      Module2["HEAP16"] = HEAP16 = new Int16Array(b);
      Module2["HEAP32"] = HEAP32 = new Int32Array(b);
      Module2["HEAPU8"] = HEAPU8 = new Uint8Array(b);
      Module2["HEAPU16"] = HEAPU16 = new Uint16Array(b);
      Module2["HEAPU32"] = HEAPU32 = new Uint32Array(b);
      Module2["HEAPF32"] = HEAPF32 = new Float32Array(b);
      Module2["HEAPF64"] = HEAPF64 = new Float64Array(b);
    }
    __name(updateMemoryViews, "updateMemoryViews");
    var wasmTable;
    var __ATPRERUN__ = [];
    var __ATINIT__ = [];
    var __ATPOSTRUN__ = [];
    var runtimeInitialized = false;
    function preRun() {
      if (Module2["preRun"]) {
        if (typeof Module2["preRun"] == "function") Module2["preRun"] = [Module2["preRun"]];
        while (Module2["preRun"].length) {
          addOnPreRun(Module2["preRun"].shift());
        }
      }
      callRuntimeCallbacks(__ATPRERUN__);
    }
    __name(preRun, "preRun");
    function initRuntime() {
      runtimeInitialized = true;
      callRuntimeCallbacks(__ATINIT__);
    }
    __name(initRuntime, "initRuntime");
    function postRun() {
      if (Module2["postRun"]) {
        if (typeof Module2["postRun"] == "function") Module2["postRun"] = [Module2["postRun"]];
        while (Module2["postRun"].length) {
          addOnPostRun(Module2["postRun"].shift());
        }
      }
      callRuntimeCallbacks(__ATPOSTRUN__);
    }
    __name(postRun, "postRun");
    function addOnPreRun(cb) {
      __ATPRERUN__.unshift(cb);
    }
    __name(addOnPreRun, "addOnPreRun");
    function addOnInit(cb) {
      __ATINIT__.unshift(cb);
    }
    __name(addOnInit, "addOnInit");
    function addOnPostRun(cb) {
      __ATPOSTRUN__.unshift(cb);
    }
    __name(addOnPostRun, "addOnPostRun");
    var runDependencies = 0;
    var runDependencyWatcher = null;
    var dependenciesFulfilled = null;
    function addRunDependency(id) {
      runDependencies++;
      if (Module2["monitorRunDependencies"]) {
        Module2["monitorRunDependencies"](runDependencies);
      }
    }
    __name(addRunDependency, "addRunDependency");
    function removeRunDependency(id) {
      runDependencies--;
      if (Module2["monitorRunDependencies"]) {
        Module2["monitorRunDependencies"](runDependencies);
      }
      if (runDependencies == 0) {
        if (runDependencyWatcher !== null) {
          clearInterval(runDependencyWatcher);
          runDependencyWatcher = null;
        }
        if (dependenciesFulfilled) {
          var callback = dependenciesFulfilled;
          dependenciesFulfilled = null;
          callback();
        }
      }
    }
    __name(removeRunDependency, "removeRunDependency");
    function abort(what) {
      if (Module2["onAbort"]) {
        Module2["onAbort"](what);
      }
      what = "Aborted(" + what + ")";
      err(what);
      ABORT = true;
      EXITSTATUS = 1;
      what += ". Build with -sASSERTIONS for more info.";
      var e = new WebAssembly.RuntimeError(what);
      readyPromiseReject(e);
      throw e;
    }
    __name(abort, "abort");
    var dataURIPrefix = "data:application/octet-stream;base64,";
    function isDataURI(filename) {
      return filename.startsWith(dataURIPrefix);
    }
    __name(isDataURI, "isDataURI");
    var wasmBinaryFile;
    if (Module2["locateFile"]) {
      wasmBinaryFile = "webp_dec.wasm";
      if (!isDataURI(wasmBinaryFile)) {
        wasmBinaryFile = locateFile(wasmBinaryFile);
      }
    } else {
      wasmBinaryFile = new URL("webp_dec.wasm", import.meta.url).href;
    }
    function getBinary(file) {
      try {
        if (file == wasmBinaryFile && wasmBinary) {
          return new Uint8Array(wasmBinary);
        }
        if (readBinary) {
          return readBinary(file);
        }
        throw "both async and sync fetching of the wasm failed";
      } catch (err2) {
        abort(err2);
      }
    }
    __name(getBinary, "getBinary");
    function getBinaryPromise(binaryFile) {
      if (!wasmBinary && (ENVIRONMENT_IS_WEB || ENVIRONMENT_IS_WORKER)) {
        if (typeof fetch == "function") {
          return fetch(binaryFile, { credentials: "same-origin" }).then(function(response) {
            if (!response["ok"]) {
              throw "failed to load wasm binary file at '" + binaryFile + "'";
            }
            return response["arrayBuffer"]();
          }).catch(function() {
            return getBinary(binaryFile);
          });
        }
      }
      return Promise.resolve().then(function() {
        return getBinary(binaryFile);
      });
    }
    __name(getBinaryPromise, "getBinaryPromise");
    function instantiateArrayBuffer(binaryFile, imports, receiver) {
      return getBinaryPromise(binaryFile).then(function(binary) {
        return WebAssembly.instantiate(binary, imports);
      }).then(function(instance) {
        return instance;
      }).then(receiver, function(reason) {
        err("failed to asynchronously prepare wasm: " + reason);
        abort(reason);
      });
    }
    __name(instantiateArrayBuffer, "instantiateArrayBuffer");
    function instantiateAsync(binary, binaryFile, imports, callback) {
      if (!binary && typeof WebAssembly.instantiateStreaming == "function" && !isDataURI(binaryFile) && typeof fetch == "function") {
        return fetch(binaryFile, { credentials: "same-origin" }).then(function(response) {
          var result = WebAssembly.instantiateStreaming(response, imports);
          return result.then(callback, function(reason) {
            err("wasm streaming compile failed: " + reason);
            err("falling back to ArrayBuffer instantiation");
            return instantiateArrayBuffer(binaryFile, imports, callback);
          });
        });
      } else {
        return instantiateArrayBuffer(binaryFile, imports, callback);
      }
    }
    __name(instantiateAsync, "instantiateAsync");
    function createWasm() {
      var info = { "a": wasmImports };
      function receiveInstance(instance, module) {
        var exports = instance.exports;
        Module2["asm"] = exports;
        wasmMemory = Module2["asm"]["s"];
        updateMemoryViews();
        wasmTable = Module2["asm"]["y"];
        addOnInit(Module2["asm"]["t"]);
        removeRunDependency("wasm-instantiate");
        return exports;
      }
      __name(receiveInstance, "receiveInstance");
      addRunDependency("wasm-instantiate");
      function receiveInstantiationResult(result) {
        receiveInstance(result["instance"]);
      }
      __name(receiveInstantiationResult, "receiveInstantiationResult");
      if (Module2["instantiateWasm"]) {
        try {
          return Module2["instantiateWasm"](info, receiveInstance);
        } catch (e) {
          err("Module.instantiateWasm callback failed with error: " + e);
          readyPromiseReject(e);
        }
      }
      instantiateAsync(wasmBinary, wasmBinaryFile, info, receiveInstantiationResult).catch(readyPromiseReject);
      return {};
    }
    __name(createWasm, "createWasm");
    function callRuntimeCallbacks(callbacks) {
      while (callbacks.length > 0) {
        callbacks.shift()(Module2);
      }
    }
    __name(callRuntimeCallbacks, "callRuntimeCallbacks");
    function ExceptionInfo(excPtr) {
      this.excPtr = excPtr;
      this.ptr = excPtr - 24;
      this.set_type = function(type) {
        HEAPU32[this.ptr + 4 >> 2] = type;
      };
      this.get_type = function() {
        return HEAPU32[this.ptr + 4 >> 2];
      };
      this.set_destructor = function(destructor) {
        HEAPU32[this.ptr + 8 >> 2] = destructor;
      };
      this.get_destructor = function() {
        return HEAPU32[this.ptr + 8 >> 2];
      };
      this.set_refcount = function(refcount) {
        HEAP32[this.ptr >> 2] = refcount;
      };
      this.set_caught = function(caught) {
        caught = caught ? 1 : 0;
        HEAP8[this.ptr + 12 >> 0] = caught;
      };
      this.get_caught = function() {
        return HEAP8[this.ptr + 12 >> 0] != 0;
      };
      this.set_rethrown = function(rethrown) {
        rethrown = rethrown ? 1 : 0;
        HEAP8[this.ptr + 13 >> 0] = rethrown;
      };
      this.get_rethrown = function() {
        return HEAP8[this.ptr + 13 >> 0] != 0;
      };
      this.init = function(type, destructor) {
        this.set_adjusted_ptr(0);
        this.set_type(type);
        this.set_destructor(destructor);
        this.set_refcount(0);
        this.set_caught(false);
        this.set_rethrown(false);
      };
      this.add_ref = function() {
        var value = HEAP32[this.ptr >> 2];
        HEAP32[this.ptr >> 2] = value + 1;
      };
      this.release_ref = function() {
        var prev = HEAP32[this.ptr >> 2];
        HEAP32[this.ptr >> 2] = prev - 1;
        return prev === 1;
      };
      this.set_adjusted_ptr = function(adjustedPtr) {
        HEAPU32[this.ptr + 16 >> 2] = adjustedPtr;
      };
      this.get_adjusted_ptr = function() {
        return HEAPU32[this.ptr + 16 >> 2];
      };
      this.get_exception_ptr = function() {
        var isPointer = ___cxa_is_pointer_type(this.get_type());
        if (isPointer) {
          return HEAPU32[this.excPtr >> 2];
        }
        var adjusted = this.get_adjusted_ptr();
        if (adjusted !== 0) return adjusted;
        return this.excPtr;
      };
    }
    __name(ExceptionInfo, "ExceptionInfo");
    var exceptionLast = 0;
    var uncaughtExceptionCount = 0;
    function ___cxa_throw(ptr, type, destructor) {
      var info = new ExceptionInfo(ptr);
      info.init(type, destructor);
      exceptionLast = ptr;
      uncaughtExceptionCount++;
      throw ptr;
    }
    __name(___cxa_throw, "___cxa_throw");
    function __embind_register_bigint(primitiveType, name, size, minRange, maxRange) {
    }
    __name(__embind_register_bigint, "__embind_register_bigint");
    function getShiftFromSize(size) {
      switch (size) {
        case 1:
          return 0;
        case 2:
          return 1;
        case 4:
          return 2;
        case 8:
          return 3;
        default:
          throw new TypeError("Unknown type size: " + size);
      }
    }
    __name(getShiftFromSize, "getShiftFromSize");
    function embind_init_charCodes() {
      var codes = new Array(256);
      for (var i = 0; i < 256; ++i) {
        codes[i] = String.fromCharCode(i);
      }
      embind_charCodes = codes;
    }
    __name(embind_init_charCodes, "embind_init_charCodes");
    var embind_charCodes = void 0;
    function readLatin1String(ptr) {
      var ret = "";
      var c = ptr;
      while (HEAPU8[c]) {
        ret += embind_charCodes[HEAPU8[c++]];
      }
      return ret;
    }
    __name(readLatin1String, "readLatin1String");
    var awaitingDependencies = {};
    var registeredTypes = {};
    var typeDependencies = {};
    var char_0 = 48;
    var char_9 = 57;
    function makeLegalFunctionName(name) {
      if (void 0 === name) {
        return "_unknown";
      }
      name = name.replace(/[^a-zA-Z0-9_]/g, "$");
      var f = name.charCodeAt(0);
      if (f >= char_0 && f <= char_9) {
        return "_" + name;
      }
      return name;
    }
    __name(makeLegalFunctionName, "makeLegalFunctionName");
    function createNamedFunction(name, body) {
      name = makeLegalFunctionName(name);
      return { [name]: function() {
        return body.apply(this, arguments);
      } }[name];
    }
    __name(createNamedFunction, "createNamedFunction");
    function extendError(baseErrorType, errorName) {
      var errorClass = createNamedFunction(errorName, function(message) {
        this.name = errorName;
        this.message = message;
        var stack = new Error(message).stack;
        if (stack !== void 0) {
          this.stack = this.toString() + "\n" + stack.replace(/^Error(:[^\n]*)?\n/, "");
        }
      });
      errorClass.prototype = Object.create(baseErrorType.prototype);
      errorClass.prototype.constructor = errorClass;
      errorClass.prototype.toString = function() {
        if (this.message === void 0) {
          return this.name;
        } else {
          return this.name + ": " + this.message;
        }
      };
      return errorClass;
    }
    __name(extendError, "extendError");
    var BindingError = void 0;
    function throwBindingError(message) {
      throw new BindingError(message);
    }
    __name(throwBindingError, "throwBindingError");
    var InternalError = void 0;
    function throwInternalError(message) {
      throw new InternalError(message);
    }
    __name(throwInternalError, "throwInternalError");
    function whenDependentTypesAreResolved(myTypes, dependentTypes, getTypeConverters) {
      myTypes.forEach(function(type) {
        typeDependencies[type] = dependentTypes;
      });
      function onComplete(typeConverters2) {
        var myTypeConverters = getTypeConverters(typeConverters2);
        if (myTypeConverters.length !== myTypes.length) {
          throwInternalError("Mismatched type converter count");
        }
        for (var i = 0; i < myTypes.length; ++i) {
          registerType(myTypes[i], myTypeConverters[i]);
        }
      }
      __name(onComplete, "onComplete");
      var typeConverters = new Array(dependentTypes.length);
      var unregisteredTypes = [];
      var registered = 0;
      dependentTypes.forEach((dt, i) => {
        if (registeredTypes.hasOwnProperty(dt)) {
          typeConverters[i] = registeredTypes[dt];
        } else {
          unregisteredTypes.push(dt);
          if (!awaitingDependencies.hasOwnProperty(dt)) {
            awaitingDependencies[dt] = [];
          }
          awaitingDependencies[dt].push(() => {
            typeConverters[i] = registeredTypes[dt];
            ++registered;
            if (registered === unregisteredTypes.length) {
              onComplete(typeConverters);
            }
          });
        }
      });
      if (0 === unregisteredTypes.length) {
        onComplete(typeConverters);
      }
    }
    __name(whenDependentTypesAreResolved, "whenDependentTypesAreResolved");
    function registerType(rawType, registeredInstance, options = {}) {
      if (!("argPackAdvance" in registeredInstance)) {
        throw new TypeError("registerType registeredInstance requires argPackAdvance");
      }
      var name = registeredInstance.name;
      if (!rawType) {
        throwBindingError('type "' + name + '" must have a positive integer typeid pointer');
      }
      if (registeredTypes.hasOwnProperty(rawType)) {
        if (options.ignoreDuplicateRegistrations) {
          return;
        } else {
          throwBindingError("Cannot register type '" + name + "' twice");
        }
      }
      registeredTypes[rawType] = registeredInstance;
      delete typeDependencies[rawType];
      if (awaitingDependencies.hasOwnProperty(rawType)) {
        var callbacks = awaitingDependencies[rawType];
        delete awaitingDependencies[rawType];
        callbacks.forEach((cb) => cb());
      }
    }
    __name(registerType, "registerType");
    function __embind_register_bool(rawType, name, size, trueValue, falseValue) {
      var shift = getShiftFromSize(size);
      name = readLatin1String(name);
      registerType(rawType, { name, "fromWireType": /* @__PURE__ */ __name(function(wt) {
        return !!wt;
      }, "fromWireType"), "toWireType": /* @__PURE__ */ __name(function(destructors, o) {
        return o ? trueValue : falseValue;
      }, "toWireType"), "argPackAdvance": 8, "readValueFromPointer": /* @__PURE__ */ __name(function(pointer) {
        var heap2;
        if (size === 1) {
          heap2 = HEAP8;
        } else if (size === 2) {
          heap2 = HEAP16;
        } else if (size === 4) {
          heap2 = HEAP32;
        } else {
          throw new TypeError("Unknown boolean type size: " + name);
        }
        return this["fromWireType"](heap2[pointer >> shift]);
      }, "readValueFromPointer"), destructorFunction: null });
    }
    __name(__embind_register_bool, "__embind_register_bool");
    var emval_free_list = [];
    var emval_handle_array = [{}, { value: void 0 }, { value: null }, { value: true }, { value: false }];
    function __emval_decref(handle) {
      if (handle > 4 && 0 === --emval_handle_array[handle].refcount) {
        emval_handle_array[handle] = void 0;
        emval_free_list.push(handle);
      }
    }
    __name(__emval_decref, "__emval_decref");
    function count_emval_handles() {
      var count = 0;
      for (var i = 5; i < emval_handle_array.length; ++i) {
        if (emval_handle_array[i] !== void 0) {
          ++count;
        }
      }
      return count;
    }
    __name(count_emval_handles, "count_emval_handles");
    function get_first_emval() {
      for (var i = 5; i < emval_handle_array.length; ++i) {
        if (emval_handle_array[i] !== void 0) {
          return emval_handle_array[i];
        }
      }
      return null;
    }
    __name(get_first_emval, "get_first_emval");
    function init_emval() {
      Module2["count_emval_handles"] = count_emval_handles;
      Module2["get_first_emval"] = get_first_emval;
    }
    __name(init_emval, "init_emval");
    var Emval = { toValue: /* @__PURE__ */ __name((handle) => {
      if (!handle) {
        throwBindingError("Cannot use deleted val. handle = " + handle);
      }
      return emval_handle_array[handle].value;
    }, "toValue"), toHandle: /* @__PURE__ */ __name((value) => {
      switch (value) {
        case void 0:
          return 1;
        case null:
          return 2;
        case true:
          return 3;
        case false:
          return 4;
        default: {
          var handle = emval_free_list.length ? emval_free_list.pop() : emval_handle_array.length;
          emval_handle_array[handle] = { refcount: 1, value };
          return handle;
        }
      }
    }, "toHandle") };
    function simpleReadValueFromPointer(pointer) {
      return this["fromWireType"](HEAP32[pointer >> 2]);
    }
    __name(simpleReadValueFromPointer, "simpleReadValueFromPointer");
    function __embind_register_emval(rawType, name) {
      name = readLatin1String(name);
      registerType(rawType, { name, "fromWireType": /* @__PURE__ */ __name(function(handle) {
        var rv = Emval.toValue(handle);
        __emval_decref(handle);
        return rv;
      }, "fromWireType"), "toWireType": /* @__PURE__ */ __name(function(destructors, value) {
        return Emval.toHandle(value);
      }, "toWireType"), "argPackAdvance": 8, "readValueFromPointer": simpleReadValueFromPointer, destructorFunction: null });
    }
    __name(__embind_register_emval, "__embind_register_emval");
    function floatReadValueFromPointer(name, shift) {
      switch (shift) {
        case 2:
          return function(pointer) {
            return this["fromWireType"](HEAPF32[pointer >> 2]);
          };
        case 3:
          return function(pointer) {
            return this["fromWireType"](HEAPF64[pointer >> 3]);
          };
        default:
          throw new TypeError("Unknown float type: " + name);
      }
    }
    __name(floatReadValueFromPointer, "floatReadValueFromPointer");
    function __embind_register_float(rawType, name, size) {
      var shift = getShiftFromSize(size);
      name = readLatin1String(name);
      registerType(rawType, { name, "fromWireType": /* @__PURE__ */ __name(function(value) {
        return value;
      }, "fromWireType"), "toWireType": /* @__PURE__ */ __name(function(destructors, value) {
        return value;
      }, "toWireType"), "argPackAdvance": 8, "readValueFromPointer": floatReadValueFromPointer(name, shift), destructorFunction: null });
    }
    __name(__embind_register_float, "__embind_register_float");
    function runDestructors(destructors) {
      while (destructors.length) {
        var ptr = destructors.pop();
        var del = destructors.pop();
        del(ptr);
      }
    }
    __name(runDestructors, "runDestructors");
    function craftInvokerFunction(humanName, argTypes, classType, cppInvokerFunc, cppTargetFunc, isAsync) {
      var argCount = argTypes.length;
      if (argCount < 2) {
        throwBindingError("argTypes array size mismatch! Must at least get return value and 'this' types!");
      }
      var isClassMethodFunc = argTypes[1] !== null && classType !== null;
      var needsDestructorStack = false;
      for (var i = 1; i < argTypes.length; ++i) {
        if (argTypes[i] !== null && argTypes[i].destructorFunction === void 0) {
          needsDestructorStack = true;
          break;
        }
      }
      var returns = argTypes[0].name !== "void";
      var expectedArgCount = argCount - 2;
      var argsWired = new Array(expectedArgCount);
      var invokerFuncArgs = [];
      var destructors = [];
      return function() {
        if (arguments.length !== expectedArgCount) {
          throwBindingError("function " + humanName + " called with " + arguments.length + " arguments, expected " + expectedArgCount + " args!");
        }
        destructors.length = 0;
        var thisWired;
        invokerFuncArgs.length = isClassMethodFunc ? 2 : 1;
        invokerFuncArgs[0] = cppTargetFunc;
        if (isClassMethodFunc) {
          thisWired = argTypes[1]["toWireType"](destructors, this);
          invokerFuncArgs[1] = thisWired;
        }
        for (var i2 = 0; i2 < expectedArgCount; ++i2) {
          argsWired[i2] = argTypes[i2 + 2]["toWireType"](destructors, arguments[i2]);
          invokerFuncArgs.push(argsWired[i2]);
        }
        var rv = cppInvokerFunc.apply(null, invokerFuncArgs);
        function onDone(rv2) {
          if (needsDestructorStack) {
            runDestructors(destructors);
          } else {
            for (var i3 = isClassMethodFunc ? 1 : 2; i3 < argTypes.length; i3++) {
              var param = i3 === 1 ? thisWired : argsWired[i3 - 2];
              if (argTypes[i3].destructorFunction !== null) {
                argTypes[i3].destructorFunction(param);
              }
            }
          }
          if (returns) {
            return argTypes[0]["fromWireType"](rv2);
          }
        }
        __name(onDone, "onDone");
        return onDone(rv);
      };
    }
    __name(craftInvokerFunction, "craftInvokerFunction");
    function ensureOverloadTable(proto, methodName, humanName) {
      if (void 0 === proto[methodName].overloadTable) {
        var prevFunc = proto[methodName];
        proto[methodName] = function() {
          if (!proto[methodName].overloadTable.hasOwnProperty(arguments.length)) {
            throwBindingError("Function '" + humanName + "' called with an invalid number of arguments (" + arguments.length + ") - expects one of (" + proto[methodName].overloadTable + ")!");
          }
          return proto[methodName].overloadTable[arguments.length].apply(this, arguments);
        };
        proto[methodName].overloadTable = [];
        proto[methodName].overloadTable[prevFunc.argCount] = prevFunc;
      }
    }
    __name(ensureOverloadTable, "ensureOverloadTable");
    function exposePublicSymbol(name, value, numArguments) {
      if (Module2.hasOwnProperty(name)) {
        if (void 0 === numArguments || void 0 !== Module2[name].overloadTable && void 0 !== Module2[name].overloadTable[numArguments]) {
          throwBindingError("Cannot register public name '" + name + "' twice");
        }
        ensureOverloadTable(Module2, name, name);
        if (Module2.hasOwnProperty(numArguments)) {
          throwBindingError("Cannot register multiple overloads of a function with the same number of arguments (" + numArguments + ")!");
        }
        Module2[name].overloadTable[numArguments] = value;
      } else {
        Module2[name] = value;
        if (void 0 !== numArguments) {
          Module2[name].numArguments = numArguments;
        }
      }
    }
    __name(exposePublicSymbol, "exposePublicSymbol");
    function heap32VectorToArray(count, firstElement) {
      var array = [];
      for (var i = 0; i < count; i++) {
        array.push(HEAPU32[firstElement + i * 4 >> 2]);
      }
      return array;
    }
    __name(heap32VectorToArray, "heap32VectorToArray");
    function replacePublicSymbol(name, value, numArguments) {
      if (!Module2.hasOwnProperty(name)) {
        throwInternalError("Replacing nonexistant public symbol");
      }
      if (void 0 !== Module2[name].overloadTable && void 0 !== numArguments) {
        Module2[name].overloadTable[numArguments] = value;
      } else {
        Module2[name] = value;
        Module2[name].argCount = numArguments;
      }
    }
    __name(replacePublicSymbol, "replacePublicSymbol");
    function dynCallLegacy(sig, ptr, args) {
      var f = Module2["dynCall_" + sig];
      return args && args.length ? f.apply(null, [ptr].concat(args)) : f.call(null, ptr);
    }
    __name(dynCallLegacy, "dynCallLegacy");
    var wasmTableMirror = [];
    function getWasmTableEntry(funcPtr) {
      var func = wasmTableMirror[funcPtr];
      if (!func) {
        if (funcPtr >= wasmTableMirror.length) wasmTableMirror.length = funcPtr + 1;
        wasmTableMirror[funcPtr] = func = wasmTable.get(funcPtr);
      }
      return func;
    }
    __name(getWasmTableEntry, "getWasmTableEntry");
    function dynCall(sig, ptr, args) {
      if (sig.includes("j")) {
        return dynCallLegacy(sig, ptr, args);
      }
      var rtn = getWasmTableEntry(ptr).apply(null, args);
      return rtn;
    }
    __name(dynCall, "dynCall");
    function getDynCaller(sig, ptr) {
      var argCache = [];
      return function() {
        argCache.length = 0;
        Object.assign(argCache, arguments);
        return dynCall(sig, ptr, argCache);
      };
    }
    __name(getDynCaller, "getDynCaller");
    function embind__requireFunction(signature, rawFunction) {
      signature = readLatin1String(signature);
      function makeDynCaller() {
        if (signature.includes("j")) {
          return getDynCaller(signature, rawFunction);
        }
        return getWasmTableEntry(rawFunction);
      }
      __name(makeDynCaller, "makeDynCaller");
      var fp = makeDynCaller();
      if (typeof fp != "function") {
        throwBindingError("unknown function pointer with signature " + signature + ": " + rawFunction);
      }
      return fp;
    }
    __name(embind__requireFunction, "embind__requireFunction");
    var UnboundTypeError = void 0;
    function getTypeName(type) {
      var ptr = ___getTypeName(type);
      var rv = readLatin1String(ptr);
      _free(ptr);
      return rv;
    }
    __name(getTypeName, "getTypeName");
    function throwUnboundTypeError(message, types) {
      var unboundTypes = [];
      var seen = {};
      function visit(type) {
        if (seen[type]) {
          return;
        }
        if (registeredTypes[type]) {
          return;
        }
        if (typeDependencies[type]) {
          typeDependencies[type].forEach(visit);
          return;
        }
        unboundTypes.push(type);
        seen[type] = true;
      }
      __name(visit, "visit");
      types.forEach(visit);
      throw new UnboundTypeError(message + ": " + unboundTypes.map(getTypeName).join([", "]));
    }
    __name(throwUnboundTypeError, "throwUnboundTypeError");
    function __embind_register_function(name, argCount, rawArgTypesAddr, signature, rawInvoker, fn, isAsync) {
      var argTypes = heap32VectorToArray(argCount, rawArgTypesAddr);
      name = readLatin1String(name);
      rawInvoker = embind__requireFunction(signature, rawInvoker);
      exposePublicSymbol(name, function() {
        throwUnboundTypeError("Cannot call " + name + " due to unbound types", argTypes);
      }, argCount - 1);
      whenDependentTypesAreResolved([], argTypes, function(argTypes2) {
        var invokerArgsArray = [argTypes2[0], null].concat(argTypes2.slice(1));
        replacePublicSymbol(name, craftInvokerFunction(name, invokerArgsArray, null, rawInvoker, fn, isAsync), argCount - 1);
        return [];
      });
    }
    __name(__embind_register_function, "__embind_register_function");
    function integerReadValueFromPointer(name, shift, signed) {
      switch (shift) {
        case 0:
          return signed ? /* @__PURE__ */ __name(function readS8FromPointer(pointer) {
            return HEAP8[pointer];
          }, "readS8FromPointer") : /* @__PURE__ */ __name(function readU8FromPointer(pointer) {
            return HEAPU8[pointer];
          }, "readU8FromPointer");
        case 1:
          return signed ? /* @__PURE__ */ __name(function readS16FromPointer(pointer) {
            return HEAP16[pointer >> 1];
          }, "readS16FromPointer") : /* @__PURE__ */ __name(function readU16FromPointer(pointer) {
            return HEAPU16[pointer >> 1];
          }, "readU16FromPointer");
        case 2:
          return signed ? /* @__PURE__ */ __name(function readS32FromPointer(pointer) {
            return HEAP32[pointer >> 2];
          }, "readS32FromPointer") : /* @__PURE__ */ __name(function readU32FromPointer(pointer) {
            return HEAPU32[pointer >> 2];
          }, "readU32FromPointer");
        default:
          throw new TypeError("Unknown integer type: " + name);
      }
    }
    __name(integerReadValueFromPointer, "integerReadValueFromPointer");
    function __embind_register_integer(primitiveType, name, size, minRange, maxRange) {
      name = readLatin1String(name);
      if (maxRange === -1) {
        maxRange = 4294967295;
      }
      var shift = getShiftFromSize(size);
      var fromWireType = /* @__PURE__ */ __name((value) => value, "fromWireType");
      if (minRange === 0) {
        var bitshift = 32 - 8 * size;
        fromWireType = /* @__PURE__ */ __name((value) => value << bitshift >>> bitshift, "fromWireType");
      }
      var isUnsignedType = name.includes("unsigned");
      var checkAssertions = /* @__PURE__ */ __name((value, toTypeName) => {
      }, "checkAssertions");
      var toWireType;
      if (isUnsignedType) {
        toWireType = /* @__PURE__ */ __name(function(destructors, value) {
          checkAssertions(value, this.name);
          return value >>> 0;
        }, "toWireType");
      } else {
        toWireType = /* @__PURE__ */ __name(function(destructors, value) {
          checkAssertions(value, this.name);
          return value;
        }, "toWireType");
      }
      registerType(primitiveType, { name, "fromWireType": fromWireType, "toWireType": toWireType, "argPackAdvance": 8, "readValueFromPointer": integerReadValueFromPointer(name, shift, minRange !== 0), destructorFunction: null });
    }
    __name(__embind_register_integer, "__embind_register_integer");
    function __embind_register_memory_view(rawType, dataTypeIndex, name) {
      var typeMapping = [Int8Array, Uint8Array, Int16Array, Uint16Array, Int32Array, Uint32Array, Float32Array, Float64Array];
      var TA = typeMapping[dataTypeIndex];
      function decodeMemoryView(handle) {
        handle = handle >> 2;
        var heap2 = HEAPU32;
        var size = heap2[handle];
        var data = heap2[handle + 1];
        return new TA(heap2.buffer, data, size);
      }
      __name(decodeMemoryView, "decodeMemoryView");
      name = readLatin1String(name);
      registerType(rawType, { name, "fromWireType": decodeMemoryView, "argPackAdvance": 8, "readValueFromPointer": decodeMemoryView }, { ignoreDuplicateRegistrations: true });
    }
    __name(__embind_register_memory_view, "__embind_register_memory_view");
    function __embind_register_std_string(rawType, name) {
      name = readLatin1String(name);
      var stdStringIsUTF8 = name === "std::string";
      registerType(rawType, { name, "fromWireType": /* @__PURE__ */ __name(function(value) {
        var length = HEAPU32[value >> 2];
        var payload = value + 4;
        var str;
        if (stdStringIsUTF8) {
          var decodeStartPtr = payload;
          for (var i = 0; i <= length; ++i) {
            var currentBytePtr = payload + i;
            if (i == length || HEAPU8[currentBytePtr] == 0) {
              var maxRead = currentBytePtr - decodeStartPtr;
              var stringSegment = UTF8ToString(decodeStartPtr, maxRead);
              if (str === void 0) {
                str = stringSegment;
              } else {
                str += String.fromCharCode(0);
                str += stringSegment;
              }
              decodeStartPtr = currentBytePtr + 1;
            }
          }
        } else {
          var a = new Array(length);
          for (var i = 0; i < length; ++i) {
            a[i] = String.fromCharCode(HEAPU8[payload + i]);
          }
          str = a.join("");
        }
        _free(value);
        return str;
      }, "fromWireType"), "toWireType": /* @__PURE__ */ __name(function(destructors, value) {
        if (value instanceof ArrayBuffer) {
          value = new Uint8Array(value);
        }
        var length;
        var valueIsOfTypeString = typeof value == "string";
        if (!(valueIsOfTypeString || value instanceof Uint8Array || value instanceof Uint8ClampedArray || value instanceof Int8Array)) {
          throwBindingError("Cannot pass non-string to std::string");
        }
        if (stdStringIsUTF8 && valueIsOfTypeString) {
          length = lengthBytesUTF8(value);
        } else {
          length = value.length;
        }
        var base = _malloc(4 + length + 1);
        var ptr = base + 4;
        HEAPU32[base >> 2] = length;
        if (stdStringIsUTF8 && valueIsOfTypeString) {
          stringToUTF8(value, ptr, length + 1);
        } else {
          if (valueIsOfTypeString) {
            for (var i = 0; i < length; ++i) {
              var charCode = value.charCodeAt(i);
              if (charCode > 255) {
                _free(ptr);
                throwBindingError("String has UTF-16 code units that do not fit in 8 bits");
              }
              HEAPU8[ptr + i] = charCode;
            }
          } else {
            for (var i = 0; i < length; ++i) {
              HEAPU8[ptr + i] = value[i];
            }
          }
        }
        if (destructors !== null) {
          destructors.push(_free, base);
        }
        return base;
      }, "toWireType"), "argPackAdvance": 8, "readValueFromPointer": simpleReadValueFromPointer, destructorFunction: /* @__PURE__ */ __name(function(ptr) {
        _free(ptr);
      }, "destructorFunction") });
    }
    __name(__embind_register_std_string, "__embind_register_std_string");
    function UTF16ToString(ptr, maxBytesToRead) {
      var str = "";
      for (var i = 0; !(i >= maxBytesToRead / 2); ++i) {
        var codeUnit = HEAP16[ptr + i * 2 >> 1];
        if (codeUnit == 0) break;
        str += String.fromCharCode(codeUnit);
      }
      return str;
    }
    __name(UTF16ToString, "UTF16ToString");
    function stringToUTF16(str, outPtr, maxBytesToWrite) {
      if (maxBytesToWrite === void 0) {
        maxBytesToWrite = 2147483647;
      }
      if (maxBytesToWrite < 2) return 0;
      maxBytesToWrite -= 2;
      var startPtr = outPtr;
      var numCharsToWrite = maxBytesToWrite < str.length * 2 ? maxBytesToWrite / 2 : str.length;
      for (var i = 0; i < numCharsToWrite; ++i) {
        var codeUnit = str.charCodeAt(i);
        HEAP16[outPtr >> 1] = codeUnit;
        outPtr += 2;
      }
      HEAP16[outPtr >> 1] = 0;
      return outPtr - startPtr;
    }
    __name(stringToUTF16, "stringToUTF16");
    function lengthBytesUTF16(str) {
      return str.length * 2;
    }
    __name(lengthBytesUTF16, "lengthBytesUTF16");
    function UTF32ToString(ptr, maxBytesToRead) {
      var i = 0;
      var str = "";
      while (!(i >= maxBytesToRead / 4)) {
        var utf32 = HEAP32[ptr + i * 4 >> 2];
        if (utf32 == 0) break;
        ++i;
        if (utf32 >= 65536) {
          var ch = utf32 - 65536;
          str += String.fromCharCode(55296 | ch >> 10, 56320 | ch & 1023);
        } else {
          str += String.fromCharCode(utf32);
        }
      }
      return str;
    }
    __name(UTF32ToString, "UTF32ToString");
    function stringToUTF32(str, outPtr, maxBytesToWrite) {
      if (maxBytesToWrite === void 0) {
        maxBytesToWrite = 2147483647;
      }
      if (maxBytesToWrite < 4) return 0;
      var startPtr = outPtr;
      var endPtr = startPtr + maxBytesToWrite - 4;
      for (var i = 0; i < str.length; ++i) {
        var codeUnit = str.charCodeAt(i);
        if (codeUnit >= 55296 && codeUnit <= 57343) {
          var trailSurrogate = str.charCodeAt(++i);
          codeUnit = 65536 + ((codeUnit & 1023) << 10) | trailSurrogate & 1023;
        }
        HEAP32[outPtr >> 2] = codeUnit;
        outPtr += 4;
        if (outPtr + 4 > endPtr) break;
      }
      HEAP32[outPtr >> 2] = 0;
      return outPtr - startPtr;
    }
    __name(stringToUTF32, "stringToUTF32");
    function lengthBytesUTF32(str) {
      var len = 0;
      for (var i = 0; i < str.length; ++i) {
        var codeUnit = str.charCodeAt(i);
        if (codeUnit >= 55296 && codeUnit <= 57343) ++i;
        len += 4;
      }
      return len;
    }
    __name(lengthBytesUTF32, "lengthBytesUTF32");
    function __embind_register_std_wstring(rawType, charSize, name) {
      name = readLatin1String(name);
      var decodeString, encodeString, getHeap, lengthBytesUTF, shift;
      if (charSize === 2) {
        decodeString = UTF16ToString;
        encodeString = stringToUTF16;
        lengthBytesUTF = lengthBytesUTF16;
        getHeap = /* @__PURE__ */ __name(() => HEAPU16, "getHeap");
        shift = 1;
      } else if (charSize === 4) {
        decodeString = UTF32ToString;
        encodeString = stringToUTF32;
        lengthBytesUTF = lengthBytesUTF32;
        getHeap = /* @__PURE__ */ __name(() => HEAPU32, "getHeap");
        shift = 2;
      }
      registerType(rawType, { name, "fromWireType": /* @__PURE__ */ __name(function(value) {
        var length = HEAPU32[value >> 2];
        var HEAP = getHeap();
        var str;
        var decodeStartPtr = value + 4;
        for (var i = 0; i <= length; ++i) {
          var currentBytePtr = value + 4 + i * charSize;
          if (i == length || HEAP[currentBytePtr >> shift] == 0) {
            var maxReadBytes = currentBytePtr - decodeStartPtr;
            var stringSegment = decodeString(decodeStartPtr, maxReadBytes);
            if (str === void 0) {
              str = stringSegment;
            } else {
              str += String.fromCharCode(0);
              str += stringSegment;
            }
            decodeStartPtr = currentBytePtr + charSize;
          }
        }
        _free(value);
        return str;
      }, "fromWireType"), "toWireType": /* @__PURE__ */ __name(function(destructors, value) {
        if (!(typeof value == "string")) {
          throwBindingError("Cannot pass non-string to C++ string type " + name);
        }
        var length = lengthBytesUTF(value);
        var ptr = _malloc(4 + length + charSize);
        HEAPU32[ptr >> 2] = length >> shift;
        encodeString(value, ptr + 4, length + charSize);
        if (destructors !== null) {
          destructors.push(_free, ptr);
        }
        return ptr;
      }, "toWireType"), "argPackAdvance": 8, "readValueFromPointer": simpleReadValueFromPointer, destructorFunction: /* @__PURE__ */ __name(function(ptr) {
        _free(ptr);
      }, "destructorFunction") });
    }
    __name(__embind_register_std_wstring, "__embind_register_std_wstring");
    function __embind_register_void(rawType, name) {
      name = readLatin1String(name);
      registerType(rawType, { isVoid: true, name, "argPackAdvance": 0, "fromWireType": /* @__PURE__ */ __name(function() {
        return void 0;
      }, "fromWireType"), "toWireType": /* @__PURE__ */ __name(function(destructors, o) {
        return void 0;
      }, "toWireType") });
    }
    __name(__embind_register_void, "__embind_register_void");
    var emval_symbols = {};
    function getStringOrSymbol(address) {
      var symbol = emval_symbols[address];
      if (symbol === void 0) {
        return readLatin1String(address);
      }
      return symbol;
    }
    __name(getStringOrSymbol, "getStringOrSymbol");
    function emval_get_global() {
      if (typeof globalThis == "object") {
        return globalThis;
      }
      function testGlobal(obj) {
        obj["$$$embind_global$$$"] = obj;
        var success = typeof $$$embind_global$$$ == "object" && obj["$$$embind_global$$$"] == obj;
        if (!success) {
          delete obj["$$$embind_global$$$"];
        }
        return success;
      }
      __name(testGlobal, "testGlobal");
      if (typeof $$$embind_global$$$ == "object") {
        return $$$embind_global$$$;
      }
      if (typeof global == "object" && testGlobal(global)) {
        $$$embind_global$$$ = global;
      } else if (typeof self == "object" && testGlobal(self)) {
        $$$embind_global$$$ = self;
      }
      if (typeof $$$embind_global$$$ == "object") {
        return $$$embind_global$$$;
      }
      throw Error("unable to get global object.");
    }
    __name(emval_get_global, "emval_get_global");
    function __emval_get_global(name) {
      if (name === 0) {
        return Emval.toHandle(emval_get_global());
      } else {
        name = getStringOrSymbol(name);
        return Emval.toHandle(emval_get_global()[name]);
      }
    }
    __name(__emval_get_global, "__emval_get_global");
    function __emval_incref(handle) {
      if (handle > 4) {
        emval_handle_array[handle].refcount += 1;
      }
    }
    __name(__emval_incref, "__emval_incref");
    function requireRegisteredType(rawType, humanName) {
      var impl = registeredTypes[rawType];
      if (void 0 === impl) {
        throwBindingError(humanName + " has unknown type " + getTypeName(rawType));
      }
      return impl;
    }
    __name(requireRegisteredType, "requireRegisteredType");
    function craftEmvalAllocator(argCount) {
      var argsList = new Array(argCount + 1);
      return function(constructor, argTypes, args) {
        argsList[0] = constructor;
        for (var i = 0; i < argCount; ++i) {
          var argType = requireRegisteredType(HEAPU32[argTypes + i * 4 >> 2], "parameter " + i);
          argsList[i + 1] = argType["readValueFromPointer"](args);
          args += argType["argPackAdvance"];
        }
        var obj = new (constructor.bind.apply(constructor, argsList))();
        return Emval.toHandle(obj);
      };
    }
    __name(craftEmvalAllocator, "craftEmvalAllocator");
    var emval_newers = {};
    function __emval_new(handle, argCount, argTypes, args) {
      handle = Emval.toValue(handle);
      var newer = emval_newers[argCount];
      if (!newer) {
        newer = craftEmvalAllocator(argCount);
        emval_newers[argCount] = newer;
      }
      return newer(handle, argTypes, args);
    }
    __name(__emval_new, "__emval_new");
    function _abort() {
      abort("");
    }
    __name(_abort, "_abort");
    function _emscripten_memcpy_big(dest, src, num) {
      HEAPU8.copyWithin(dest, src, src + num);
    }
    __name(_emscripten_memcpy_big, "_emscripten_memcpy_big");
    function getHeapMax() {
      return 2147483648;
    }
    __name(getHeapMax, "getHeapMax");
    function emscripten_realloc_buffer(size) {
      var b = wasmMemory.buffer;
      try {
        wasmMemory.grow(size - b.byteLength + 65535 >>> 16);
        updateMemoryViews();
        return 1;
      } catch (e) {
      }
    }
    __name(emscripten_realloc_buffer, "emscripten_realloc_buffer");
    function _emscripten_resize_heap(requestedSize) {
      var oldSize = HEAPU8.length;
      requestedSize = requestedSize >>> 0;
      var maxHeapSize = getHeapMax();
      if (requestedSize > maxHeapSize) {
        return false;
      }
      let alignUp = /* @__PURE__ */ __name((x, multiple) => x + (multiple - x % multiple) % multiple, "alignUp");
      for (var cutDown = 1; cutDown <= 4; cutDown *= 2) {
        var overGrownHeapSize = oldSize * (1 + 0.2 / cutDown);
        overGrownHeapSize = Math.min(overGrownHeapSize, requestedSize + 100663296);
        var newSize = Math.min(maxHeapSize, alignUp(Math.max(requestedSize, overGrownHeapSize), 65536));
        var replacement = emscripten_realloc_buffer(newSize);
        if (replacement) {
          return true;
        }
      }
      return false;
    }
    __name(_emscripten_resize_heap, "_emscripten_resize_heap");
    embind_init_charCodes();
    BindingError = Module2["BindingError"] = extendError(Error, "BindingError");
    InternalError = Module2["InternalError"] = extendError(Error, "InternalError");
    init_emval();
    UnboundTypeError = Module2["UnboundTypeError"] = extendError(Error, "UnboundTypeError");
    var wasmImports = { "n": ___cxa_throw, "o": __embind_register_bigint, "l": __embind_register_bool, "r": __embind_register_emval, "k": __embind_register_float, "c": __embind_register_function, "b": __embind_register_integer, "a": __embind_register_memory_view, "g": __embind_register_std_string, "f": __embind_register_std_wstring, "m": __embind_register_void, "d": __emval_decref, "e": __emval_get_global, "i": __emval_incref, "h": __emval_new, "j": _abort, "q": _emscripten_memcpy_big, "p": _emscripten_resize_heap };
    var asm = createWasm();
    var ___wasm_call_ctors = /* @__PURE__ */ __name(function() {
      return (___wasm_call_ctors = Module2["asm"]["t"]).apply(null, arguments);
    }, "___wasm_call_ctors");
    var _malloc = /* @__PURE__ */ __name(function() {
      return (_malloc = Module2["asm"]["u"]).apply(null, arguments);
    }, "_malloc");
    var _free = /* @__PURE__ */ __name(function() {
      return (_free = Module2["asm"]["v"]).apply(null, arguments);
    }, "_free");
    var ___getTypeName = Module2["___getTypeName"] = function() {
      return (___getTypeName = Module2["___getTypeName"] = Module2["asm"]["w"]).apply(null, arguments);
    };
    var __embind_initialize_bindings = Module2["__embind_initialize_bindings"] = function() {
      return (__embind_initialize_bindings = Module2["__embind_initialize_bindings"] = Module2["asm"]["x"]).apply(null, arguments);
    };
    var ___errno_location = /* @__PURE__ */ __name(function() {
      return (___errno_location = Module2["asm"]["__errno_location"]).apply(null, arguments);
    }, "___errno_location");
    var ___cxa_is_pointer_type = /* @__PURE__ */ __name(function() {
      return (___cxa_is_pointer_type = Module2["asm"]["z"]).apply(null, arguments);
    }, "___cxa_is_pointer_type");
    var calledRun;
    dependenciesFulfilled = /* @__PURE__ */ __name(function runCaller() {
      if (!calledRun) run();
      if (!calledRun) dependenciesFulfilled = runCaller;
    }, "runCaller");
    function run() {
      if (runDependencies > 0) {
        return;
      }
      preRun();
      if (runDependencies > 0) {
        return;
      }
      function doRun() {
        if (calledRun) return;
        calledRun = true;
        Module2["calledRun"] = true;
        if (ABORT) return;
        initRuntime();
        readyPromiseResolve(Module2);
        if (Module2["onRuntimeInitialized"]) Module2["onRuntimeInitialized"]();
        postRun();
      }
      __name(doRun, "doRun");
      if (Module2["setStatus"]) {
        Module2["setStatus"]("Running...");
        setTimeout(function() {
          setTimeout(function() {
            Module2["setStatus"]("");
          }, 1);
          doRun();
        }, 1);
      } else {
        doRun();
      }
    }
    __name(run, "run");
    if (Module2["preInit"]) {
      if (typeof Module2["preInit"] == "function") Module2["preInit"] = [Module2["preInit"]];
      while (Module2["preInit"].length > 0) {
        Module2["preInit"].pop()();
      }
    }
    run();
    return Module2.ready;
  });
})();
var webp_dec_default = Module;

// ../../../Users/diegohaz/Developer/ariviso/node_modules/.pnpm/@jsquash+webp@1.5.0/node_modules/@jsquash/webp/utils.js
function initEmscriptenModule(moduleFactory, wasmModule, moduleOptionOverrides = {}) {
  let instantiateWasm;
  if (wasmModule) {
    instantiateWasm = /* @__PURE__ */ __name((imports, callback) => {
      const instance = new WebAssembly.Instance(wasmModule, imports);
      callback(instance);
      return instance.exports;
    }, "instantiateWasm");
  }
  return moduleFactory({
    // Just to be safe, don't automatically invoke any wasm functions
    noInitialRun: true,
    instantiateWasm,
    ...moduleOptionOverrides
  });
}
__name(initEmscriptenModule, "initEmscriptenModule");

// ../../../Users/diegohaz/Developer/ariviso/node_modules/.pnpm/@jsquash+webp@1.5.0/node_modules/@jsquash/webp/decode.js
var emscriptenModule;
async function init3(module, moduleOptionOverrides) {
  let actualModule = module;
  let actualOptions = moduleOptionOverrides;
  if (arguments.length === 1 && !(module instanceof WebAssembly.Module)) {
    actualModule = void 0;
    actualOptions = module;
  }
  emscriptenModule = initEmscriptenModule(webp_dec_default, actualModule, actualOptions);
}
__name(init3, "init");
async function decode3(buffer) {
  if (!emscriptenModule)
    init3();
  const module = await emscriptenModule;
  const result = module.decode(buffer);
  if (!result)
    throw new Error("Decoding error");
  return result;
}
__name(decode3, "decode");

// source/packages/compare/src/jsquash.ts
async function createCodecs(modules) {
  const png2 = await init(modules.png);
  await init2(modules.png);
  let webpMemory;
  await init3({
    instantiateWasm(imports, callback) {
      const instance = new WebAssembly.Instance(modules.webp, imports);
      webpMemory = Object.values(instance.exports).find(
        (value) => value instanceof WebAssembly.Memory
      );
      callback(instance);
      return instance.exports;
    }
  });
  return {
    decodePng: decode_default,
    decodeWebp: decode3,
    wasmMemoryBytes() {
      return png2.memory.buffer.byteLength + (webpMemory?.buffer.byteLength ?? 0);
    },
    encodePng(image) {
      return encode2(
        new ImageData(Uint8ClampedArray.from(image.data), image.width, image.height)
      );
    }
  };
}
__name(createCodecs, "createCodecs");

// source/apps/compare/src/codecs.ts
var codecsReady = createCodecs({ png, webp });

// source/packages/compare/src/types.ts
var imageLimits = Object.freeze({
  maxEncodedBytes: 2 * 1024 * 1024,
  maxPixels: 21e5,
  maxDimension: 8192,
  maxProfileBytes: 65536
});
var ImageValidationError = class extends Error {
  static {
    __name(this, "ImageValidationError");
  }
  code;
  constructor(code, message) {
    super(message);
    this.code = code;
    this.name = "ImageValidationError";
  }
};
function invalid(code, message) {
  throw new ImageValidationError(code, message);
}
__name(invalid, "invalid");
function assertDimensions(width, height, limits) {
  if (!Number.isSafeInteger(width) || !Number.isSafeInteger(height) || width < 1 || height < 1) {
    invalid("dimensions", "Image dimensions must be positive integers.");
  }
  if (width > limits.maxDimension || height > limits.maxDimension || width * height > limits.maxPixels) {
    invalid("image-too-large", "Image dimensions exceed the configured decode limit.");
  }
}
__name(assertDimensions, "assertDimensions");

// source/packages/compare/src/binary.ts
function read32(bytes, offset, littleEndian = false) {
  return new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength).getUint32(
    offset,
    littleEndian
  );
}
__name(read32, "read32");
function textAt(bytes, start, length) {
  return String.fromCharCode(...bytes.subarray(start, start + length));
}
__name(textAt, "textAt");
function crc32(bytes) {
  let value = 4294967295;
  for (const byte of bytes) {
    value ^= byte;
    for (let i = 0; i < 8; i += 1) {
      value = value >>> 1 ^ (value & 1 ? 3988292384 : 0);
    }
  }
  return (value ^ 4294967295) >>> 0;
}
__name(crc32, "crc32");
function joinBytes(parts) {
  const bytes = new Uint8Array(parts.reduce((total, part) => total + part.length, 0));
  let offset = 0;
  for (const part of parts) {
    bytes.set(part, offset);
    offset += part.length;
  }
  return bytes;
}
__name(joinBytes, "joinBytes");
async function sha256(bytes) {
  const digest = await crypto.subtle.digest("SHA-256", bytes);
  return Array.from(new Uint8Array(digest), (byte) => byte.toString(16).padStart(2, "0")).join("");
}
__name(sha256, "sha256");
async function inflateBounded(bytes, maximum) {
  const reader = new Blob([bytes]).stream().pipeThrough(new DecompressionStream("deflate")).getReader();
  const parts = [];
  let length = 0;
  try {
    while (true) {
      const next = await reader.read();
      if (next.done) break;
      length += next.value.length;
      if (length > maximum) {
        await reader.cancel();
        invalid("decoded-size", "Compressed data exceeds the declared image or profile size.");
      }
      parts.push(next.value);
    }
  } catch (error) {
    if (error instanceof Error && error.name === "ImageValidationError") {
      throw error;
    }
    invalid("compressed-data", "Image contains an invalid compressed stream.");
  } finally {
    reader.releaseLock();
  }
  return joinBytes(parts);
}
__name(inflateBounded, "inflateBounded");

// source/packages/compare/src/profile.ts
var supportedProfileDigest = "12afb4d9953adee0607d347daee5b78b18d6b3cab2d572b88970703f5edb37bc";
async function validateProfile(profile) {
  if (await sha256(profile) !== supportedProfileDigest) {
    invalid("unsupported-profile", "Only the verified Chromium sRGB ICC profile is supported.");
  }
  return "srgb-chromium-icc-v1";
}
__name(validateProfile, "validateProfile");

// source/packages/compare/src/exif.ts
var webkitLayout = "4d4d002a00000008000187690004000000010000001a000000000003a00100030000000100010000a00200040000000100000000a0030004000000010000000000000000";
function validateWebkitExif(data, width, height) {
  const expected = Uint8Array.from(
    webkitLayout.match(/../g) ?? [],
    (pair) => Number.parseInt(pair, 16)
  );
  const view = new DataView(expected.buffer);
  view.setUint32(48, width);
  view.setUint32(60, height);
  if (data.length !== expected.length || !data.every((byte, index) => byte === expected[index])) {
    invalid(
      "unsupported-profile",
      "PNG EXIF metadata must be WebKit's unrotated sRGB screenshot layout."
    );
  }
}
__name(validateWebkitExif, "validateWebkitExif");

// source/packages/compare/src/png.ts
var chromaticities = [31270, 32900, 64e3, 33e3, 3e4, 6e4, 15e3, 6e3];
var singletonChunks = /* @__PURE__ */ new Set([
  "IHDR",
  "PLTE",
  "tRNS",
  "gAMA",
  "cHRM",
  "sRGB",
  "iCCP",
  "eXIf",
  "IEND"
]);
function filteredSize(width, height, channels, interlace) {
  if (!interlace) {
    return height * (width * channels + 1);
  }
  const passes = [
    [0, 0, 8, 8],
    [4, 0, 8, 8],
    [0, 4, 4, 8],
    [2, 0, 4, 4],
    [0, 2, 2, 4],
    [1, 0, 2, 2],
    [0, 1, 1, 2]
  ];
  let length = 0;
  for (const pass of passes) {
    const [left = 0, top = 0, horizontal = 1, vertical = 1] = pass;
    const columns = Math.max(0, Math.ceil((width - left) / horizontal));
    const rows = Math.max(0, Math.ceil((height - top) / vertical));
    if (columns && rows) {
      length += rows * (columns * channels + 1);
    }
  }
  return length;
}
__name(filteredSize, "filteredSize");
async function inspectPng(bytes, limits) {
  const chunks = /* @__PURE__ */ new Set();
  const decodeChunks = [bytes.subarray(0, 8)];
  const compressed = [];
  let width = 0;
  let height = 0;
  let color = -1;
  let channels = 0;
  let interlace = 0;
  let paletteEntries = 0;
  let dataEnded = false;
  let profile = "srgb-unprofiled-v1";
  let offset = 8;
  let chunkCount = 0;
  while (offset < bytes.length) {
    chunkCount += 1;
    if (chunkCount > 1024) {
      invalid("png-chunk-count", "PNG contains too many chunks.");
    }
    if (bytes.length - offset < 12) {
      invalid("png-truncated", "PNG contains a truncated chunk.");
    }
    const length = read32(bytes, offset);
    const end = offset + 12 + length;
    if (end > bytes.length) {
      invalid("png-truncated", "PNG chunk exceeds the file length.");
    }
    const name = textAt(bytes, offset + 4, 4);
    if (!/^[A-Za-z]{2}[A-Z][A-Za-z]$/.test(name)) {
      invalid("png-chunk", "PNG chunk name is invalid.");
    }
    if (read32(bytes, end - 4) !== crc32(bytes.subarray(offset + 4, end - 4))) {
      invalid("png-crc", "PNG chunk checksum does not match.");
    }
    const data = bytes.subarray(offset + 8, end - 4);
    if (!chunks.size && name !== "IHDR") {
      invalid("png-order", "PNG must start with IHDR.");
    }
    if (singletonChunks.has(name) && chunks.has(name)) {
      invalid("png-duplicate", "PNG contains a duplicate singleton chunk.");
    }
    if (["acTL", "fcTL", "fdAT"].includes(name)) {
      invalid("animated-image", "Animated PNG is unsupported.");
    }
    if (["cICP", "mDCv", "cLLi"].includes(name)) {
      invalid("unsupported-profile", "PNG contains unsupported color or orientation metadata.");
    }
    if (name === "IHDR") {
      if (length !== 13) {
        invalid("png-header", "PNG IHDR length must be 13.");
      }
      width = read32(data, 0);
      height = read32(data, 4);
      assertDimensions(width, height, limits);
      color = data[9] ?? -1;
      channels = (/* @__PURE__ */ new Map([
        [0, 1],
        [2, 3],
        [3, 1],
        [4, 2],
        [6, 4]
      ])).get(color) ?? 0;
      interlace = data[12] ?? -1;
      if (data[8] !== 8 || !channels || data[10] !== 0 || data[11] !== 0 || interlace > 1) {
        invalid(
          "png-encoding",
          "Only static 8-bit PNG color types and standard compression are supported."
        );
      }
    } else if (["PLTE", "tRNS", "gAMA", "cHRM", "sRGB", "iCCP"].includes(name)) {
      if (chunks.has("IDAT")) {
        invalid(
          "png-order",
          "PNG palette, transparency and color metadata must precede image data."
        );
      }
      if (["gAMA", "cHRM", "sRGB", "iCCP"].includes(name) && chunks.has("PLTE")) {
        invalid("png-order", "PNG color metadata must precede the palette.");
      }
      if (name === "PLTE") {
        if (!length || length > 768 || length % 3 || color === 0 || color === 4 || chunks.has("tRNS")) {
          invalid("png-palette", "PNG palette is invalid for this color type.");
        }
        paletteEntries = length / 3;
      }
      if (name === "tRNS") {
        const valid = color === 0 && length === 2 && data[0] === 0 || color === 2 && length === 6 && data[0] === 0 && data[2] === 0 && data[4] === 0 || color === 3 && length > 0 && length <= paletteEntries;
        if (!valid) {
          invalid("png-transparency", "PNG transparency data is invalid.");
        }
      }
      if (name === "gAMA" && (length !== 4 || read32(data, 0) !== 45455)) {
        invalid("unsupported-profile", "PNG gamma must describe sRGB.");
      }
      if (name === "cHRM" && (length !== 32 || chromaticities.some((value, index) => read32(data, index * 4) !== value))) {
        invalid("unsupported-profile", "PNG chromaticities must describe sRGB.");
      }
      if (name === "sRGB") {
        if (length !== 1 || (data[0] ?? 4) > 3 || chunks.has("iCCP")) {
          invalid("unsupported-profile", "PNG sRGB metadata is invalid or conflicts with ICC.");
        }
        profile = "srgb-explicit-v1";
      }
      if (name === "iCCP") {
        const nameEnd = data.indexOf(0);
        if (nameEnd < 1 || nameEnd > 79 || data[nameEnd + 1] !== 0 || chunks.has("sRGB")) {
          invalid("unsupported-profile", "PNG ICC metadata is invalid or conflicts with sRGB.");
        }
        profile = await validateProfile(
          await inflateBounded(data.slice(nameEnd + 2), limits.maxProfileBytes)
        );
      }
    } else if (name === "eXIf") {
      validateWebkitExif(data, width, height);
      if (profile === "srgb-unprofiled-v1") {
        profile = "srgb-explicit-v1";
      }
    } else if (name === "IDAT") {
      if (dataEnded || color === 3 && !paletteEntries) {
        invalid("png-order", "PNG image data must be consecutive and follow its required palette.");
      }
      compressed.push(data);
    } else if (name === "IEND") {
      if (length || !chunks.has("IDAT") || end !== bytes.length) {
        invalid("png-end", "PNG must end after image data with an empty IEND.");
      }
    } else if (/^[A-Z]/.test(name)) {
      invalid("png-chunk", "PNG contains an unknown critical chunk.");
    }
    if (name !== "IDAT" && chunks.has("IDAT")) {
      dataEnded = true;
    }
    if (["IHDR", "PLTE", "tRNS", "IDAT", "IEND"].includes(name)) {
      decodeChunks.push(bytes.subarray(offset, end));
    }
    chunks.add(name);
    offset = end;
  }
  if (!chunks.has("IEND")) {
    invalid("png-end", "PNG is missing IEND.");
  }
  const expected = filteredSize(width, height, channels, interlace);
  const inflated = await inflateBounded(joinBytes(compressed), expected);
  if (inflated.length !== expected) {
    invalid("decoded-size", "PNG decompressed data does not match its dimensions.");
  }
  return { width, height, profile, decodeBytes: joinBytes(decodeChunks) };
}
__name(inspectPng, "inspectPng");

// source/packages/compare/src/webp.ts
function read24(bytes, offset) {
  return (bytes[offset] ?? 0) + (bytes[offset + 1] ?? 0) * 256 + (bytes[offset + 2] ?? 0) * 65536;
}
__name(read24, "read24");
async function inspectWebp(bytes, limits) {
  if (read32(bytes, 4, true) + 8 !== bytes.length) {
    invalid("webp-size", "WebP RIFF length does not match the file.");
  }
  let offset = 12;
  let width = 0;
  let height = 0;
  let canvasWidth = 0;
  let canvasHeight = 0;
  let flags = 0;
  let profile = "srgb-unprofiled-v1";
  const chunks = /* @__PURE__ */ new Set();
  while (offset < bytes.length) {
    if (bytes.length - offset < 8) {
      invalid("webp-truncated", "WebP contains a truncated chunk.");
    }
    const name = textAt(bytes, offset, 4);
    const length = read32(bytes, offset + 4, true);
    const end = offset + 8 + length;
    if (end + length % 2 > bytes.length || length % 2 && bytes[end] !== 0) {
      invalid("webp-truncated", "WebP chunk length or padding is invalid.");
    }
    if (chunks.has(name)) {
      invalid("webp-duplicate", "WebP contains a duplicate chunk.");
    }
    const data = bytes.subarray(offset + 8, end);
    if (["ANIM", "ANMF"].includes(name)) {
      invalid("animated-image", "Animated WebP is unsupported.");
    }
    if (name === "VP8 " || name === "ALPH") {
      invalid("lossy-webp", "Only lossless WebP is supported.");
    }
    if (name === "VP8X") {
      flags = data[0] ?? 0;
      if (offset !== 12 || length !== 10 || flags & ~48 || data[1] || data[2] || data[3]) {
        invalid("webp-header", "WebP extended header has unsupported flags or layout.");
      }
      canvasWidth = read24(data, 4) + 1;
      canvasHeight = read24(data, 7) + 1;
      assertDimensions(canvasWidth, canvasHeight, limits);
    } else if (name === "ICCP") {
      if (!chunks.has("VP8X") || chunks.has("VP8L") || !(flags & 32) || length > limits.maxProfileBytes) {
        invalid("unsupported-profile", "WebP ICC profile has invalid flags, position, or size.");
      }
      profile = await validateProfile(data);
    } else if (name === "VP8L") {
      if (length < 5 || data[0] !== 47) {
        invalid("webp-header", "WebP lossless header is invalid.");
      }
      const packed = read32(data, 1, true);
      if (packed >>> 29) {
        invalid("webp-version", "WebP lossless version is unsupported.");
      }
      width = (packed & 16383) + 1;
      height = (packed >>> 14 & 16383) + 1;
      assertDimensions(width, height, limits);
      if (chunks.has("VP8X") && (width !== canvasWidth || height !== canvasHeight)) {
        invalid("webp-dimensions", "WebP canvas and lossless dimensions differ.");
      }
    } else {
      invalid("webp-chunk", "WebP contains an unsupported chunk.");
    }
    chunks.add(name);
    offset = end + length % 2;
  }
  if (!chunks.has("VP8L") || Boolean(flags & 32) !== chunks.has("ICCP")) {
    invalid("webp-incomplete", "WebP is missing required lossless image or profile data.");
  }
  return { width, height, profile, decodeBytes: bytes };
}
__name(inspectWebp, "inspectWebp");

// source/packages/compare/src/image.ts
var pngSignature = [137, 80, 78, 71, 13, 10, 26, 10];
async function validateImage(input, limits = imageLimits) {
  if (input.length > limits.maxEncodedBytes) {
    invalid("encoded-size", "Image bytes exceed the configured upload limit.");
  }
  if (input.length < 12) {
    invalid("image-format", "Image is truncated or has an unsupported format.");
  }
  const original = Uint8Array.from(input);
  let format;
  if (pngSignature.every((byte, index) => original[index] === byte)) {
    format = "png";
  } else if (textAt(original, 0, 4) === "RIFF" && textAt(original, 8, 4) === "WEBP") {
    format = "webp";
  } else {
    invalid("image-format", "Only PNG and lossless WebP are supported.");
  }
  const metadata = format === "png" ? await inspectPng(original, limits) : await inspectWebp(original, limits);
  return { ...metadata, format, original, digest: await sha256(original) };
}
__name(validateImage, "validateImage");
async function decodeImage(image, codecs) {
  let pixels;
  try {
    pixels = await (image.format === "png" ? codecs.decodePng : codecs.decodeWebp)(
      image.decodeBytes.buffer
    );
  } catch {
    invalid("decode-failed", "Image decoder rejected the validated input.");
  }
  if (pixels.width !== image.width || pixels.height !== image.height || pixels.data.length !== image.width * image.height * 4) {
    invalid("decode-dimensions", "Decoded pixels do not match the validated dimensions.");
  }
  return pixels;
}
__name(decodeImage, "decodeImage");
async function readBounded(stream, maximum) {
  const reader = stream.getReader();
  const buffer = new Uint8Array(maximum);
  let offset = 0;
  try {
    while (true) {
      const next = await reader.read();
      if (next.done) break;
      if (offset + next.value.length > maximum) {
        await reader.cancel();
        invalid("encoded-size", "Image bytes exceed the configured upload limit.");
      }
      buffer.set(next.value, offset);
      offset += next.value.length;
    }
  } finally {
    reader.releaseLock();
  }
  return buffer.slice(0, offset);
}
__name(readBounded, "readBounded");

// source/apps/compare/src/capacity.ts
var CodecBusyError = class extends Error {
  static {
    __name(this, "CodecBusyError");
  }
  constructor() {
    super("The image codec is busy. Retry the request.");
    this.name = "CodecBusyError";
  }
};
var occupied = false;
async function withCodecCapacity(operation) {
  if (occupied) {
    throw new CodecBusyError();
  }
  occupied = true;
  try {
    return await operation();
  } finally {
    occupied = false;
  }
}
__name(withCodecCapacity, "withCodecCapacity");

// source/apps/compare/src/validate.ts
async function validateRequest(request, codecs) {
  const headers = { "Cache-Control": "no-store", "X-Content-Type-Options": "nosniff" };
  if (request.method !== "POST" || new URL(request.url).pathname !== "/validate") {
    return new Response("Not found", { status: 404, headers });
  }
  const body = request.body;
  if (!body) {
    return Response.json({ error: "Image bytes are required" }, { status: 400, headers });
  }
  try {
    return await withCodecCapacity(async () => {
      const bytes = await readBounded(body, imageLimits.maxEncodedBytes);
      const image = await validateImage(bytes);
      await decodeImage(image, codecs);
      return Response.json(
        {
          digest: image.digest,
          width: image.width,
          height: image.height,
          bytes: image.original.length,
          contentType: `image/${image.format}`,
          profile: image.profile
        },
        { headers }
      );
    });
  } catch (error) {
    if (error instanceof CodecBusyError) {
      return Response.json(
        { code: "codec-busy", error: error.message },
        { status: 503, headers: { ...headers, "Retry-After": "1" } }
      );
    }
    if (error instanceof ImageValidationError) {
      return Response.json({ code: error.code, error: error.message }, { status: 422, headers });
    }
    throw error;
  }
}
__name(validateRequest, "validateRequest");

// comparator.mjs
var comparator_default = {
  async fetch(request) {
    return validateRequest(request, await codecsReady);
  }
};
export {
  comparator_default as default
};
//# sourceMappingURL=comparator.js.map
