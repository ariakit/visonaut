import { ImageValidationError } from "@ariviso/compare";
import { ConflictError, IncompleteError, reconcileWork, Service } from "@ariviso/service";
import { codecsReady } from "./codecs.ts";
import { processComparisonTask } from "./process.ts";
import { CodecBusyError, withCodecCapacity } from "./capacity.ts";
import { validateRequest } from "./validate.ts";

interface ComparisonMessage {
  taskId: string;
}

function validMessage(value: unknown): value is ComparisonMessage {
  if (!value || typeof value !== "object" || !Object.hasOwn(value, "taskId")) return false;
  return (
    "taskId" in value &&
    typeof value.taskId === "string" &&
    value.taskId.length > 0 &&
    value.taskId.length < 512
  );
}

async function finishComparison(service: Service, comparisonId: string) {
  try {
    await service.finalizeComparison({ comparisonId, now: Date.now() });
  } catch (error) {
    if (error instanceof IncompleteError || error instanceof ConflictError) return;
    throw error;
  }
}

async function consume(message: Message<unknown>, env: Env) {
  if (!validMessage(message.body)) {
    console.error(JSON.stringify({ event: "comparison-invalid-message" }));
    message.retry({ delaySeconds: 60 });
    return;
  }
  const service = new Service(env.DB);
  const taskId = message.body.taskId;
  const owner = crypto.randomUUID();
  try {
    const task = await service.claimComparisonTask({
      taskId,
      owner,
      now: Date.now(),
      leaseMilliseconds: 120_000,
    });
    if (!task) {
      const state = await service.getComparisonTaskState(taskId);
      if (state?.state === "complete") {
        const completedTask = await service.getComparisonTask(taskId);
        await finishComparison(service, completedTask.comparisonId);
      }
      if (state?.state === "complete" || state?.state === "dead" || state?.state === "superseded") {
        message.ack();
      } else {
        message.retry({ delaySeconds: 60 });
      }
      return;
    }
    const { result, artifacts } = await processComparisonTask({
      task,
      images: env.IMAGES,
      codecs: await codecsReady,
    });
    await service.commitComparisonResult({
      taskId,
      leaseOwner: owner,
      now: Date.now(),
      result,
      artifacts,
    });
    await finishComparison(service, task.comparisonId);
    message.ack();
  } catch (error) {
    const code =
      error instanceof ImageValidationError
        ? error.code
        : error instanceof Error
          ? error.name
          : "Error";
    console.error(JSON.stringify({ event: "comparison-task-failed", taskId, code }));
    await service.failComparisonTask({
      taskId,
      owner,
      now: Date.now(),
      retryAt: Date.now() + 60_000,
      error: code,
    });
    const state = await service.getComparisonTaskState(taskId);
    if (state?.state === "dead" || state?.state === "superseded") {
      message.ack();
      return;
    }
    message.retry({ delaySeconds: 60 });
  }
}

export default {
  async fetch(request: Request) {
    return validateRequest(request, await codecsReady);
  },
  async queue(batch: MessageBatch<unknown>, env: Env) {
    for (const message of batch.messages) {
      try {
        await withCodecCapacity(() => consume(message, env));
      } catch (error) {
        if (!(error instanceof CodecBusyError)) {
          throw error;
        }
        message.retry({ delaySeconds: 1 });
      }
    }
  },
  async scheduled(_controller: ScheduledController, env: Env) {
    await reconcileWork(env.DB, {
      now: Date.now(),
      limit: 100,
      kind: "compare",
      publish: async (taskId) => {
        await env.COMPARISONS.send({ taskId });
      },
    });
    const service = new Service(env.DB);
    const recovered = await service.reconcileComparisons({ now: Date.now(), limit: 100 });
    if (recovered.errors.length) {
      console.error(
        JSON.stringify({ event: "comparison-finalization-failed", count: recovered.errors.length }),
      );
    }
  },
} satisfies ExportedHandler<Env>;
