import { cv } from "clava";
import { includes } from "../utils/includes.ts";
import { getSpacingValue } from "../utils/styles.ts";
import { edge } from "./edge.ts";

const ROUNDED_VALUES = ["none", "xs", "sm", "md", "lg", "xl", "2xl", "3xl", "4xl", "full"] as const;

export type FrameRoundedValue = (typeof ROUNDED_VALUES)[number] | "unset";

/**
 * Resolves a `$rounded` value to its class, or to the radius channel when the
 * value is a length or an expression rather than a named step.
 *
 * A component that declares its own `$rounded` replaces this one rather than
 * merging with it, so call this for every value it does not handle itself, or
 * the named steps stop working on that component.
 */
export function getFrameRoundedClass(value?: FrameRoundedValue | (string & {})) {
  if (value == null) return;
  // "unset" rather than false: a false branch would give frame and every
  // extender an implicit constant default, which deadens downstream computed
  // fallbacks like the glider's and the control slot's.
  if (value === "unset") return;
  if (includes(ROUNDED_VALUES, value)) {
    const valueMap = {
      none: "ak-frame-none",
      xs: "ak-frame-xs",
      sm: "ak-frame-sm",
      md: "ak-frame-md",
      lg: "ak-frame-lg",
      xl: "ak-frame-xl",
      "2xl": "ak-frame-2xl",
      "3xl": "ak-frame-3xl",
      "4xl": "ak-frame-4xl",
      full: "ak-frame-full",
    } satisfies Record<Exclude<FrameRoundedValue, "unset">, string>;
    return valueMap[value];
  }
  // A bare word is a scale key that some component added, and one this
  // component did not declare has nothing to say here. Only a length, a
  // percentage or an expression is a radius to spend.
  if (!/[(.\d%]/.test(value)) return;
  return {
    class: "ak-frame-(--frame-radius)",
    style: { "--frame-radius": value },
  };
}

/**
 * The frame geometry on its own: radius, padding, margin, borders and the
 * concentric-radius layout, with no colour behind it. Extend this when an
 * element takes frame geometry but paints nothing, so it does not open a layer
 * it has no use for. Most components want `frame`.
 */
export const frameBase = cv({
  variants: {
    /**
     * Enables the frame system, which allows you to set the element's radius,
     * padding, margin, borders, and concentric-radius layout.
     */
    $frame: "ak-frame",
    /**
     * Stretches the element to fill the parent frame's content box while
     * collapsing shared borders. The element's corners are rounded to match the
     * parent frame's corners based on the parent's `$orientation`. If this
     * isn't inferred automatically, use `$frameStart` and `$frameEnd` to
     * indicate whether the frame is the first or last child in the current
     * flow, which affects how the corners are rounded.
     */
    $cover: "ak-frame-cover",
    /**
     * Sets the frame flow direction. This affects how nested `$cover` frames
     * are rounded.
     */
    $orientation: {
      unset: "",
      horizontal: "ak-frame-row",
      vertical: "ak-frame-col",
    },
    /**
     * Marks the frame as the first child in the current flow, where
     * `$orientation` is determined by the parent frame. This only has an effect
     * when used together with `$cover` and determines how the current frame's
     * corners are rounded. Usually, this doesn't need to be set explicitly if
     * the element is already the first child in the current HTML tree. This is
     * useful when you render another element as the first child instead, one
     * that is not shown or is absolutely positioned.
     */
    $frameStart: "ak-frame-start",
    /**
     * Marks the frame as the last child in the current flow. This should be
     * used together with `$cover` and determines how the current frame's
     * corners are rounded. Usually, this doesn't need to be set explicitly if
     * the element is already the last child in the current HTML tree. This is
     * useful when you render another element as the last child instead, one
     * that is not shown or is absolutely positioned.
     */
    $frameEnd: "ak-frame-end",
    /**
     * Sets the default border radius for the element. Takes a named step from
     * `none` to `4xl`, `full`, or any length or expression such as
     * `var(--my-radius)`. If the frame is nested, this value will be adjusted
     * to stay concentric with the parent unless `$forceRounded` is used or the
     * parent padding plus the child margin is at least 1rem, in which case the
     * concentric effect is not visually meaningful.
     */
    $rounded(value?: FrameRoundedValue | (string & {})) {
      return getFrameRoundedClass(value);
    },
    /**
     * Forces the element to use the `$rounded` value exactly for its radius,
     * regardless of the parent frame context.
     */
    $forceRounded: "ak-frame-force",
    /**
     * Sets the element's frame padding. This affects nested frames' radius
     * calculations unless it's set to `1rem` or more, in which case the
     * concentric effect is no longer visually meaningful.
     */
    $p(value?: "unset" | "none" | (string & {}) | number) {
      if (value == null) return;
      if (value === "unset") return;
      if (value === "none") return "ak-frame-p-0";
      return {
        class: "ak-frame-p-(--frame-padding)",
        style: { "--frame-padding": getSpacingValue(value) },
      };
    },
    /**
     * Sets the element's frame margin. This affects the frame's radius
     * calculations if the current frame is nested, unless the sum of the parent
     * padding and the child margin is at least `1rem`, in which case the
     * concentric effect is no longer visually meaningful.
     */
    $m(value?: "unset" | "none" | (string & {}) | number) {
      if (value == null) return;
      if (value === "unset") return;
      if (value === "none") return "ak-frame-m-0";
      return {
        class: "ak-frame-m-(--frame-margin)",
        style: { "--frame-margin": getSpacingValue(value) },
      };
    },
    /**
     * Specifies how the border is rendered. Setting it to `auto` uses either a
     * border or a ring, depending on the parent layer's lightness.
     */
    $borderType: {
      unset: "",
      auto: "ak-frame-bordering-(--border-width)",
      border: "ak-frame-border-(--border-width)",
      ring: "ak-frame-ring-(--border-width)",
      // Tailwind's inset ring uses a shadow, so share the frame's real border
      // fallback in forced colors, including its geometry and requested width.
      inset:
        "ring-(length:--border-width) ring-inset forced-colors:ak-frame-border-(--border-width)",
      dashed: "ak-frame-border-(--border-width) border-dashed",
      dotted: "ak-frame-border-(--border-width) border-dotted",
    },
    /**
     * Sets the border width. When set to `inherit`, the border uses the parent
     * frame's border or ring width and color. When set to `true`, it defaults
     * to `1px`. When set to `false`, the element draws no border, even when its
     * component sets a `$borderType` or it sits inside a bordered frame.
     */
    $border(value?: "inherit" | boolean | number) {
      if (value == null) return;
      // --border-width inherits. Left unset, a $borderType passed along with
      // false, or one on a descendant, would draw at the width of a bordered
      // ancestor.
      if (value === false) {
        return { style: { "--border-width": "0px" } };
      }
      if (value === "inherit") {
        return "ak-frame-bordering-inherit ak-edge-inherit";
      }
      if (value === true) {
        value = 1;
      }
      return { style: { "--border-width": `${value}px` } };
    },
  },
  defaultVariants: {
    $frame: true,
    $borderType(defaultValue, variants) {
      if (variants.$border === "inherit") {
        return "unset";
      }
      // No border also drops the type a component keeps. At a zero width, its
      // ring would still paint a shadow, which Firefox draws as faint arcs at
      // rounded corners.
      if (variants.$border === false) {
        return "unset";
      }
      // An explicit or component-level $borderType wins; $border alone only
      // implies the adaptive type when nothing else asked for a specific one.
      if (defaultValue !== undefined) {
        return defaultValue;
      }
      if (variants.$border) {
        return "auto";
      }
      return defaultValue;
    },
  },
});

/**
 * The frame geometry plus the edge colours it paints with, and the layer those
 * colours resolve against. This is the frame primitive components normally
 * extend.
 */
export const frame = cv({
  extend: [edge, frameBase],
  defaultVariants: {
    // A frame is geometry, not a surface. It opens a layer only to give its
    // text and edges a color context, and paints nothing until a layer variant
    // or a state moves the color, so whatever sits behind it stays visible: a
    // glider, a gradient, or content scrolling under a sticky bar. A frame that
    // is a surface of its own sets `$layer` to `true` or to a color.
    $layer: "transparent",
    // These two clear variants declared by `edge`. They belong here rather than
    // in `edge` because a computed default only sees the variants its own
    // component declares or extends, so in `edge` they could not read $border.
    $edge(defaultValue, variants) {
      if (variants.$border === "inherit") {
        return "unset";
      }
      return defaultValue;
    },
    $edgeWeight(defaultValue, variants) {
      if (variants.$border === "inherit") {
        return "unset";
      }
      return defaultValue;
    },
  },
});
