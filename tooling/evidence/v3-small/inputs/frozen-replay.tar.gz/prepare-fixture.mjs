import {readFile,writeFile,mkdir} from 'node:fs/promises';
import {gunzipSync} from 'node:zlib';
import {resolve} from 'node:path';
import {createHash} from 'node:crypto';
const directory=new URL('./fixture/',import.meta.url).pathname;
const output=resolve(process.argv[2]??directory+'prepared');
await mkdir(output,{recursive:true});
const inputs=JSON.parse(await readFile(directory+'INPUTS.json','utf8'));
const sql=gunzipSync(await readFile(directory+'prepared.sql.gz'));
if(sql.length!==inputs.preparedSqlBytes||createHash('sha256').update(sql).digest('hex')!==inputs.preparedSqlSha256){throw new Error('Fixture SQL differs.');}
await writeFile(output+'/prepared.sql',sql,{flag:'wx',mode:0o600});
const manifest=JSON.parse(await readFile(directory+'seed-objects.portable.json','utf8'));
for(const object of manifest.objects){if(object.bucket==='quarantine'){object.sourcePath=resolve(directory,object.sourcePath);}}
await writeFile(output+'/seed-objects.json',JSON.stringify(manifest));
console.log(JSON.stringify({fixtureDirectory:output,sqlBytes:sql.length,sqlSha256:inputs.preparedSqlSha256}));
