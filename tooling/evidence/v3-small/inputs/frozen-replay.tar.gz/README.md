# Completed small v3 recovery evidence

This private evidence package records a completed hosted recovery drill. It is not a launch approval. The source has two runs with 3,582 capture identities each. The candidate inherits the original image ownership of the baseline. It is not two fresh upload attempts. The historical WebP corpus is repeated across distinct keys. A synthetic 1% changed fraction exercises review and history storage. It is not an observed production change rate.

The frozen application source is in `controller/implementation`. Its 77 file hashes are in `receipts/frozen-implementation.json`. The exact deployed bundle is `worker/worker.js`. This small proof uses the original v3 archive bound. The separate 35,820-capture proof uses the later progress-limit fix and is not included here.

The archive wrote 357 pages and a 156,567-byte root. Cold backup completed in 525.612 seconds; the next logical daily backup completed in 22.601 seconds and reused its existing groups. Each backup has 7 groups, 7,540 objects, and 232,185,001 bytes. The complete restore took 1,053.196 seconds, from 11:10:38.877 UTC through 11:28:12.073 UTC on 2026-09-22. This includes SQL import, all object copies, independent database-reference checks, exact retained table and private history hashes, sanitation, secret rotation, and a failed rotation propagation check followed by a successful resume. The target stays inactive. All counters and timestamps are in `receipts`.

The initial SQL source is compressed in `fixture/prepared.sql.gz`. It has synthetic fixture sessions and accounts only. No live credentials or signed URLs are included. Its exact size and digest are in `fixture/INPUTS.json`. The object manifest preserves every key, digest, and byte count; only local input paths were relocated. The real immutable image corpus stays in the private read-only Cloudflare bucket named by `wrangler.template.json`.

## Replay on fresh diagnostic resources

Use Node 24.18.0 and Wrangler 4.136.1 with the pinned Ariviso dependency installation. Never reuse a production writable binding or an old restore target. Create four fresh D1 databases and five fresh R2 buckets, then fill the explicit placeholders in `wrangler.template.json`. The only reused binding is the read-only corpus bucket. The wrapper permits reads only for the fixture's fixed original and protected-image mapping; it cannot list, write, or delete that corpus.

```sh
node prepare-fixture.mjs /private/path/to/fresh-fixture
cp wrangler.template.json wrangler.jsonc
# Fill each fresh resource ID and name in wrangler.jsonc.
node /path/to/ariviso/node_modules/wrangler/bin/wrangler.js deploy --config wrangler.jsonc
```

Install three new fixture-only Worker secrets: `DRILL_TOKEN`, `AUTH_SECRET`, and `INGEST_CAPABILITY_SECRET`. Store the diagnostic bearer in `controller/token` with mode 0600. Keep the D1 export-only API credential on the operator machine. It is never bound to the Worker. Copy the completed config to `controller/wrangler.jsonc` with its main path changed to `../worker/worker.js`, and put the new database IDs and names into `controller/resources.json`.

```sh
export APPLICATION_ROOT=/path/to/ariviso
export FIXTURE_DIRECTORY=/private/path/to/fresh-fixture
export EXPORT_TOKEN_FILE=/private/path/to/export-only-token
export DRILL_ENDPOINT=https://fresh-diagnostic-worker.workers.dev
cd controller
node phases.mjs small seed verify-source archive cold warm restore rotate
```

Use a new empty `controller/results` directory for replay. The delivered receipts are separate. The bundled controller resolves the configured paths and does not need its original `/tmp` directory. Do not delete a failed restore checkpoint. Every resume validates its root/SQL identity and the target's SQL import marker, then verifies its existing byte copies. Never copy a diagnostic secret into evidence or publish this private source package as a public client artifact.

The cold and warm daily dates are logical test dates. They prove fresh SQL export plus immutable group reuse; they are not evidence of an unattended 24-hour scheduling interval. The bundle's provisional 512 MiB SQL and 30-second HTTP CPU settings were sufficient for this small fixture. The separate 1.182 GB SQL test establishes that these bounds are too small for the normal 30-day ownership shape. Larger runtime settings, real queue CPU, retained-volume restore throughput, and the complete launch cost model are separate evidence.
