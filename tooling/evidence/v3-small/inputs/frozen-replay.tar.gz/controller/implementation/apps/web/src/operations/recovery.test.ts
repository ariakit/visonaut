import { expect, it } from "vitest";
import { sanitizeRestoredDatabase } from "./recovery.ts";
import { TestDatabase, captured, context } from "./test-fixtures.ts";

it("keeps verified history and drops unfinished run and comparison archives independently of auth tables", async () => {
  using database = new TestDatabase();
  const fixture = context(database);
  await captured(fixture.context, "ready");
  await captured(fixture.context, "building");
  database.connection.exec(`
    INSERT INTO operations_run_archives(run_id,generation,state,source_revision,project_revision,object_key,digest,bytes,page_count,progress_json,created_at,verified_at)
      VALUES('ready','generation','ready',0,0,'history/ready/generation/manifest.json','digest',1,0,'{}',0,0),
      ('building','generation','building',0,0,'history/building/generation/manifest.json',NULL,NULL,0,'{}',0,NULL);
    INSERT INTO operations_comparison_archives(comparison_id,run_id,generation,state,object_key,digest,bytes,page_count,created_at,verified_at)
      VALUES('comparison-ready','ready','supplement','ready','history/ready/supplement/manifest.json','digest',1,0,0,0),
      ('comparison-building','building','supplement','building',NULL,NULL,NULL,0,0,NULL);
    DROP TABLE account;
  `);
  await sanitizeRestoredDatabase(database, fixture.state.time);
  expect(
    database.connection.prepare("SELECT run_id,state FROM operations_run_archives").all(),
  ).toEqual([{ run_id: "ready", state: "ready" }]);
  expect(
    database.connection
      .prepare("SELECT comparison_id,state FROM operations_comparison_archives")
      .all(),
  ).toEqual([{ comparison_id: "comparison-ready", state: "ready" }]);
  expect(
    database.connection.prepare("SELECT id,active,state FROM ariviso_runs ORDER BY id").all(),
  ).toEqual([
    { id: "building", active: 0, state: "failed" },
    { id: "ready", active: 0, state: "failed" },
  ]);
});
