import {createRequire} from 'node:module';
import {readFile,writeFile,realpath} from 'node:fs/promises';
import {spawnSync} from 'node:child_process';
import {createHash} from 'node:crypto';
import {fileURLToPath} from 'node:url';
const directory=fileURLToPath(new URL('./',import.meta.url));
const applicationRoot=process.env.APPLICATION_ROOT;if(!applicationRoot)throw new Error('Set APPLICATION_ROOT to the checked-out Ariviso source with pinned installed dependencies.');
const require=createRequire(await realpath(applicationRoot+'/node_modules/wrangler/package.json'));
const config=JSON.parse(await readFile(directory+'wrangler.jsonc','utf8'));
config.$schema=applicationRoot+'/node_modules/wrangler/config-schema.json';
for(const name of ['service','protocol','security'])config.alias['@ariviso/'+name]=directory+'implementation/packages/'+name+'/src/index.ts';
config.alias.jose=applicationRoot+'/packages/security/node_modules/jose/dist/webapi/index.js';
await writeFile(directory+'wrangler.jsonc',JSON.stringify(config,null,2)+'\n');
const frozen=JSON.parse(await readFile(directory+'results/frozen-implementation.json','utf8'));
for(const [path,digest]of Object.entries(frozen))if(createHash('sha256').update(await readFile(directory+'implementation/'+path)).digest('hex')!==digest)throw new Error('Frozen implementation changed: '+path);
const result=spawnSync(process.execPath,[applicationRoot+'/node_modules/wrangler/bin/wrangler.js','deploy','--dry-run','--config',directory+'wrangler.jsonc','--outdir',directory+'results/bundle'],{stdio:'inherit',env:{...process.env,WRANGLER_LOG_PATH:directory+'results/wrangler-build.log',WRANGLER_SEND_METRICS:'false'}});if(result.status!==0)throw new Error('Worker build failed.');
require('esbuild').buildSync({entryPoints:[directory+'run.mjs'],bundle:true,format:'esm',platform:'node',outfile:directory+'run.bundle.mjs'});
const paths=['worker.mjs','stores.mjs','run.mjs','results/bundle/worker.js','run.bundle.mjs'];const files=[];for(const path of paths){const bytes=await readFile(directory+path);files.push({path,bytes:bytes.length,sha256:createHash('sha256').update(bytes).digest('hex')});}
await writeFile(directory+'results/harness-build.json',JSON.stringify({at:new Date().toISOString(),files},null,2)+'\n');
