/** Private diagnostic prefixes isolate the two workloads within disposable buckets. */
export function prefixedStore(store, prefix, counts, label) {
  const record = method => {counts[`${label}.${method}`]=(counts[`${label}.${method}`]??0)+1;};
  const key = value => {
    if(typeof value!=='string'||!value||value.startsWith('/')||value.includes('..')||/[\u0000-\u001f]/u.test(value))throw new Error('Unsafe diagnostic object key.');
    return prefix+value;
  };
  return {
    async get(value){record('get');return store.get(key(value));},
    async put(value,...args){record('put');return store.put(key(value),...args);},
    async delete(value){record('delete');return store.delete(Array.isArray(value)?value.map(key):key(value));},
    async list(options){record('list');const page=await store.list({...options,prefix:prefix+(options.prefix??'')});return {...page,objects:page.objects.map(object=>({...object,key:object.key.slice(prefix.length)}))};},
    async createMultipartUpload(value,options){record('createMultipartUpload');return measuredUpload(await store.createMultipartUpload(key(value),options),record);},
    resumeMultipartUpload(value,id){return measuredUpload(store.resumeMultipartUpload(key(value),id),record);},
  };
}
function measuredUpload(upload,record){return {key:upload.key,uploadId:upload.uploadId,...Object.fromEntries(['uploadPart','complete','abort'].map(method=>[method,async(...args)=>{record('multipart.'+method);return upload[method](...args);}]))};}
export function corpusKey(value) {
  let match=value.match(/^runs\/e0800000-0000-4000-8000-000000000001\/images\/e0800000-0000-4000-8001-(\d{12})$/u);
  let role='original';
  if(!match){match=value.match(/^baselines\/e0800000-0000-4000-8000-000000000005\/e0800000-0000-4000-8001-(\d{12})\.webp$/u);role='baseline';}
  if(!match)return null;
  const index=Number(match[1]);
  if(!Number.isSafeInteger(index)||index<0||index>=35820)throw new Error('Corpus index exceeds fixture bound.');
  const file=`image-${String(index).padStart(6,'0')}.webp`;
  return role==='original'?`runs/e08-baseline/originals/${file}`:`baselines/e08-baseline-snapshot/${file}`;
}
/** Only get is reachable on the existing E08 corpus binding. All writes stay in OVERLAY. */
export function sourceImages(corpus,overlay,counts){
  return {
    ...overlay,
    async get(key){const mapped=corpusKey(key);if(!mapped)return overlay.get(key);counts['corpus.get']=(counts['corpus.get']??0)+1;return corpus.get(mapped);},
    async put(key,...args){if(corpusKey(key))throw new Error('The corpus is read-only.');return overlay.put(key,...args);},
    async delete(keys){if((Array.isArray(keys)?keys:[keys]).some(corpusKey))throw new Error('The corpus is read-only.');return overlay.delete(keys);},
  };
}
export function measuredDatabase(database,queries){
  const record=(sql,result,start)=>{queries.push({sql:sql.slice(0,120),milliseconds:performance.now()-start,meta:result.meta??null});return result;};
  const wrap=(statement,sql)=>({native:statement,sql,bind(...values){return wrap(statement.bind(...values),sql);},async all(){const start=performance.now();return record(sql,await statement.all(),start);},async first(){return (await this.all()).results?.[0]??null;},async run(){const start=performance.now();return record(sql,await statement.run(),start);}});
  return {prepare(sql){return wrap(database.prepare(sql),sql);},async batch(statements){const start=performance.now();const results=await database.batch(statements.map(statement=>statement.native));return results.map((result,index)=>record(statements[index].sql,result,start));}};
}
