import {spawn} from 'node:child_process';
import {appendFile} from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
const directory=fileURLToPath(new URL('./',import.meta.url));
const scenario=process.argv[2];const phases=process.argv.slice(3);
if(!['small','large'].includes(scenario)||!phases.length)throw new Error('Provide scenario and explicit ordered phases.');
for(const phase of phases){
 const startedAt=Date.now();console.log(JSON.stringify({scenario,phase,startedAt}));
 const child=spawn(process.execPath,[directory+'run.bundle.mjs',scenario,phase],{cwd:directory,env:process.env,stdio:'inherit'});
 const code=await new Promise((resolve,reject)=>{child.on('error',reject);child.on('close',resolve);});
 await appendFile(directory+'results/'+scenario+'/phase-timings.jsonl',JSON.stringify({scenario,phase,startedAt,completedAt:Date.now(),exitCode:code})+'\n');
 if(code!==0)throw new Error('Stopped at failed phase '+phase+'. Inspect saved evidence before resume.');
}
