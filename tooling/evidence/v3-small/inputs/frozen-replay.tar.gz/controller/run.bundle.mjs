// tooling/v3/run.mjs
import { createHash, randomUUID, randomBytes } from "node:crypto";
import { createReadStream, createWriteStream } from "node:fs";
import { readFile, writeFile, appendFile, mkdir, rename } from "node:fs/promises";
import { Readable } from "node:stream";
import { pipeline } from "node:stream/promises";
import { spawn } from "node:child_process";

// tooling/v3/implementation/apps/web/src/operations/cloudflare-export.ts
function object(value) {
  if (!value || typeof value !== "object" || Array.isArray(value))
    throw new Error("Cloudflare returned an invalid export response.");
  return value;
}
function createCloudflareDatabaseExporter(configuration) {
  if (!/^[a-f0-9]{32}$/iu.test(configuration.accountId) || !/^[a-f0-9-]{36}$/iu.test(configuration.databaseId) || !configuration.apiToken || !Number.isSafeInteger(configuration.maximumMilliseconds) || configuration.maximumMilliseconds < 1)
    throw new Error("Invalid database export configuration.");
  const request2 = configuration.request ?? fetch;
  return {
    async export() {
      const signal = AbortSignal.timeout(configuration.maximumMilliseconds);
      const endpoint2 = `https://api.cloudflare.com/client/v4/accounts/${configuration.accountId}/d1/database/${configuration.databaseId}/export`;
      let bookmark;
      while (true) {
        const response = await request2(endpoint2, {
          method: "POST",
          headers: {
            authorization: `Bearer ${configuration.apiToken}`,
            "content-type": "application/json"
          },
          body: JSON.stringify({ output_format: "polling", current_bookmark: bookmark }),
          redirect: "manual",
          signal
        });
        if (!response.ok) {
          await response.body?.cancel();
          throw new Error("Cloudflare database export failed.");
        }
        const envelope = object(await response.json());
        const result = object(envelope.result);
        if (envelope.success !== true || result.status === "error")
          throw new Error("Cloudflare database export failed.");
        if (result.status === "complete") {
          const details = object(result.result);
          if (typeof details.signed_url !== "string")
            throw new Error("Cloudflare export URL is missing.");
          const url = new URL(details.signed_url);
          if (url.protocol !== "https:" || url.username || url.password)
            throw new Error("Cloudflare export URL is invalid.");
          const download = await request2(url, { redirect: "manual", signal });
          if (!download.ok || !download.body) {
            await download.body?.cancel();
            throw new Error("Cloudflare database download failed.");
          }
          const length = download.headers.get("content-length");
          const encoding = download.headers.get("content-encoding");
          const bytes = length && /^\d+$/.test(length) && (!encoding || encoding === "identity") ? Number(length) : void 0;
          return { body: download.body, bytes: Number.isSafeInteger(bytes) ? bytes : void 0 };
        }
        if (typeof result.at_bookmark !== "string" || !result.at_bookmark)
          throw new Error("Cloudflare export bookmark is missing.");
        bookmark = result.at_bookmark;
        await new Promise((resolve, reject) => {
          signal.throwIfAborted();
          const timer = setTimeout(done, 1e3);
          function done() {
            signal.removeEventListener("abort", abort);
            resolve();
          }
          function abort() {
            clearTimeout(timer);
            reject(new Error("Database export timed out."));
          }
          signal.addEventListener("abort", abort, { once: true });
        });
      }
    }
  };
}

// tooling/v3/implementation/apps/web/src/operations/common.ts
function safeKey(key2) {
  if (!key2 || key2.startsWith("/") || key2.includes("\\") || key2.split("/").some((part) => !part || part === "." || part === "..") || new TextEncoder().encode(key2).length > 900) {
    throw new Error("Object key is outside the supported private namespace.");
  }
  return key2;
}

// tooling/v3/implementation/apps/web/src/operations/backup-format.ts
var maximumBackupMetadataBytes = 4 * 1024 * 1024;
var maximumBackupPageObjects = 1e3;
function backupGroupPrefix(id) {
  if (!/^[a-f0-9]{32}$/u.test(id)) throw new Error("Invalid backup group identity.");
  return `backup-groups/${id}/`;
}
function record(value) {
  if (!value || typeof value !== "object" || Array.isArray(value))
    throw new Error("Invalid backup metadata record.");
  return Object.fromEntries(Object.entries(value));
}
function integer(value, minimum = 0) {
  if (typeof value !== "number" || !Number.isSafeInteger(value) || value < minimum)
    throw new Error("Invalid backup metadata count.");
  return value;
}
function digest(value) {
  if (typeof value !== "string" || !/^[a-f0-9]{64}$/u.test(value))
    throw new Error("Invalid backup metadata digest.");
  return value;
}
function key(value) {
  if (typeof value !== "string") throw new Error("Invalid backup metadata key.");
  safeKey(value);
  return value;
}
function parseBackupPage(value) {
  const page = record(value);
  const bytes = integer(page.bytes, 1);
  if (bytes > maximumBackupMetadataBytes) throw new Error("Backup page exceeds its bound.");
  return { key: key(page.key), digest: digest(page.digest), bytes, objects: integer(page.objects) };
}
function parseGroupReference(value) {
  const group = record(value);
  if (typeof group.id !== "string") throw new Error("Invalid backup group identity.");
  const prefix = backupGroupPrefix(group.id);
  const page = parseBackupPage(group);
  if (page.key !== `${prefix}manifest-${page.digest}.json`)
    throw new Error("Invalid backup group namespace.");
  return { ...page, id: group.id, objectBytes: integer(group.objectBytes) };
}
function parseGroupManifest(value, reference) {
  const manifest = record(value);
  if (manifest.version !== 1 || manifest.id !== reference.id || !Array.isArray(manifest.pages))
    throw new Error("Invalid backup group manifest.");
  const prefix = backupGroupPrefix(reference.id);
  const pages = manifest.pages.map((entry, ordinal) => {
    const page = parseBackupPage(entry);
    if (page.key !== `${prefix}pages/${String(ordinal).padStart(6, "0")}-${page.digest}.json` || page.objects > maximumBackupPageObjects)
      throw new Error("Invalid backup group page namespace.");
    return page;
  });
  const objects = integer(manifest.objects);
  const bytes = integer(manifest.bytes);
  if (objects !== reference.objects || bytes !== reference.objectBytes || pages.reduce((sum, page) => sum + page.objects, 0) !== objects)
    throw new Error("Backup group counts differ.");
  return { version: 1, id: reference.id, pages, objects, bytes };
}
function parseGroupedBackup(value, id) {
  const manifest = record(value);
  const database = record(manifest.database);
  if (manifest.version !== 3 || manifest.id !== id || !Array.isArray(manifest.pages))
    throw new Error("Unsupported grouped backup manifest.");
  const prefix = `backups/${id}/`;
  const databaseKey = key(database.key);
  if (!databaseKey.startsWith(`${prefix}database-`) || !databaseKey.endsWith(".sql"))
    throw new Error("Invalid backup database namespace.");
  const pages = manifest.pages.map((entry, ordinal) => {
    const page = parseBackupPage(entry);
    if (page.key !== `${prefix}groups/${String(ordinal).padStart(6, "0")}-${page.digest}.json` || page.objects > maximumBackupPageObjects)
      throw new Error("Invalid backup membership namespace.");
    return page;
  });
  const groups = integer(manifest.groups);
  if (pages.reduce((sum, page) => sum + page.objects, 0) !== groups)
    throw new Error("Backup membership count differs.");
  return {
    version: 3,
    id,
    createdAt: integer(manifest.createdAt),
    completedAt: integer(manifest.completedAt),
    database: {
      key: databaseKey,
      digest: digest(database.digest),
      bytes: integer(database.bytes, 1)
    },
    pages,
    groups,
    objects: integer(manifest.objects),
    bytes: integer(manifest.bytes)
  };
}

// tooling/v3/run.mjs
var directory = new URL("./", import.meta.url).pathname;
var scenario = process.argv[2];
var phase = process.argv[3];
if (!["small", "large"].includes(scenario)) throw new Error("Use small or large.");
var resource = JSON.parse(await readFile(directory + "resources.json", "utf8"));
var fixtureDirectory = process.env.FIXTURE_DIRECTORY ?? "/tmp/ariviso-v3-fixture-" + (scenario === "small" ? 3582 : 35820);
var applicationRoot = process.env.APPLICATION_ROOT ?? "/Users/diegohaz/Developer/ariviso";
var fixture = JSON.parse(await readFile(fixtureDirectory + "/seed-objects.json", "utf8"));
var output = directory + "results/" + scenario;
await mkdir(output, { recursive: true });
var endpoint = process.env.DRILL_ENDPOINT ?? "https://ariviso-v3-drill-20260922.ariakit.workers.dev";
var token = (await readFile(directory + "token", "utf8")).trim();
var wait = (milliseconds) => new Promise((resolve) => setTimeout(resolve, milliseconds));
var sourceDatabase = resource.databases.find((row) => row.binding === (scenario === "small" ? "SOURCE_SMALL" : "SOURCE_LARGE"));
var targetDatabase = resource.databases.find((row) => row.binding === (scenario === "small" ? "TARGET_SMALL" : "TARGET_LARGE"));
async function save(name, value) {
  await writeFile(output + "/" + name + ".tmp", JSON.stringify(value, null, 2) + "\n");
  await rename(output + "/" + name + ".tmp", output + "/" + name + ".json");
}
async function log(value) {
  const record2 = { at: (/* @__PURE__ */ new Date()).toISOString(), scenario, phase, ...value };
  await appendFile(output + "/events.jsonl", JSON.stringify(record2) + "\n");
  console.log(JSON.stringify({ at: record2.at, scenario, phase, step: value.step, summary: value.summary, milliseconds: value.milliseconds, error: value.error }));
}
async function request(path, options = {}) {
  const join = path.includes("?") ? "&" : "?";
  const response = await fetch(endpoint + path + join + "scenario=" + scenario, { ...options, headers: { authorization: `Bearer ${token}`, ...options.headers }, redirect: "error", signal: AbortSignal.timeout(6e5), duplex: "half" });
  if (!response.ok) {
    const detail = await response.text();
    let parsed;
    try {
      parsed = JSON.parse(detail);
    } catch {
      parsed = { body: detail.slice(0, 1e4) };
    }
    await log({ step: "request-failure", path, status: response.status, ...parsed });
    throw new Error(path + ": HTTP" + response.status + ": " + detail.slice(0, 2e3));
  }
  return response;
}
async function json(path, value) {
  const response = await request(path, value === void 0 ? {} : { method: "POST", body: JSON.stringify(value), headers: { "content-type": "application/json" } });
  return { ...await response.json(), placement: response.headers.get("cf-placement") };
}
async function digestFile(path) {
  const hash = createHash("sha256");
  let bytes = 0;
  for await (const part of createReadStream(path)) {
    hash.update(part);
    bytes += part.length;
  }
  return { digest: hash.digest("hex"), bytes };
}
async function command(arguments_, file) {
  const child = spawn(process.execPath, [applicationRoot + "/node_modules/wrangler/bin/wrangler.js", ...arguments_, "--config", directory + "wrangler.jsonc"], { cwd: directory, env: { ...process.env, WRANGLER_LOG_PATH: output + "/wrangler.log", WRANGLER_SEND_METRICS: "false" }, stdio: ["ignore", "pipe", "pipe"] });
  const destination = createWriteStream(output + "/" + file);
  child.stdout.pipe(destination, { end: false });
  child.stderr.pipe(destination, { end: false });
  await new Promise((resolve, reject) => {
    child.on("error", reject);
    child.on("close", (code) => {
      destination.end();
      code ? reject(new Error("Wrangler failed; see " + file)) : resolve();
    });
  });
}
async function exportDatabase(path) {
  const exporter = createCloudflareDatabaseExporter({ accountId: resource.accountId, databaseId: sourceDatabase.database_id, apiToken: (await readFile(process.env.EXPORT_TOKEN_FILE ?? "/tmp/ariviso-cloudflare-backup-token", "utf8")).trim(), maximumMilliseconds: 24e4 });
  const startedAt = Date.now();
  await pipeline(Readable.fromWeb((await exporter.export()).body), createWriteStream(path, { mode: 384 }));
  return { startedAt, completedAt: Date.now(), ...await digestFile(path) };
}
async function fingerprint(target = false) {
  const results = {};
  for (const table of ["ariviso_decisions", "ariviso_decision_replacements", "ariviso_identity_history", "ariviso_reservations", "ariviso_lineage_edges", "ariviso_snapshots", "ariviso_images", "ariviso_snapshot_images", "ariviso_capture_profiles", "operations_run_archives", "operations_comparison_archives"]) {
    results[table] = await json("/fingerprint?table=" + table + "&target=" + target);
  }
  return results;
}
async function stage(path, day, attempt, expected) {
  const { uploadId } = await json("/backup/stage-start", { day, attempt });
  const parts = [];
  try {
    for (let offset = 0; offset < expected.bytes; offset += 8388608) {
      const end = Math.min(expected.bytes, offset + 8388608) - 1;
      const response = await request("/backup/stage-part?day=" + day + "&attempt=" + attempt + "&uploadId=" + encodeURIComponent(uploadId) + "&part=" + (parts.length + 1), { method: "PUT", body: createReadStream(path, { start: offset, end }), headers: { "content-type": "application/sql", "content-length": String(end - offset + 1) } });
      const result = await response.json();
      parts.push({ partNumber: result.partNumber, etag: result.etag });
    }
    const verified = await json("/backup/stage-complete", { day, attempt, uploadId, parts });
    if (verified.digest !== expected.digest || verified.bytes !== expected.bytes) throw new Error("Staged SQL differs.");
    return { day, attempt, stagedAt: Date.now(), parts: parts.length, ...verified };
  } catch (error) {
    await json("/backup/stage-abort", { day, attempt, uploadId }).catch(() => {
    });
    throw error;
  }
}
async function checkedJson(reference) {
  if (reference.bytes > maximumBackupMetadataBytes) throw new Error("Backup metadata exceeds bound.");
  const response = await request("/backup/object?key=" + encodeURIComponent(reference.key));
  const bytes = new Uint8Array(await response.arrayBuffer());
  if (bytes.length !== reference.bytes || createHash("sha256").update(bytes).digest("hex") !== reference.digest) throw new Error("Backup metadata differs.");
  return JSON.parse(new TextDecoder().decode(bytes));
}
if (phase === "seed" || phase === "seed-metadata") {
  if (phase === "seed") await command(["d1", "execute", sourceDatabase.database_name, "--remote", "--file", fixtureDirectory + "/prepared.sql", "--yes"], "source-import.log");
  else {
    const source = await json("/source/summary");
    if (source.rows.ariviso_captures !== fixture.fixture.capturesPerRun * 2 || source.archive.length) throw new Error("Pre-imported fixture count/state differs.");
  }
  for (const object2 of fixture.objects.filter((row) => row.bucket === "quarantine")) {
    const bytes = await readFile(object2.sourcePath);
    const response = await request("/seed/object?store=private&key=" + encodeURIComponent(object2.key), { method: "PUT", body: bytes, headers: { "content-type": object2.contentType } });
    const saved = await response.json();
    if (saved.digest !== object2.digest || saved.bytes !== object2.bytes) throw new Error("Seed metadata differs.");
  }
  const summary = await json("/source/summary");
  await save("seed-summary", summary);
  await save("before-archive-fingerprints", await fingerprint());
  await log({ step: "seed-complete", summary });
} else if (phase === "verify-source") {
  let objects = 0, bytes = 0;
  for (let offset = 0; offset < fixture.objects.length; offset += 1e3) {
    const page = fixture.objects.slice(offset, offset + 1e3).map(({ bucket, key: key2, digest: digest2, bytes: bytes2 }) => ({ bucket, key: key2, digest: digest2, bytes: bytes2 }));
    const result = await json("/source/verify", { objects: page });
    objects += result.objects;
    bytes += result.bytes;
    await log({ step: offset / 1e3, summary: { objects, bytes }, ...result });
  }
  await save("source-verified", { objects, bytes, completedAt: Date.now() });
} else if (phase === "archive") {
  const startedAt = Date.now();
  const before = await json("/source/summary");
  await save("before-archive-summary", before);
  await save("before-archive-sql", await exportDatabase(output + "/before-archive.sql"));
  for (let step = 0; step < 5e3; step++) {
    const result = await json("/archive/step", {});
    await log({ step, ...result, summary: { report: result.result, after: result.after } });
    if (result.result.attention.length) throw new Error("Archive needs attention.");
    if (result.result.completed.includes(fixture.fixture.reviewRunId)) {
      const after = await json("/source/summary");
      await save("archive-summary", { startedAt, completedAt: Date.now(), steps: step + 1, before, after });
      await save("after-archive-fingerprints", await fingerprint());
      await save("archive-root", await json("/history/root"));
      await save("after-archive-sql", await exportDatabase(output + "/after-archive.sql"));
      break;
    }
    if (step === 4999) throw new Error("Archive exceeded controller step cap.");
  }
} else if (phase === "cold" || phase === "warm") {
  const offset = phase === "warm" ? 864e5 : 0;
  const day = new Date(Date.now() + offset).toISOString().slice(0, 10);
  const state = await json("/backup/state");
  const previous = state.rows.find((row) => row.id === day);
  let progress;
  try {
    progress = JSON.parse(await readFile(output + "/" + phase + "-checkpoint.json", "utf8"));
  } catch {
    progress = { day, startedAt: Date.now(), steps: 0 };
    await save(phase + "-checkpoint", progress);
  }
  if (progress.day !== day) throw new Error("Backup checkpoint belongs to a different day.");
  if (!previous || previous.state === "exporting") {
    const attempt = randomUUID();
    const pending = json("/backup/step", { offset, attempt });
    let settled = false;
    pending.then(() => settled = true, () => settled = true);
    let pinned = false;
    for (let i = 0; i < 100 && !settled; i++) {
      const check = await json("/backup/export-request?attempt=" + attempt);
      if (check.request) {
        if (check.request.day !== day || check.request.attempt !== attempt) throw new Error("Export request identity differs.");
        pinned = true;
        break;
      }
      await wait(200);
    }
    if (!pinned) {
      await pending;
      throw new Error("Backup did not acquire this export lease; resume after its prior lease ends.");
    }
    const path = output + "/" + phase + "-source.sql";
    const exported = { day, attempt, ...await exportDatabase(path) };
    await save(phase + "-source-snapshot", exported);
    await save(phase + "-staging", await stage(path, day, attempt, exported));
    const exportedStep = await pending;
    await log({ step: "export", ...exportedStep });
    if (exportedStep.result.attention.length || exportedStep.row?.state !== "copying") throw new Error("Pinned export did not commit to copying; inspect and resume instead of starting an unstaged attempt.");
  }
  for (let step = 0; step < 1e4; step++) {
    const result = await json("/backup/step", { offset, attempt: randomUUID() });
    progress.steps++;
    await save(phase + "-checkpoint", progress);
    await log({ step: progress.steps, ...result, summary: { state: result.row?.state, objects: result.row?.object_count, report: result.result } });
    if (result.result.attention.length) throw new Error("Backup needs attention.");
    if (result.row?.state === "exporting") throw new Error("Backup unexpectedly returned to exporting; resume through the staged export handshake.");
    if (result.row?.state === "complete") {
      const manifest = parseGroupedBackup(await (await request("/backup/object?key=" + encodeURIComponent(`backups/${day}/complete.json`))).json(), day);
      const exported = JSON.parse(await readFile(output + "/" + phase + "-source-snapshot.json", "utf8"));
      if (manifest.database.digest !== exported.digest || manifest.database.bytes !== exported.bytes) throw new Error("Completed backup differs from the recorded pinned SQL export.");
      await save(phase + "-backup-manifest", manifest);
      await save(phase + "-summary", { ...progress, completedAt: Date.now(), manifest });
      break;
    }
    if (step === 9999) throw new Error("Backup exceeded controller step cap.");
    await wait(1e3);
  }
} else if (phase === "restore") {
  const raw = await readFile(output + "/warm-backup-manifest.json", "utf8");
  const value = JSON.parse(raw);
  const manifest = parseGroupedBackup(value, value.id);
  const identity = { backupId: manifest.id, rootDigest: createHash("sha256").update(JSON.stringify(manifest)).digest("hex"), databaseDigest: manifest.database.digest };
  let checkpoint;
  try {
    checkpoint = JSON.parse(await readFile(output + "/restore-checkpoint.json", "utf8"));
  } catch {
    checkpoint = { ...identity, startedAt: Date.now(), imported: false, pages: {} };
    await save("restore-checkpoint", checkpoint);
  }
  for (const [key2, value2] of Object.entries(identity)) if (checkpoint[key2] !== value2) throw new Error("Restore checkpoint refers to another snapshot: " + key2);
  const current = await json("/restore/import-state");
  if (current.marker) {
    if (current.marker.digest !== manifest.database.digest) throw new Error("A different snapshot is already imported.");
    checkpoint.imported = true;
    checkpoint.importedAt ??= Date.now();
    await save("restore-checkpoint", checkpoint);
  } else if (checkpoint.imported) throw new Error("Previously imported restore marker is missing.");
  if (!checkpoint.imported) {
    const empty = await json("/restore/empty");
    if (!empty.empty) throw new Error("Restore target is not empty; inspect import state before resume.");
    const sql = output + "/restored.sql";
    await pipeline(Readable.fromWeb((await request("/backup/object?key=" + encodeURIComponent(manifest.database.key))).body), createWriteStream(sql, { mode: 384 }));
    const verified = await digestFile(sql);
    if (verified.digest !== manifest.database.digest || verified.bytes !== manifest.database.bytes) throw new Error("Backup SQL differs.");
    await appendFile(sql, `
CREATE TABLE diagnostic_restore_marker(digest TEXT NOT NULL); INSERT INTO diagnostic_restore_marker VALUES('${verified.digest}');
`);
    await command(["d1", "execute", targetDatabase.database_name, "--remote", "--file", sql, "--yes"], "restore-import.log");
    checkpoint.imported = true;
    checkpoint.importedAt = Date.now();
    await save("restore-checkpoint", checkpoint);
  }
  let count = 0, bytes = 0, groupsCount = 0;
  const seen = /* @__PURE__ */ new Set();
  for (const page of manifest.pages) {
    const groups = await checkedJson(page);
    if (!Array.isArray(groups) || groups.length !== page.objects) throw new Error("Membership count differs.");
    for (const value2 of groups) {
      const group = parseGroupReference(value2);
      if (seen.has(group.id)) throw new Error("Duplicate backup group membership.");
      seen.add(group.id);
      const inventory = parseGroupManifest(await checkedJson(group), group);
      let groupBytes = 0;
      for (let i = 0; i < inventory.pages.length; i++) {
        const reference = inventory.pages[i];
        const key2 = group.id + "/" + i;
        let result = checkpoint.pages[key2];
        if (result) {
          if (result.digest !== reference.digest || result.objects !== reference.objects) throw new Error("Restore page receipt differs.");
        } else {
          result = await json("/restore/page", { group, page: i });
          if (result.objects !== reference.objects) throw new Error("Restored page object count differs.");
          checkpoint.pages[key2] = { digest: reference.digest, objects: result.objects, bytes: result.bytes };
          await save("restore-checkpoint", checkpoint);
          await log({ step: key2, ...result, summary: { objects: count + result.objects, bytes: bytes + result.bytes } });
        }
        count += result.objects;
        bytes += result.bytes;
        groupBytes += result.bytes;
      }
      if (groupBytes !== inventory.bytes) throw new Error("Restored group bytes differ.");
      groupsCount++;
    }
  }
  if (count !== manifest.objects || bytes !== manifest.bytes || groupsCount !== manifest.groups) throw new Error("Restored aggregate differs.");
  const before = await fingerprint(false), after = await fingerprint(true);
  for (const table of Object.keys(before)) if (before[table].digest !== after[table].digest || before[table].count !== after[table].count) throw new Error("Restored table differs: " + table);
  await save("restored-fingerprints", { before, after });
  const root = (await json("/history/root")).archive;
  const sections = [...new Set(root.manifest.pages.map((page) => page.section))];
  const history = {};
  for (const section of sections) {
    const left = await json("/history/section?section=" + section);
    const right = await json("/history/section?section=" + section + "&target=true");
    if (left.digest !== right.digest || left.rows !== right.rows) throw new Error("Restored history differs: " + section);
    history[section] = { source: left, target: right };
  }
  await save("restored-history-equivalence", history);
  for (const kind of ["originals", "snapshots", "archives"]) {
    let after2 = "";
    do {
      const result = await json("/restore/references", { kind, after: after2 });
      await log({ step: "verify-" + kind, ...result });
      if (result.done) break;
      after2 = result.after;
    } while (true);
  }
  await json("/restore/sanitize", {});
  const report = await json("/restore/report");
  if (report.foreignKeys.length || report.sessions || report.tokens || report.active) throw new Error("Restore sanitation failed.");
  checkpoint.completedAt = Date.now();
  await save("restore-checkpoint", checkpoint);
  await save("restore-summary", { checkpoint, report, objects: count, bytes, groups: groupsCount, requiresSecretRotation: true });
} else if (phase === "rotate") {
  let rotation;
  try {
    rotation = JSON.parse(await readFile(output + "/rotation-secret-checkpoint.json", "utf8"));
  } catch (error) {
    if (error.code !== "ENOENT") throw error;
    rotation = { before: await json("/rotation/proof"), oldCapability: (await json("/rotation/issue")).token, oldToken: token, secrets: { DRILL_TOKEN: randomBytes(32).toString("hex"), AUTH_SECRET: randomBytes(32).toString("hex"), INGEST_CAPABILITY_SECRET: randomBytes(32).toString("hex") } };
    await writeFile(output + "/rotation-secret-checkpoint.json", JSON.stringify(rotation), { mode: 384 });
  }
  const candidate = await fetch(endpoint + "/health?scenario=" + scenario, { headers: { authorization: `Bearer ${rotation.secrets.DRILL_TOKEN}` }, redirect: "error" });
  if (candidate.status !== 200) {
    if (candidate.status !== 401) throw new Error("Unknown active diagnostic secret.");
    await writeFile(output + "/rotated-secrets.json", JSON.stringify(rotation.secrets), { mode: 384 });
    await command(["secret", "bulk", output + "/rotated-secrets.json"], "rotation.log");
  }
  token = rotation.secrets.DRILL_TOKEN;
  await writeFile(directory + "token", token, { mode: 384 });
  let propagated = false;
  for (let attempt = 0; attempt < 60; attempt++) {
    const fresh2 = await fetch(endpoint + "/health?scenario=" + scenario, { headers: { authorization: `Bearer ${token}` }, redirect: "error" });
    const stale = await fetch(endpoint + "/health?scenario=" + scenario, { headers: { authorization: `Bearer ${rotation.oldToken}` }, redirect: "error" });
    await fresh2.body?.cancel();
    await stale.body?.cancel();
    if (fresh2.status === 200 && stale.status === 401) {
      propagated = true;
      break;
    }
    await wait(1e3);
  }
  if (!propagated) throw new Error("Fixture secret deployment has not propagated; resume with the same rotation checkpoint.");
  const after = await json("/rotation/proof");
  const oldAccess = await fetch(endpoint + "/health?scenario=" + scenario, { headers: { authorization: `Bearer ${rotation.oldToken}` }, redirect: "error" });
  const oldIngest = await fetch(endpoint + "/rotation/verify?scenario=" + scenario, { method: "POST", headers: { authorization: `Bearer ${token}`, "content-type": "application/json" }, body: JSON.stringify({ token: rotation.oldCapability }), redirect: "error" });
  const fresh = (await json("/rotation/issue")).token;
  const freshValid = await json("/rotation/verify", { token: fresh });
  const oldUnexpired = JSON.parse(Buffer.from(rotation.oldCapability.split(".")[1], "base64url")).exp * 1e3 > Date.now();
  if (!oldUnexpired || oldAccess.status !== 401 || oldIngest.status !== 401 || !freshValid.valid || after.authSecretDigest === rotation.before.authSecretDigest || after.ingestSecretDigest === rotation.before.ingestSecretDigest) throw new Error("Secret rotation proof failed.");
  const summary = JSON.parse(await readFile(output + "/restore-summary.json", "utf8"));
  const result = { before: rotation.before, after, oldUnexpired, oldAccess: oldAccess.status, oldIngest: oldIngest.status, freshValid: true, rotatedAt: Date.now() };
  await save("rotation-result", result);
  await save("restore-summary", { ...summary, requiresSecretRotation: false, readyAt: result.rotatedAt, recoveryMilliseconds: result.rotatedAt - summary.checkpoint.startedAt, activated: false });
  await log({ step: "rotation-complete", summary: result });
} else if (phase === "benchmark") {
  const saved = JSON.parse(await readFile(output + "/warm-backup-manifest.json", "utf8"));
  const manifest = parseGroupedBackup(saved, saved.id);
  const tasks = [];
  const seen = /* @__PURE__ */ new Set();
  for (const page of manifest.pages) {
    const values = await checkedJson(page);
    if (values.length !== page.objects) throw new Error("Membership count differs.");
    for (const value of values) {
      const group = parseGroupReference(value);
      if (seen.has(group.id)) throw new Error("Duplicate group.");
      seen.add(group.id);
      const inventory = parseGroupManifest(await checkedJson(group), group);
      for (let page2 = 0; page2 < inventory.pages.length; page2++) if (inventory.pages[page2].objects === 1e3) tasks.push({ group, page: page2 });
    }
  }
  if (tasks.length < 64) throw new Error("Benchmark needs64fullactualinventorypages.");
  for (const concurrency of [8, 16, 32, 64]) {
    const id = randomUUID();
    const selected = tasks.slice(0, 64);
    const startedAt = Date.now();
    let cursor = 0;
    const receipts = [];
    const errors = [];
    await log({ step: "benchmark-start", summary: { id, concurrency, pages: selected.length, objects: 64e3 } });
    await Promise.all(Array.from({ length: concurrency }, async () => {
      while (cursor < selected.length) {
        const index = cursor++;
        try {
          const result = await json("/restore/page", { ...selected[index], benchmark: id });
          receipts[index] = result;
          await log({ step: `benchmark-${concurrency}-${index}`, ...result });
        } catch (error) {
          errors.push({ index, error: String(error) });
        }
      }
    }));
    const completedAt = Date.now();
    const objects = receipts.reduce((sum, result) => sum + (result?.objects ?? 0), 0);
    const bytes = receipts.reduce((sum, result) => sum + (result?.bytes ?? 0), 0);
    await save("benchmark-" + concurrency, { id, concurrency, startedAt, completedAt, objects, bytes, errors, receipts, objectsPerSecond: objects / ((completedAt - startedAt) / 1e3) });
    if (errors.length) throw new Error("Restore saturation failed; preserve diagnosticprefixforinspection.");
    for (const store of ["images", "private"]) {
      for (let i = 0; i < 1e4; i++) {
        const result = await json("/benchmark/cleanup", { id, store });
        if (!result.more) break;
        if (i === 9999) throw new Error("Benchmark cleanup exceeded bound.");
      }
    }
  }
} else throw new Error("Unknown phase.");
