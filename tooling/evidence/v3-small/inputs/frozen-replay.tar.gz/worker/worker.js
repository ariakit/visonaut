var __defProp = Object.defineProperty;
var __name = (target, value) => __defProp(target, "name", { value, configurable: true });

// worker.mjs
import { createHash as createHash7 } from "node:crypto";

// ../../../../../Users/diegohaz/Developer/ariviso/node_modules/.pnpm/jose@6.2.12/node_modules/jose/dist/webapi/lib/buffer_utils.js
var encoder = new TextEncoder();
var decoder = new TextDecoder();
var strictDecoder = new TextDecoder("utf-8", { fatal: true });
var MAX_INT32 = 2 ** 32;
function concat(...buffers) {
  const size = buffers.reduce((acc, { length }) => acc + length, 0), buf = new Uint8Array(size);
  let i = 0;
  for (const buffer of buffers)
    buf.set(buffer, i), i += buffer.length;
  return buf;
}
__name(concat, "concat");
var NON_ASCII = /[^\x00-\x7f]/;
function encode(string2) {
  if (typeof string2 == "string" && string2.length >= 128) {
    if (NON_ASCII.test(string2))
      throw new TypeError("non-ASCII string encountered in encode()");
    return encoder.encode(string2);
  }
  const bytes = new Uint8Array(string2.length);
  for (let i = 0; i < string2.length; i++) {
    const code = string2.charCodeAt(i);
    if (code > 127)
      throw new TypeError("non-ASCII string encountered in encode()");
    bytes[i] = code;
  }
  return bytes;
}
__name(encode, "encode");
function encodeBase64(input, url = false) {
  if (Uint8Array.prototype.toBase64)
    return input.toBase64({ alphabet: url ? "base64url" : "base64", omitPadding: url });
  const CHUNK_SIZE = 32768, arr = [];
  for (let i = 0; i < input.length; i += CHUNK_SIZE)
    arr.push(String.fromCharCode.apply(null, input.subarray(i, i + CHUNK_SIZE)));
  const encoded = btoa(arr.join(""));
  return url ? encoded.replace(/=/g, "").replace(/\+/g, "-").replace(/\//g, "_") : encoded;
}
__name(encodeBase64, "encodeBase64");
function decodeBase64(encoded, url = false) {
  if (Uint8Array.fromBase64)
    return Uint8Array.fromBase64(encoded, { alphabet: url ? "base64url" : "base64" });
  if (url) {
    if (encoded.includes("+") || encoded.includes("/"))
      throw new TypeError("Invalid base64url");
    encoded = encoded.replace(/-/g, "+").replace(/_/g, "/");
  }
  const binary = atob(encoded), bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++)
    bytes[i] = binary.charCodeAt(i);
  return bytes;
}
__name(decodeBase64, "decodeBase64");

// ../../../../../Users/diegohaz/Developer/ariviso/node_modules/.pnpm/jose@6.2.12/node_modules/jose/dist/webapi/util/errors.js
var JOSEError = class extends Error {
  static {
    __name(this, "JOSEError");
  }
  static code = "ERR_JOSE_GENERIC";
  code = "ERR_JOSE_GENERIC";
  constructor(message2, options) {
    super(message2, options), this.name = this.constructor.name, Error.captureStackTrace?.(this, this.constructor);
  }
};
var JWTClaimValidationFailed = class extends JOSEError {
  static {
    __name(this, "JWTClaimValidationFailed");
  }
  static code = "ERR_JWT_CLAIM_VALIDATION_FAILED";
  code = "ERR_JWT_CLAIM_VALIDATION_FAILED";
  claim;
  reason;
  payload;
  constructor(message2, payload, claim2 = "unspecified", reason = "unspecified") {
    super(message2, { cause: { claim: claim2, reason, payload } }), this.claim = claim2, this.reason = reason, this.payload = payload;
  }
};
var JWTExpired = class extends JOSEError {
  static {
    __name(this, "JWTExpired");
  }
  static code = "ERR_JWT_EXPIRED";
  code = "ERR_JWT_EXPIRED";
  claim;
  reason;
  payload;
  constructor(message2, payload, claim2 = "unspecified", reason = "unspecified") {
    super(message2, { cause: { claim: claim2, reason, payload } }), this.claim = claim2, this.reason = reason, this.payload = payload;
  }
};
var JOSEAlgNotAllowed = class extends JOSEError {
  static {
    __name(this, "JOSEAlgNotAllowed");
  }
  static code = "ERR_JOSE_ALG_NOT_ALLOWED";
  code = "ERR_JOSE_ALG_NOT_ALLOWED";
};
var JOSENotSupported = class extends JOSEError {
  static {
    __name(this, "JOSENotSupported");
  }
  static code = "ERR_JOSE_NOT_SUPPORTED";
  code = "ERR_JOSE_NOT_SUPPORTED";
};
var JWSInvalid = class extends JOSEError {
  static {
    __name(this, "JWSInvalid");
  }
  static code = "ERR_JWS_INVALID";
  code = "ERR_JWS_INVALID";
};
var JWTInvalid = class extends JOSEError {
  static {
    __name(this, "JWTInvalid");
  }
  static code = "ERR_JWT_INVALID";
  code = "ERR_JWT_INVALID";
};
var JWSSignatureVerificationFailed = class extends JOSEError {
  static {
    __name(this, "JWSSignatureVerificationFailed");
  }
  static code = "ERR_JWS_SIGNATURE_VERIFICATION_FAILED";
  code = "ERR_JWS_SIGNATURE_VERIFICATION_FAILED";
  constructor(message2 = "signature verification failed", options) {
    super(message2, options);
  }
};

// ../../../../../Users/diegohaz/Developer/ariviso/node_modules/.pnpm/jose@6.2.12/node_modules/jose/dist/webapi/util/base64url.js
var invalid = "The input to be decoded is not correctly encoded.";
function decode(input) {
  try {
    return decodeBase64(typeof input == "string" ? input : decoder.decode(input), true);
  } catch (cause) {
    throw new TypeError(invalid, { cause });
  }
}
__name(decode, "decode");
function encode2(input) {
  return encodeBase64(typeof input == "string" ? encoder.encode(input) : input, true);
}
__name(encode2, "encode");

// ../../../../../Users/diegohaz/Developer/ariviso/node_modules/.pnpm/jose@6.2.12/node_modules/jose/dist/webapi/lib/validate.js
function isObject(input) {
  if (typeof input != "object" || input === null || Object.prototype.toString.call(input) !== "[object Object]")
    return false;
  const prototype = Object.getPrototypeOf(input);
  return prototype === null || Object.getPrototypeOf(prototype) === null;
}
__name(isObject, "isObject");
function isDisjoint(...headers) {
  const parameters = /* @__PURE__ */ new Set();
  for (const header of headers)
    if (header)
      for (const parameter of Object.keys(header)) {
        if (parameters.has(parameter))
          return false;
        parameters.add(parameter);
      }
  return true;
}
__name(isDisjoint, "isDisjoint");
function assertNotSet(value, name) {
  if (value !== void 0)
    throw new TypeError(`${name} can only be called once`);
}
__name(assertNotSet, "assertNotSet");
function decodeBase64url(value, label, ErrorClass) {
  try {
    return decode(value);
  } catch {
    throw new ErrorClass(`Failed to base64url decode the ${label}`);
  }
}
__name(decodeBase64url, "decodeBase64url");
function encodeBase64url(value, label, ErrorClass) {
  try {
    return encode(value);
  } catch {
    throw new ErrorClass(`The ${label} is not a valid base64url string`);
  }
}
__name(encodeBase64url, "encodeBase64url");
function parseJoseHeader(b64, ErrorClass, message2) {
  let parsed;
  try {
    parsed = JSON.parse(strictDecoder.decode(decode(b64)));
  } catch {
    throw new ErrorClass(message2);
  }
  if (!isObject(parsed))
    throw new ErrorClass(message2);
  return parsed;
}
__name(parseJoseHeader, "parseJoseHeader");
var JWS_RECOGNIZED = { __proto__: null, b64: true };
function validateAlgorithms(option, algorithms) {
  if (algorithms !== void 0 && (!Array.isArray(algorithms) || algorithms.some((s) => typeof s != "string")))
    throw new TypeError(`"${option}" option must be an array of strings`);
  return algorithms === void 0 ? void 0 : new Set(algorithms);
}
__name(validateAlgorithms, "validateAlgorithms");
function validateCritDuplicates(Err, protectedHeader) {
  const { crit } = protectedHeader ?? {};
  if (Array.isArray(crit) && new Set(crit).size !== crit.length)
    throw new Err('"crit" (Critical) Header Parameter MUST NOT contain duplicate values');
}
__name(validateCritDuplicates, "validateCritDuplicates");
function validateCrit(Err, recognizedDefault, recognizedOption, protectedHeader, joseHeader) {
  if (joseHeader.crit !== void 0 && protectedHeader?.crit === void 0)
    throw new Err('"crit" (Critical) Header Parameter MUST be integrity protected');
  if (!protectedHeader || protectedHeader.crit === void 0)
    return [];
  if (!Array.isArray(protectedHeader.crit) || protectedHeader.crit.length === 0 || protectedHeader.crit.some((input) => typeof input != "string" || input.length === 0))
    throw new Err('"crit" (Critical) Header Parameter MUST be an array of non-empty strings when present');
  const recognized = recognizedOption === void 0 ? recognizedDefault : { __proto__: null, ...recognizedOption, ...recognizedDefault };
  for (const parameter of protectedHeader.crit) {
    if (!(parameter in recognized))
      throw new JOSENotSupported(`Extension Header Parameter "${parameter}" is not recognized`);
    if (!Object.hasOwn(joseHeader, parameter) || joseHeader[parameter] === void 0)
      throw new Err(`Extension Header Parameter "${parameter}" is missing`);
    if (recognized[parameter] && (!Object.hasOwn(protectedHeader, parameter) || protectedHeader[parameter] === void 0))
      throw new Err(`Extension Header Parameter "${parameter}" MUST be integrity protected`);
  }
  return protectedHeader.crit;
}
__name(validateCrit, "validateCrit");
function validateB64(protectedHeader, extensions) {
  if (extensions.includes("b64")) {
    const b64 = protectedHeader.b64;
    if (typeof b64 != "boolean")
      throw new JWSInvalid('The "b64" (base64url-encode payload) Header Parameter must be a boolean');
    return b64;
  }
  return true;
}
__name(validateB64, "validateB64");
function serializeJoseHeader(Err, header) {
  let serialized, parsed;
  try {
    serialized = JSON.stringify(header), parsed = JSON.parse(serialized);
  } catch (cause) {
    throw new Err("JOSE Header is not valid JSON", { cause });
  }
  if (!isObject(parsed))
    throw new Err("JOSE Header is not a JSON object");
  return [parsed, serialized];
}
__name(serializeJoseHeader, "serializeJoseHeader");

// ../../../../../Users/diegohaz/Developer/ariviso/node_modules/.pnpm/jose@6.2.12/node_modules/jose/dist/webapi/lib/key.js
var tag = /* @__PURE__ */ __name((key2) => key2[Symbol.toStringTag], "tag");
var jwkMatchesOp = /* @__PURE__ */ __name((entry, key2, usage) => {
  const { alg } = entry;
  if (key2.use !== void 0) {
    const expected = usage === "sign" || usage === "verify" ? "sig" : "enc";
    if (key2.use !== expected)
      throw new TypeError(`Invalid key for this operation, its "use" must be "${expected}" when present`);
  }
  if (key2.alg !== void 0 && key2.alg !== alg)
    throw new TypeError(`Invalid key for this operation, its "alg" must be "${alg}" when present`);
  if (Array.isArray(key2.key_ops)) {
    const expectedKeyOp = usage === "encrypt" || usage === "decrypt" ? entry.ops?.[usage === "encrypt" ? 0 : 1] : usage;
    if (expectedKeyOp && !key2.key_ops.includes(expectedKeyOp))
      throw new TypeError(`Invalid key for this operation, its "key_ops" must include "${expectedKeyOp}" when present`);
  }
}, "jwkMatchesOp");
async function prepareKey(entry, key2, usage) {
  const { alg, secret } = entry, privateKey = usage === "decrypt" || usage === "sign";
  if (secret && key2 instanceof Uint8Array)
    return key2;
  let normalized, keyObject;
  if (isObject(key2)) {
    if (normalized = normalizeJwk(key2), typeof normalized.kty != "string")
      throw invalidKeyType(alg, key2, secret);
    if (!(secret ? normalized.kty === "oct" && typeof normalized.k == "string" : normalized.kty !== "oct" && (privateKey ? normalized.kty === "AKP" && typeof normalized.priv == "string" || typeof normalized.d == "string" : normalized.d === void 0 && normalized.priv === void 0)))
      throw new TypeError(secret ? 'JSON Web Key for symmetric algorithms must have JWK "kty" (Key Type) equal to "oct" and the JWK "k" (Key Value) present' : `JSON Web Key for this operation must be a ${privateKey ? "private" : "public"} JWK`);
    if (jwkMatchesOp(entry, normalized, usage), normalized.kty === "oct")
      return decode(normalized.k);
    if (!Object.isFrozen(key2)) {
      const { key_ops } = key2;
      Array.isArray(key_ops) && Object.freeze(key_ops), Object.freeze(key2);
    }
  } else {
    if (!isKeyLike(key2))
      throw invalidKeyType(alg, key2, secret);
    const expectedType = secret ? "secret" : privateKey ? "private" : "public";
    if (key2.type !== expectedType && (secret || ["secret", "public", "private"].includes(key2.type)))
      throw new TypeError(`${tag(key2)} instances must be of type "${expectedType}" for the ${alg} algorithm`);
    if (isCryptoKey(key2))
      return key2;
    if (keyObject = key2, keyObject.type === "secret")
      return keyObject.export();
  }
  cache ||= /* @__PURE__ */ new WeakMap();
  const cacheKey = key2;
  let cached = cache.get(cacheKey);
  if (cached?.[alg])
    return cached[alg];
  if (cached || cache.set(cacheKey, cached = {}), keyObject && typeof keyObject.toCryptoKey == "function") {
    const isPublic = keyObject.type === "public", crv = nist[keyObject.asymmetricKeyDetails?.namedCurve], params = entry.resolve?.({ crv, asymmetricKeyType: keyObject.asymmetricKeyType }) ?? entry.subtle;
    return cached[alg] = keyObject.toCryptoKey(params, isPublic, entry.usages[isPublic ? 0 : 1]);
  }
  return normalized ??= keyObject.export({ format: "jwk" }), normalized.alg = alg, cached[alg] = await jwkToKey(entry, normalized);
}
__name(prepareKey, "prepareKey");
var cache;
var nist = {
  __proto__: null,
  prime256v1: "P-256",
  secp384r1: "P-384",
  secp521r1: "P-521"
};
var isCryptoKey = /* @__PURE__ */ __name((key2) => {
  if (key2?.[Symbol.toStringTag] === "CryptoKey")
    return true;
  try {
    return key2 instanceof CryptoKey;
  } catch {
    return false;
  }
}, "isCryptoKey");
var isKeyObject = /* @__PURE__ */ __name((key2) => key2?.[Symbol.toStringTag] === "KeyObject", "isKeyObject");
var isKeyLike = /* @__PURE__ */ __name((key2) => isCryptoKey(key2) || isKeyObject(key2), "isKeyLike");
function message(msg, actual, ...types) {
  if (types.length > 2) {
    const last = types.pop();
    msg += `one of type ${types.join(", ")}, or ${last}.`;
  } else types.length === 2 ? msg += `one of type ${types[0]} or ${types[1]}.` : msg += `of type ${types[0]}.`;
  return actual == null ? msg += ` Received ${actual}` : typeof actual == "function" && actual.name ? msg += ` Received function ${actual.name}` : typeof actual == "object" && actual != null && actual.constructor?.name && (msg += ` Received an instance of ${actual.constructor.name}`), msg;
}
__name(message, "message");
function invalidKeyType(alg, actual, secret) {
  const types = ["CryptoKey", "KeyObject", "JSON Web Key"];
  return secret && types.push("Uint8Array"), new TypeError(message(`Key for the ${alg} algorithm must be `, actual, ...types));
}
__name(invalidKeyType, "invalidKeyType");
var unusable = /* @__PURE__ */ __name((name, prop = "algorithm.name") => new TypeError(`CryptoKey does not support this operation, its ${prop} must be ${name}`), "unusable");
function checkUsage(key2, usage) {
  if (usage && !key2.usages.includes(usage))
    throw new TypeError(`CryptoKey does not support this operation, its usages must include ${usage}.`);
}
__name(checkUsage, "checkUsage");
function checkModulusLength(alg, key2) {
  const { modulusLength } = key2.algorithm;
  if (typeof modulusLength != "number" || modulusLength < 2048)
    throw new TypeError(`${alg} requires key modulusLength to be 2048 bits or larger`);
}
__name(checkModulusLength, "checkModulusLength");
function checkCryptoKey(key2, expected, usage) {
  const algorithm = key2.algorithm;
  if (algorithm.name !== expected.name)
    throw unusable(expected.name);
  if (expected.hash && algorithm.hash?.name !== expected.hash)
    throw unusable(expected.hash, "algorithm.hash");
  if (expected.namedCurve && algorithm.namedCurve !== expected.namedCurve)
    throw unusable(expected.namedCurve, "algorithm.namedCurve");
  if (expected.length !== void 0 && algorithm.length !== expected.length)
    throw unusable(expected.length, "algorithm.length");
  checkUsage(key2, usage);
}
__name(checkCryptoKey, "checkCryptoKey");
function snapshotJwk(jwk) {
  return { __proto__: null, ...jwk };
}
__name(snapshotJwk, "snapshotJwk");
function normalizeJwk(jwk) {
  const normalized = snapshotJwk(jwk);
  if (normalized.ext !== void 0 && typeof normalized.ext != "boolean")
    throw new TypeError('"ext" (Extractable) Parameter must be a boolean');
  if (normalized.key_ops !== void 0) {
    const value = normalized.key_ops, keyOps = Array.isArray(value) ? [...value] : void 0;
    if (!keyOps || keyOps.some((operation) => typeof operation != "string") || new Set(keyOps).size !== keyOps.length)
      throw new TypeError('"key_ops" (Key Operations) Parameter must be an array of unique strings');
    normalized.key_ops = keyOps;
  }
  return normalized;
}
__name(normalizeJwk, "normalizeJwk");
async function jwkToKey(entry, jwk, extractable) {
  if (!entry.kty.includes(jwk.kty))
    throw new JOSENotSupported('Invalid or unsupported JWK "alg" (Algorithm) Parameter value');
  const algorithm = entry.resolve?.({ kty: jwk.kty, crv: jwk.crv }) ?? entry.subtle, isPrivate = !!(jwk.d || jwk.priv), keyData = { ...jwk, ext: extractable ?? jwk.ext };
  return keyData.kty !== "AKP" && delete keyData.alg, delete keyData.use, crypto.subtle.importKey("jwk", keyData, algorithm, keyData.ext ?? !isPrivate, jwk.key_ops ?? entry.usages[isPrivate ? 1 : 0]);
}
__name(jwkToKey, "jwkToKey");
async function rawKey(key2, expected, usage, extractable = false) {
  return key2 instanceof Uint8Array && (key2 = await crypto.subtle.importKey("raw", key2, expected, extractable, [usage])), checkCryptoKey(key2, expected, usage), key2;
}
__name(rawKey, "rawKey");

// ../../../../../Users/diegohaz/Developer/ariviso/node_modules/.pnpm/jose@6.2.12/node_modules/jose/dist/webapi/lib/key_descriptor.js
function table(entries) {
  const out = { __proto__: null };
  for (const alg in entries)
    out[alg] = { ...entries[alg], alg };
  return out;
}
__name(table, "table");

// ../../../../../Users/diegohaz/Developer/ariviso/node_modules/.pnpm/jose@6.2.12/node_modules/jose/dist/webapi/lib/jws_algorithms.js
var sig = [["verify"], ["sign"]];
function hmac(bits) {
  const subtle = { name: "HMAC", hash: `SHA-${bits}` };
  return { kty: ["oct"], secret: true, subtle, signing: subtle, usages: sig };
}
__name(hmac, "hmac");
function rsa(bits, saltLength) {
  const subtle = { name: saltLength ? "RSA-PSS" : "RSASSA-PKCS1-v1_5", hash: `SHA-${bits}` };
  return {
    kty: ["RSA"],
    subtle,
    signing: saltLength ? { ...subtle, saltLength } : subtle,
    usages: sig,
    minRsaBits: 2048
  };
}
__name(rsa, "rsa");
function ecdsa(crv, bits) {
  return {
    kty: ["EC"],
    crv,
    subtle: { name: "ECDSA", namedCurve: crv },
    signing: { name: "ECDSA", hash: `SHA-${bits}` },
    usages: sig
  };
}
__name(ecdsa, "ecdsa");
function eddsa() {
  const subtle = { name: "Ed25519" };
  return {
    kty: ["OKP"],
    crv: "Ed25519",
    subtle,
    signing: subtle,
    usages: sig
  };
}
__name(eddsa, "eddsa");
function mldsa(bits) {
  const subtle = { name: `ML-DSA-${bits}` };
  return {
    kty: ["AKP"],
    subtle,
    signing: subtle,
    usages: sig
  };
}
__name(mldsa, "mldsa");
var JWS = table({
  HS256: hmac(256),
  HS384: hmac(384),
  HS512: hmac(512),
  RS256: rsa(256),
  RS384: rsa(384),
  RS512: rsa(512),
  PS256: rsa(256, 32),
  PS384: rsa(384, 48),
  PS512: rsa(512, 64),
  ES256: ecdsa("P-256", 256),
  ES384: ecdsa("P-384", 384),
  ES512: ecdsa("P-521", 512),
  EdDSA: eddsa(),
  Ed25519: eddsa(),
  "ML-DSA-44": mldsa(44),
  "ML-DSA-65": mldsa(65),
  "ML-DSA-87": mldsa(87)
});
function jwsAlgorithm(alg) {
  const entry = typeof alg == "string" ? JWS[alg] : void 0;
  if (!entry)
    throw new JOSENotSupported(`alg ${alg} is not supported either by JOSE or your javascript runtime`);
  return entry;
}
__name(jwsAlgorithm, "jwsAlgorithm");

// ../../../../../Users/diegohaz/Developer/ariviso/node_modules/.pnpm/jose@6.2.12/node_modules/jose/dist/webapi/lib/jws_verify.js
function prepareVerify(options) {
  return [options && validateAlgorithms("algorithms", options.algorithms), options?.crit];
}
__name(prepareVerify, "prepareVerify");
function parseProtectedHeader(encodedProtected) {
  return encodedProtected === void 0 ? {} : parseJoseHeader(encodedProtected, JWSInvalid, "JWS Protected Header is invalid");
}
__name(parseProtectedHeader, "parseProtectedHeader");
function encodeCompactUnencodedPayload(payload) {
  try {
    return encode(payload);
  } catch {
    throw new JWSInvalid("JWS Compact Serialization payload must use only ASCII characters");
  }
}
__name(encodeCompactUnencodedPayload, "encodeCompactUnencodedPayload");
async function verifySignature(jws, shared, key2, encodeUnencodedPayload, parsedProtected) {
  const { protected: encodedProtected, header, payload: inputPayload } = jws, parsedProt = parsedProtected ?? parseProtectedHeader(encodedProtected);
  if (!isDisjoint(parsedProt, header))
    throw new JWSInvalid("JWS Protected and JWS Unprotected Header Parameter names must be disjoint");
  const joseHeader = { ...parsedProt, ...header }, b64 = validateB64(parsedProt, validateCrit(JWSInvalid, JWS_RECOGNIZED, shared[1], parsedProt, joseHeader)), { alg } = joseHeader;
  if (typeof alg != "string" || !alg)
    throw new JWSInvalid('JWS "alg" (Algorithm) Header Parameter missing or invalid');
  if (shared[0] && !shared[0].has(alg))
    throw new JOSEAlgNotAllowed('"alg" (Algorithm) Header Parameter value not allowed');
  if (b64) {
    if (typeof inputPayload != "string")
      throw new JWSInvalid("JWS Payload must be a string");
  } else if (typeof inputPayload != "string" && !(inputPayload instanceof Uint8Array))
    throw new JWSInvalid("JWS Payload must be a string or an Uint8Array instance");
  const signingPayload = b64 || typeof inputPayload != "string" ? inputPayload : encodeUnencodedPayload(inputPayload);
  let resolvedKey = false;
  typeof key2 == "function" && (key2 = await key2(parsedProt, jws), resolvedKey = true);
  const entry = jwsAlgorithm(alg), data = concat(encodedProtected !== void 0 ? encode(encodedProtected) : new Uint8Array(), encode("."), typeof signingPayload == "string" ? shared[2] ??= encodeBase64url(signingPayload, "payload", JWSInvalid) : signingPayload), signature = decodeBase64url(jws.signature, "signature", JWSInvalid), k = await prepareKey(entry, key2, "verify"), cryptoKey = await rawKey(k, entry.subtle, "verify");
  entry.minRsaBits && checkModulusLength(entry.alg, cryptoKey);
  let verified = false;
  try {
    verified = await crypto.subtle.verify(entry.signing, cryptoKey, signature, data);
  } catch {
  }
  if (!verified)
    throw new JWSSignatureVerificationFailed();
  const result = { payload: typeof signingPayload == "string" ? decodeBase64url(signingPayload, "payload", JWSInvalid) : signingPayload };
  return encodedProtected !== void 0 && (result.protectedHeader = parsedProt), header !== void 0 && (result.unprotectedHeader = header), resolvedKey ? [{ ...result, key: k }, b64] : [result, b64];
}
__name(verifySignature, "verifySignature");
async function verifyCompact(jws, shared, key2) {
  if (jws instanceof Uint8Array && (jws = decoder.decode(jws)), typeof jws != "string")
    throw new JWSInvalid("Compact JWS must be a string or Uint8Array");
  const { 0: protectedHeader, 1: payload, 2: signature, length } = jws.split(".");
  if (length !== 3)
    throw new JWSInvalid("Invalid Compact JWS");
  return verifySignature({ payload, protected: protectedHeader, signature }, shared, key2, encodeCompactUnencodedPayload);
}
__name(verifyCompact, "verifyCompact");

// ../../../../../Users/diegohaz/Developer/ariviso/node_modules/.pnpm/jose@6.2.12/node_modules/jose/dist/webapi/lib/jwt_claims_set.js
var epoch = /* @__PURE__ */ __name((date) => Math.floor(date.getTime() / 1e3), "epoch");
var multipliers = {
  s: 1,
  m: 60,
  h: 3600,
  d: 86400,
  w: 604800,
  y: 31557600
};
var REGEX = /^(\+|\-)? ?(\d+|\d+\.\d+) ?(seconds?|secs?|s|minutes?|mins?|m|hours?|hrs?|h|days?|d|weeks?|w|years?|yrs?|y)(?: (ago|from now))?$/i;
var checkFailed = "check_failed";
function invalidDuration() {
  throw new TypeError("Invalid time period format");
}
__name(invalidDuration, "invalidDuration");
function secs(str) {
  typeof str != "string" && invalidDuration();
  const matched = REGEX.exec(str);
  (!matched || matched[4] && matched[1]) && invalidDuration();
  const value = parseFloat(matched[2]), numericDate2 = Math.round(value * multipliers[matched[3][0].toLowerCase()]);
  return Number.isFinite(numericDate2) || invalidDuration(), matched[1] === "-" || matched[4] === "ago" ? -numericDate2 : numericDate2;
}
__name(secs, "secs");
function validateInput(label, input) {
  if (!Number.isFinite(input))
    throw new TypeError(`Invalid ${label} input`);
  return input;
}
__name(validateInput, "validateInput");
function validateStringClaim(claim2, value) {
  if (typeof value != "string")
    throw new TypeError(`"${claim2}" claim must be a string`);
}
__name(validateStringClaim, "validateStringClaim");
function validateAudienceClaim(value) {
  if (typeof value != "string" && (!Array.isArray(value) || Array.from(value).some((member2) => typeof member2 != "string")))
    throw new TypeError('"aud" claim must be a string or an array of strings');
}
__name(validateAudienceClaim, "validateAudienceClaim");
function numericDate(value, label) {
  return typeof value == "number" ? validateInput(label, value) : value instanceof Date ? validateInput(label, epoch(value)) : epoch(/* @__PURE__ */ new Date()) + secs(value);
}
__name(numericDate, "numericDate");
var normalizeTyp = /* @__PURE__ */ __name((value) => {
  const normalized = value.toLowerCase();
  return value.includes("/") ? normalized : `application/${normalized}`;
}, "normalizeTyp");
var checkAudiencePresence = /* @__PURE__ */ __name((audPayload, audOption) => typeof audPayload == "string" ? audOption.includes(audPayload) : Array.isArray(audPayload) ? audOption.some((aud) => audPayload.includes(aud)) : false, "checkAudiencePresence");
function validateNumericDate(payload, claim2, required = false) {
  const value = payload[claim2];
  if (!(value === void 0 && !required)) {
    if (typeof value != "number")
      throw new JWTClaimValidationFailed(`"${claim2}" claim must be a number`, payload, claim2, "invalid");
    return value;
  }
}
__name(validateNumericDate, "validateNumericDate");
function unexpectedClaim(payload, claim2) {
  throw new JWTClaimValidationFailed(`unexpected "${claim2}" claim value`, payload, claim2, checkFailed);
}
__name(unexpectedClaim, "unexpectedClaim");
function validateClaimsSet(protectedHeader, encodedPayload, options = {}) {
  let payload;
  try {
    payload = JSON.parse(strictDecoder.decode(encodedPayload));
  } catch {
  }
  if (!isObject(payload))
    throw new JWTInvalid("JWT Claims Set must be a top-level JSON object");
  const { typ } = options;
  if (typ !== void 0 && (typeof protectedHeader.typ != "string" || normalizeTyp(protectedHeader.typ) !== normalizeTyp(typ)))
    throw new JWTClaimValidationFailed('unexpected "typ" JWT header value', payload, "typ", checkFailed);
  const { requiredClaims = [], issuer, subject, audience, maxTokenAge } = options, presenceCheck = [...requiredClaims];
  maxTokenAge !== void 0 && presenceCheck.push("iat"), audience !== void 0 && presenceCheck.push("aud"), subject !== void 0 && presenceCheck.push("sub"), issuer !== void 0 && presenceCheck.push("iss");
  for (const claim2 of new Set(presenceCheck.reverse()))
    if (!Object.hasOwn(payload, claim2))
      throw new JWTClaimValidationFailed(`missing required "${claim2}" claim`, payload, claim2, "missing");
  issuer !== void 0 && !(Array.isArray(issuer) ? issuer : [issuer]).includes(payload.iss) && unexpectedClaim(payload, "iss"), subject !== void 0 && payload.sub !== subject && unexpectedClaim(payload, "sub"), audience !== void 0 && !checkAudiencePresence(payload.aud, typeof audience == "string" ? [audience] : audience) && unexpectedClaim(payload, "aud");
  const { clockTolerance } = options;
  let tolerance = 0;
  if (typeof clockTolerance == "string")
    tolerance = secs(clockTolerance);
  else if (clockTolerance !== void 0) {
    if (typeof clockTolerance != "number")
      throw new TypeError("Invalid clockTolerance option type");
    tolerance = clockTolerance;
  }
  validateInput("clockTolerance option", tolerance);
  const { currentDate } = options, now = validateInput("currentDate option", epoch(currentDate === void 0 ? /* @__PURE__ */ new Date() : currentDate)), iat = validateNumericDate(payload, "iat", maxTokenAge !== void 0), nbf = validateNumericDate(payload, "nbf");
  if (nbf !== void 0 && nbf > now + tolerance)
    throw new JWTClaimValidationFailed('"nbf" claim timestamp check failed', payload, "nbf", checkFailed);
  const exp = validateNumericDate(payload, "exp");
  if (exp !== void 0 && exp <= now - tolerance)
    throw new JWTExpired('"exp" claim timestamp check failed', payload, "exp", checkFailed);
  if (maxTokenAge !== void 0) {
    const age = now - iat, max = validateInput("maxTokenAge option", typeof maxTokenAge == "number" ? maxTokenAge : secs(maxTokenAge));
    if (age - tolerance > max)
      throw new JWTExpired('"iat" claim timestamp check failed (too far in the past)', payload, "iat", checkFailed);
    if (age < -tolerance)
      throw new JWTClaimValidationFailed('"iat" claim timestamp check failed (it should be in the past)', payload, "iat", checkFailed);
  }
  return payload;
}
__name(validateClaimsSet, "validateClaimsSet");
var producerPayloads;
function producerPayload(producer) {
  return producerPayloads.get(producer);
}
__name(producerPayload, "producerPayload");
function jwtData(producer) {
  const payload = producerPayload(producer);
  for (const claim2 of ["iat", "nbf", "exp"]) {
    const value = payload[claim2];
    if (typeof value == "number" && !Number.isFinite(value))
      throw new TypeError(`"${claim2}" claim must be a finite number`);
  }
  return encoder.encode(JSON.stringify(payload));
}
__name(jwtData, "jwtData");
var JWTClaimsBuilder = class {
  static {
    __name(this, "JWTClaimsBuilder");
  }
  constructor(payload = {}) {
    if (!isObject(payload))
      throw new TypeError("JWT Claims Set MUST be an object");
    (producerPayloads ||= /* @__PURE__ */ new WeakMap()).set(this, structuredClone(payload));
  }
  setIssuer(value) {
    return validateStringClaim("iss", value), producerPayload(this).iss = value, this;
  }
  setSubject(value) {
    return validateStringClaim("sub", value), producerPayload(this).sub = value, this;
  }
  setAudience(value) {
    return validateAudienceClaim(value), producerPayload(this).aud = value, this;
  }
  setJti(value) {
    return validateStringClaim("jti", value), producerPayload(this).jti = value, this;
  }
  setNotBefore(value) {
    return producerPayload(this).nbf = numericDate(value, "setNotBefore"), this;
  }
  setExpirationTime(value) {
    return producerPayload(this).exp = numericDate(value, "setExpirationTime"), this;
  }
  setIssuedAt(value) {
    const payload = producerPayload(this);
    return value === void 0 ? payload.iat = epoch(/* @__PURE__ */ new Date()) : typeof value == "string" ? payload.iat = validateInput("setIssuedAt", epoch(/* @__PURE__ */ new Date()) + secs(value)) : payload.iat = numericDate(value, "setIssuedAt"), this;
  }
};

// ../../../../../Users/diegohaz/Developer/ariviso/node_modules/.pnpm/jose@6.2.12/node_modules/jose/dist/webapi/jwt/verify.js
async function jwtVerify(jwt, key2, options) {
  const [verified, b64] = await verifyCompact(jwt, prepareVerify(options), key2);
  if (!b64)
    throw new JWTInvalid("JWTs MUST NOT use unencoded payload");
  const payload = validateClaimsSet(verified.protectedHeader, verified.payload, options);
  return { ...verified, payload };
}
__name(jwtVerify, "jwtVerify");

// ../../../../../Users/diegohaz/Developer/ariviso/node_modules/.pnpm/jose@6.2.12/node_modules/jose/dist/webapi/lib/jws_sign.js
async function createSignature(input, key2, rejectUnencoded) {
  let [payload, protectedHeader, unprotectedHeader, crit] = input, protectedHeaderString = "";
  if (protectedHeader !== void 0) {
    const normalized = serializeJoseHeader(JWSInvalid, protectedHeader);
    protectedHeader = normalized[0], protectedHeaderString = encode2(normalized[1]);
  }
  if (unprotectedHeader !== void 0 && (unprotectedHeader = serializeJoseHeader(JWSInvalid, unprotectedHeader)[0]), !protectedHeader && !unprotectedHeader)
    throw new JWSInvalid("either setProtectedHeader or setUnprotectedHeader must be called before #sign()");
  if (!isDisjoint(protectedHeader, unprotectedHeader))
    throw new JWSInvalid("JWS Protected and JWS Unprotected Header Parameter names must be disjoint");
  const joseHeader = { ...protectedHeader, ...unprotectedHeader };
  validateCritDuplicates(JWSInvalid, protectedHeader);
  const b64 = validateB64(protectedHeader, validateCrit(JWSInvalid, JWS_RECOGNIZED, crit, protectedHeader, joseHeader));
  b64 || rejectUnencoded?.();
  const { alg } = joseHeader;
  if (typeof alg != "string" || !alg)
    throw new JWSInvalid('JWS "alg" (Algorithm) Header Parameter missing or invalid');
  const entry = jwsAlgorithm(alg);
  let payloadS = "", payloadB = payload, data;
  if (b64) {
    const encoded = input[4];
    encoded ? (payloadS = encoded[0] ??= encode2(payload), payloadB = encoded[1] ??= encode(payloadS)) : (payloadS = encode2(payload), data = encoder.encode(`${protectedHeaderString}.${payloadS}`));
  }
  data ??= concat(encode(protectedHeaderString), encode("."), payloadB);
  const k = await rawKey(await prepareKey(entry, key2, "sign"), entry.subtle, "sign");
  entry.minRsaBits && checkModulusLength(entry.alg, k);
  const jws = {
    signature: encode2(new Uint8Array(await crypto.subtle.sign(entry.signing, k, data))),
    payload: payloadS
  };
  return protectedHeader && (jws.protected = protectedHeaderString), unprotectedHeader && (jws.header = unprotectedHeader), [jws, b64];
}
__name(createSignature, "createSignature");
async function createCompactSignature(payload, protectedHeader, crit, key2, rejectUnencoded) {
  const [jws] = await createSignature([payload, protectedHeader, void 0, crit], key2, rejectUnencoded);
  return `${jws.protected}.${jws.payload}.${jws.signature}`;
}
__name(createCompactSignature, "createCompactSignature");

// ../../../../../Users/diegohaz/Developer/ariviso/node_modules/.pnpm/jose@6.2.12/node_modules/jose/dist/webapi/jwt/sign.js
var SignJWT_base = JWTClaimsBuilder;
var SignJWT = class extends SignJWT_base {
  static {
    __name(this, "SignJWT");
  }
  #protectedHeader;
  setProtectedHeader(protectedHeader) {
    return assertNotSet(this.#protectedHeader, "setProtectedHeader"), this.#protectedHeader = protectedHeader, this;
  }
  async sign(key2, options) {
    return createCompactSignature(jwtData(this), this.#protectedHeader, options?.crit, key2, () => {
      throw new JWTInvalid("JWTs MUST NOT use unencoded payload");
    });
  }
};

// implementation/packages/security/src/errors.ts
var SecurityError = class extends Error {
  constructor(code, status, message2) {
    super(message2);
    this.code = code;
    this.status = status;
    this.name = "SecurityError";
  }
  code;
  status;
  static {
    __name(this, "SecurityError");
  }
};
function record(value) {
  if (!value || typeof value !== "object" || Array.isArray(value)) {
    throw new SecurityError("invalid_metadata", 503, "Trusted metadata is unavailable.");
  }
  return value;
}
__name(record, "record");
function textField(value) {
  if (typeof value !== "string" || value.length === 0) {
    throw new SecurityError("invalid_metadata", 503, "Trusted metadata is unavailable.");
  }
  return value;
}
__name(textField, "textField");
function numericId(value) {
  if (typeof value === "number" && Number.isSafeInteger(value) && value > 0) {
    return String(value);
  }
  if (typeof value === "string" && /^[1-9]\d*$/.test(value)) {
    return value;
  }
  throw new SecurityError("invalid_metadata", 503, "Trusted metadata is unavailable.");
}
__name(numericId, "numericId");

// implementation/packages/security/src/capabilities.ts
function signingKey(configuration) {
  if (configuration.secret.length < 32) {
    throw new Error("A capability secret must contain at least 32 characters.");
  }
  return new TextEncoder().encode(configuration.secret);
}
__name(signingKey, "signingKey");
function positiveInteger(value) {
  if (typeof value !== "number" || !Number.isSafeInteger(value) || value < 1) {
    throw new SecurityError("invalid_capability", 401, "The ingest credential is invalid.");
  }
  return value;
}
__name(positiveInteger, "positiveInteger");
function parseCapability(value) {
  const data = record(value);
  return {
    runId: textField(data.runId),
    repositoryId: numericId(data.repositoryId),
    workflowRunId: numericId(data.workflowRunId),
    workflowAttempt: positiveInteger(data.workflowAttempt),
    testedSha: textField(data.testedSha),
    planDigest: textField(data.planDigest),
    shardKey: textField(data.shardKey),
    jobId: numericId(data.jobId),
    maximumBytes: positiveInteger(data.maximumBytes),
    maximumImages: positiveInteger(data.maximumImages)
  };
}
__name(parseCapability, "parseCapability");
async function issueToken(configuration, kind, claims, expiresIn) {
  if (!Number.isSafeInteger(expiresIn) || expiresIn < 1 || expiresIn > 900) {
    throw new Error("Ingest credentials must expire within 15 minutes.");
  }
  return new SignJWT({ ...claims, kind, environment: configuration.environment }).setProtectedHeader({ alg: "HS256", typ: "JWT" }).setIssuer(configuration.issuer).setAudience(`ariviso:${kind}:${configuration.environment}`).setJti(crypto.randomUUID()).setIssuedAt().setExpirationTime(`${expiresIn}s`).sign(signingKey(configuration));
}
__name(issueToken, "issueToken");
async function verifyToken(configuration, kind, token) {
  try {
    const result = await jwtVerify(token, signingKey(configuration), {
      algorithms: ["HS256"],
      issuer: configuration.issuer,
      audience: `ariviso:${kind}:${configuration.environment}`,
      typ: "JWT",
      requiredClaims: ["exp", "iat", "jti"],
      maxTokenAge: "15m"
    });
    if (result.payload.kind !== kind || result.payload.environment !== configuration.environment) {
      throw new Error("Wrong credential kind.");
    }
    return result.payload;
  } catch {
    throw new SecurityError(
      "invalid_capability",
      401,
      "The ingest credential is invalid or expired."
    );
  }
}
__name(verifyToken, "verifyToken");
function issueIngestCapability(configuration, capability, expiresIn = 600) {
  return issueToken(configuration, "ingest", parseCapability(capability), expiresIn);
}
__name(issueIngestCapability, "issueIngestCapability");
async function verifyIngestCapability(configuration, token) {
  return parseCapability(await verifyToken(configuration, "ingest", token));
}
__name(verifyIngestCapability, "verifyIngestCapability");

// worker.mjs
import { setTimeout } from "node:timers/promises";

// implementation/packages/service/src/database.ts
var ConflictError = class extends Error {
  constructor(message2, current) {
    super(message2);
    this.current = current;
    this.name = "ConflictError";
  }
  current;
  static {
    __name(this, "ConflictError");
  }
  code = "CONFLICT";
};
var IncompleteError = class extends Error {
  static {
    __name(this, "IncompleteError");
  }
  code = "INCOMPLETE";
  constructor(message2) {
    super(message2);
    this.name = "IncompleteError";
  }
};
function statement(database, sql, values = []) {
  return database.prepare(sql).bind(...values);
}
__name(statement, "statement");
function assertion(database, predicate, values = []) {
  return statement(
    database,
    `INSERT INTO ariviso_assertions (valid) VALUES (CASE WHEN (${predicate}) THEN 1 ELSE 0 END)`,
    values
  );
}
__name(assertion, "assertion");
async function atomic(database, statements) {
  try {
    return await database.batch([
      ...statements,
      statement(database, "DELETE FROM ariviso_assertions")
    ]);
  } catch (error) {
    if (error instanceof Error && /CHECK constraint failed.*valid|ariviso_assertions/.test(error.message)) {
      throw new ConflictError("State changed. Refresh the comparison before trying again.");
    }
    throw error;
  }
}
__name(atomic, "atomic");

// implementation/packages/service/src/historical.ts
function historicalOwner(comparisonId) {
  return `historical:${comparisonId}`;
}
__name(historicalOwner, "historicalOwner");
function historicalGuard(database, comparisonId, requireEligible = true) {
  return assertion(
    database,
    `EXISTS (SELECT 1 FROM ariviso_comparisons comparison
    JOIN ariviso_runs run ON run.id = comparison.run_id
    JOIN work_retained_runs retained ON retained.id = run.id
    JOIN work_retention_pins pin ON pin.run_id = run.id
    WHERE comparison.id = ? AND comparison.purpose = 'historical' AND comparison.state = 'comparing'
      AND run.active = 0 AND run.sealed_at IS NOT NULL AND retained.byte_state = 'live'
      AND pin.owner = ? AND pin.reason = 'manual')
    AND NOT EXISTS (SELECT 1 FROM ariviso_comparison_rows row
      JOIN ariviso_captures capture ON capture.id = row.candidate_capture_id
      JOIN ariviso_images image ON image.id = capture.image_id
      WHERE row.comparison_id = ? AND (image.bytes_present != 1 OR NOT EXISTS (
        SELECT 1 FROM work_retention_pins pin JOIN work_retained_runs retained ON retained.id = pin.run_id
        WHERE pin.run_id = image.run_id AND pin.owner = ? AND pin.reason = 'manual' AND retained.byte_state = 'live')))
    AND NOT EXISTS (SELECT 1 FROM ariviso_comparisons comparison
      WHERE comparison.id = ? AND comparison.reference_snapshot_id IS NOT NULL AND NOT EXISTS (
        SELECT 1 FROM ariviso_snapshots snapshot
        JOIN ariviso_snapshot_retention retention ON retention.snapshot_id = snapshot.id
        JOIN ariviso_pins pin ON pin.snapshot_id = snapshot.id
        WHERE snapshot.id = comparison.reference_snapshot_id AND (? = 0 OR snapshot.reference_eligible = 1)
          AND retention.byte_state = 'live' AND pin.reason = 'historical' AND pin.owner_id = comparison.id))`,
    [
      comparisonId,
      historicalOwner(comparisonId),
      comparisonId,
      historicalOwner(comparisonId),
      comparisonId,
      requireEligible ? 1 : 0
    ]
  );
}
__name(historicalGuard, "historicalGuard");
async function finalizeHistoricalComparison(database, comparisonId) {
  const unavailableReference = await database.prepare(`SELECT 1 FROM ariviso_comparisons comparison
    JOIN ariviso_snapshots snapshot ON snapshot.id = comparison.reference_snapshot_id
    WHERE comparison.id = ? AND snapshot.reference_eligible != 1`).bind(comparisonId).first();
  const failedTask = await database.prepare(`SELECT 1 FROM ariviso_comparison_rows row
    LEFT JOIN work_tasks task ON task.id = row.id
    WHERE row.comparison_id = ? AND (row.outcome = 'error' OR (row.outcome = 'pending' AND task.state = 'dead')) LIMIT 1`).bind(comparisonId).first();
  const pending = await database.prepare(
    "SELECT 1 FROM ariviso_comparison_rows WHERE comparison_id = ? AND outcome = 'pending' LIMIT 1"
  ).bind(comparisonId).first();
  const failed = Boolean(failedTask || unavailableReference);
  if (pending && !failed) {
    throw new IncompleteError("Required historical comparisons have not completed.");
  }
  await atomic(database, [
    historicalGuard(database, comparisonId, !failed),
    assertion(
      database,
      `NOT EXISTS (SELECT 1 FROM ariviso_comparison_rows row WHERE row.comparison_id = ?
      AND (row.decision_id IS NOT NULL OR row.source_decision_id IS NOT NULL OR row.decision_revision != 0))`,
      [comparisonId]
    ),
    statement(
      database,
      "UPDATE ariviso_comparisons SET state = ? WHERE id = ? AND purpose = 'historical' AND state = 'comparing'",
      [failed ? "invalidated" : "ready", comparisonId]
    ),
    ...failed ? [
      statement(
        database,
        "UPDATE ariviso_comparison_rows SET outcome = 'error' WHERE comparison_id = ? AND outcome = 'pending'",
        [comparisonId]
      ),
      statement(
        database,
        `UPDATE work_tasks SET state = 'dead', lease_token = NULL, lease_until = NULL,
      last_error = 'Historical comparison failed' WHERE id IN (SELECT id FROM ariviso_comparison_rows WHERE comparison_id = ?) AND state IN ('queued', 'leased')`,
        [comparisonId]
      )
    ] : []
    // The verified supplement releases these roots after preserving the result.
  ]);
}
__name(finalizeHistoricalComparison, "finalizeHistoricalComparison");
async function expireHistoricalPreparations(database, now) {
  await atomic(database, [
    statement(
      database,
      `DELETE FROM work_retention_pins WHERE reason = 'manual' AND owner IN (
      SELECT 'historical:' || id FROM ariviso_historical_preparations WHERE lease_until <= ?)`,
      [now]
    ),
    statement(
      database,
      "DELETE FROM ariviso_pins WHERE reason = 'historical' AND owner_id IN (SELECT id FROM ariviso_historical_preparations WHERE lease_until <= ?)",
      [now]
    ),
    statement(
      database,
      `DELETE FROM ariviso_captures WHERE run_id IN (
      SELECT preparation.run_id FROM ariviso_historical_preparations preparation
      JOIN ariviso_runs run ON run.id = preparation.run_id WHERE preparation.lease_until <= ? AND run.detail_archived = 1)
      AND NOT EXISTS (SELECT 1 FROM ariviso_comparison_rows row WHERE row.candidate_capture_id = ariviso_captures.id OR row.reference_capture_id = ariviso_captures.id)
      AND NOT EXISTS (SELECT 1 FROM ariviso_snapshot_images image WHERE image.capture_id = ariviso_captures.id)
      AND NOT EXISTS (SELECT 1 FROM work_retention_pins pin WHERE pin.run_id = ariviso_captures.run_id AND pin.reason = 'manual')`,
      [now]
    ),
    statement(
      database,
      `DELETE FROM ariviso_shards WHERE run_id IN (
      SELECT preparation.run_id FROM ariviso_historical_preparations preparation JOIN ariviso_runs run ON run.id = preparation.run_id
      WHERE preparation.lease_until <= ? AND run.detail_archived = 1)
      AND NOT EXISTS (SELECT 1 FROM ariviso_captures capture WHERE capture.run_id = ariviso_shards.run_id AND capture.shard_key = ariviso_shards.key)
      AND NOT EXISTS (SELECT 1 FROM work_retention_pins pin WHERE pin.run_id = ariviso_shards.run_id AND pin.reason = 'manual')`,
      [now]
    ),
    statement(
      database,
      `UPDATE ariviso_shards SET expected_json = '{}', discovery_json = NULL WHERE run_id IN (
      SELECT preparation.run_id FROM ariviso_historical_preparations preparation JOIN ariviso_runs run ON run.id = preparation.run_id
      WHERE preparation.lease_until <= ? AND run.detail_archived = 1)
      AND NOT EXISTS (SELECT 1 FROM work_retention_pins pin WHERE pin.run_id = ariviso_shards.run_id AND pin.reason = 'manual')`,
      [now]
    ),
    statement(database, "DELETE FROM ariviso_historical_preparations WHERE lease_until <= ?", [
      now
    ])
  ]);
}
__name(expireHistoricalPreparations, "expireHistoricalPreparations");

// implementation/packages/service/src/prune.ts
async function affectedHistoryOwners(database, runId) {
  const rows = await database.prepare(`WITH affected(id) AS (
    SELECT id FROM ariviso_captures WHERE run_id=?
    UNION SELECT row.reference_capture_id FROM ariviso_comparison_rows row
      JOIN ariviso_comparisons comparison ON comparison.id=row.comparison_id WHERE comparison.run_id=?
    UNION SELECT row.candidate_capture_id FROM ariviso_comparison_rows row
      JOIN ariviso_comparisons comparison ON comparison.id=row.comparison_id WHERE comparison.run_id=?
  ) SELECT capture.run_id FROM ariviso_captures capture JOIN affected ON affected.id=capture.id
    UNION SELECT image.run_id FROM ariviso_images image JOIN ariviso_captures capture ON capture.image_id=image.id
      JOIN affected ON affected.id=capture.id`).bind(runId, runId, runId).all();
  return JSON.stringify([.../* @__PURE__ */ new Set([runId, ...(rows.results ?? []).map((row) => row.run_id)])]);
}
__name(affectedHistoryOwners, "affectedHistoryOwners");
function pruneArchivedImageMetadataStatements(database, ownersJson) {
  return [
    statement(
      database,
      `DELETE FROM ariviso_captures WHERE run_id IN (SELECT value FROM json_each(?))
      AND run_id IN (SELECT id FROM ariviso_runs WHERE detail_archived=1)
      AND NOT EXISTS(SELECT 1 FROM work_retention_pins pin WHERE pin.run_id=ariviso_captures.run_id AND pin.reason='manual')
      AND NOT EXISTS(SELECT 1 FROM ariviso_snapshot_images copy WHERE copy.capture_id=ariviso_captures.id)
      AND NOT EXISTS(SELECT 1 FROM ariviso_comparison_rows row WHERE row.reference_capture_id=ariviso_captures.id OR row.candidate_capture_id=ariviso_captures.id)`,
      [ownersJson]
    ),
    statement(
      database,
      `DELETE FROM ariviso_images WHERE run_id IN (SELECT value FROM json_each(?)) AND bytes_present=0
      AND run_id IN (SELECT id FROM ariviso_runs WHERE detail_archived=1)
      AND NOT EXISTS(SELECT 1 FROM ariviso_captures capture WHERE capture.image_id=ariviso_images.id)
      AND NOT EXISTS(SELECT 1 FROM ariviso_snapshot_images copy WHERE copy.image_id=ariviso_images.id)`,
      [ownersJson]
    )
  ];
}
__name(pruneArchivedImageMetadataStatements, "pruneArchivedImageMetadataStatements");

// implementation/packages/service/src/history.ts
var ArchivedCommandResultError = class extends Error {
  static {
    __name(this, "ArchivedCommandResultError");
  }
  runId;
  commandId;
  constructor(runId, commandId) {
    super("The saved command result is in the private run archive.");
    this.name = "ArchivedCommandResultError";
    this.runId = runId;
    this.commandId = commandId;
  }
};
async function commandRequestDigest(request) {
  const digest2 = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(request));
  return Array.from(new Uint8Array(digest2), (value) => value.toString(16).padStart(2, "0")).join(
    ""
  );
}
__name(commandRequestDigest, "commandRequestDigest");
function archiveEligibilitySql(runAlias) {
  if (!/^[A-Za-z_][A-Za-z0-9_]*$/.test(runAlias)) throw new Error("Invalid SQL alias");
  return `${runAlias}.active = 0 AND ${runAlias}.closed_at IS NOT NULL
    AND ${runAlias}.detail_archived = 0
    AND NOT EXISTS (SELECT 1 FROM work_retained_runs retained
      WHERE retained.id=${runAlias}.id AND retained.byte_state='deleting')
    AND NOT EXISTS (SELECT 1 FROM ariviso_snapshots snapshot
      WHERE snapshot.run_id=${runAlias}.id AND snapshot.reference_eligible=1)
    AND NOT EXISTS (SELECT 1 FROM ariviso_projects project
      LEFT JOIN ariviso_promotions promotion ON promotion.id=project.promotion_id
      JOIN ariviso_snapshots snapshot ON snapshot.id=project.snapshot_id
        OR snapshot.id=promotion.previous_snapshot_id
      WHERE snapshot.run_id=${runAlias}.id)
    AND NOT EXISTS (SELECT 1 FROM work_retention_pins pin
      WHERE pin.run_id=${runAlias}.id AND NOT (
        pin.reason='comparison' AND (
          EXISTS (SELECT 1 FROM ariviso_runs dependent
            WHERE dependent.active=0 AND pin.owner='inherited-by:' || dependent.id)
          OR EXISTS (SELECT 1 FROM ariviso_comparisons comparison
            JOIN ariviso_runs dependent ON dependent.id=comparison.run_id
            WHERE dependent.active=0 AND pin.owner='comparison:' || comparison.id))))
    AND NOT EXISTS (SELECT 1 FROM ariviso_captures capture
      JOIN ariviso_comparison_rows row ON row.reference_capture_id=capture.id OR row.candidate_capture_id=capture.id
      JOIN ariviso_comparisons comparison ON comparison.id=row.comparison_id
      JOIN ariviso_runs dependent ON dependent.id=comparison.run_id
      WHERE capture.run_id=${runAlias}.id AND dependent.id!=${runAlias}.id
        AND dependent.active=1 AND dependent.state IN ('uploading','comparing','reviewing'))`;
}
__name(archiveEligibilitySql, "archiveEligibilitySql");
function archiveGuard(database, input, requireEligible = true) {
  return assertion(
    database,
    `EXISTS (
    SELECT 1 FROM operations_run_archives archive JOIN ariviso_runs run ON run.id=archive.run_id
    JOIN ariviso_projects project ON project.id=run.project_id
    WHERE archive.run_id=? AND archive.generation=? AND archive.state='building'
      AND archive.lease_token=? AND archive.lease_until>?
      AND archive.source_revision=? AND run.revision=?
      AND archive.project_revision=? AND project.revision=?
      ${requireEligible ? `AND ${archiveEligibilitySql("run")}` : ""})`,
    [
      input.runId,
      input.generation,
      input.token,
      input.now,
      input.sourceRevision,
      input.sourceRevision,
      input.projectRevision,
      input.projectRevision
    ]
  );
}
__name(archiveGuard, "archiveGuard");
async function prepareArchivedCommandReplay(database, input) {
  const digest2 = await commandRequestDigest(input.requestJson);
  await atomic(database, [
    // This only prepares a replay hash. The final destructive batch rechecks all roots.
    archiveGuard(database, input, false),
    assertion(
      database,
      `EXISTS(SELECT 1 FROM ariviso_commands command
      JOIN ariviso_comparisons comparison ON comparison.id=command.comparison_id
      WHERE command.id=? AND comparison.run_id=? AND command.request_json=?)`,
      [input.commandId, input.runId, input.requestJson]
    ),
    statement(database, "UPDATE ariviso_commands SET request_digest=? WHERE id=?", [
      digest2,
      input.commandId
    ])
  ]);
}
__name(prepareArchivedCommandReplay, "prepareArchivedCommandReplay");
async function compactRunHistory(database, input) {
  if (!/^[A-Za-z0-9_-]+$/.test(input.runId) || !/^[A-Za-z0-9_-]+$/.test(input.generation) || input.objectKey !== `history/${input.runId}/${input.generation}/manifest.json` || !/^[a-f0-9]{64}$/.test(input.digest) || !Number.isSafeInteger(input.bytes) || input.bytes < 1 || !Number.isSafeInteger(input.pageCount) || input.pageCount < 1) {
    throw new Error("Invalid verified history archive proof");
  }
  const existing = await database.prepare("SELECT state,generation,digest FROM operations_run_archives WHERE run_id=?").bind(input.runId).first();
  if (existing?.state === "ready") {
    if (existing.generation !== input.generation || existing.digest !== input.digest)
      throw new ConflictError("Another archive generation is already linked.");
    return;
  }
  const owners = await affectedHistoryOwners(database, input.runId);
  await atomic(database, [
    archiveGuard(database, input),
    assertion(
      database,
      `NOT EXISTS(SELECT 1 FROM ariviso_commands command JOIN ariviso_comparisons comparison ON comparison.id=command.comparison_id WHERE comparison.run_id=? AND command.request_digest IS NULL)`,
      [input.runId]
    ),
    statement(
      database,
      `DELETE FROM work_tasks WHERE state='complete' AND id IN (SELECT row.id FROM ariviso_comparison_rows row JOIN ariviso_comparisons comparison ON comparison.id=row.comparison_id WHERE comparison.run_id=?)`,
      [input.runId]
    ),
    statement(
      database,
      `DELETE FROM ariviso_comparison_rows WHERE comparison_id IN (SELECT id FROM ariviso_comparisons WHERE run_id=?) AND NOT EXISTS(SELECT 1 FROM ariviso_decisions decision WHERE decision.row_id=ariviso_comparison_rows.id)`,
      [input.runId]
    ),
    statement(
      database,
      `UPDATE ariviso_comparison_rows SET reference_capture_id=NULL,candidate_capture_id=NULL,tuple_json='{}',result_json=NULL WHERE comparison_id IN (SELECT id FROM ariviso_comparisons WHERE run_id=?)`,
      [input.runId]
    ),
    statement(
      database,
      `DELETE FROM ariviso_captures WHERE run_id=? AND NOT EXISTS(SELECT 1 FROM ariviso_snapshot_images copy WHERE copy.capture_id=ariviso_captures.id) AND NOT EXISTS(SELECT 1 FROM ariviso_comparison_rows row WHERE row.reference_capture_id=ariviso_captures.id OR row.candidate_capture_id=ariviso_captures.id)`,
      [input.runId]
    ),
    statement(database, "UPDATE ariviso_captures SET metadata_json='{}' WHERE run_id=?", [
      input.runId
    ]),
    statement(
      database,
      `DELETE FROM ariviso_shards WHERE run_id=? AND NOT EXISTS(SELECT 1 FROM ariviso_captures capture WHERE capture.run_id=ariviso_shards.run_id AND capture.shard_key=ariviso_shards.key)`,
      [input.runId]
    ),
    statement(
      database,
      "UPDATE ariviso_shards SET expected_json='{}',discovery_json=NULL WHERE run_id=?",
      [input.runId]
    ),
    statement(
      database,
      `UPDATE ariviso_commands SET request_json='{}',previous_json='{}',result_json='{}' WHERE comparison_id IN (SELECT id FROM ariviso_comparisons WHERE run_id=?)`,
      [input.runId]
    ),
    statement(database, "DELETE FROM ariviso_audit WHERE run_id=?", [input.runId]),
    statement(database, "DELETE FROM ariviso_lineage WHERE target_run_id=?", [input.runId]),
    statement(
      database,
      "UPDATE ariviso_runs SET plan_json='{}',detail_archived=1,revision=revision+1 WHERE id=?",
      [input.runId]
    ),
    ...pruneArchivedImageMetadataStatements(database, owners),
    statement(
      database,
      "UPDATE ariviso_projects SET revision=revision+1 WHERE id=(SELECT project_id FROM ariviso_runs WHERE id=?)",
      [input.runId]
    ),
    statement(
      database,
      "INSERT INTO ariviso_audit(id,project_id,run_id,action,detail_json,created_at) SELECT ?,project_id,id,'archive-history',?,? FROM ariviso_runs WHERE id=?",
      [
        crypto.randomUUID(),
        JSON.stringify({ generation: input.generation, digest: input.digest }),
        input.now,
        input.runId
      ]
    ),
    statement(
      database,
      `UPDATE operations_run_archives SET state='ready',digest=?,bytes=?,page_count=?,verified_at=?,progress_json='{}',lease_token=NULL,lease_until=NULL WHERE run_id=?`,
      [input.digest, input.bytes, input.pageCount, input.now, input.runId]
    )
  ]);
}
__name(compactRunHistory, "compactRunHistory");

// implementation/packages/service/src/lineage.ts
function materializeLineageStatements(database, targetRunId, proofDigest) {
  const ancestors = `WITH RECURSIVE ancestors(id) AS (
    SELECT source_run_id FROM ariviso_lineage_edges WHERE target_run_id=?
    UNION SELECT edge.source_run_id FROM ariviso_lineage_edges edge JOIN ancestors ON edge.target_run_id=ancestors.id
  )`;
  return [
    assertion(database, `(${ancestors} SELECT COUNT(*) FROM ancestors)<=100000`, [targetRunId]),
    statement(
      database,
      `${ancestors} INSERT INTO ariviso_lineage(source_run_id,target_run_id,proof_digest)
      SELECT id,?,? FROM ancestors WHERE id!=? ON CONFLICT(source_run_id,target_run_id) DO NOTHING`,
      [targetRunId, targetRunId, proofDigest, targetRunId]
    )
  ];
}
__name(materializeLineageStatements, "materializeLineageStatements");

// implementation/packages/service/src/work.ts
function positiveInteger2(value, name) {
  if (!Number.isSafeInteger(value) || value < 1) {
    throw new Error(`${name} must be a positive safe integer`);
  }
}
__name(positiveInteger2, "positiveInteger");
function validateLease(params) {
  positiveInteger2(params.leaseMs, "leaseMs");
  if (!params.token) {
    throw new Error("A unique lease token is required");
  }
}
__name(validateLease, "validateLease");
async function getWork(database, id) {
  return database.prepare("SELECT * FROM work_tasks WHERE id = ?").bind(id).first();
}
__name(getWork, "getWork");
async function claimWork(database, params) {
  validateLease(params);
  await database.prepare(`
    UPDATE work_tasks SET state = 'dead', lease_token = NULL, lease_until = NULL,
      last_error = 'Lease expired after final attempt', updated_at = ?
    WHERE id = ? AND state = 'leased' AND lease_until <= ? AND attempts >= max_attempts
  `).bind(params.now, params.id, params.now).run();
  return database.prepare(`
    UPDATE work_tasks SET state = 'leased', attempts = attempts + 1,
      lease_token = ?, lease_until = ?, updated_at = ?
    WHERE id = ? AND attempts < max_attempts AND (
      (state = 'queued' AND available_at <= ?) OR
      (state = 'leased' AND lease_until <= ?)
    ) RETURNING *
  `).bind(params.token, params.now + params.leaseMs, params.now, params.id, params.now, params.now).first();
}
__name(claimWork, "claimWork");
function workLeaseAssertion(database, params) {
  return assertion(
    database,
    `EXISTS (SELECT 1 FROM work_tasks WHERE id = ?
    AND state = 'leased' AND lease_token = ? AND lease_until > ?)`,
    [params.id, params.token, params.now]
  );
}
__name(workLeaseAssertion, "workLeaseAssertion");
function completeWorkStatement(database, params) {
  return database.prepare(`
    UPDATE work_tasks SET state = 'complete', result = ?, lease_until = NULL,
      updated_at = ? WHERE id = ? AND state = 'leased' AND lease_token = ? AND lease_until > ?
    RETURNING id
  `).bind(params.result, params.now, params.id, params.token, params.now);
}
__name(completeWorkStatement, "completeWorkStatement");
async function failWork(database, params) {
  const result = await database.prepare(`
    UPDATE work_tasks SET state = CASE WHEN attempts >= max_attempts THEN 'dead' ELSE 'queued' END,
      available_at = ?, last_error = ?, lease_token = NULL, lease_until = NULL, updated_at = ?
    WHERE id = ? AND state = 'leased' AND lease_token = ? AND lease_until > ? RETURNING id
  `).bind(
    Math.max(params.now, params.retryAt),
    params.error.slice(0, 4096),
    params.now,
    params.id,
    params.token,
    params.now
  ).first();
  return result !== null;
}
__name(failWork, "failWork");
function statusIntentStatements(database, input) {
  positiveInteger2(input.revision, "revision");
  positiveInteger2(input.maxAttempts, "maxAttempts");
  return [
    database.prepare(`
      INSERT INTO work_checks (id, desired_revision) VALUES (?, ?)
      ON CONFLICT(id) DO UPDATE SET desired_revision = excluded.desired_revision
      WHERE excluded.desired_revision > work_checks.desired_revision
    `).bind(input.checkId, input.revision),
    database.prepare(`
      INSERT INTO work_status_outbox (check_id, revision, run_id, attempt,
        comparison_revision, source_revision, conclusion, details_url, max_attempts, available_at)
      SELECT ?, ?, ?, ?, ?, ?, ?, ?, ?, ?
      WHERE EXISTS (SELECT 1 FROM work_checks WHERE id = ? AND desired_revision = ?)
      ON CONFLICT(check_id, revision) DO UPDATE SET run_id = excluded.run_id,
        attempt = excluded.attempt, comparison_revision = excluded.comparison_revision,
        source_revision = excluded.source_revision, conclusion = excluded.conclusion,
        details_url = excluded.details_url, max_attempts = excluded.max_attempts
    `).bind(
      input.checkId,
      input.revision,
      input.runId,
      input.attempt,
      input.comparisonRevision,
      input.sourceRevision,
      input.conclusion,
      input.detailsUrl,
      input.maxAttempts,
      input.now,
      input.checkId,
      input.revision
    )
  ];
}
__name(statusIntentStatements, "statusIntentStatements");
var closedRunRetentionMs = 30 * 24 * 60 * 60 * 1e3;

// implementation/packages/service/src/service.ts
async function captureProfilesDigest(captures) {
  const profiles = captures.map((capture) => [capture.itemKey, capture.variantKey, capture.profileDigest]).sort(
    (left, right) => JSON.stringify(left) < JSON.stringify(right) ? -1 : JSON.stringify(left) > JSON.stringify(right) ? 1 : 0
  );
  const digest2 = await crypto.subtle.digest(
    "SHA-256",
    new TextEncoder().encode(JSON.stringify(profiles))
  );
  return Array.from(new Uint8Array(digest2), (value) => value.toString(16).padStart(2, "0")).join(
    ""
  );
}
__name(captureProfilesDigest, "captureProfilesDigest");
function identity(itemKey, variantKey) {
  return JSON.stringify([itemKey, variantKey]);
}
__name(identity, "identity");
function requestJson(input) {
  const { now: _now, ...request } = input;
  return JSON.stringify(request);
}
__name(requestJson, "requestJson");
function parseCommandResult(json2) {
  return JSON.parse(json2);
}
__name(parseCommandResult, "parseCommandResult");
var Service = class {
  constructor(database) {
    this.database = database;
  }
  database;
  static {
    __name(this, "Service");
  }
  sql(sql, values = []) {
    return statement(this.database, sql, values);
  }
  guard(sql, values = []) {
    return assertion(this.database, sql, values);
  }
  async one(sql, values = []) {
    const row = await this.sql(sql, values).first();
    if (!row) {
      throw new IncompleteError("The requested record does not exist.");
    }
    return row;
  }
  async rows(sql, values = []) {
    return (await this.sql(sql, values).all()).results ?? [];
  }
  async project(id) {
    return this.one("SELECT * FROM ariviso_projects WHERE id = ?", [id]);
  }
  async run(id) {
    return this.one("SELECT * FROM ariviso_runs WHERE id = ?", [id]);
  }
  async comparison(id) {
    return this.one("SELECT * FROM ariviso_comparisons WHERE id = ?", [id]);
  }
  async comparisonRows(id) {
    return this.rows(
      "SELECT * FROM ariviso_comparison_rows WHERE comparison_id = ? ORDER BY ordinal, id",
      [id]
    );
  }
  async createPolicy(input) {
    const policy = input.policy;
    if (!policy.id || !Number.isFinite(policy.channelThreshold) || policy.channelThreshold < 0 || policy.channelThreshold > 255 || !Number.isSafeInteger(policy.maxChangedPixels) || policy.maxChangedPixels < 0 || !Number.isFinite(policy.maxChangedRatio) || policy.maxChangedRatio < 0 || policy.maxChangedRatio > 1) {
      throw new IncompleteError("Invalid trusted comparison policy.");
    }
    await atomic(this.database, [
      this.sql(
        "INSERT INTO ariviso_policies (digest, policy_json) VALUES (?, ?) ON CONFLICT(digest) DO NOTHING",
        [input.digest, JSON.stringify(policy)]
      ),
      this.guard("EXISTS (SELECT 1 FROM ariviso_policies WHERE digest = ? AND policy_json = ?)", [
        input.digest,
        JSON.stringify(policy)
      ])
    ]);
  }
  async createProject(input) {
    await this.sql(
      "INSERT INTO ariviso_projects (id, repository_id, policy_digest) VALUES (?, ?, ?)",
      [input.id, input.repositoryId, input.policyDigest]
    ).run();
  }
  projectGuard(project) {
    return this.guard("EXISTS (SELECT 1 FROM ariviso_projects WHERE id = ? AND revision = ?)", [
      project.id,
      project.revision
    ]);
  }
  activeGuard(run) {
    return this.guard(
      "EXISTS (SELECT 1 FROM ariviso_runs WHERE id = ? AND active = 1 AND revision = ?)",
      [run.id, run.revision]
    );
  }
  reviewGuard(run, comparisonId) {
    return this.guard(
      "EXISTS (SELECT 1 FROM ariviso_runs run JOIN ariviso_comparisons comparison ON comparison.id = run.comparison_id WHERE run.id = ? AND run.active = 1 AND run.revision = ? AND run.sealed_at IS NOT NULL AND comparison.id = ? AND comparison.state = 'ready')",
      [run.id, run.revision, comparisonId]
    );
  }
  touch(run, now) {
    return [
      this.sql("UPDATE ariviso_projects SET revision = revision + 1 WHERE id = ?", [
        run.project_id
      ]),
      this.sql("UPDATE ariviso_runs SET revision = revision + 1 WHERE id = ?", [run.id]),
      this.sql(
        "UPDATE work_checks SET desired_revision = (SELECT revision FROM ariviso_projects WHERE id = ?) WHERE id IN (SELECT id FROM ariviso_checks WHERE project_id = ?)",
        [run.project_id, run.project_id]
      ),
      this.sql(
        "INSERT INTO ariviso_status_outbox (id, run_id, run_revision, created_at) SELECT ?, id, revision, ? FROM ariviso_runs WHERE id = ?",
        [crypto.randomUUID(), now, run.id]
      )
    ];
  }
  audit(run, action, detail, now, actorId = null) {
    return this.sql(
      "INSERT INTO ariviso_audit (id, project_id, run_id, actor_id, action, detail_json, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)",
      [crypto.randomUUID(), run.project_id, run.id, actorId, action, JSON.stringify(detail), now]
    );
  }
  async reserveRun(input) {
    if (!input.verificationDigest || !input.lineageKey || input.plan.shards.length === 0) {
      throw new IncompleteError("A verified full plan and lineage are required.");
    }
    const existing = await this.sql(
      "SELECT * FROM ariviso_runs WHERE project_id = ? AND external_run_id = ? AND attempt = ?",
      [input.projectId, input.externalRunId, input.attempt]
    ).first();
    if (existing) {
      if (existing.tested_sha !== input.testedSha || existing.plan_digest !== input.plan.digest || existing.lineage_key !== input.lineageKey) {
        throw new ConflictError(
          "The run identity already has different trusted metadata.",
          existing
        );
      }
      return existing;
    }
    const project = await this.project(input.projectId);
    if (new TextEncoder().encode(JSON.stringify(input.plan)).byteLength > 15e5) {
      throw new IncompleteError("The trusted plan is too large for one run record.");
    }
    const keys = /* @__PURE__ */ new Set();
    const identities = /* @__PURE__ */ new Set();
    for (const shard of input.plan.shards) {
      if (keys.has(shard.key) || !shard.discovery && (shard.tests.length === 0 || shard.captures.length === 0) || shard.discovery && (!shard.discovery.executorDigest || !shard.discovery.configurationDigest)) {
        throw new IncompleteError("Each trusted shard needs unique identity, tests, and captures.");
      }
      keys.add(shard.key);
      for (const capture of shard.captures) {
        const key2 = identity(capture.itemKey, capture.variantKey);
        if (identities.has(key2) || !shard.tests.includes(capture.testId)) {
          throw new IncompleteError(
            "The trusted plan contains a duplicate or unaccounted capture."
          );
        }
        identities.add(key2);
      }
    }
    for (const key2 of input.rerunShardKeys) {
      if (!keys.has(key2)) {
        throw new IncompleteError("An unknown shard was marked as rerun.");
      }
    }
    const statements = [
      this.projectGuard(project),
      this.guard(
        "NOT EXISTS (SELECT 1 FROM ariviso_runs WHERE project_id = ? AND external_run_id = ? AND attempt >= ?)",
        [input.projectId, input.externalRunId, input.attempt]
      ),
      this.sql(
        "UPDATE ariviso_runs SET active = 0, state = 'superseded', closed_at = COALESCE(closed_at, ?), revision = revision + 1 WHERE project_id = ? AND external_run_id = ? AND active = 1",
        [input.now, input.projectId, input.externalRunId]
      ),
      this.sql(
        "UPDATE work_retained_runs SET closed_at = COALESCE(closed_at, ?) WHERE id IN (SELECT id FROM ariviso_runs WHERE project_id = ? AND external_run_id = ? AND active = 0)",
        [input.now, input.projectId, input.externalRunId]
      ),
      this.sql(
        "DELETE FROM work_retention_pins WHERE reason = 'review' AND owner IN (SELECT 'review:' || id FROM ariviso_runs WHERE project_id = ? AND external_run_id = ? AND active = 0)",
        [input.projectId, input.externalRunId]
      ),
      this.sql(
        "INSERT INTO ariviso_runs (id, project_id, external_run_id, attempt, kind, tested_sha, lineage_key, plan_digest, plan_json, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
        [
          input.id,
          input.projectId,
          input.externalRunId,
          input.attempt,
          input.kind,
          input.testedSha,
          input.lineageKey,
          input.plan.digest,
          JSON.stringify(input.plan),
          input.now
        ]
      ),
      this.sql("INSERT INTO work_retained_runs (id, object_prefix) VALUES (?, ?)", [
        input.id,
        `runs/${input.id}/`
      ]),
      this.sql("INSERT INTO work_retention_pins (run_id, owner, reason) VALUES (?, ?, 'review')", [
        input.id,
        `review:${input.id}`
      ])
    ];
    if (input.maximumActiveRuns !== void 0) {
      if (!Number.isSafeInteger(input.maximumActiveRuns) || input.maximumActiveRuns < 1)
        throw new IncompleteError("The active run admission limit is invalid.");
      statements.push(
        this.guard(
          "(SELECT COUNT(*) FROM ariviso_runs WHERE active=1 AND state IN ('uploading','comparing')) <= ?",
          [input.maximumActiveRuns]
        )
      );
    }
    for (const sourceId of new Set(input.verifiedRelatedRunIds)) {
      statements.push(
        this.guard("EXISTS (SELECT 1 FROM ariviso_runs WHERE id = ? AND project_id = ?)", [
          sourceId,
          input.projectId
        ])
      );
      statements.push(
        this.sql(
          "INSERT INTO ariviso_lineage_edges (source_run_id, target_run_id, proof_digest) VALUES (?, ?, ?)",
          [sourceId, input.id, input.verificationDigest]
        )
      );
    }
    statements.push(
      ...materializeLineageStatements(this.database, input.id, input.verificationDigest)
    );
    for (const sha of new Set(input.verifiedAncestorShas)) {
      statements.push(
        this.sql(
          "INSERT INTO ariviso_ancestry (run_id, ancestor_sha, proof_digest) VALUES (?, ?, ?)",
          [input.id, sha, input.verificationDigest]
        )
      );
    }
    for (const shard of input.plan.shards) {
      statements.push(
        this.sql(
          "INSERT INTO ariviso_shards (run_id, key, profile_digest, expected_json) VALUES (?, ?, ?, ?)",
          [input.id, shard.key, shard.profileDigest, JSON.stringify(shard)]
        )
      );
    }
    if (input.inheritFromRunId) {
      statements.push(
        this.guard(
          "EXISTS (SELECT 1 FROM ariviso_runs WHERE id = ? AND project_id = ? AND external_run_id = ? AND tested_sha = ? AND plan_digest = ? AND attempt < ?)",
          [
            input.inheritFromRunId,
            input.projectId,
            input.externalRunId,
            input.testedSha,
            input.plan.digest,
            input.attempt
          ]
        )
      );
      for (const shard of input.plan.shards) {
        if (input.rerunShardKeys.includes(shard.key)) continue;
        const inherited = input.verifiedInheritedShards?.find((entry) => entry.key === shard.key);
        if (!inherited) {
          throw new IncompleteError(
            "Each inherited shard requires verified manifest and full capture-profile identity."
          );
        }
        statements.push(
          this.guard(
            "EXISTS (SELECT 1 FROM ariviso_shards WHERE run_id = ? AND key = ? AND manifest_digest = ? AND full_profile_digest = ?)",
            [
              input.inheritFromRunId,
              shard.key,
              inherited.manifestDigest,
              inherited.captureProfileDigest
            ]
          )
        );
        statements.push(
          this.guard(
            "EXISTS (SELECT 1 FROM ariviso_shards WHERE run_id = ? AND key = ? AND state = 'complete' AND profile_digest = ?)",
            [input.inheritFromRunId, shard.key, shard.profileDigest]
          )
        );
        statements.push(
          this.sql(
            "UPDATE ariviso_shards SET state = 'complete', manifest_digest = (SELECT manifest_digest FROM ariviso_shards WHERE run_id = ? AND key = ?), full_profile_digest = ?, expected_json = (SELECT expected_json FROM ariviso_shards WHERE run_id = ? AND key = ?), discovery_json = (SELECT discovery_json FROM ariviso_shards WHERE run_id = ? AND key = ?), source_run_id = ?, source_attempt = (SELECT COALESCE(shard.source_attempt, source.attempt) FROM ariviso_shards shard JOIN ariviso_runs source ON source.id = shard.run_id WHERE shard.run_id = ? AND shard.key = ?) WHERE run_id = ? AND key = ?",
            [
              input.inheritFromRunId,
              shard.key,
              inherited.captureProfileDigest,
              input.inheritFromRunId,
              shard.key,
              input.inheritFromRunId,
              shard.key,
              input.inheritFromRunId,
              input.inheritFromRunId,
              shard.key,
              input.id,
              shard.key
            ]
          )
        );
        statements.push(
          this.sql(
            "INSERT INTO ariviso_captures (id, run_id, shard_key, item_key, variant_key, ordinal, image_id, profile_digest, test_id, test_retry, metadata_json) SELECT ? || ':' || id, ?, shard_key, item_key, variant_key, ordinal, image_id, profile_digest, test_id, test_retry, metadata_json FROM ariviso_captures WHERE run_id = ? AND shard_key = ?",
            [input.id, input.id, input.inheritFromRunId, shard.key]
          )
        );
      }
    }
    statements.push(
      this.sql(
        "INSERT INTO work_retention_pins (run_id, owner, reason) SELECT DISTINCT image.run_id, ?, 'comparison' FROM ariviso_captures capture JOIN ariviso_images image ON image.id = capture.image_id WHERE capture.run_id = ? AND image.run_id != ? ON CONFLICT(run_id, owner) DO NOTHING",
        [`inherited-by:${input.id}`, input.id, input.id]
      )
    );
    statements.push(
      this.sql("UPDATE ariviso_projects SET revision = revision + 1 WHERE id = ?", [project.id])
    );
    statements.push(
      this.sql(
        "UPDATE work_checks SET desired_revision = (SELECT revision FROM ariviso_projects WHERE id = ?) WHERE id IN (SELECT id FROM ariviso_checks WHERE project_id = ?)",
        [project.id, project.id]
      )
    );
    await atomic(this.database, statements);
    return this.run(input.id);
  }
  /** Call only after the trusted decoder and R2 write have both succeeded. */
  async registerImage(image) {
    const run = await this.run(image.runId);
    await atomic(this.database, [
      this.activeGuard(run),
      this.guard(
        "EXISTS (SELECT 1 FROM ariviso_runs WHERE id = ? AND sealed_at IS NULL AND state = 'uploading')",
        [run.id]
      ),
      this.guard("EXISTS (SELECT 1 FROM work_retained_runs WHERE id = ? AND byte_state = 'live')", [
        run.id
      ]),
      this.sql(
        "INSERT INTO ariviso_images (id, run_id, digest, object_key, content_type, bytes, width, height) VALUES (?, ?, ?, ?, ?, ?, ?, ?) ON CONFLICT(id) DO NOTHING",
        [
          image.id,
          image.runId,
          image.digest,
          image.objectKey,
          image.contentType,
          image.bytes,
          image.width,
          image.height
        ]
      ),
      this.guard(
        "EXISTS (SELECT 1 FROM ariviso_images WHERE id = ? AND run_id = ? AND digest = ? AND object_key = ? AND bytes = ? AND width = ? AND height = ? AND content_type = ?)",
        [
          image.id,
          image.runId,
          image.digest,
          image.objectKey,
          image.bytes,
          image.width,
          image.height,
          image.contentType
        ]
      )
    ]);
  }
  async commitShard(input) {
    const run = await this.run(input.runId);
    const shard = await this.one("SELECT * FROM ariviso_shards WHERE run_id = ? AND key = ?", [run.id, input.key]);
    if (shard.state === "complete") {
      if (shard.manifest_digest !== input.manifestDigest) {
        throw new ConflictError("The sealed shard has a different manifest.");
      }
      return;
    }
    let expected = JSON.parse(shard.expected_json);
    if (expected.discovery) {
      const proof = input.verifiedDiscovery;
      if (!proof || proof.executorDigest !== expected.discovery.executorDigest || proof.configurationDigest !== expected.discovery.configurationDigest || proof.externalRunId !== run.external_run_id || proof.attempt !== run.attempt || proof.testedSha !== run.tested_sha || !proof.verificationDigest || !proof.inventoryDigest || !proof.jobId) {
        throw new IncompleteError(
          "Candidate discovery needs verified successful-job evidence from the trusted executor and configuration."
        );
      }
      const identities = new Set(
        proof.captures.map((capture) => identity(capture.itemKey, capture.variantKey))
      );
      if (proof.tests.length === 0 || proof.captures.length === 0 || new Set(proof.tests).size !== proof.tests.length || identities.size !== proof.captures.length || proof.captures.some((capture) => !proof.tests.includes(capture.testId))) {
        throw new IncompleteError(
          "The verified candidate inventory is empty, duplicated, or incomplete."
        );
      }
      expected = { ...expected, tests: proof.tests, captures: proof.captures };
    } else if (input.verifiedDiscovery) {
      throw new IncompleteError("This trusted shard does not permit candidate discovery.");
    }
    const outcomes = new Map(input.finalTestOutcomes.map((outcome) => [outcome.testId, outcome]));
    if (outcomes.size !== expected.tests.length || outcomes.size !== input.finalTestOutcomes.length) {
      throw new IncompleteError("The shard must report every required test exactly once.");
    }
    for (const testId of expected.tests) {
      if (outcomes.get(testId)?.status !== "passed") {
        throw new IncompleteError("A required test did not pass its final attempt.");
      }
    }
    const captures = new Map(
      input.captures.map((capture) => [identity(capture.itemKey, capture.variantKey), capture])
    );
    if (captures.size !== expected.captures.length || captures.size !== input.captures.length) {
      throw new IncompleteError("The shard must contain every required capture exactly once.");
    }
    for (const required of expected.captures) {
      const capture = captures.get(identity(required.itemKey, required.variantKey));
      if (!capture || capture.testId !== required.testId || !(expected.environmentProfileDigests ?? [expected.profileDigest]).includes(
        capture.environmentProfileDigest
      ) || capture.testRetry !== outcomes.get(required.testId)?.retry) {
        throw new IncompleteError(
          "A capture does not match the trusted plan or final successful test attempt."
        );
      }
    }
    for (let offset = 0; offset < input.captures.length; offset += 100) {
      const captures2 = JSON.stringify(
        input.captures.slice(offset, offset + 100).map((capture) => ({ ...capture, metadataJson: JSON.stringify(capture.metadata) }))
      );
      await atomic(this.database, [
        this.activeGuard(run),
        this.guard("EXISTS (SELECT 1 FROM ariviso_runs WHERE id = ? AND sealed_at IS NULL)", [
          run.id
        ]),
        this.guard(
          "EXISTS (SELECT 1 FROM work_retained_runs WHERE id = ? AND byte_state = 'live')",
          [run.id]
        ),
        this.guard(
          "NOT EXISTS (SELECT 1 FROM json_each(?) staged WHERE NOT EXISTS (SELECT 1 FROM ariviso_images image WHERE image.id = json_extract(staged.value, '$.imageId') AND image.run_id = ? AND image.bytes_present = 1))",
          [captures2, run.id]
        ),
        this.sql(
          "INSERT INTO ariviso_captures (id, run_id, shard_key, item_key, variant_key, ordinal, image_id, profile_digest, test_id, test_retry, metadata_json) SELECT json_extract(value, '$.id'), ?, ?, json_extract(value, '$.itemKey'), json_extract(value, '$.variantKey'), json_extract(value, '$.ordinal'), json_extract(value, '$.imageId'), json_extract(value, '$.profileDigest'), json_extract(value, '$.testId'), json_extract(value, '$.testRetry'), json_extract(value, '$.metadataJson') FROM json_each(?) WHERE true ON CONFLICT(id) DO NOTHING",
          [run.id, input.key, captures2]
        ),
        this.guard(
          "NOT EXISTS (SELECT 1 FROM json_each(?) staged WHERE NOT EXISTS (SELECT 1 FROM ariviso_captures capture WHERE capture.id = json_extract(staged.value, '$.id') AND capture.run_id = ? AND capture.shard_key = ? AND capture.item_key = json_extract(staged.value, '$.itemKey') AND capture.variant_key = json_extract(staged.value, '$.variantKey') AND capture.ordinal = json_extract(staged.value, '$.ordinal') AND capture.image_id = json_extract(staged.value, '$.imageId') AND capture.profile_digest = json_extract(staged.value, '$.profileDigest') AND capture.test_id = json_extract(staged.value, '$.testId') AND capture.test_retry = json_extract(staged.value, '$.testRetry') AND capture.metadata_json = json_extract(staged.value, '$.metadataJson')))",
          [captures2, run.id, input.key]
        )
      ]);
    }
    const profileDigest = await captureProfilesDigest(input.captures);
    await atomic(this.database, [
      this.activeGuard(run),
      this.guard("(SELECT count(*) FROM ariviso_captures WHERE run_id = ? AND shard_key = ?) = ?", [
        run.id,
        input.key,
        input.captures.length
      ]),
      this.sql(
        "UPDATE ariviso_shards SET state = 'complete', manifest_digest = ?, full_profile_digest = ?, expected_json = ?, discovery_json = ?, source_run_id = ?, source_attempt = ? WHERE run_id = ? AND key = ? AND state = 'pending'",
        [
          input.manifestDigest,
          profileDigest,
          JSON.stringify(expected),
          input.verifiedDiscovery ? JSON.stringify(input.verifiedDiscovery) : null,
          run.id,
          run.attempt,
          run.id,
          input.key
        ]
      ),
      this.guard(
        "EXISTS (SELECT 1 FROM ariviso_shards WHERE run_id = ? AND key = ? AND manifest_digest = ? AND state = 'complete')",
        [run.id, input.key, input.manifestDigest]
      )
    ]);
  }
  async failRun(input) {
    const run = await this.run(input.runId);
    if (run.state === "failed") {
      return this.status(run.id);
    }
    const project = await this.project(run.project_id);
    await atomic(this.database, [
      this.projectGuard(project),
      this.activeGuard(run),
      this.guard(
        "EXISTS (SELECT 1 FROM ariviso_runs WHERE id = ? AND sealed_at IS NULL AND state = 'uploading')",
        [run.id]
      ),
      this.sql("UPDATE ariviso_runs SET state = 'failed' WHERE id = ?", [run.id]),
      this.audit(run, "capture-failed", { reason: input.reason.slice(0, 4096) }, input.now),
      ...this.touch(run, input.now)
    ]);
    return this.status(run.id);
  }
  async sealRun(input) {
    const run = await this.run(input.runId);
    if (run.sealed_at !== null) {
      return run;
    }
    await atomic(this.database, [
      this.activeGuard(run),
      this.guard("EXISTS (SELECT 1 FROM ariviso_runs WHERE id = ? AND state = 'uploading')", [
        run.id
      ]),
      this.guard(
        "NOT EXISTS (SELECT 1 FROM ariviso_shards WHERE run_id = ? AND state != 'complete') AND EXISTS (SELECT 1 FROM ariviso_captures WHERE run_id = ?)",
        [run.id, run.id]
      ),
      this.guard(
        "NOT EXISTS (SELECT 1 FROM ariviso_captures c JOIN ariviso_images i ON i.id = c.image_id WHERE c.run_id = ? AND i.bytes_present != 1)",
        [run.id]
      ),
      this.sql("UPDATE ariviso_runs SET sealed_at = ?, state = 'comparing' WHERE id = ?", [
        input.now,
        run.id
      ]),
      this.audit(run, "seal", {}, input.now),
      ...this.touch(run, input.now)
    ]);
    return this.run(run.id);
  }
  async referenceCandidates(projectId) {
    return this.rows(
      "SELECT snapshot.* FROM ariviso_snapshots snapshot WHERE snapshot.project_id = ? AND snapshot.reference_eligible = 1 AND NOT EXISTS (SELECT 1 FROM ariviso_snapshot_images image WHERE image.snapshot_id = snapshot.id AND image.copied != 1) ORDER BY snapshot.created_at DESC, snapshot.id",
      [projectId]
    );
  }
  async selectReferenceSnapshot(runId, historical = false) {
    const run = await this.run(runId);
    const project = await this.project(run.project_id);
    if (project.fresh_setup && project.snapshot_id === null) return null;
    const snapshot = await this.sql(
      "SELECT snapshot.* FROM ariviso_snapshots snapshot JOIN ariviso_ancestry ancestry ON ancestry.ancestor_sha = snapshot.tested_sha AND ancestry.run_id = ? WHERE snapshot.project_id = ? AND snapshot.reference_eligible = 1 AND (? != 'main' OR snapshot.id = ?) AND NOT EXISTS (SELECT 1 FROM ariviso_snapshot_images image WHERE image.snapshot_id = snapshot.id AND image.copied != 1) ORDER BY (snapshot.id = ?) DESC, snapshot.created_at DESC, snapshot.id LIMIT 1",
      [
        run.id,
        project.id,
        historical ? "historical" : run.kind,
        project.snapshot_id,
        project.snapshot_id
      ]
    ).first();
    if (!snapshot) {
      throw new IncompleteError(
        "No retained accepted ancestor is eligible. Verify ancestry or capture current main."
      );
    }
    return snapshot.id;
  }
  async createComparison(input) {
    const run = await this.run(input.runId);
    const project = await this.project(run.project_id);
    const historical = input.purpose === "historical";
    if (historical && (!Number.isSafeInteger(input.expectedCaptureCount) || (input.expectedCaptureCount ?? 0) < 1)) {
      throw new IncompleteError("The complete stored capture inventory is required.");
    }
    const guards = [
      this.projectGuard(project),
      this.guard("EXISTS (SELECT 1 FROM ariviso_projects WHERE id = ? AND baseline_revision = ?)", [
        project.id,
        input.expectedBaselineRevision ?? project.baseline_revision
      ]),
      historical ? this.guard(
        "EXISTS (SELECT 1 FROM ariviso_runs WHERE id = ? AND active = 0 AND revision = ?)",
        [run.id, run.revision]
      ) : this.activeGuard(run),
      this.guard("EXISTS (SELECT 1 FROM ariviso_runs WHERE id = ? AND sealed_at IS NOT NULL)", [
        run.id
      ])
    ];
    if (input.referenceSnapshotId) {
      guards.push(
        this.guard(
          "EXISTS (SELECT 1 FROM ariviso_snapshots s JOIN ariviso_ancestry a ON a.ancestor_sha = s.tested_sha AND a.run_id = ? WHERE s.id = ? AND s.project_id = ? AND s.reference_eligible = 1)",
          [run.id, input.referenceSnapshotId, project.id]
        )
      );
      guards.push(
        this.guard(
          "NOT EXISTS (SELECT 1 FROM ariviso_snapshot_images WHERE snapshot_id = ? AND copied != 1)",
          [input.referenceSnapshotId]
        )
      );
      guards.push(
        this.sql(
          "INSERT OR IGNORE INTO ariviso_pins (snapshot_id, reason, owner_id) VALUES (?, ?, ?)",
          [input.referenceSnapshotId, historical ? "historical" : "comparison", input.id]
        )
      );
      guards.push(
        this.sql(
          "INSERT OR IGNORE INTO work_retention_pins (run_id, owner, reason) SELECT run_id, ?, ? FROM ariviso_snapshots WHERE id = ?",
          [
            historical ? historicalOwner(input.id) : `comparison:${input.id}`,
            historical ? "manual" : "comparison",
            input.referenceSnapshotId
          ]
        )
      );
    } else {
      guards.push(
        this.guard(
          "EXISTS (SELECT 1 FROM ariviso_projects WHERE id = ? AND fresh_setup = 1 AND snapshot_id IS NULL)",
          [project.id]
        )
      );
    }
    if (run.kind === "main" && !historical) {
      guards.push(
        this.guard("EXISTS (SELECT 1 FROM ariviso_projects WHERE id = ? AND snapshot_id IS ?)", [
          project.id,
          input.referenceSnapshotId
        ])
      );
    }
    if (historical) {
      guards.push(
        this.guard(
          "EXISTS (SELECT 1 FROM work_retained_runs WHERE id = ? AND byte_state = 'live')",
          [run.id]
        ),
        this.guard("(SELECT COUNT(*) FROM ariviso_captures WHERE run_id = ?) = ?", [
          run.id,
          input.expectedCaptureCount ?? 0
        ]),
        this.guard(
          "NOT EXISTS (SELECT 1 FROM ariviso_captures capture LEFT JOIN ariviso_images image ON image.id = capture.image_id WHERE capture.run_id = ? AND (image.id IS NULL OR image.bytes_present != 1 OR image.validated != 1))",
          [run.id]
        ),
        this.sql(
          "INSERT OR IGNORE INTO work_retention_pins(run_id, owner, reason) SELECT ?, ?, 'manual' UNION SELECT image.run_id, ?, 'manual' FROM ariviso_captures capture JOIN ariviso_images image ON image.id = capture.image_id WHERE capture.run_id = ?",
          [run.id, historicalOwner(input.id), historicalOwner(input.id), run.id]
        )
      );
      if (run.detail_archived) {
        guards.push(
          this.guard(
            "EXISTS (SELECT 1 FROM ariviso_historical_preparations WHERE id = ? AND run_id = ? AND lease_until > ?)",
            [input.id, run.id, input.now]
          )
        );
      }
      guards.push(this.sql("DELETE FROM ariviso_historical_preparations WHERE id = ?", [input.id]));
    }
    const tuple = `json_object('projectId', ?, 'itemKey', c.item_key, 'variantKey', c.variant_key, 'referenceDigest', ri.digest, 'candidateDigest', ci.digest, 'referenceProfileDigest', r.profile_digest, 'candidateProfileDigest', c.profile_digest, 'comparisonPolicyDigest', ?)`;
    const removalTuple = `json_object('projectId', ?, 'itemKey', r.item_key, 'variantKey', r.variant_key, 'referenceDigest', ri.digest, 'candidateDigest', NULL, 'referenceProfileDigest', r.profile_digest, 'candidateProfileDigest', NULL, 'comparisonPolicyDigest', ?)`;
    await atomic(this.database, [
      ...guards,
      this.sql(
        "INSERT INTO ariviso_comparisons (id, run_id, reference_snapshot_id, baseline_revision, policy_digest, ordinal, created_at, purpose) SELECT ?, ?, ?, ?, ?, COALESCE(MAX(ordinal), 0) + 1, ?, ? FROM ariviso_comparisons WHERE run_id = ?",
        [
          input.id,
          run.id,
          input.referenceSnapshotId,
          project.baseline_revision,
          project.policy_digest,
          input.now,
          historical ? "historical" : "review",
          run.id
        ]
      ),
      this.sql(
        `INSERT INTO ariviso_comparison_rows (id, comparison_id, item_key, variant_key, ordinal, reference_capture_id, candidate_capture_id, tuple_json, outcome) SELECT ? || ':' || c.id, ?, c.item_key, c.variant_key, c.ordinal, r.id, c.id, ${tuple}, CASE WHEN r.id IS NULL THEN 'changed' ELSE 'pending' END FROM ariviso_captures c JOIN ariviso_images ci ON ci.id = c.image_id LEFT JOIN (SELECT capture.* FROM ariviso_snapshot_images si JOIN ariviso_captures capture ON capture.id = si.capture_id WHERE si.snapshot_id = ?) r ON r.item_key = c.item_key AND r.variant_key = c.variant_key LEFT JOIN ariviso_images ri ON ri.id = r.image_id WHERE c.run_id = ?`,
        [input.id, input.id, project.id, project.policy_digest, input.referenceSnapshotId, run.id]
      ),
      this.sql(
        `INSERT INTO ariviso_comparison_rows (id, comparison_id, item_key, variant_key, ordinal, reference_capture_id, candidate_capture_id, tuple_json, outcome) SELECT ? || ':removed:' || r.id, ?, r.item_key, r.variant_key, (SELECT COALESCE(MAX(ordinal), 0) + 1 FROM ariviso_captures WHERE run_id = ?) + r.ordinal, r.id, NULL, ${removalTuple}, 'changed' FROM ariviso_snapshot_images si JOIN ariviso_captures r ON r.id = si.capture_id JOIN ariviso_images ri ON ri.id = r.image_id WHERE si.snapshot_id = ? AND NOT EXISTS (SELECT 1 FROM ariviso_captures c WHERE c.run_id = ? AND c.item_key = r.item_key AND c.variant_key = r.variant_key)`,
        [
          input.id,
          input.id,
          run.id,
          project.id,
          project.policy_digest,
          input.referenceSnapshotId,
          run.id
        ]
      ),
      this.sql(
        "INSERT INTO work_tasks (id, kind, payload, max_attempts, available_at, created_at, updated_at) SELECT id, 'compare', json_object('taskId', id), ?, ?, ?, ? FROM ariviso_comparison_rows WHERE comparison_id = ? AND outcome = 'pending'",
        [input.maxAttempts, input.now, input.now, input.now, input.id]
      ),
      ...historical ? [] : [
        this.sql(
          "UPDATE ariviso_runs SET comparison_id = ?, state = 'comparing' WHERE id = ?",
          [input.id, run.id]
        ),
        this.audit(
          run,
          "compare",
          { comparisonId: input.id, referenceSnapshotId: input.referenceSnapshotId },
          input.now
        ),
        ...this.touch(run, input.now)
      ]
    ]);
    return this.comparison(input.id);
  }
  async getComparisonTask(taskId) {
    const row = await this.one("SELECT * FROM ariviso_comparison_rows WHERE id = ?", [
      taskId
    ]);
    const comparison = await this.comparison(row.comparison_id);
    const readImage = /* @__PURE__ */ __name(async (captureId, reference) => {
      if (!captureId) return null;
      const image = reference ? await this.one(
        "SELECT i.id, si.object_key, i.digest, i.width, i.height, i.bytes, i.content_type FROM ariviso_snapshot_images si JOIN ariviso_images i ON i.id = si.image_id WHERE si.snapshot_id = ? AND si.capture_id = ? AND si.copied = 1",
        [comparison.reference_snapshot_id, captureId]
      ) : await this.one(
        "SELECT i.* FROM ariviso_images i JOIN ariviso_captures c ON c.image_id = i.id WHERE c.id = ? AND i.bytes_present = 1",
        [captureId]
      );
      return {
        imageId: image.id,
        objectKey: image.object_key,
        digest: image.digest,
        width: image.width,
        height: image.height,
        bytes: image.bytes,
        contentType: image.content_type
      };
    }, "readImage");
    const policyRecord = await this.one(
      "SELECT policy_json FROM ariviso_policies WHERE digest = ?",
      [comparison.policy_digest]
    );
    const policy = JSON.parse(policyRecord.policy_json);
    return {
      id: row.id,
      comparisonId: comparison.id,
      runId: comparison.run_id,
      policyDigest: comparison.policy_digest,
      policy,
      reference: await readImage(row.reference_capture_id, true),
      candidate: await readImage(row.candidate_capture_id, false)
    };
  }
  async getComparisonTaskState(taskId) {
    const state = await this.sql(
      "SELECT run.active, run.comparison_id, row.comparison_id AS row_comparison_id, comparison.purpose, comparison.state AS comparison_state FROM ariviso_comparison_rows row JOIN ariviso_comparisons comparison ON comparison.id = row.comparison_id JOIN ariviso_runs run ON run.id = comparison.run_id WHERE row.id = ?",
      [taskId]
    ).first();
    if (!state) {
      const archived = await this.sql(
        "SELECT 1 FROM ariviso_comparisons comparison JOIN ariviso_runs run ON run.id=comparison.run_id WHERE (run.detail_archived=1 OR EXISTS (SELECT 1 FROM operations_comparison_archives archive WHERE archive.comparison_id=comparison.id AND archive.state='ready')) AND substr(?,1,length(comparison.id)+1)=comparison.id || ':' LIMIT 1",
        [taskId]
      ).first();
      if (archived) return { state: "superseded" };
      throw new IncompleteError("The comparison task has not been scheduled.");
    }
    if (state.purpose === "historical" && state.comparison_state === "invalidated") {
      return { state: "dead" };
    }
    if (state.purpose !== "historical" && (!state.active || state.comparison_id !== state.row_comparison_id)) {
      return { state: "superseded" };
    }
    const task = await getWork(this.database, taskId);
    if (!task) {
      throw new IncompleteError("The comparison task has not been scheduled.");
    }
    return task;
  }
  async claimComparisonTask(input) {
    const state = await this.getComparisonTaskState(input.taskId);
    if (state.state === "superseded" || state.state === "dead" || state.state === "complete")
      return null;
    const claimed = await claimWork(this.database, {
      id: input.taskId,
      token: input.owner,
      now: input.now,
      leaseMs: input.leaseMilliseconds
    });
    if (!claimed) return null;
    return this.getComparisonTask(input.taskId);
  }
  async failComparisonTask(input) {
    return failWork(this.database, {
      id: input.taskId,
      token: input.owner,
      now: input.now,
      retryAt: input.retryAt,
      error: input.error
    });
  }
  async commitComparisonResult(input) {
    const row = await this.one("SELECT * FROM ariviso_comparison_rows WHERE id = ?", [
      input.taskId
    ]);
    const tuple = JSON.parse(row.tuple_json);
    const result = tuple.referenceProfileDigest !== tuple.candidateProfileDigest ? { ...input.result, outcome: "changed" } : input.result;
    const comparison = await this.comparison(row.comparison_id);
    const run = await this.run(comparison.run_id);
    if (row.result_json) {
      if (row.result_json !== JSON.stringify(result)) {
        throw new ConflictError("A comparison result is immutable.");
      }
      return;
    }
    if (!Number.isFinite(input.result.ratio) || input.result.ratio < 0 || input.result.ratio > 1 || !Number.isSafeInteger(input.result.changedPixels) || input.result.changedPixels < 0) {
      throw new IncompleteError("The comparison result is invalid.");
    }
    const artifactStatements = [];
    for (const artifact of input.artifacts ?? []) {
      if (artifact.runId !== run.id) {
        throw new IncompleteError("Derived images belong to the comparison run.");
      }
      artifactStatements.push(
        this.sql(
          "INSERT INTO ariviso_images (id, run_id, digest, object_key, content_type, bytes, width, height, role) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?) ON CONFLICT(id) DO NOTHING",
          [
            artifact.id,
            artifact.runId,
            artifact.digest,
            artifact.objectKey,
            artifact.contentType,
            artifact.bytes,
            artifact.width,
            artifact.height,
            artifact.role
          ]
        )
      );
      artifactStatements.push(
        this.guard(
          "EXISTS (SELECT 1 FROM ariviso_images WHERE id = ? AND run_id = ? AND digest = ? AND object_key = ? AND content_type = ? AND bytes = ? AND width = ? AND height = ? AND role = ? AND bytes_present = 1)",
          [
            artifact.id,
            artifact.runId,
            artifact.digest,
            artifact.objectKey,
            artifact.contentType,
            artifact.bytes,
            artifact.width,
            artifact.height,
            artifact.role
          ]
        )
      );
    }
    if (input.result.maskImageId) {
      artifactStatements.push(
        this.guard(
          "EXISTS (SELECT 1 FROM ariviso_images WHERE id = ? AND run_id = ? AND role = 'mask' AND bytes_present = 1)",
          [input.result.maskImageId, run.id]
        )
      );
    }
    if (input.result.thumbnailImageId) {
      artifactStatements.push(
        this.guard(
          "EXISTS (SELECT 1 FROM ariviso_images WHERE id = ? AND run_id = ? AND role = 'thumbnail' AND bytes_present = 1)",
          [input.result.thumbnailImageId, run.id]
        )
      );
    }
    await atomic(this.database, [
      workLeaseAssertion(this.database, {
        id: input.taskId,
        token: input.leaseOwner,
        now: input.now
      }),
      ...comparison.purpose === "historical" ? [historicalGuard(this.database, comparison.id)] : [
        this.activeGuard(run),
        this.guard("EXISTS (SELECT 1 FROM ariviso_runs WHERE id = ? AND comparison_id = ?)", [
          run.id,
          comparison.id
        ])
      ],
      this.guard(
        "EXISTS (SELECT 1 FROM ariviso_comparisons WHERE id = ? AND state = 'comparing')",
        [comparison.id]
      ),
      this.guard(
        "EXISTS (SELECT 1 FROM ariviso_comparison_rows WHERE id = ? AND result_json IS NULL)",
        [row.id]
      ),
      ...artifactStatements,
      this.sql("UPDATE ariviso_comparison_rows SET outcome = ?, result_json = ? WHERE id = ?", [
        result.outcome,
        JSON.stringify(result),
        row.id
      ]),
      completeWorkStatement(this.database, {
        id: input.taskId,
        token: input.leaseOwner,
        now: input.now,
        result: JSON.stringify(result)
      })
    ]);
  }
  acceptanceValiditySql() {
    return `decision.verdict = 'approved' AND decision.revoked = 0
      AND json_extract(decision.tuple_json,'$.referenceDigest') IS json_extract(row.tuple_json,'$.referenceDigest')
      AND json_extract(decision.tuple_json,'$.candidateDigest') IS json_extract(row.tuple_json,'$.candidateDigest')
      AND decision.tuple_json = row.tuple_json
      AND EXISTS (SELECT 1 FROM ariviso_comparison_rows source_row
        JOIN ariviso_comparisons source_comparison ON source_comparison.id = source_row.comparison_id
        JOIN ariviso_runs source_run ON source_run.id = source_comparison.run_id
        JOIN ariviso_comparisons target_comparison ON target_comparison.id = row.comparison_id
        JOIN ariviso_runs target_run ON target_run.id = target_comparison.run_id
        WHERE source_row.id = decision.row_id AND source_row.decision_id = decision.id
        AND source_run.project_id = target_run.project_id
        AND (source_run.id = target_run.id OR EXISTS (SELECT 1 FROM ariviso_lineage lineage
          WHERE lineage.source_run_id = source_run.id AND lineage.target_run_id = target_run.id))
        AND NOT EXISTS (SELECT 1 FROM ariviso_decision_replacements replacement
          JOIN ariviso_decisions successor ON successor.id = replacement.replacement_decision_id
          WHERE replacement.source_decision_id = decision.id AND successor.revoked = 0
          AND (replacement.scope = 'shared' OR replacement.scope_run_id = target_run.id
            OR EXISTS (SELECT 1 FROM ariviso_lineage lineage
              WHERE lineage.source_run_id = replacement.scope_run_id AND lineage.target_run_id = target_run.id))))`;
  }
  eligibleAcceptanceSql() {
    return `EXISTS (SELECT 1 FROM ariviso_decisions decision
      WHERE decision.id = COALESCE(row.source_decision_id, row.decision_id)
      AND ${this.acceptanceValiditySql()})`;
  }
  async eligibleApprovalRowIds(comparisonId) {
    const rows = await this.rows(
      `SELECT row.id FROM ariviso_comparison_rows row WHERE row.comparison_id = ? AND row.outcome = 'changed' AND ${this.eligibleAcceptanceSql()} ORDER BY row.ordinal, row.id`,
      [comparisonId]
    );
    return rows.map((row) => row.id);
  }
  readyGuard(comparisonId) {
    return this.guard(
      `NOT EXISTS (SELECT 1 FROM ariviso_comparison_rows row WHERE row.comparison_id = ? AND (row.outcome NOT IN ('unchanged', 'changed') OR (row.outcome = 'changed' AND NOT ${this.eligibleAcceptanceSql()})))`,
      [comparisonId]
    );
  }
  currentBaselineGuard(projectId) {
    return this.guard(
      `NOT EXISTS (SELECT 1 FROM ariviso_projects project
        JOIN ariviso_snapshots snapshot ON snapshot.id = project.snapshot_id
        JOIN ariviso_comparison_rows row ON row.comparison_id = snapshot.comparison_id
        WHERE project.id = ? AND row.outcome = 'changed'
        AND NOT ${this.eligibleAcceptanceSql()})`,
      [projectId]
    );
  }
  async finalizeComparison(input) {
    const comparison = await this.comparison(input.comparisonId);
    const run = await this.run(comparison.run_id);
    if (comparison.purpose === "historical") {
      if (comparison.state === "comparing") {
        await finalizeHistoricalComparison(this.database, comparison.id);
      }
      return this.status(run.id);
    }
    if (run.detail_archived) {
      throw new ConflictError("Archived history is read-only.");
    }
    const project = await this.project(run.project_id);
    if (comparison.state === "ready") {
      return this.status(run.id);
    }
    const pending = await this.sql(
      "SELECT 1 AS found FROM ariviso_comparison_rows WHERE comparison_id = ? AND outcome IN ('pending', 'error') LIMIT 1",
      [comparison.id]
    ).first();
    if (pending) {
      throw new IncompleteError("Required comparisons have not completed.");
    }
    const reuse = `SELECT decision.id FROM ariviso_decisions decision WHERE ${this.acceptanceValiditySql()} ORDER BY decision.created_at, decision.id LIMIT 1`;
    const automaticKind = `CASE WHEN row.reference_capture_id IS NULL THEN 'introduction' ELSE 'removal' END`;
    const eligibleAutomatic = `row.comparison_id = ? AND row.outcome = 'changed' AND row.source_decision_id IS NULL AND row.decision_id IS NULL AND (row.reference_capture_id IS NULL OR row.candidate_capture_id IS NULL) AND NOT EXISTS (SELECT 1 FROM ariviso_reservations reservation JOIN ariviso_decisions decision ON decision.id = reservation.decision_id JOIN ariviso_comparison_rows reserved_row ON reserved_row.id = decision.row_id JOIN ariviso_comparisons reserved_comparison ON reserved_comparison.id = reserved_row.comparison_id WHERE reservation.project_id = ? AND reservation.item_key = row.item_key AND reservation.variant_key = row.variant_key AND reservation.kind = ${automaticKind} AND (reservation.lineage_key = ? OR EXISTS (SELECT 1 FROM ariviso_lineage l WHERE l.source_run_id = reserved_comparison.run_id AND l.target_run_id = ?))) AND (row.reference_capture_id IS NOT NULL OR NOT EXISTS (SELECT 1 FROM ariviso_identity_history h WHERE h.project_id = ? AND h.item_key = row.item_key AND h.variant_key = row.variant_key AND (h.lineage_key = ? OR h.lineage_key = 'main')))`;
    const statements = [
      this.projectGuard(project),
      this.activeGuard(run),
      this.guard("EXISTS (SELECT 1 FROM ariviso_runs WHERE id = ? AND comparison_id = ?)", [
        run.id,
        comparison.id
      ]),
      this.guard(
        "EXISTS (SELECT 1 FROM ariviso_comparisons WHERE id = ? AND state = 'comparing')",
        [comparison.id]
      ),
      this.guard(
        "NOT EXISTS (SELECT 1 FROM ariviso_comparison_rows WHERE comparison_id = ? AND outcome IN ('pending', 'error'))",
        [comparison.id]
      ),
      this.sql(
        `UPDATE ariviso_comparison_rows AS row SET source_decision_id = (${reuse}) WHERE row.comparison_id = ? AND row.outcome = 'changed'`,
        [comparison.id]
      ),
      this.sql(
        `INSERT INTO ariviso_decisions (id, row_id, revision, verdict, kind, tuple_json, created_at) SELECT 'automatic:' || row.id, row.id, 1, 'approved', 'automatic', row.tuple_json, ? FROM ariviso_comparison_rows row WHERE ${eligibleAutomatic}`,
        [
          input.now,
          comparison.id,
          project.id,
          run.lineage_key,
          run.id,
          project.id,
          run.lineage_key
        ]
      ),
      this.sql(
        "UPDATE ariviso_comparison_rows SET decision_id = 'automatic:' || id, decision_revision = 1 WHERE comparison_id = ? AND EXISTS (SELECT 1 FROM ariviso_decisions WHERE id = 'automatic:' || ariviso_comparison_rows.id)",
        [comparison.id]
      ),
      this.sql(
        `INSERT INTO ariviso_reservations (project_id, lineage_key, item_key, variant_key, kind, decision_id) SELECT ?, ?, row.item_key, row.variant_key, ${automaticKind}, row.decision_id FROM ariviso_comparison_rows row WHERE row.comparison_id = ? AND row.decision_id IS NOT NULL`,
        [project.id, run.lineage_key, comparison.id]
      )
    ];
    statements.push(
      this.sql(
        "INSERT OR IGNORE INTO ariviso_identity_history (project_id, lineage_key, item_key, variant_key) SELECT ?, ?, item_key, variant_key FROM ariviso_captures WHERE run_id = ?",
        [project.id, run.lineage_key, run.id]
      )
    );
    statements.push(
      this.sql("UPDATE ariviso_comparisons SET state = 'ready' WHERE id = ?", [comparison.id])
    );
    statements.push(this.sql("UPDATE ariviso_runs SET state = 'reviewing' WHERE id = ?", [run.id]));
    statements.push(
      this.audit(run, "comparison-ready", { comparisonId: comparison.id }, input.now)
    );
    statements.push(...this.touch(run, input.now));
    await atomic(this.database, statements);
    return this.status(run.id);
  }
  async reconcileComparisons(input) {
    await expireHistoricalPreparations(this.database, input.now);
    const candidates = await this.rows(
      "SELECT c.id FROM ariviso_comparisons c JOIN ariviso_runs r ON r.id = c.run_id WHERE c.state = 'comparing' AND ((c.purpose = 'review' AND r.active = 1 AND r.comparison_id = c.id AND NOT EXISTS (SELECT 1 FROM ariviso_comparison_rows row WHERE row.comparison_id = c.id AND row.outcome IN ('pending', 'error'))) OR (c.purpose = 'historical' AND (NOT EXISTS (SELECT 1 FROM ariviso_comparison_rows row WHERE row.comparison_id = c.id AND row.outcome = 'pending') OR EXISTS (SELECT 1 FROM ariviso_comparison_rows row JOIN work_tasks task ON task.id = row.id WHERE row.comparison_id = c.id AND task.state = 'dead') OR EXISTS (SELECT 1 FROM ariviso_snapshots snapshot WHERE snapshot.id = c.reference_snapshot_id AND snapshot.reference_eligible = 0)))) ORDER BY c.created_at, c.id LIMIT ?",
      [input.limit]
    );
    const completed = [];
    const errors = [];
    for (const candidate of candidates) {
      try {
        await this.finalizeComparison({ comparisonId: candidate.id, now: input.now });
        completed.push(candidate.id);
      } catch (error) {
        errors.push({
          comparisonId: candidate.id,
          message: error instanceof Error ? error.message : "Comparison reconciliation failed"
        });
      }
    }
    return { completed, errors };
  }
  async status(runId) {
    const run = await this.run(runId);
    if (!run.active) {
      return { run, status: "superseded", pending: 0, rejected: 0 };
    }
    if (run.state === "failed") {
      const failures2 = await this.rows(
        "SELECT id, json_extract(detail_json, '$.reason') AS last_error FROM ariviso_audit WHERE run_id = ? AND action = 'capture-failed' ORDER BY created_at DESC, id LIMIT 1",
        [run.id]
      );
      return { run, status: "failed", pending: 0, rejected: 0, failures: failures2 };
    }
    if (!run.comparison_id || run.sealed_at === null) {
      return { run, status: "incomplete", pending: 0, rejected: 0 };
    }
    const comparison = await this.comparison(run.comparison_id);
    if (comparison.state === "invalidated") {
      return { run, comparison, status: "needs-recompare", pending: 0, rejected: 0 };
    }
    const failures = await this.rows(
      "SELECT task.id, task.last_error FROM work_tasks task JOIN ariviso_comparison_rows row ON row.id = task.id WHERE row.comparison_id = ? AND task.state = 'dead' ORDER BY task.id LIMIT 20",
      [comparison.id]
    );
    if (failures.length > 0) {
      return { run, comparison, status: "failed", pending: 0, rejected: 0, failures };
    }
    if (comparison.state !== "ready") {
      return { run, comparison, status: "comparing", pending: 0, rejected: 0 };
    }
    const counts = await this.one(
      `SELECT COALESCE(SUM(CASE WHEN row.outcome NOT IN ('changed', 'unchanged') OR (row.outcome = 'changed' AND NOT ${this.eligibleAcceptanceSql()}) THEN 1 ELSE 0 END), 0) AS pending, COALESCE(SUM(CASE WHEN decision.verdict = 'rejected' AND decision.revoked = 0 THEN 1 ELSE 0 END), 0) AS rejected FROM ariviso_comparison_rows row LEFT JOIN ariviso_decisions decision ON decision.id = row.decision_id WHERE row.comparison_id = ?`,
      [comparison.id]
    );
    const project = await this.project(run.project_id);
    const currentPromotion = project.promotion_id ? await this.sql(
      "SELECT 1 AS found FROM ariviso_promotions WHERE id = ? AND comparison_id = ? AND revoked = 0",
      [project.promotion_id, comparison.id]
    ).first() : null;
    if (counts.pending === 0 && !currentPromotion && comparison.baseline_revision !== project.baseline_revision) {
      return { run, comparison, status: "needs-recompare", ...counts };
    }
    return {
      run,
      comparison,
      status: counts.pending === 0 ? "passed" : counts.rejected > 0 ? "rejected" : "needs-review",
      ...counts
    };
  }
  async prepareStatusIntent(input) {
    const run = await this.run(input.runId);
    const project = await this.project(run.project_id);
    const status = await this.status(run.id);
    if (status.status === "superseded") {
      throw new ConflictError("A superseded attempt cannot publish a check.");
    }
    const conclusion = status.status === "passed" ? "success" : status.status === "needs-review" || status.status === "rejected" || status.status === "failed" ? "failure" : "pending";
    const comparison = run.comparison_id ? await this.comparison(run.comparison_id) : null;
    await atomic(this.database, [
      this.projectGuard(project),
      this.activeGuard(run),
      this.sql(
        "INSERT INTO ariviso_checks (id, project_id, external_run_id) VALUES (?, ?, ?) ON CONFLICT(id) DO NOTHING",
        [input.checkId, project.id, run.external_run_id]
      ),
      this.guard(
        "EXISTS (SELECT 1 FROM ariviso_checks WHERE id = ? AND project_id = ? AND external_run_id = ?)",
        [input.checkId, project.id, run.external_run_id]
      ),
      ...statusIntentStatements(this.database, {
        checkId: input.checkId,
        revision: project.revision,
        runId: run.id,
        attempt: run.attempt,
        comparisonRevision: comparison?.ordinal ?? 0,
        sourceRevision: project.revision,
        conclusion,
        detailsUrl: input.detailsUrl,
        maxAttempts: input.maxAttempts,
        now: input.now
      }),
      this.sql(
        "UPDATE ariviso_status_outbox SET delivered_at = ? WHERE run_id = ? AND run_revision <= ?",
        [input.now, run.id, run.revision]
      )
    ]);
    return { revision: project.revision, conclusion };
  }
  /** Use alongside the delivery lease check immediately before sending to GitHub. */
  async isStatusIntentCurrent(intent) {
    const current = await this.sql(
      "SELECT 1 AS found FROM ariviso_runs run JOIN ariviso_projects project ON project.id = run.project_id LEFT JOIN ariviso_comparisons comparison ON comparison.id = run.comparison_id WHERE run.id = ? AND run.active = 1 AND run.attempt = ? AND project.revision = ? AND COALESCE(comparison.ordinal, 0) = ?",
      [intent.run_id, intent.attempt, intent.source_revision, intent.comparison_revision]
    ).first();
    return current !== null;
  }
  /** Retire only work that no longer owns the current promotion. */
  async retireRun(input) {
    const run = await this.run(input.runId);
    const project = await this.project(run.project_id);
    await atomic(this.database, [
      this.projectGuard(project),
      this.guard(
        "NOT EXISTS (SELECT 1 FROM ariviso_projects project JOIN ariviso_snapshots snapshot ON snapshot.id = project.snapshot_id WHERE snapshot.run_id = ?)",
        [run.id]
      ),
      this.sql(
        "UPDATE ariviso_runs SET active = 0, state = 'superseded', closed_at = COALESCE(closed_at, ?) WHERE id = ?",
        [input.now, run.id]
      ),
      this.sql("UPDATE work_retained_runs SET closed_at = COALESCE(closed_at, ?) WHERE id = ?", [
        input.now,
        run.id
      ]),
      this.sql(
        "DELETE FROM work_retention_pins WHERE run_id = ? AND owner = ? AND reason = 'review'",
        [run.id, `review:${run.id}`]
      ),
      ...this.touch(run, input.now),
      this.audit(run, "retire", {}, input.now)
    ]);
  }
  async commandReplay(commandId, request) {
    const command = await this.sql("SELECT * FROM ariviso_commands WHERE id = ?", [
      commandId
    ]).first();
    if (!command) return null;
    if (command.request_digest) {
      const archive = await this.sql(
        "SELECT archive.run_id FROM operations_run_archives archive JOIN ariviso_comparisons comparison ON comparison.run_id=archive.run_id WHERE comparison.id=? AND archive.state='ready'",
        [command.comparison_id]
      ).first();
      if (archive) {
        if (await commandRequestDigest(request) !== command.request_digest) {
          throw new ConflictError("The command ID already belongs to another request.");
        }
        throw new ArchivedCommandResultError(archive.run_id, command.id);
      }
    }
    if (command.request_json !== request) {
      throw new ConflictError("The command ID already belongs to another request.");
    }
    return parseCommandResult(command.result_json);
  }
  invalidateDependents(project, now) {
    return [
      this.sql(
        "UPDATE ariviso_runs SET revision = revision + 1 WHERE project_id = ? AND active = 1",
        [project.id]
      ),
      this.sql(
        "INSERT INTO ariviso_status_outbox (id, run_id, run_revision, created_at) SELECT ? || ':' || id, id, revision, ? FROM ariviso_runs WHERE project_id = ? AND active = 1",
        [crypto.randomUUID(), now, project.id]
      )
    ];
  }
  rollbackStatements(project, promotion, now) {
    return [
      this.guard(
        "EXISTS (SELECT 1 FROM ariviso_projects WHERE id = ? AND promotion_id = ? AND baseline_revision = ? AND snapshot_id = ?)",
        [project.id, promotion.id, project.baseline_revision, promotion.snapshot_id]
      ),
      this.guard(
        "NOT EXISTS (SELECT 1 FROM ariviso_snapshot_images WHERE snapshot_id IN (?, ?) AND copied != 1)",
        [promotion.snapshot_id, promotion.previous_snapshot_id]
      ),
      this.sql(
        "UPDATE ariviso_projects SET snapshot_id = ?, promotion_id = NULL, baseline_revision = baseline_revision + 1, fresh_setup = CASE WHEN ? IS NULL THEN 1 ELSE 0 END WHERE id = ?",
        [promotion.previous_snapshot_id, promotion.previous_snapshot_id, project.id]
      ),
      this.sql(
        "UPDATE ariviso_snapshots SET reference_eligible = 0, state = 'revoked' WHERE id = ?",
        [promotion.snapshot_id]
      ),
      this.sql("UPDATE ariviso_promotions SET revoked = 1 WHERE id = ?", [promotion.id]),
      this.sql(
        "UPDATE ariviso_comparisons SET state = 'invalidated' WHERE reference_snapshot_id = ? AND id != ? AND purpose = 'review'",
        [promotion.snapshot_id, promotion.comparison_id]
      ),
      this.sql("UPDATE ariviso_runs SET state = 'reviewing' WHERE comparison_id = ?", [
        promotion.comparison_id
      ]),
      this.sql(
        "INSERT INTO ariviso_status_outbox (id, run_id, run_revision, created_at) SELECT ? || ':' || id, id, revision, ? FROM ariviso_runs WHERE project_id = ? AND active = 1",
        [crypto.randomUUID(), now, project.id]
      )
    ];
  }
  async review(input) {
    const request = requestJson({ ...input });
    const replay = await this.commandReplay(input.commandId, request);
    if (replay) {
      return replay;
    }
    if (!input.actorId || !input.sessionId || input.targets.length === 0 || new Set(input.targets.map((target) => target.id)).size !== input.targets.length) {
      throw new IncompleteError(
        "A review command requires a maintainer, session, and unique targets."
      );
    }
    const comparison = await this.comparison(input.comparisonId);
    const run = await this.run(comparison.run_id);
    if (run.detail_archived) {
      throw new ConflictError("Archived history is read-only.");
    }
    const project = await this.project(run.project_id);
    const rows = await this.comparisonRows(comparison.id);
    const selected = input.targets.map((target) => {
      const row = rows.find((entry) => entry.id === target.id);
      if (!row || row.outcome !== "changed" || row.decision_revision !== target.expectedRevision) {
        throw new ConflictError("A target changed or belongs to another comparison.", row);
      }
      return row;
    });
    if (input.wholeItemKey) {
      const itemRows = rows.filter(
        (row) => row.item_key === input.wholeItemKey && row.outcome === "changed"
      );
      if (itemRows.length !== selected.length || selected.some((row) => row.item_key !== input.wholeItemKey)) {
        throw new ConflictError("The whole-item target list must include every changed variant.");
      }
    }
    const acceptedHistory = await this.sql(
      "SELECT * FROM ariviso_promotions WHERE comparison_id = ? ORDER BY created_at DESC LIMIT 1",
      [comparison.id]
    ).first();
    if (acceptedHistory && !acceptedHistory.revoked && input.verdict === "approved") {
      return {
        commandId: input.commandId,
        revisions: input.targets,
        selection: input.selection,
        baselineRevision: project.baseline_revision,
        promotionId: project.promotion_id,
        noop: true
      };
    }
    let rollback = null;
    if (acceptedHistory && !acceptedHistory.revoked) {
      if (project.promotion_id !== acceptedHistory.id || input.expectedPromotionId !== acceptedHistory.id || input.expectedBaselineRevision !== project.baseline_revision) {
        throw new ConflictError(
          "This promotion is no longer current. Use explicit recovery.",
          project
        );
      }
      rollback = acceptedHistory;
    }
    if (comparison.state !== "ready" || !run.active || run.comparison_id !== comparison.id) {
      throw new ConflictError("Only the active complete comparison can be reviewed.", run);
    }
    const statements = [this.projectGuard(project), this.reviewGuard(run, comparison.id)];
    const previous = { decisions: [], rollback };
    const result = {
      commandId: input.commandId,
      revisions: [],
      selection: input.selection,
      baselineRevision: project.baseline_revision + (rollback ? 1 : 0),
      promotionId: rollback ? null : project.promotion_id
    };
    for (const row of selected) {
      const effectiveId = row.source_decision_id ?? row.decision_id;
      const effective = effectiveId ? await this.one("SELECT * FROM ariviso_decisions WHERE id = ?", [effectiveId]) : null;
      if (rollback && effective?.kind === "automatic") {
        throw new ConflictError(
          "Automatically accepted promoted history is protected. Capture a correction in a new main run.",
          row
        );
      }
      statements.push(
        this.guard(
          "EXISTS (SELECT 1 FROM ariviso_comparison_rows WHERE id = ? AND comparison_id = ? AND decision_revision = ?)",
          [row.id, comparison.id, row.decision_revision]
        )
      );
      previous.decisions.push({
        id: row.id,
        decisionId: row.decision_id,
        sourceDecisionId: row.source_decision_id,
        revision: row.decision_revision
      });
      const decisionId = crypto.randomUUID();
      statements.push(
        this.sql("UPDATE ariviso_decisions SET revoked = 1 WHERE id = ?", [row.decision_id])
      );
      statements.push(
        this.sql(
          "INSERT INTO ariviso_decisions (id, row_id, revision, verdict, kind, actor_id, command_id, tuple_json, created_at) VALUES (?, ?, ?, ?, 'human', ?, ?, ?, ?)",
          [
            decisionId,
            row.id,
            row.decision_revision + 1,
            input.verdict,
            input.actorId,
            input.commandId,
            row.tuple_json,
            input.now
          ]
        )
      );
      if (row.source_decision_id) {
        statements.push(
          this.sql(
            "INSERT INTO ariviso_decision_replacements (source_decision_id, replacement_decision_id, scope, scope_run_id) VALUES (?, ?, ?, ?)",
            [
              row.source_decision_id,
              decisionId,
              rollback || input.verdict === "approved" ? "descendants" : "shared",
              run.id
            ]
          )
        );
      }
      statements.push(
        this.sql(
          "INSERT INTO ariviso_decision_replacements (source_decision_id, replacement_decision_id, scope, scope_run_id) SELECT source_decision_id, ?, scope, scope_run_id FROM ariviso_decision_replacements WHERE replacement_decision_id = ?",
          [decisionId, effectiveId]
        )
      );
      statements.push(
        this.sql(
          "UPDATE ariviso_comparison_rows SET decision_revision = decision_revision + 1, decision_id = ?, source_decision_id = NULL WHERE id = ?",
          [decisionId, row.id]
        )
      );
      result.revisions.push({ id: row.id, expectedRevision: row.decision_revision + 1 });
    }
    if (rollback) {
      statements.push(...this.rollbackStatements(project, rollback, input.now));
    }
    statements.push(
      this.sql(
        "INSERT INTO ariviso_commands (id, request_json, actor_id, session_id, kind, comparison_id, previous_json, result_json, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
        [
          input.commandId,
          request,
          input.actorId,
          input.sessionId,
          input.verdict === "approved" ? "approve" : "reject",
          comparison.id,
          JSON.stringify(previous),
          JSON.stringify(result),
          input.now
        ]
      )
    );
    statements.push(
      this.audit(
        run,
        input.verdict === "approved" ? "approve" : "reject",
        { commandId: input.commandId, targets: input.targets },
        input.now,
        input.actorId
      )
    );
    statements.push(
      this.currentBaselineGuard(project.id),
      ...this.invalidateDependents(project, input.now),
      ...this.touch(run, input.now)
    );
    try {
      await atomic(this.database, statements);
    } catch (error) {
      const replay2 = await this.commandReplay(result.commandId, request);
      if (replay2) {
        return replay2;
      }
      throw error;
    }
    return result;
  }
  async undo(input) {
    const request = requestJson({ ...input });
    const replay = await this.commandReplay(input.undoCommandId, request);
    if (replay) {
      return replay;
    }
    const command = await this.one("SELECT * FROM ariviso_commands WHERE id = ?", [
      input.commandId
    ]);
    if (command.actor_id !== input.actorId || command.session_id !== input.sessionId || command.undone_by || command.kind === "undo") {
      throw new ConflictError("Only your saved command in this review session can be undone.");
    }
    const saved = parseCommandResult(command.result_json);
    const previous = JSON.parse(command.previous_json);
    const comparison = await this.comparison(command.comparison_id);
    const run = await this.run(comparison.run_id);
    const project = await this.project(run.project_id);
    if (project.baseline_revision !== input.expectedBaselineRevision) {
      throw new ConflictError("The baseline changed after this command.", project);
    }
    if (!run.active || run.comparison_id !== comparison.id || comparison.state !== "ready") {
      throw new ConflictError("The command no longer targets the active comparison.");
    }
    const promotion = project.promotion_id ? await this.one("SELECT * FROM ariviso_promotions WHERE id = ?", [
      project.promotion_id
    ]) : null;
    const historical = await this.sql(
      "SELECT 1 AS found FROM ariviso_promotions WHERE comparison_id = ? LIMIT 1",
      [comparison.id]
    ).first();
    if (historical && !previous.rollback && promotion?.comparison_id !== comparison.id) {
      throw new ConflictError("A later promotion prevents Undo. Use explicit recovery.");
    }
    const rollingBack = command.kind === "approve" && promotion?.comparison_id === comparison.id ? promotion : null;
    const restoring = previous.rollback;
    if (restoring && (project.baseline_revision !== saved.baselineRevision || project.snapshot_id !== restoring.previous_snapshot_id || project.promotion_id !== null)) {
      throw new ConflictError("The rejection rollback has changed. Its Undo is stale.");
    }
    const statements = [
      this.projectGuard(project),
      this.reviewGuard(run, comparison.id),
      this.guard("EXISTS (SELECT 1 FROM ariviso_commands WHERE id = ? AND undone_by IS NULL)", [
        command.id
      ])
    ];
    const result = {
      commandId: input.undoCommandId,
      revisions: [],
      selection: saved.selection,
      baselineRevision: project.baseline_revision + (rollingBack || restoring ? 1 : 0),
      promotionId: restoring ? crypto.randomUUID() : rollingBack ? null : project.promotion_id
    };
    for (const target of saved.revisions) {
      const prior = previous.decisions.find((entry) => entry.id === target.id);
      if (!prior) {
        throw new IncompleteError("The saved command does not contain its prior verdict.");
      }
      statements.push(
        this.guard(
          "EXISTS (SELECT 1 FROM ariviso_comparison_rows WHERE id = ? AND decision_revision = ?)",
          [target.id, target.expectedRevision]
        )
      );
      statements.push(
        this.sql(
          "UPDATE ariviso_decisions SET revoked = 1 WHERE id = (SELECT decision_id FROM ariviso_comparison_rows WHERE id = ?)",
          [target.id]
        )
      );
      statements.push(
        this.sql("UPDATE ariviso_decisions SET revoked = 0 WHERE id = ?", [prior.decisionId])
      );
      statements.push(
        this.sql(
          "UPDATE ariviso_comparison_rows SET decision_revision = decision_revision + 1, decision_id = ?, source_decision_id = ? WHERE id = ?",
          [prior.decisionId, prior.sourceDecisionId, target.id]
        )
      );
      result.revisions.push({ id: target.id, expectedRevision: target.expectedRevision + 1 });
    }
    if (rollingBack) {
      statements.push(...this.rollbackStatements(project, rollingBack, input.now));
    }
    if (restoring) {
      statements.push(this.readyGuard(comparison.id));
      statements.push(
        this.guard(
          "NOT EXISTS (SELECT 1 FROM ariviso_snapshot_images WHERE snapshot_id IN (?, ?) AND copied != 1)",
          [restoring.snapshot_id, restoring.previous_snapshot_id]
        )
      );
      statements.push(
        this.sql(
          "UPDATE ariviso_snapshots SET reference_eligible = 1, state = 'accepted' WHERE id = ?",
          [restoring.snapshot_id]
        )
      );
      statements.push(
        this.sql(
          "INSERT INTO ariviso_promotions (id, project_id, snapshot_id, previous_snapshot_id, comparison_id, baseline_revision, command_id, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
          [
            result.promotionId,
            project.id,
            restoring.snapshot_id,
            restoring.previous_snapshot_id,
            comparison.id,
            result.baselineRevision,
            input.undoCommandId,
            input.now
          ]
        )
      );
      statements.push(
        this.sql(
          "UPDATE ariviso_projects SET snapshot_id = ?, promotion_id = ?, baseline_revision = baseline_revision + 1, fresh_setup = 0 WHERE id = ?",
          [restoring.snapshot_id, result.promotionId, project.id]
        )
      );
      statements.push(
        this.sql("UPDATE ariviso_runs SET state = 'accepted' WHERE id = ?", [run.id])
      );
    }
    statements.push(
      this.sql("UPDATE ariviso_commands SET undone_by = ? WHERE id = ?", [
        input.undoCommandId,
        command.id
      ])
    );
    statements.push(
      this.sql(
        "INSERT INTO ariviso_commands (id, request_json, actor_id, session_id, kind, comparison_id, previous_json, result_json, created_at) VALUES (?, ?, ?, ?, 'undo', ?, ?, ?, ?)",
        [
          input.undoCommandId,
          request,
          input.actorId,
          input.sessionId,
          comparison.id,
          JSON.stringify({ decisions: [], rollback: null }),
          JSON.stringify(result),
          input.now
        ]
      )
    );
    statements.push(
      this.audit(
        run,
        "undo",
        { commandId: command.id, undoCommandId: input.undoCommandId },
        input.now,
        input.actorId
      )
    );
    statements.push(
      this.currentBaselineGuard(project.id),
      ...this.invalidateDependents(project, input.now),
      ...this.touch(run, input.now)
    );
    try {
      await atomic(this.database, statements);
    } catch (error) {
      const replay2 = await this.commandReplay(result.commandId, request);
      if (replay2) {
        return replay2;
      }
      throw error;
    }
    return result;
  }
  async preparePromotion(input) {
    const existing = await this.sql("SELECT * FROM ariviso_snapshots WHERE id = ?", [
      input.snapshotId
    ]).first();
    if (existing) {
      if (existing.comparison_id !== input.comparisonId || existing.prefix !== input.prefix || existing.state === "revoked") {
        throw new ConflictError("The snapshot ID belongs to another or revoked promotion.");
      }
      return this.pendingSnapshotCopies(existing.id, input.copyLimit ?? 100);
    }
    const comparison = await this.comparison(input.comparisonId);
    const run = await this.run(comparison.run_id);
    const project = await this.project(run.project_id);
    if (run.kind !== "main" || !input.prefix.startsWith("baselines/")) {
      throw new IncompleteError("Only a complete main run can use a protected baseline prefix.");
    }
    await atomic(this.database, [
      this.projectGuard(project),
      this.activeGuard(run),
      this.readyGuard(comparison.id),
      this.guard(
        "EXISTS (SELECT 1 FROM ariviso_comparisons WHERE id = ? AND state = 'ready' AND baseline_revision = ? AND reference_snapshot_id IS ?)",
        [comparison.id, project.baseline_revision, project.snapshot_id]
      ),
      this.guard(
        "EXISTS (SELECT 1 FROM ariviso_runs WHERE id = ? AND comparison_id = ? AND sealed_at IS NOT NULL)",
        [run.id, comparison.id]
      ),
      this.sql(
        "INSERT INTO ariviso_snapshots (id, project_id, run_id, comparison_id, tested_sha, prefix, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)",
        [
          input.snapshotId,
          project.id,
          run.id,
          comparison.id,
          run.tested_sha,
          input.prefix,
          input.now
        ]
      ),
      this.sql(
        "INSERT INTO ariviso_snapshot_images (snapshot_id, capture_id, image_id, object_key, digest) SELECT ?, c.id, i.id, ? || '/' || i.id, i.digest FROM ariviso_captures c JOIN ariviso_images i ON i.id = c.image_id WHERE c.run_id = ?",
        [input.snapshotId, input.prefix, run.id]
      ),
      this.sql(
        "INSERT INTO ariviso_pins (snapshot_id, reason, owner_id) VALUES (?, 'promotion', ?)",
        [input.snapshotId, input.snapshotId]
      ),
      this.sql(
        "INSERT INTO work_retention_pins (run_id, owner, reason) VALUES (?, ?, 'promotion')",
        [run.id, `promotion:${input.snapshotId}`]
      )
    ]);
    return this.pendingSnapshotCopies(input.snapshotId, input.copyLimit ?? 100);
  }
  async cancelPreparedPromotion(input) {
    const snapshot = await this.one("SELECT * FROM ariviso_snapshots WHERE id = ?", [
      input.snapshotId
    ]);
    if (snapshot.state === "revoked") return;
    const run = await this.run(snapshot.run_id);
    const project = await this.project(run.project_id);
    await atomic(this.database, [
      this.projectGuard(project),
      this.guard(
        "EXISTS (SELECT 1 FROM ariviso_snapshots WHERE id = ? AND state = 'copying' AND reference_eligible = 0)",
        [snapshot.id]
      ),
      this.guard("NOT EXISTS (SELECT 1 FROM ariviso_promotions WHERE snapshot_id = ?)", [
        snapshot.id
      ]),
      this.sql("UPDATE ariviso_snapshots SET state = 'revoked' WHERE id = ?", [snapshot.id]),
      this.sql(
        "DELETE FROM ariviso_pins WHERE snapshot_id = ? AND reason = 'promotion' AND owner_id = ?",
        [snapshot.id, snapshot.id]
      ),
      this.sql(
        "DELETE FROM work_retention_pins WHERE run_id = ? AND owner = ? AND reason = 'promotion'",
        [run.id, `promotion:${snapshot.id}`]
      ),
      this.audit(run, "cancel-prepared-promotion", { snapshotId: snapshot.id }, input.now),
      ...this.touch(run, input.now)
    ]);
  }
  async pendingSnapshotCopies(snapshotId, limit) {
    if (!Number.isSafeInteger(limit) || limit < 1) {
      throw new IncompleteError("A positive copy-page limit is required.");
    }
    return this.rows(
      "SELECT si.*, i.object_key AS source_object_key, i.bytes, i.content_type FROM ariviso_snapshot_images si JOIN ariviso_images i ON i.id = si.image_id WHERE si.snapshot_id = ? AND si.copied = 0 ORDER BY si.capture_id LIMIT ?",
      [snapshotId, limit]
    );
  }
  async snapshotCopies(snapshotId) {
    return this.rows(
      "SELECT si.*, i.object_key AS source_object_key FROM ariviso_snapshot_images si JOIN ariviso_images i ON i.id = si.image_id WHERE si.snapshot_id = ?",
      [snapshotId]
    );
  }
  /** Mark a copy only after an R2 read verifies its digest at the protected key. */
  async recordSnapshotCopy(input) {
    await atomic(this.database, [
      this.guard("EXISTS (SELECT 1 FROM ariviso_snapshots WHERE id = ? AND state = 'copying')", [
        input.snapshotId
      ]),
      this.guard(
        "EXISTS (SELECT 1 FROM ariviso_snapshot_images WHERE snapshot_id = ? AND capture_id = ? AND object_key = ? AND digest = ?)",
        [input.snapshotId, input.captureId, input.objectKey, input.digest]
      ),
      this.sql(
        "UPDATE ariviso_snapshot_images SET copied = 1 WHERE snapshot_id = ? AND capture_id = ?",
        [input.snapshotId, input.captureId]
      )
    ]);
  }
  async promote(input) {
    const snapshot = await this.one("SELECT * FROM ariviso_snapshots WHERE id = ?", [
      input.snapshotId
    ]);
    const comparison = await this.comparison(snapshot.comparison_id);
    const run = await this.run(snapshot.run_id);
    const project = await this.project(run.project_id);
    if (project.promotion_id === input.promotionId && project.snapshot_id === snapshot.id) {
      return project;
    }
    const statements = [
      this.projectGuard(project),
      this.activeGuard(run),
      this.readyGuard(comparison.id),
      this.guard(
        "EXISTS (SELECT 1 FROM ariviso_projects WHERE id = ? AND baseline_revision = ? AND snapshot_id IS ?)",
        [project.id, input.expectedBaselineRevision, comparison.reference_snapshot_id]
      ),
      this.guard(
        "EXISTS (SELECT 1 FROM ariviso_runs WHERE id = ? AND kind = 'main' AND comparison_id = ? AND sealed_at IS NOT NULL)",
        [run.id, comparison.id]
      ),
      this.guard(
        "EXISTS (SELECT 1 FROM ariviso_comparisons WHERE id = ? AND state = 'ready' AND baseline_revision = ?)",
        [comparison.id, project.baseline_revision]
      ),
      this.guard("EXISTS (SELECT 1 FROM ariviso_snapshots WHERE id = ? AND state = 'copying')", [
        snapshot.id
      ]),
      this.guard(
        "NOT EXISTS (SELECT 1 FROM ariviso_snapshot_images WHERE snapshot_id = ? AND copied != 1) AND (SELECT count(*) FROM ariviso_snapshot_images WHERE snapshot_id = ?) = (SELECT count(*) FROM ariviso_captures WHERE run_id = ?)",
        [snapshot.id, snapshot.id, run.id]
      )
    ];
    if (project.snapshot_id) {
      statements.push(
        this.guard(
          "EXISTS (SELECT 1 FROM ariviso_snapshots s JOIN ariviso_ancestry a ON a.ancestor_sha = s.tested_sha AND a.run_id = ? WHERE s.id = ? AND s.reference_eligible = 1)",
          [run.id, project.snapshot_id]
        )
      );
      statements.push(
        this.sql(
          "INSERT OR IGNORE INTO ariviso_pins (snapshot_id, reason, owner_id) VALUES (?, 'rollback', ?)",
          [project.snapshot_id, input.promotionId]
        )
      );
    }
    statements.push(
      this.sql(
        "INSERT INTO ariviso_promotions (id, project_id, snapshot_id, previous_snapshot_id, comparison_id, baseline_revision, command_id, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
        [
          input.promotionId,
          project.id,
          snapshot.id,
          project.snapshot_id,
          comparison.id,
          project.baseline_revision + 1,
          input.commandId ?? null,
          input.now
        ]
      )
    );
    statements.push(
      this.sql(
        "UPDATE ariviso_runs SET active=0,closed_at=COALESCE(closed_at,?),revision=revision+1 WHERE id IN (SELECT run_id FROM ariviso_snapshots WHERE id=?) AND id!=? AND state='accepted'",
        [input.now, project.snapshot_id, run.id]
      ),
      this.sql(
        "UPDATE work_retained_runs SET closed_at=COALESCE(closed_at,?) WHERE id IN (SELECT run_id FROM ariviso_snapshots WHERE id=?) AND id!=?",
        [input.now, project.snapshot_id, run.id]
      ),
      this.sql(
        "DELETE FROM work_retention_pins WHERE reason='review' AND owner IN (SELECT 'review:' || run_id FROM ariviso_snapshots WHERE id=? AND run_id!=?)",
        [project.snapshot_id, run.id]
      ),
      this.sql(
        "UPDATE ariviso_snapshots SET state = 'accepted', reference_eligible = 1 WHERE id = ?",
        [snapshot.id]
      )
    );
    statements.push(
      this.sql(
        "UPDATE work_retention_pins SET reason = 'baseline' WHERE run_id = ? AND owner = ?",
        [run.id, `promotion:${snapshot.id}`]
      )
    );
    statements.push(
      this.sql(
        "UPDATE ariviso_projects SET snapshot_id = ?, promotion_id = ?, baseline_revision = baseline_revision + 1, fresh_setup = 0 WHERE id = ?",
        [snapshot.id, input.promotionId, project.id]
      )
    );
    statements.push(this.sql("UPDATE ariviso_runs SET state = 'accepted' WHERE id = ?", [run.id]));
    statements.push(
      this.sql(
        "INSERT OR IGNORE INTO ariviso_identity_history (project_id, lineage_key, item_key, variant_key) SELECT ?, 'main', item_key, variant_key FROM ariviso_captures WHERE run_id = ?",
        [project.id, run.id]
      )
    );
    statements.push(
      this.sql(
        "UPDATE ariviso_comparisons SET state = 'invalidated' WHERE id != ? AND run_id IN (SELECT id FROM ariviso_runs WHERE project_id = ? AND active = 1 AND state != 'accepted')",
        [comparison.id, project.id]
      )
    );
    statements.push(
      this.audit(
        run,
        "promote",
        { snapshotId: snapshot.id, promotionId: input.promotionId },
        input.now
      )
    );
    statements.push(
      ...this.invalidateDependents(project, input.now),
      ...this.touch(run, input.now)
    );
    await atomic(this.database, statements);
    return this.project(project.id);
  }
};

// implementation/apps/web/src/operations/backups-v2.ts
import { createHash as createHash3 } from "node:crypto";

// implementation/apps/web/src/operations/common.ts
import { createHash } from "node:crypto";
async function recordEvent(database, input) {
  const id = `${input.kind}:${input.subject}:${input.code}`;
  await database.prepare(`INSERT INTO operations_events(id,kind,subject_id,code,first_seen_at,last_seen_at)
    VALUES(?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET last_seen_at=excluded.last_seen_at,
    occurrences=operations_events.occurrences+1,resolved_at=NULL`).bind(id, input.kind, input.subject, input.code, input.now, input.now).run();
}
__name(recordEvent, "recordEvent");
async function resolveEvents(database, kind, subject, now) {
  await database.prepare(
    "UPDATE operations_events SET resolved_at=? WHERE kind=? AND subject_id=? AND resolved_at IS NULL"
  ).bind(now, kind, subject).run();
}
__name(resolveEvents, "resolveEvents");
async function digestStream(stream, maximum) {
  const hash2 = createHash("sha256");
  const reader = stream.getReader();
  let bytes = 0;
  try {
    while (true) {
      const chunk = await reader.read();
      if (chunk.done) break;
      bytes += chunk.value.byteLength;
      if (bytes > maximum) {
        await reader.cancel();
        throw new Error("Object exceeds the configured operations limit.");
      }
      hash2.update(chunk.value);
    }
  } finally {
    reader.releaseLock();
  }
  return { digest: hash2.digest("hex"), bytes };
}
__name(digestStream, "digestStream");
async function putKnownLength(store, key2, body, bytes, options) {
  if (!Number.isSafeInteger(bytes) || bytes < 0) {
    await body.cancel();
    throw new Error("Object length must be a nonnegative safe integer.");
  }
  const fixed = new FixedLengthStream(bytes);
  const controller = new AbortController();
  const transfer = body.pipeTo(fixed.writable, { signal: controller.signal });
  void transfer.catch(() => {
  });
  try {
    const saved = await store.put(key2, fixed.readable, options);
    if (saved === null) throw new Error("Object changed during its conditional copy.");
    await transfer;
  } finally {
    controller.abort();
    if (!fixed.readable.locked) await fixed.readable.cancel().catch(() => {
    });
    await transfer.catch(() => {
    });
  }
}
__name(putKnownLength, "putKnownLength");
async function copyVerifiedObject(params) {
  const source = await params.source.get(params.sourceKey);
  if (!source || source.size > params.maximum || params.expectedBytes !== void 0 && source.size !== params.expectedBytes) {
    await source?.body.cancel();
    throw new Error("Required source object is missing or has an invalid size.");
  }
  const hash2 = createHash("sha256");
  let bytes = 0;
  const verifying = source.body.pipeThrough(
    new TransformStream({
      transform(chunk, controller) {
        bytes += chunk.byteLength;
        if (bytes > params.maximum)
          throw new Error("Object exceeds the configured operations limit.");
        hash2.update(chunk);
        controller.enqueue(chunk);
      }
    })
  );
  try {
    const existing = await params.destination.get(params.destinationKey);
    if (existing) {
      await existing.body.cancel();
      await digestStream(verifying, params.maximum);
    } else {
      await putKnownLength(params.destination, params.destinationKey, verifying, source.size, {
        onlyIf: { etagDoesNotMatch: "*" },
        httpMetadata: {
          contentType: source.httpMetadata?.contentType ?? "application/octet-stream"
        },
        customMetadata: source.customMetadata
      });
    }
  } finally {
    if (!verifying.locked) await verifying.cancel().catch(() => {
    });
  }
  const verified = { bytes, digest: hash2.digest("hex") };
  if (verified.bytes !== source.size || params.expectedDigest && verified.digest !== params.expectedDigest) {
    throw new Error("Source object digest or length does not match its record.");
  }
  const stored = await params.destination.get(params.destinationKey);
  if (!stored || stored.size !== verified.bytes) {
    await stored?.body.cancel();
    throw new Error("Destination object was not stored in full.");
  }
  const confirmed = await digestStream(stored.body, params.maximum);
  if (confirmed.digest !== verified.digest || confirmed.bytes !== verified.bytes) {
    throw new Error("Destination object failed integrity verification.");
  }
  return {
    ...confirmed,
    contentType: source.httpMetadata?.contentType ?? "application/octet-stream"
  };
}
__name(copyVerifiedObject, "copyVerifiedObject");
function safeKey(key2) {
  if (!key2 || key2.startsWith("/") || key2.includes("\\") || key2.split("/").some((part) => !part || part === "." || part === "..") || new TextEncoder().encode(key2).length > 900) {
    throw new Error("Object key is outside the supported private namespace.");
  }
  return key2;
}
__name(safeKey, "safeKey");
async function mapConcurrent(values, concurrency, operation) {
  const results = [];
  let cursor = 0;
  const workers = await Promise.allSettled(
    Array.from({ length: Math.min(concurrency, values.length) }, async () => {
      while (cursor < values.length) {
        const index = cursor++;
        const value = values[index];
        if (value === void 0) throw new Error("Missing concurrent operation input.");
        results[index] = await operation(value);
      }
    })
  );
  for (const worker of workers) {
    if (worker.status === "rejected") throw worker.reason;
  }
  return results;
}
__name(mapConcurrent, "mapConcurrent");

// implementation/apps/web/src/operations/object-stream.ts
import { createHash as createHash2 } from "node:crypto";
async function putBoundedStream(store, key2, source, maximum) {
  if (!Number.isSafeInteger(maximum) || maximum < 1 || source.bytes !== void 0 && (!Number.isSafeInteger(source.bytes) || source.bytes < 1 || source.bytes > maximum)) {
    await source.body.cancel();
    throw new Error("Database export has an invalid declared length.");
  }
  const hash2 = createHash2("sha256");
  let bytes = 0;
  function observe(chunk) {
    bytes += chunk.byteLength;
    if (bytes > maximum) throw new Error("Database export exceeds configured bound.");
    hash2.update(chunk);
  }
  __name(observe, "observe");
  if (source.bytes !== void 0) {
    const bounded = source.body.pipeThrough(
      new TransformStream({
        transform(chunk, controller) {
          observe(chunk);
          controller.enqueue(chunk);
        }
      })
    );
    await putKnownLength(store, key2, bounded, source.bytes, {
      httpMetadata: { contentType: "application/sql" }
    });
  } else {
    const reader = source.body.getReader();
    let upload;
    const buffer = new Uint8Array(Math.min(8 * 1024 * 1024, maximum));
    const parts = [];
    let buffered = 0;
    let complete = false;
    try {
      upload = await store.createMultipartUpload(key2, {
        httpMetadata: { contentType: "application/sql" }
      });
      while (true) {
        const next = await reader.read();
        if (next.done) break;
        observe(next.value);
        for (let offset = 0; offset < next.value.byteLength; ) {
          const take = Math.min(buffer.byteLength - buffered, next.value.byteLength - offset);
          buffer.set(next.value.subarray(offset, offset + take), buffered);
          buffered += take;
          offset += take;
          if (buffered === buffer.byteLength) {
            if (parts.length >= 1e4) throw new Error("Database export has too many parts.");
            parts.push(await upload.uploadPart(parts.length + 1, buffer));
            buffered = 0;
          }
        }
      }
      if (!bytes) throw new Error("Database export is empty.");
      if (buffered) {
        if (parts.length >= 1e4) throw new Error("Database export has too many parts.");
        parts.push(await upload.uploadPart(parts.length + 1, buffer.subarray(0, buffered)));
      }
      await upload.complete(parts);
      complete = true;
    } finally {
      await reader.cancel().catch(() => {
      });
      reader.releaseLock();
      if (!complete) await upload?.abort();
    }
  }
  return { bytes, digest: hash2.digest("hex") };
}
__name(putBoundedStream, "putBoundedStream");

// implementation/apps/web/src/operations/backup-objects.ts
var BACKUP_RETENTION = 30 * 24 * 60 * 60 * 1e3;
function noBackupDeletion(context2) {
  return assertion(
    context2.database,
    "NOT EXISTS(SELECT 1 FROM operations_backup_objects WHERE state='deleting')"
  );
}
__name(noBackupDeletion, "noBackupDeletion");

// implementation/apps/web/src/operations/backups-v2.ts
function backupGuard(context2, id, token) {
  return assertion(
    context2.database,
    "EXISTS(SELECT 1 FROM operations_backups WHERE id=? AND lease_token=? AND lease_until>?)",
    [id, token, context2.now()]
  );
}
__name(backupGuard, "backupGuard");
async function backupDaily(context2, exporter) {
  const { database, budget } = context2;
  const report = { completed: [], deferred: [], attention: [], hasMore: false };
  const day = new Date(context2.now()).toISOString().slice(0, 10);
  const unfinished = await database.prepare(
    "SELECT * FROM operations_backups WHERE state IN ('exporting','copying') ORDER BY created_at LIMIT 1"
  ).first();
  const id = unfinished?.id ?? day;
  const existing = unfinished ?? await database.prepare("SELECT * FROM operations_backups WHERE id=?").bind(id).first();
  if (existing && !["exporting", "copying"].includes(existing.state)) return report;
  if (!existing) {
    await atomic(database, [
      noBackupDeletion(context2),
      assertion(
        database,
        "NOT EXISTS(SELECT 1 FROM work_retained_runs WHERE byte_state='deleting')"
      ),
      database.prepare("INSERT INTO operations_backups(id,state,created_at) VALUES(?,'exporting',?)").bind(id, context2.now()),
      database.prepare(
        `INSERT INTO work_retention_pins(run_id,owner,reason) SELECT id,?,'recovery' FROM work_retained_runs WHERE byte_state='live'`
      ).bind(`backup:${id}`)
    ]);
  }
  const token = crypto.randomUUID();
  const row = await database.prepare(`UPDATE operations_backups SET lease_token=?,lease_until=? WHERE id=? AND state IN ('exporting','copying')
    AND (lease_token IS NULL OR lease_until<=?) RETURNING *`).bind(token, context2.now() + budget.leaseMilliseconds, id, context2.now()).first();
  if (!row) {
    report.deferred.push(id);
    return report;
  }
  const prefix = `backups/${id}/`;
  try {
    if (row.state === "exporting") {
      const key2 = `${prefix}database-${token}.sql`;
      const source = await exporter.export();
      const { bytes, digest: digest2 } = await putBoundedStream(
        context2.backups,
        key2,
        source,
        budget.maximumDatabaseBytes
      );
      const saved = await context2.backups.get(key2);
      if (!saved) throw new Error("Database export was not saved.");
      const verified = await digestStream(saved.body, budget.maximumDatabaseBytes);
      if (!bytes || verified.bytes !== bytes || verified.digest !== digest2)
        throw new Error("Database export integrity failed.");
      await atomic(database, [
        backupGuard(context2, id, token),
        assertion(
          database,
          "NOT EXISTS(SELECT 1 FROM work_retained_runs WHERE byte_state='deleting')"
        ),
        database.prepare(
          "INSERT INTO work_retention_pins(run_id,owner,reason) SELECT id,?,'recovery' FROM work_retained_runs WHERE byte_state='live' ON CONFLICT(run_id,owner) DO NOTHING"
        ).bind(`backup:${id}`),
        // Freeze the required superset once while recovery pins protect the SQL snapshot.
        database.prepare(`INSERT OR IGNORE INTO operations_backup_inventory(backup_id,source,object_key,digest,bytes)
          SELECT ?,'images',object_key,digest,bytes FROM ariviso_images WHERE bytes_present=1`).bind(id),
        database.prepare(`INSERT OR IGNORE INTO operations_backup_inventory(backup_id,source,object_key,digest,bytes)
          SELECT ?,'images',copy.object_key,copy.digest,image.bytes FROM ariviso_snapshot_images copy
          JOIN ariviso_images image ON image.id=copy.image_id WHERE copy.copied=1`).bind(id),
        database.prepare(`INSERT OR IGNORE INTO operations_backup_inventory(backup_id,source,object_key)
          SELECT ?,'quarantine',provenance.plan_object_key FROM ingest_run_provenance provenance
          JOIN work_retention_pins pin ON pin.run_id=provenance.run_id WHERE pin.owner=?`).bind(id, `backup:${id}`),
        database.prepare(`INSERT OR IGNORE INTO operations_backup_inventory(backup_id,source,object_key)
          SELECT ?,'quarantine',manifest.object_key FROM ingest_manifests manifest
          JOIN work_retention_pins pin ON pin.run_id=manifest.run_id WHERE pin.owner=?`).bind(id, `backup:${id}`),
        database.prepare(
          `UPDATE operations_backups SET state='copying',database_key=?,database_digest=?,database_bytes=? WHERE id=?`
        ).bind(key2, digest2, bytes, id)
      ]);
      report.hasMore = true;
      report.deferred.push(id);
      return report;
    }
    if (row.source_kind !== 4) {
      const cursor = row.cursor ? JSON.parse(row.cursor) : ["", ""];
      if (!Array.isArray(cursor) || cursor.length !== 2 || cursor.some((value) => typeof value !== "string"))
        throw new Error("Backup inventory cursor is invalid.");
      await atomic(database, [
        backupGuard(context2, id, token),
        database.prepare(`INSERT OR IGNORE INTO operations_backup_objects(source,object_key,backup_key,state,retire_after)
          SELECT source,object_key,'backup-objects/'||source||'/'||lower(hex(randomblob(16))),'pending',?
          FROM operations_backup_inventory WHERE backup_id=? AND (source,object_key)>(?,?)
          ORDER BY source,object_key LIMIT ?`).bind(context2.now() + BACKUP_RETENTION, id, cursor[0], cursor[1], budget.objectsPerStep)
      ]);
      const required2 = await database.prepare(`SELECT inventory.source,inventory.object_key AS key,
        inventory.digest,inventory.bytes,copy.backup_key,copy.state,copy.digest AS copied_digest,
        copy.bytes AS copied_bytes,copy.content_type
        FROM operations_backup_inventory inventory JOIN operations_backup_objects copy
          ON copy.source=inventory.source AND copy.object_key=inventory.object_key
        WHERE inventory.backup_id=? AND (inventory.source,inventory.object_key)>(?,?)
        ORDER BY inventory.source,inventory.object_key LIMIT ?`).bind(id, cursor[0], cursor[1], budget.objectsPerStep).all();
      const objects = await mapConcurrent(required2.results ?? [], 6, async (object2) => {
        safeKey(object2.key);
        const backupKey = object2.backup_key;
        if (object2.state === "ready") {
          if (!object2.copied_digest || !object2.copied_bytes || !object2.content_type || object2.digest !== null && object2.digest !== object2.copied_digest || object2.bytes !== null && object2.bytes !== object2.copied_bytes)
            throw new Error("Immutable backup reference changed.");
          return {
            source: object2.source,
            key: object2.key,
            backupKey,
            digest: object2.copied_digest,
            bytes: object2.copied_bytes,
            contentType: object2.content_type
          };
        }
        if (object2.state !== "pending") throw new Error("Backup object is being deleted.");
        const copy = await copyVerifiedObject({
          source: object2.source === "images" ? context2.images : context2.quarantine,
          destination: context2.backups,
          sourceKey: object2.key,
          destinationKey: backupKey,
          maximum: budget.maximumObjectBytes,
          expectedDigest: object2.digest ?? void 0,
          expectedBytes: object2.bytes ?? void 0
        });
        return { source: object2.source, key: object2.key, backupKey, ...copy };
      });
      const encoded2 = JSON.stringify(objects);
      const digest2 = createHash3("sha256").update(encoded2).digest("hex");
      const key2 = `${prefix}pages/${digest2}.json`;
      await context2.backups.put(key2, encoded2, {
        httpMetadata: { contentType: "application/json" }
      });
      const saved = await context2.backups.get(key2);
      if (!saved || (await digestStream(saved.body, 4 * 1024 * 1024)).digest !== digest2)
        throw new Error("Backup inventory was not stored intact.");
      const last = objects.at(-1);
      await atomic(database, [
        backupGuard(context2, id, token),
        database.prepare(`INSERT INTO operations_backup_objects(source,object_key,backup_key,state,digest,bytes,content_type,retire_after)
          SELECT json_extract(value,'$.source'),json_extract(value,'$.key'),json_extract(value,'$.backupKey'),'ready',
            json_extract(value,'$.digest'),json_extract(value,'$.bytes'),json_extract(value,'$.contentType'),?
          FROM json_each(?) WHERE true ON CONFLICT(source,object_key) DO UPDATE SET
            state='ready',digest=excluded.digest,bytes=excluded.bytes,content_type=excluded.content_type
          WHERE operations_backup_objects.state='pending'`).bind(context2.now() + BACKUP_RETENTION, encoded2),
        database.prepare(
          "INSERT INTO operations_backup_pages(backup_id,ordinal,object_key,digest,objects) VALUES(?,?,?,?,?)"
        ).bind(id, row.page_count, key2, digest2, objects.length),
        database.prepare(`UPDATE operations_backups SET cursor=?,source_kind=?,page_count=page_count+1,
          object_count=object_count+?,image_bytes=image_bytes+? WHERE id=?`).bind(
          last ? JSON.stringify([last.source, last.key]) : row.cursor,
          objects.length === budget.objectsPerStep ? 0 : 4,
          objects.length,
          objects.reduce((sum, item) => sum + item.bytes, 0),
          id
        )
      ]);
      report.hasMore = true;
      report.deferred.push(id);
      return report;
    }
    if (!row.database_key || !row.database_digest || !row.database_bytes)
      throw new Error("Backup database record is incomplete.");
    const pages = await database.prepare(
      "SELECT object_key AS key,digest,objects FROM operations_backup_pages WHERE backup_id=? ORDER BY ordinal"
    ).bind(id).all();
    const required = await database.prepare(
      "SELECT object_key AS key,digest,objects FROM operations_backup_required WHERE backup_id=? ORDER BY ordinal"
    ).bind(id).all();
    const manifest = {
      version: 2,
      id,
      createdAt: row.created_at,
      completedAt: context2.now(),
      database: { key: row.database_key, digest: row.database_digest, bytes: row.database_bytes },
      pages: pages.results ?? [],
      required: required.results ?? [],
      objects: row.object_count,
      bytes: row.image_bytes
    };
    const encoded = JSON.stringify(manifest);
    if (encoded.length > 4 * 1024 * 1024)
      throw new Error("Backup inventory exceeds supported bounds.");
    await context2.backups.put(`${prefix}complete.json`, encoded, {
      httpMetadata: { contentType: "application/json" }
    });
    await atomic(database, [
      backupGuard(context2, id, token),
      database.prepare("UPDATE operations_backups SET state='complete',completed_at=? WHERE id=?").bind(context2.now(), id),
      database.prepare(`UPDATE operations_backup_objects SET last_completed_at=?,retire_after=?
        WHERE (source,object_key) IN (SELECT source,object_key FROM operations_backup_inventory WHERE backup_id=?)`).bind(context2.now(), context2.now() + BACKUP_RETENTION, id),
      database.prepare("DELETE FROM operations_backup_inventory WHERE backup_id=?").bind(id),
      database.prepare("DELETE FROM work_retention_pins WHERE owner=? AND reason='recovery'").bind(`backup:${id}`)
    ]);
    await resolveEvents(database, "backup", id, context2.now());
    report.completed.push(id);
  } catch {
    await recordEvent(database, {
      kind: "backup",
      subject: id,
      code: "backup-failed",
      now: context2.now()
    });
    report.attention.push(id);
  } finally {
    await database.prepare(
      "UPDATE operations_backups SET lease_token=NULL,lease_until=NULL WHERE id=? AND lease_token=?"
    ).bind(id, token).run();
  }
  return report;
}
__name(backupDaily, "backupDaily");

// implementation/apps/web/src/operations/backup-groups.ts
import { createHash as createHash5 } from "node:crypto";

// implementation/apps/web/src/operations/backup-format.ts
import { createHash as createHash4 } from "node:crypto";
var maximumBackupMetadataBytes = 4 * 1024 * 1024;
var maximumBackupPageObjects = 1e3;
function backupGroupPrefix(id) {
  if (!/^[a-f0-9]{32}$/u.test(id)) throw new Error("Invalid backup group identity.");
  return `backup-groups/${id}/`;
}
__name(backupGroupPrefix, "backupGroupPrefix");
async function putBackupJson(store, key2, value, contentAddressed = false) {
  safeKey(key2);
  const encoded = JSON.stringify(value);
  const bytes = new TextEncoder().encode(encoded).byteLength;
  if (bytes > maximumBackupMetadataBytes) throw new Error("Backup metadata exceeds its bound.");
  const digest2 = createHash4("sha256").update(encoded).digest("hex");
  if (contentAddressed) key2 = `${key2}${digest2}.json`;
  await store.put(key2, encoded, {
    onlyIf: { etagDoesNotMatch: "*" },
    httpMetadata: { contentType: "application/json" }
  });
  const saved = await store.get(key2);
  if (!saved) throw new Error("Backup metadata was not saved.");
  const verified = await digestStream(saved.body, maximumBackupMetadataBytes);
  if (verified.digest !== digest2 || verified.bytes !== bytes) {
    throw new Error("Backup metadata was not stored intact.");
  }
  return { key: key2, digest: digest2, bytes };
}
__name(putBackupJson, "putBackupJson");
async function readBackupJson(store, reference) {
  const object2 = await store.get(reference.key);
  if (!object2 || object2.size !== reference.bytes || object2.size > maximumBackupMetadataBytes) {
    await object2?.body.cancel();
    throw new Error("Backup metadata is missing or exceeds its bound.");
  }
  const bytes = new Uint8Array(await new Response(object2.body).arrayBuffer());
  if (bytes.byteLength !== reference.bytes || createHash4("sha256").update(bytes).digest("hex") !== reference.digest) {
    throw new Error("Backup metadata is corrupt.");
  }
  const value = JSON.parse(new TextDecoder().decode(bytes));
  return value;
}
__name(readBackupJson, "readBackupJson");
function record2(value) {
  if (!value || typeof value !== "object" || Array.isArray(value))
    throw new Error("Invalid backup metadata record.");
  return Object.fromEntries(Object.entries(value));
}
__name(record2, "record");
function integer(value, minimum = 0) {
  if (typeof value !== "number" || !Number.isSafeInteger(value) || value < minimum)
    throw new Error("Invalid backup metadata count.");
  return value;
}
__name(integer, "integer");
function digest(value) {
  if (typeof value !== "string" || !/^[a-f0-9]{64}$/u.test(value))
    throw new Error("Invalid backup metadata digest.");
  return value;
}
__name(digest, "digest");
function key(value) {
  if (typeof value !== "string") throw new Error("Invalid backup metadata key.");
  safeKey(value);
  return value;
}
__name(key, "key");
function parseBackupPage(value) {
  const page = record2(value);
  const bytes = integer(page.bytes, 1);
  if (bytes > maximumBackupMetadataBytes) throw new Error("Backup page exceeds its bound.");
  return { key: key(page.key), digest: digest(page.digest), bytes, objects: integer(page.objects) };
}
__name(parseBackupPage, "parseBackupPage");
function parseGroupReference(value) {
  const group = record2(value);
  if (typeof group.id !== "string") throw new Error("Invalid backup group identity.");
  const prefix = backupGroupPrefix(group.id);
  const page = parseBackupPage(group);
  if (page.key !== `${prefix}manifest-${page.digest}.json`)
    throw new Error("Invalid backup group namespace.");
  return { ...page, id: group.id, objectBytes: integer(group.objectBytes) };
}
__name(parseGroupReference, "parseGroupReference");
function parseGroupManifest(value, reference) {
  const manifest = record2(value);
  if (manifest.version !== 1 || manifest.id !== reference.id || !Array.isArray(manifest.pages))
    throw new Error("Invalid backup group manifest.");
  const prefix = backupGroupPrefix(reference.id);
  const pages = manifest.pages.map((entry, ordinal) => {
    const page = parseBackupPage(entry);
    if (page.key !== `${prefix}pages/${String(ordinal).padStart(6, "0")}-${page.digest}.json` || page.objects > maximumBackupPageObjects)
      throw new Error("Invalid backup group page namespace.");
    return page;
  });
  const objects = integer(manifest.objects);
  const bytes = integer(manifest.bytes);
  if (objects !== reference.objects || bytes !== reference.objectBytes || pages.reduce((sum, page) => sum + page.objects, 0) !== objects)
    throw new Error("Backup group counts differ.");
  return { version: 1, id: reference.id, pages, objects, bytes };
}
__name(parseGroupManifest, "parseGroupManifest");
function parseBackupObjects(value, groupId, count) {
  if (!Array.isArray(value) || value.length !== count || value.length > maximumBackupPageObjects)
    throw new Error("Backup object count differs.");
  const prefix = backupGroupPrefix(groupId);
  return value.map((entry) => {
    const object2 = record2(entry);
    if (object2.source !== "images" && object2.source !== "quarantine")
      throw new Error("Invalid backup source.");
    const sourceKey = key(object2.key);
    const backupKey = key(object2.backupKey);
    const expected = `${prefix}objects/${object2.source}/${createHash4("sha256").update(sourceKey).digest("hex")}`;
    if (backupKey !== expected || typeof object2.contentType !== "string")
      throw new Error("Invalid backup object namespace.");
    return {
      source: object2.source,
      key: sourceKey,
      backupKey,
      digest: digest(object2.digest),
      bytes: integer(object2.bytes, 1),
      contentType: object2.contentType
    };
  });
}
__name(parseBackupObjects, "parseBackupObjects");

// implementation/apps/web/src/operations/history-format.ts
var historySections = [
  "run",
  "project",
  "shards",
  "images",
  "captures",
  "comparisons",
  "comparisonRows",
  "decisions",
  "commands",
  "audit",
  "snapshots",
  "snapshotImages",
  "referenceSnapshots",
  "referenceCaptures",
  "referenceImages",
  "referenceSnapshotImages",
  "provenance",
  "manifests",
  "profiles",
  "policies",
  "lineage",
  "ancestry",
  "reservations",
  "identityHistory",
  "decisionReplacements",
  "acceptance",
  "documents",
  "uploads",
  "tasks"
];
var maximumHistoryPages = 4096;
var maximumHistoryRowsPerPage = 100;
function record3(value) {
  if (!value || typeof value !== "object" || Array.isArray(value)) {
    throw new Error("History metadata must be an object.");
  }
  return value;
}
__name(record3, "record");
function integer2(value, minimum, maximum) {
  if (typeof value !== "number" || !Number.isSafeInteger(value) || value < minimum || value > maximum) {
    throw new Error("History metadata has an invalid bound.");
  }
  return value;
}
__name(integer2, "integer");
function section(value) {
  const match = historySections.find((name) => name === value);
  if (!match) throw new Error("History section is unsupported.");
  return match;
}
__name(section, "section");
function historyPrefix(runId, generation) {
  if (![runId, generation].every((value) => /^[A-Za-z0-9_-]{1,100}$/u.test(value))) {
    throw new Error("History identity is outside the private namespace.");
  }
  return `history/${runId}/${generation}/`;
}
__name(historyPrefix, "historyPrefix");
function parseHistoryManifest(value, input) {
  const manifest = record3(value);
  const prefix = historyPrefix(input.runId, input.generation);
  if (manifest.version !== 1 || manifest.runId !== input.runId || manifest.generation !== input.generation || !Array.isArray(manifest.pages) || manifest.pages.length > maximumHistoryPages) {
    throw new Error("History manifest identity is inconsistent.");
  }
  const counts = {};
  let lastSection = -1;
  const pages = manifest.pages.map((value2, index) => {
    const page = record3(value2);
    const name = section(page.section);
    const sectionIndex = historySections.indexOf(name);
    if (page.key !== `${prefix}${String(index).padStart(6, "0")}.json` || typeof page.digest !== "string" || !/^[a-f0-9]{64}$/u.test(page.digest) || sectionIndex < lastSection) {
      throw new Error("History page identity is inconsistent.");
    }
    lastSection = sectionIndex;
    const rows = integer2(page.rows, 1, maximumHistoryRowsPerPage);
    if (typeof page.firstCursor !== "string" || !page.firstCursor || page.firstCursor.length > 8192 || typeof page.lastCursor !== "string" || !page.lastCursor || page.lastCursor.length > 8192)
      throw new Error("History keyset cursor is invalid.");
    const firstCursor = page.firstCursor;
    const lastCursor = page.lastCursor;
    counts[name] = (counts[name] ?? 0) + rows;
    return {
      key: page.key,
      digest: page.digest,
      bytes: integer2(page.bytes, 1, input.maximumObjectBytes),
      section: name,
      rows,
      firstCursor,
      lastCursor
    };
  });
  const declared = record3(manifest.counts);
  for (const name of historySections) {
    if ((declared[name] ?? 0) !== (counts[name] ?? 0)) {
      throw new Error("History section count is inconsistent.");
    }
  }
  if (Object.keys(declared).some((name) => !historySections.some((section2) => name === section2))) {
    throw new Error("History section count is unsupported.");
  }
  return { version: 1, runId: input.runId, generation: input.generation, pages, counts };
}
__name(parseHistoryManifest, "parseHistoryManifest");
function parseHistoryPage(value, manifest, expected) {
  const page = record3(value);
  if (page.version !== 1 || page.runId !== manifest.runId || page.generation !== manifest.generation || page.section !== expected.section || !Array.isArray(page.rows) || page.rows.length !== expected.rows) {
    throw new Error("History page content is inconsistent.");
  }
  return {
    version: 1,
    runId: manifest.runId,
    generation: manifest.generation,
    section: expected.section,
    rows: page.rows.map(record3)
  };
}
__name(parseHistoryPage, "parseHistoryPage");

// implementation/apps/web/src/operations/backup-groups.ts
var backupDeletionGrace = 24 * 60 * 60 * 1e3;
var archiveDescriptor = "json_object('archive_kind',archive.archive_kind,'archive_id',archive.archive_id,'run_id',archive.run_id,'generation',archive.generation,'object_key',archive.object_key,'digest',archive.digest,'bytes',archive.bytes,'page_count',archive.page_count)";
function noGroupDeletion(context2) {
  return assertion(
    context2.database,
    "NOT EXISTS(SELECT 1 FROM operations_backup_groups WHERE state='deleting')"
  );
}
__name(noGroupDeletion, "noGroupDeletion");
function freezeBackupGroups(context2, backupId) {
  const { database } = context2;
  const sources2 = [
    {
      kind: "run",
      query: `SELECT run.id AS source_id,CASE WHEN run.sealed_at IS NULL THEN ? ELSE 'sealed' END AS source_revision,'{}' AS source_json
        FROM ariviso_runs run JOIN work_retained_runs retained ON retained.id=run.id JOIN work_retention_pins pin ON pin.run_id=run.id WHERE retained.byte_state='live' AND pin.owner=?`,
      values: [`backup:${backupId}`, `backup:${backupId}`]
    },
    {
      kind: "comparison",
      query: `SELECT comparison.id AS source_id,CASE WHEN comparison.state='comparing' THEN ? ELSE 'sealed' END AS source_revision,'{}' AS source_json
        FROM ariviso_comparisons comparison JOIN work_retained_runs retained ON retained.id=comparison.run_id JOIN work_retention_pins pin ON pin.run_id=comparison.run_id WHERE retained.byte_state='live' AND pin.owner=?
        AND NOT EXISTS(SELECT 1 FROM operations_ready_history_archives archive WHERE archive.archive_kind='comparison' AND archive.archive_id=comparison.id)
        AND EXISTS(SELECT 1 FROM ariviso_comparison_rows row WHERE row.comparison_id=comparison.id)`,
      values: [`backup:${backupId}`, `backup:${backupId}`]
    },
    {
      kind: "derived",
      query: `SELECT archive.archive_kind||':'||archive.archive_id AS source_id,archive.generation AS source_revision,${archiveDescriptor} AS source_json
        FROM operations_ready_history_archives archive JOIN work_retained_runs retained ON retained.id=archive.run_id JOIN work_retention_pins pin ON pin.run_id=archive.run_id
        WHERE retained.byte_state='live' AND pin.owner=?`,
      values: [`backup:${backupId}`]
    },
    {
      kind: "snapshot",
      query: `SELECT snapshot.id AS source_id,CASE WHEN snapshot.state='copying' THEN ? ELSE 'sealed' END AS source_revision,'{}' AS source_json
        FROM ariviso_snapshots snapshot JOIN ariviso_snapshot_retention retention ON retention.snapshot_id=snapshot.id
        WHERE retention.byte_state IN ('live','retiring') AND EXISTS(SELECT 1 FROM ariviso_snapshot_images image WHERE image.snapshot_id=snapshot.id AND image.copied=1)`,
      values: [`backup:${backupId}`]
    },
    {
      kind: "archive",
      query: `SELECT archive_kind||':'||archive_id AS source_id,generation AS source_revision,
        ${archiveDescriptor} AS source_json FROM operations_ready_history_archives archive`,
      values: []
    }
  ];
  return sources2.flatMap(({ kind, query, values }) => [
    database.prepare(`INSERT INTO operations_backup_groups(id,kind,source_id,source_revision,source_json,state,prefix,retire_after,created_at)
      SELECT lower(hex(randomblob(16))),?,source_id,source_revision,source_json,'copying',NULL,?,?
      FROM(${query}) WHERE true
      ON CONFLICT(kind,source_id,source_revision) DO NOTHING`).bind(kind, context2.now() + BACKUP_RETENTION + backupDeletionGrace, context2.now(), ...values),
    database.prepare(
      "UPDATE operations_backup_groups SET prefix='backup-groups/'||id||'/' WHERE prefix IS NULL"
    ),
    database.prepare(`INSERT INTO operations_backup_members(backup_id,group_id)
      SELECT ?,groups.id FROM operations_backup_groups groups JOIN(${query}) source
      ON groups.kind=? AND groups.source_id=source.source_id AND groups.source_revision=source.source_revision
      WHERE groups.state IN ('copying','ready') ON CONFLICT DO NOTHING`).bind(backupId, ...values, kind)
  ]);
}
__name(freezeBackupGroups, "freezeBackupGroups");
function decodeCursor(group) {
  return group.cursor ? JSON.parse(group.cursor) : null;
}
__name(decodeCursor, "decodeCursor");
function stringCursor(value) {
  if (value !== null && typeof value !== "string") throw new Error("Invalid backup source cursor.");
  return value ?? "";
}
__name(stringCursor, "stringCursor");
async function runSources(context2, group) {
  const cursor = decodeCursor(group);
  if (cursor !== null && (!Array.isArray(cursor) || cursor.length !== 2 || !["images", "metadata"].includes(cursor[0])))
    throw new Error("Invalid run backup cursor.");
  const stage = cursor?.[0] ?? "images";
  const after = stringCursor(cursor?.[1] ?? null);
  const { database, budget } = context2;
  if (stage === "images") {
    const rows2 = await database.prepare(`SELECT 'images' AS source,object_key AS key,digest,bytes FROM ariviso_images
      WHERE run_id=? AND role='original' AND bytes_present=1 AND object_key>? ORDER BY object_key LIMIT ?`).bind(group.source_id, after, budget.objectsPerStep).all();
    const objects2 = rows2.results ?? [];
    return {
      objects: objects2,
      cursor: objects2.length === budget.objectsPerStep ? ["images", objects2.at(-1)?.key] : ["metadata", ""],
      done: false
    };
  }
  const rows = await database.prepare(`SELECT 'quarantine' AS source,object_key AS key,NULL AS digest,NULL AS bytes FROM(
    SELECT plan_object_key AS object_key FROM ingest_run_provenance WHERE run_id=?
    UNION SELECT object_key FROM ingest_manifests WHERE run_id=?) WHERE object_key>? ORDER BY object_key LIMIT ?`).bind(group.source_id, group.source_id, after, budget.objectsPerStep).all();
  const objects = rows.results ?? [];
  return {
    objects,
    cursor: ["metadata", objects.at(-1)?.key ?? after],
    done: objects.length < budget.objectsPerStep
  };
}
__name(runSources, "runSources");
async function comparisonSources(context2, group) {
  const cursor = decodeCursor(group);
  if (cursor !== null && (!Array.isArray(cursor) || cursor.length !== 2 || !Number.isSafeInteger(cursor[0]) || typeof cursor[1] !== "string"))
    throw new Error("Invalid comparison backup cursor.");
  const limit = Math.max(1, Math.floor(context2.budget.objectsPerStep / 2));
  const rows = await context2.database.prepare(`SELECT id,ordinal,result_json FROM ariviso_comparison_rows
    WHERE comparison_id=? AND (ordinal,id)>(?,?) ORDER BY ordinal,id LIMIT ?`).bind(group.source_id, cursor?.[0] ?? -1, cursor?.[1] ?? "", limit).all();
  const ids = /* @__PURE__ */ new Set();
  for (const row of rows.results ?? []) {
    if (!row.result_json) continue;
    const result = JSON.parse(row.result_json);
    if (!result || typeof result !== "object" || Array.isArray(result))
      throw new Error("Invalid saved comparison result.");
    for (const name of ["thumbnailImageId", "maskImageId"]) {
      const id = Object.getOwnPropertyDescriptor(result, name)?.value;
      if (id === void 0) continue;
      if (typeof id !== "string") throw new Error("Invalid saved comparison artifact.");
      ids.add(id);
    }
  }
  const images = ids.size ? await context2.database.prepare(`SELECT 'images' AS source,object_key AS key,digest,bytes FROM ariviso_images
    WHERE id IN(SELECT value FROM json_each(?)) AND bytes_present=1 AND role IN ('thumbnail','mask') ORDER BY object_key`).bind(JSON.stringify([...ids])).all() : { results: [] };
  const last = rows.results?.at(-1);
  return {
    objects: images.results ?? [],
    cursor: last ? [last.ordinal, last.id] : cursor,
    done: (rows.results?.length ?? 0) < limit
  };
}
__name(comparisonSources, "comparisonSources");
async function derivedSources(context2, group) {
  const { pointer, manifest } = await archiveManifest(context2, group);
  const cursor = decodeCursor(group);
  if (cursor !== null && (!Array.isArray(cursor) || cursor.length !== 2 || cursor.some((value) => !Number.isSafeInteger(value) || value < 0)))
    throw new Error("Invalid archived artifact cursor.");
  const pages = manifest.pages.filter((page2) => page2.section === "images");
  const pageIndex = cursor?.[0] ?? 0;
  const offset = cursor?.[1] ?? 0;
  const reference = pages[pageIndex];
  if (!reference) return { objects: [], cursor: [pageIndex, 0], done: true };
  const page = parseHistoryPage(
    await readBackupJson(context2.images, reference),
    manifest,
    reference
  );
  const selected = page.rows.slice(offset, offset + context2.budget.objectsPerStep).filter(
    (row) => row.run_id === pointer.run_id && (row.role === "thumbnail" || row.role === "mask") && row.bytes_present === 1
  );
  const ids = selected.map((row) => {
    if (typeof row.id !== "string") throw new Error("Invalid archived artifact identity.");
    return row.id;
  });
  const rows = ids.length ? await context2.database.prepare(`SELECT id,'images' AS source,object_key AS key,digest,bytes FROM ariviso_images
    WHERE run_id=? AND id IN(SELECT value FROM json_each(?)) AND role IN ('thumbnail','mask') AND bytes_present=1 ORDER BY object_key`).bind(pointer.run_id, JSON.stringify(ids)).all() : { results: [] };
  const objects = rows.results ?? [];
  if (objects.length !== selected.length || objects.some((object2) => {
    const saved = selected.find((row) => row.id === object2.id);
    return !saved || saved.object_key !== object2.key || saved.digest !== object2.digest || saved.bytes !== object2.bytes;
  }))
    throw new Error("Archived artifact is missing or differs from its inventory.");
  const nextPage = offset + context2.budget.objectsPerStep >= page.rows.length;
  return {
    objects,
    cursor: nextPage ? [pageIndex + 1, 0] : [pageIndex, offset + context2.budget.objectsPerStep],
    done: nextPage && pageIndex + 1 >= pages.length
  };
}
__name(derivedSources, "derivedSources");
async function snapshotSources(context2, group) {
  const after = stringCursor(decodeCursor(group));
  const rows = await context2.database.prepare(`SELECT 'images' AS source,copy.object_key AS key,copy.digest,image.bytes
    FROM ariviso_snapshot_images copy JOIN ariviso_images image ON image.id=copy.image_id
    WHERE copy.snapshot_id=? AND copy.copied=1 AND copy.object_key>? ORDER BY copy.object_key LIMIT ?`).bind(group.source_id, after, context2.budget.objectsPerStep).all();
  const objects = rows.results ?? [];
  return {
    objects,
    cursor: objects.at(-1)?.key ?? after,
    done: objects.length < context2.budget.objectsPerStep
  };
}
__name(snapshotSources, "snapshotSources");
async function archiveManifest(context2, group) {
  const pointer = JSON.parse(group.source_json);
  if (!["run", "comparison"].includes(pointer.archive_kind) || `${pointer.archive_kind}:${pointer.archive_id}` !== group.source_id || pointer.generation !== group.source_revision)
    throw new Error("Archive backup identity differs.");
  const raw = await readBackupJson(context2.images, {
    key: pointer.object_key,
    digest: pointer.digest,
    bytes: pointer.bytes
  });
  const manifest = parseHistoryManifest(raw, {
    runId: pointer.run_id,
    generation: pointer.generation,
    maximumObjectBytes: context2.budget.maximumObjectBytes
  });
  if (manifest.pages.length !== pointer.page_count)
    throw new Error("Archive backup page count differs.");
  return { pointer, manifest };
}
__name(archiveManifest, "archiveManifest");
async function archiveSources(context2, group) {
  const { pointer, manifest } = await archiveManifest(context2, group);
  const cursor = decodeCursor(group);
  if (cursor !== null && (!Number.isSafeInteger(cursor) || typeof cursor !== "number" || cursor < 0))
    throw new Error("Invalid archive backup cursor.");
  const offset = cursor ?? 0;
  const objects = [
    { source: "images", key: pointer.object_key, digest: pointer.digest, bytes: pointer.bytes },
    ...manifest.pages.map((page) => ({ source: "images", ...page }))
  ];
  return {
    objects: objects.slice(offset, offset + context2.budget.objectsPerStep),
    cursor: offset + context2.budget.objectsPerStep,
    done: offset + context2.budget.objectsPerStep >= objects.length
  };
}
__name(archiveSources, "archiveSources");
function groupReference(group) {
  if (group.state !== "ready" || !group.manifest_key || !group.manifest_digest || !group.manifest_bytes)
    throw new Error("Backup group is not ready.");
  return {
    id: group.id,
    key: group.manifest_key,
    digest: group.manifest_digest,
    bytes: group.manifest_bytes,
    objects: group.object_count,
    objectBytes: group.object_bytes
  };
}
__name(groupReference, "groupReference");
async function copyBackupGroup(context2, group, guard) {
  const prefix = backupGroupPrefix(group.id);
  if (prefix !== group.prefix || group.state !== "copying")
    throw new Error("Invalid backup group state.");
  if (group.cursor === '"complete"') {
    const pages = await context2.database.prepare(
      "SELECT object_key AS key,digest,bytes,objects FROM operations_backup_group_pages WHERE group_id=? ORDER BY ordinal"
    ).bind(group.id).all();
    const manifest = {
      version: 1,
      id: group.id,
      pages: pages.results ?? [],
      objects: group.object_count,
      bytes: group.object_bytes
    };
    const saved = await putBackupJson(context2.backups, `${prefix}manifest-`, manifest, true);
    await atomic(context2.database, [
      guard(),
      context2.database.prepare(
        "UPDATE operations_backup_groups SET state='ready',manifest_key=?,manifest_digest=?,manifest_bytes=? WHERE id=? AND state='copying'"
      ).bind(saved.key, saved.digest, saved.bytes, group.id),
      context2.database.prepare("DELETE FROM operations_backup_group_pages WHERE group_id=?").bind(group.id)
    ]);
    return true;
  }
  const source = await {
    run: runSources,
    comparison: comparisonSources,
    derived: derivedSources,
    snapshot: snapshotSources,
    archive: archiveSources
  }[group.kind](context2, group);
  const objects = await mapConcurrent(source.objects, 6, async (object2) => {
    const keyDigest = createHash5("sha256").update(object2.key).digest("hex");
    const backupKey = `${prefix}objects/${object2.source}/${keyDigest}`;
    const copy = await copyVerifiedObject({
      source: object2.source === "images" ? context2.images : context2.quarantine,
      destination: context2.backups,
      sourceKey: object2.key,
      destinationKey: backupKey,
      maximum: context2.budget.maximumObjectBytes,
      expectedDigest: object2.digest ?? void 0,
      expectedBytes: object2.bytes ?? void 0
    });
    return { source: object2.source, key: object2.key, backupKey, ...copy };
  });
  const statements = [];
  if (objects.length) {
    const page = await putBackupJson(
      context2.backups,
      `${prefix}pages/${String(group.page_count).padStart(6, "0")}-`,
      objects,
      true
    );
    statements.push(
      context2.database.prepare(
        "INSERT INTO operations_backup_group_pages(group_id,ordinal,object_key,digest,bytes,objects) VALUES(?,?,?,?,?,?)"
      ).bind(group.id, group.page_count, page.key, page.digest, page.bytes, objects.length)
    );
  }
  statements.push(
    context2.database.prepare(
      `UPDATE operations_backup_groups SET cursor=?,page_count=page_count+?,object_count=object_count+?,object_bytes=object_bytes+? WHERE id=? AND state='copying'`
    ).bind(
      JSON.stringify(source.done ? "complete" : source.cursor),
      objects.length ? 1 : 0,
      objects.length,
      objects.reduce((sum, object2) => sum + object2.bytes, 0),
      group.id
    )
  );
  await atomic(context2.database, [guard(), ...statements]);
  return false;
}
__name(copyBackupGroup, "copyBackupGroup");

// implementation/apps/web/src/operations/backups.ts
function backupGuard2(context2, id, token) {
  return assertion(
    context2.database,
    "EXISTS(SELECT 1 FROM operations_backups WHERE id=? AND state IN ('exporting','copying') AND lease_token=? AND lease_until>?)",
    [id, token, context2.now()]
  );
}
__name(backupGuard2, "backupGuard");
function pinLiveRuns(context2, id) {
  return context2.database.prepare(
    "INSERT INTO work_retention_pins(run_id,owner,reason) SELECT id,?,'recovery' FROM work_retained_runs WHERE byte_state='live' ON CONFLICT(run_id,owner) DO NOTHING"
  ).bind(`backup:${id}`);
}
__name(pinLiveRuns, "pinLiveRuns");
async function backupDaily2(context2, exporter) {
  const { database, budget } = context2;
  if (budget.objectsPerStep < 2 || budget.objectsPerStep > 1e3)
    throw new Error("Grouped backups require between 2 and 1000 objects per step.");
  const report = { completed: [], deferred: [], attention: [], hasMore: false };
  const unfinished = await database.prepare(
    "SELECT * FROM operations_backups WHERE state IN ('exporting','copying') ORDER BY created_at LIMIT 1"
  ).first();
  if (unfinished?.format_version === 2) return backupDaily(context2, exporter);
  const id = unfinished?.id ?? new Date(context2.now()).toISOString().slice(0, 10);
  const existing = unfinished ?? await database.prepare("SELECT * FROM operations_backups WHERE id=?").bind(id).first();
  if (existing && !["exporting", "copying"].includes(existing.state)) return report;
  if (!existing) {
    await atomic(database, [
      noBackupDeletion(context2),
      noGroupDeletion(context2),
      assertion(
        database,
        "NOT EXISTS(SELECT 1 FROM operations_backups WHERE state IN ('exporting','copying'))"
      ),
      assertion(
        database,
        "NOT EXISTS(SELECT 1 FROM work_retained_runs WHERE byte_state='deleting') AND NOT EXISTS(SELECT 1 FROM ariviso_snapshot_retention WHERE byte_state='deleting')"
      ),
      database.prepare(
        "INSERT INTO operations_backups(id,state,format_version,created_at) VALUES(?,'exporting',3,?)"
      ).bind(id, context2.now()),
      pinLiveRuns(context2, id)
    ]);
  }
  const token = crypto.randomUUID();
  const row = await database.prepare(`UPDATE operations_backups SET lease_token=?,lease_until=? WHERE id=? AND state IN ('exporting','copying')
    AND (lease_token IS NULL OR lease_until<=?) RETURNING *`).bind(token, context2.now() + budget.leaseMilliseconds, id, context2.now()).first();
  if (!row) {
    report.deferred.push(id);
    return report;
  }
  const guard = /* @__PURE__ */ __name(() => backupGuard2(context2, id, token), "guard");
  const prefix = `backups/${id}/`;
  let publishing = false;
  try {
    if (row.state === "exporting") {
      const key2 = `${prefix}database-${token}.sql`;
      const written = await putBoundedStream(
        context2.backups,
        key2,
        await exporter.export(),
        budget.maximumDatabaseBytes
      );
      const saved = await context2.backups.get(key2);
      if (!saved) throw new Error("Database export was not saved.");
      const verified = await digestStream(saved.body, budget.maximumDatabaseBytes);
      if (!written.bytes || verified.bytes !== written.bytes || verified.digest !== written.digest)
        throw new Error("Database export integrity failed.");
      await atomic(database, [
        guard(),
        assertion(
          database,
          "NOT EXISTS(SELECT 1 FROM work_retained_runs WHERE byte_state='deleting') AND NOT EXISTS(SELECT 1 FROM ariviso_snapshot_retention WHERE byte_state='deleting')"
        ),
        pinLiveRuns(context2, id),
        ...freezeBackupGroups(context2, id),
        database.prepare(
          "UPDATE operations_backups SET state='copying',database_key=?,database_digest=?,database_bytes=? WHERE id=?"
        ).bind(key2, written.digest, written.bytes, id)
      ]);
    } else if (row.source_kind === 0) {
      const group = row.active_group_id ? await database.prepare(`SELECT groups.* FROM operations_backup_groups groups WHERE groups.id=?
          AND EXISTS(SELECT 1 FROM operations_backup_members WHERE backup_id=? AND group_id=groups.id)`).bind(row.active_group_id, id).first() : await database.prepare(`SELECT groups.* FROM operations_backup_members member JOIN operations_backup_groups groups ON groups.id=member.group_id
          WHERE member.backup_id=? AND member.group_id>? AND groups.state='copying' ORDER BY member.group_id LIMIT 1`).bind(id, row.cursor ?? "").first();
      if (group) {
        if (!row.active_group_id)
          await atomic(database, [
            guard(),
            database.prepare("UPDATE operations_backups SET active_group_id=? WHERE id=?").bind(group.id, id)
          ]);
        if (group.state === "ready" || await copyBackupGroup(context2, group, guard))
          await atomic(database, [
            guard(),
            database.prepare("UPDATE operations_backups SET cursor=?,active_group_id=NULL WHERE id=?").bind(group.id, id)
          ]);
      } else if (row.active_group_id) {
        throw new Error("The active backup group disappeared.");
      } else
        await atomic(database, [
          guard(),
          database.prepare("UPDATE operations_backups SET source_kind=1,cursor=NULL WHERE id=?").bind(id)
        ]);
    } else if (row.source_kind === 1) {
      const groups = await database.prepare(`SELECT groups.* FROM operations_backup_members member JOIN operations_backup_groups groups ON groups.id=member.group_id
        WHERE member.backup_id=? AND member.group_id>? ORDER BY member.group_id LIMIT ?`).bind(id, row.cursor ?? "", budget.objectsPerStep).all();
      const references = (groups.results ?? []).map(groupReference);
      const statements = [];
      if (references.length) {
        const saved = await putBackupJson(
          context2.backups,
          `${prefix}groups/${String(row.page_count).padStart(6, "0")}-`,
          references,
          true
        );
        statements.push(
          database.prepare(
            "INSERT INTO operations_backup_pages(backup_id,ordinal,object_key,digest,bytes,objects) VALUES(?,?,?,?,?,?)"
          ).bind(id, row.page_count, saved.key, saved.digest, saved.bytes, references.length)
        );
      }
      statements.push(
        database.prepare(
          `UPDATE operations_backups SET cursor=?,source_kind=?,completed_at=CASE WHEN ?=2 THEN ? ELSE completed_at END,page_count=page_count+?,required_count=required_count+?,object_count=object_count+?,image_bytes=image_bytes+? WHERE id=?`
        ).bind(
          references.at(-1)?.id ?? row.cursor,
          references.length === budget.objectsPerStep ? 1 : 2,
          references.length === budget.objectsPerStep ? 1 : 2,
          context2.now(),
          references.length ? 1 : 0,
          references.length,
          references.reduce((sum, group) => sum + group.objects, 0),
          references.reduce((sum, group) => sum + group.objectBytes, 0),
          id
        )
      );
      await atomic(database, [guard(), ...statements]);
    } else {
      if (!row.database_key || !row.database_digest || !row.database_bytes)
        throw new Error("Backup database record is incomplete.");
      const pages = await database.prepare(
        `SELECT object_key AS key,digest,bytes,objects FROM operations_backup_pages WHERE backup_id=? ORDER BY ordinal`
      ).bind(id).all();
      const manifest = {
        version: 3,
        id,
        createdAt: row.created_at,
        completedAt: row.completed_at ?? row.created_at,
        database: { key: row.database_key, digest: row.database_digest, bytes: row.database_bytes },
        pages: pages.results ?? [],
        groups: row.required_count,
        objects: row.object_count,
        bytes: row.image_bytes
      };
      publishing = true;
      await putBackupJson(context2.backups, `${prefix}complete.json`, manifest);
      await atomic(database, [
        guard(),
        database.prepare("UPDATE operations_backups SET state='complete',completed_at=? WHERE id=?").bind(context2.now(), id),
        database.prepare(
          `UPDATE operations_backup_groups SET last_completed_at=?,retire_after=? WHERE id IN(SELECT group_id FROM operations_backup_members WHERE backup_id=?)`
        ).bind(context2.now(), context2.now() + BACKUP_RETENTION + backupDeletionGrace, id),
        database.prepare("DELETE FROM operations_backup_members WHERE backup_id=?").bind(id),
        database.prepare("DELETE FROM operations_backup_pages WHERE backup_id=?").bind(id),
        database.prepare("DELETE FROM work_retention_pins WHERE owner=? AND reason='recovery'").bind(`backup:${id}`)
      ]);
      await resolveEvents(database, "backup", id, context2.now());
      report.completed.push(id);
      return report;
    }
    report.hasMore = true;
    report.deferred.push(id);
  } catch {
    const owned = "EXISTS(SELECT 1 FROM operations_backups WHERE id=? AND state IN ('exporting','copying') AND lease_token=? AND lease_until>?)";
    const statements = [
      database.prepare(`INSERT INTO operations_events(id,kind,subject_id,code,first_seen_at,last_seen_at)
      SELECT ?,'backup',?,'backup-failed',?,? WHERE ${owned}
      ON CONFLICT(id) DO UPDATE SET last_seen_at=excluded.last_seen_at,occurrences=operations_events.occurrences+1,resolved_at=NULL RETURNING id`).bind(
        `backup:${id}:backup-failed`,
        id,
        context2.now(),
        context2.now(),
        id,
        token,
        context2.now()
      )
    ];
    if (!publishing && row.source_kind < 2) {
      statements.push(
        database.prepare(`UPDATE operations_backups SET failures=failures+1,state=CASE WHEN failures+1>=? THEN 'failed' ELSE state END
        WHERE id=? AND state IN ('exporting','copying') AND lease_token=? AND lease_until>?`).bind(budget.maxAttempts, id, token, context2.now())
      );
      const failed = "EXISTS(SELECT 1 FROM operations_backups WHERE id=? AND state='failed' AND lease_token=?)";
      statements.push(
        database.prepare(`DELETE FROM operations_backup_members WHERE backup_id=? AND ${failed}`).bind(id, id, token)
      );
      statements.push(
        database.prepare(
          `DELETE FROM work_retention_pins WHERE owner=? AND reason='recovery' AND ${failed}`
        ).bind(`backup:${id}`, id, token)
      );
    }
    const saved = await atomic(database, statements);
    if (saved[0]?.results?.length) report.attention.push(id);
  } finally {
    await database.prepare(
      "UPDATE operations_backups SET lease_token=NULL,lease_until=NULL WHERE id=? AND lease_token=?"
    ).bind(id, token).run();
  }
  return report;
}
__name(backupDaily2, "backupDaily");

// implementation/apps/web/src/operations/history.ts
import { createHash as createHash6 } from "node:crypto";
import { Buffer as Buffer2 } from "node:buffer";

// implementation/packages/protocol/src/hash.ts
function canonicalJson(value) {
  const seen = /* @__PURE__ */ new Set();
  const encode4 = /* @__PURE__ */ __name((item) => {
    if (item === null) return "null";
    if (typeof item === "string" || typeof item === "boolean") {
      return JSON.stringify(item);
    }
    if (typeof item === "number" && Number.isFinite(item)) {
      return JSON.stringify(item);
    }
    if (typeof item !== "object" || !item) {
      throw new TypeError("Canonical JSON requires finite JSON values");
    }
    if (seen.has(item)) {
      throw new TypeError("Canonical JSON cannot contain cycles");
    }
    if (!Array.isArray(item) && Object.getPrototypeOf(item) !== Object.prototype && Object.getPrototypeOf(item) !== null) {
      throw new TypeError("Canonical JSON requires plain objects");
    }
    seen.add(item);
    let result;
    if (Array.isArray(item)) {
      if (Object.keys(item).length !== item.length) {
        throw new TypeError("Canonical JSON cannot contain sparse arrays");
      }
      result = `[${item.map(encode4).join(",")}]`;
    } else {
      result = `{${Object.entries(item).sort(([left], [right]) => left < right ? -1 : left > right ? 1 : 0).map(([key2, entry]) => `${JSON.stringify(key2)}:${encode4(entry)}`).join(",")}}`;
    }
    seen.delete(item);
    return result;
  }, "encode");
  return encode4(value);
}
__name(canonicalJson, "canonicalJson");
async function sha256(bytes) {
  const digest2 = await crypto.subtle.digest("SHA-256", Uint8Array.from(bytes));
  return Array.from(new Uint8Array(digest2), (byte) => byte.toString(16).padStart(2, "0")).join("");
}
__name(sha256, "sha256");
async function digestJson(value) {
  return sha256(new TextEncoder().encode(canonicalJson(value)));
}
__name(digestJson, "digestJson");
function isJson(value, depth = 0) {
  if (depth > 24) return false;
  if (value === null) return true;
  if (typeof value === "string" || typeof value === "boolean") return true;
  if (typeof value === "number") {
    return Number.isFinite(value);
  }
  if (Array.isArray(value)) {
    return value.every((item) => isJson(item, depth + 1));
  }
  if (!value || typeof value !== "object") return false;
  if (Object.getPrototypeOf(value) !== Object.prototype && Object.getPrototypeOf(value) !== null)
    return false;
  return Object.values(value).every((item) => isJson(item, depth + 1));
}
__name(isJson, "isJson");

// implementation/packages/protocol/src/validate.ts
var ProtocolError = class extends Error {
  constructor(code, message2) {
    super(message2);
    this.code = code;
    this.name = "ProtocolError";
  }
  code;
  static {
    __name(this, "ProtocolError");
  }
};
function fail(message2) {
  throw new ProtocolError("INVALID_MANIFEST", message2);
}
__name(fail, "fail");
function object(value, label) {
  if (!value || typeof value !== "object" || Array.isArray(value)) {
    fail(`${label} must be an object`);
  }
  if (Object.getPrototypeOf(value) !== Object.prototype && Object.getPrototypeOf(value) !== null) {
    fail(`${label} must be a plain object`);
  }
}
__name(object, "object");
function field(value, key2) {
  if (!Object.hasOwn(value, key2)) {
    fail(`Missing ${key2}`);
  }
  return value[key2];
}
__name(field, "field");
function string(value, label, maximum = 1024) {
  if (typeof value !== "string" || !value.length || value.length > maximum || Array.from(value).some(
    (character) => character.charCodeAt(0) < 32 || character.charCodeAt(0) === 127
  )) {
    fail(`${label} must be a nonempty string of at most ${maximum} characters without controls`);
  }
}
__name(string, "string");
function integer3(value, label, minimum = 0, maximum = Number.MAX_SAFE_INTEGER) {
  if (typeof value !== "number" || !Number.isSafeInteger(value) || value < minimum || value > maximum) {
    fail(`${label} must be an integer between ${minimum} and ${maximum}`);
  }
}
__name(integer3, "integer");
function member(value, values, label) {
  if (!values.some((entry) => entry === value)) {
    fail(`${label} must be one of ${values.join(", ")}`);
  }
}
__name(member, "member");
function validateDigest(value, label = "digest") {
  if (typeof value !== "string" || !/^[a-f0-9]{64}$/.test(value)) {
    fail(`${label} must be a lowercase SHA-256 digest`);
  }
}
__name(validateDigest, "validateDigest");
function validateViewport(value) {
  object(value, "viewport");
  integer3(field(value, "width"), "viewport.width", 1, 1e5);
  integer3(field(value, "height"), "viewport.height", 1, 1e5);
}
__name(validateViewport, "validateViewport");
function validateProfile(value) {
  object(value, "profile");
  member(field(value, "browser"), ["chromium", "firefox", "webkit"], "browser");
  for (const key2 of ["browserVersion", "locale", "timezone", "comparisonEngineVersion"]) {
    string(field(value, key2), key2);
  }
  for (const key2 of ["osImageDigest", "fontsDigest", "comparisonPolicyDigest"]) {
    validateDigest(field(value, key2), key2);
  }
  validateViewport(field(value, "viewport"));
  const scale = field(value, "deviceScaleFactor");
  if (typeof scale !== "number" || !Number.isFinite(scale) || scale <= 0 || scale > 10) {
    fail("deviceScaleFactor must be greater than zero and at most 10");
  }
  member(field(value, "reducedMotion"), ["reduce", "no-preference"], "reducedMotion");
  member(field(value, "colorScheme"), ["light", "dark", "no-preference"], "colorScheme");
  member(field(value, "contrast"), ["more", "no-preference"], "contrast");
  member(field(value, "forcedColors"), ["active", "none"], "forcedColors");
  member(field(value, "animationPolicy"), ["disabled"], "animationPolicy");
  const options = field(value, "captureOptions");
  object(options, "captureOptions");
  if (!isJson(options)) {
    fail("captureOptions must contain bounded JSON values");
  }
}
__name(validateProfile, "validateProfile");

// implementation/apps/web/src/profiles.ts
function metadataObject(encoded) {
  const value = JSON.parse(encoded);
  if (value === null || typeof value !== "object" || Array.isArray(value)) {
    throw new Error("Capture metadata must be a JSON object.");
  }
  return Object.fromEntries(Object.entries(value));
}
__name(metadataObject, "metadataObject");
function referencedDigest(metadata, digest2) {
  const value = metadata.profile;
  if (value === null || typeof value !== "object" || Array.isArray(value)) return null;
  if (!Object.hasOwn(value, "$arivisoProfileDigest")) return null;
  const reference = Object.fromEntries(Object.entries(value));
  if (Object.keys(reference).length !== 1 || reference.$arivisoProfileDigest !== digest2) {
    throw new Error("The stored capture profile reference is invalid.");
  }
  validateDigest(digest2);
  return digest2;
}
__name(referencedDigest, "referencedDigest");
async function hydrateCaptureMetadata(database, captures) {
  const metadata = captures.map((capture) => metadataObject(capture.metadata_json));
  const references = captures.map((capture, index) => {
    const value = metadata[index];
    if (!value) throw new Error("Capture metadata is unavailable.");
    return referencedDigest(value, capture.profile_digest);
  });
  const digests = [...new Set(references.filter((digest2) => digest2 !== null))];
  const profiles = /* @__PURE__ */ new Map();
  for (let offset = 0; offset < digests.length; offset += 50) {
    const result = await database.prepare(
      "SELECT digest,profile_json FROM ariviso_capture_profiles WHERE digest IN (SELECT value FROM json_each(?))"
    ).bind(JSON.stringify(digests.slice(offset, offset + 50))).all();
    for (const row of result.results ?? []) {
      const profile = JSON.parse(row.profile_json);
      validateProfile(profile);
      if (canonicalJson(profile) !== row.profile_json || await digestJson(profile) !== row.digest) {
        throw new Error("The stored capture profile does not match its digest.");
      }
      profiles.set(row.digest, profile);
    }
  }
  return captures.map((capture, index) => {
    const digest2 = references[index];
    if (!digest2) return capture;
    const profile = profiles.get(digest2);
    if (!profile) throw new Error("The stored capture profile is unavailable.");
    return {
      ...capture,
      metadata_json: JSON.stringify({ ...metadata[index], profile })
    };
  });
}
__name(hydrateCaptureMetadata, "hydrateCaptureMetadata");

// implementation/apps/web/src/operations/history.ts
var sources = {
  run: { table: "ariviso_runs", scope: "record.id=?" },
  project: {
    table: "ariviso_projects",
    scope: "record.id=(SELECT project_id FROM ariviso_runs WHERE id=?)"
  },
  shards: { table: "ariviso_shards", scope: "record.run_id=?" },
  images: {
    table: "ariviso_images",
    scope: "record.run_id=? OR record.id IN(SELECT image_id FROM ariviso_captures WHERE run_id=?)"
  },
  captures: { table: "ariviso_captures", scope: "record.run_id=?" },
  comparisons: { table: "ariviso_comparisons", scope: "record.run_id=?" },
  comparisonRows: {
    table: "ariviso_comparison_rows",
    scope: "record.comparison_id IN(SELECT id FROM ariviso_comparisons WHERE run_id=?)"
  },
  decisions: {
    table: "ariviso_decisions",
    scope: "record.row_id IN(SELECT row.id FROM ariviso_comparison_rows row JOIN ariviso_comparisons comparison ON comparison.id=row.comparison_id WHERE comparison.run_id=?) OR record.id IN(SELECT source_decision_id FROM ariviso_comparison_rows row JOIN ariviso_comparisons comparison ON comparison.id=row.comparison_id WHERE comparison.run_id=?)"
  },
  commands: {
    table: "ariviso_commands",
    scope: "record.comparison_id IN(SELECT id FROM ariviso_comparisons WHERE run_id=?)"
  },
  audit: { table: "ariviso_audit", scope: "record.run_id=?" },
  snapshots: { table: "ariviso_snapshots", scope: "record.run_id=?" },
  snapshotImages: {
    table: "ariviso_snapshot_images",
    scope: "record.snapshot_id IN(SELECT id FROM ariviso_snapshots WHERE run_id=?)"
  },
  referenceSnapshots: {
    table: "ariviso_snapshots",
    scope: "record.id IN(SELECT reference_snapshot_id FROM ariviso_comparisons WHERE run_id=?)"
  },
  referenceCaptures: {
    table: "ariviso_captures",
    scope: "record.id IN(SELECT reference_capture_id FROM ariviso_comparison_rows row JOIN ariviso_comparisons comparison ON comparison.id=row.comparison_id WHERE comparison.run_id=?)"
  },
  referenceImages: {
    table: "ariviso_images",
    scope: "record.id IN(SELECT capture.image_id FROM ariviso_captures capture JOIN ariviso_comparison_rows row ON row.reference_capture_id=capture.id JOIN ariviso_comparisons comparison ON comparison.id=row.comparison_id WHERE comparison.run_id=?)"
  },
  referenceSnapshotImages: {
    table: "ariviso_snapshot_images",
    scope: "record.snapshot_id IN(SELECT reference_snapshot_id FROM ariviso_comparisons WHERE run_id=?)"
  },
  provenance: {
    table: "ingest_run_provenance",
    scope: "record.run_id=? OR record.run_id IN(SELECT image.run_id FROM ariviso_images image JOIN ariviso_captures capture ON capture.image_id=image.id WHERE capture.run_id=?)"
  },
  manifests: {
    table: "ingest_manifests",
    scope: "record.run_id=? OR record.run_id IN(SELECT image.run_id FROM ariviso_images image JOIN ariviso_captures capture ON capture.image_id=image.id WHERE capture.run_id=?)"
  },
  profiles: {
    table: "ariviso_capture_profiles",
    scope: "record.digest IN(SELECT profile_digest FROM ariviso_captures WHERE run_id=? OR id IN(SELECT reference_capture_id FROM ariviso_comparison_rows row JOIN ariviso_comparisons comparison ON comparison.id=row.comparison_id WHERE comparison.run_id=?))"
  },
  policies: {
    table: "ariviso_policies",
    scope: "record.digest IN(SELECT policy_digest FROM ariviso_comparisons WHERE run_id=?)"
  },
  lineage: { table: "ariviso_lineage", scope: "record.source_run_id=? OR record.target_run_id=?" },
  ancestry: { table: "ariviso_ancestry", scope: "record.run_id=?" },
  reservations: {
    table: "ariviso_reservations",
    scope: "record.project_id=(SELECT project_id FROM ariviso_runs WHERE id=?) AND record.lineage_key=(SELECT lineage_key FROM ariviso_runs WHERE id=?)"
  },
  identityHistory: {
    table: "ariviso_identity_history",
    scope: "record.project_id=(SELECT project_id FROM ariviso_runs WHERE id=?) AND record.lineage_key=(SELECT lineage_key FROM ariviso_runs WHERE id=?)"
  },
  decisionReplacements: {
    table: "ariviso_decision_replacements",
    scope: "record.source_decision_id IN(SELECT decision.id FROM ariviso_decisions decision JOIN ariviso_comparison_rows row ON row.id=decision.row_id JOIN ariviso_comparisons comparison ON comparison.id=row.comparison_id WHERE comparison.run_id=?) OR record.replacement_decision_id IN(SELECT decision.id FROM ariviso_decisions decision JOIN ariviso_comparison_rows row ON row.id=decision.row_id JOIN ariviso_comparisons comparison ON comparison.id=row.comparison_id WHERE comparison.run_id=?)"
  },
  uploads: { table: "ingest_uploads", scope: "record.run_id=?" },
  tasks: {
    table: "work_tasks",
    scope: "record.id IN(SELECT row.id FROM ariviso_comparison_rows row JOIN ariviso_comparisons comparison ON comparison.id=row.comparison_id WHERE comparison.run_id=?)"
  }
};
var comparisonSources2 = {
  comparisons: { table: "ariviso_comparisons", scope: "record.id=?" },
  comparisonRows: { table: "ariviso_comparison_rows", scope: "record.comparison_id=?" },
  captures: {
    table: "ariviso_captures",
    scope: "record.id IN(SELECT candidate_capture_id FROM ariviso_comparison_rows WHERE comparison_id=?)"
  },
  referenceCaptures: {
    table: "ariviso_captures",
    scope: "record.id IN(SELECT reference_capture_id FROM ariviso_comparison_rows WHERE comparison_id=?)"
  },
  images: {
    table: "ariviso_images",
    scope: "record.id IN(SELECT capture.image_id FROM ariviso_captures capture JOIN ariviso_comparison_rows row ON row.candidate_capture_id=capture.id WHERE row.comparison_id=?) OR record.id IN(SELECT json_extract(result_json,'$.maskImageId') FROM ariviso_comparison_rows WHERE comparison_id=?) OR record.id IN(SELECT json_extract(result_json,'$.thumbnailImageId') FROM ariviso_comparison_rows WHERE comparison_id=?)"
  },
  referenceImages: {
    table: "ariviso_images",
    scope: "record.id IN(SELECT capture.image_id FROM ariviso_captures capture JOIN ariviso_comparison_rows row ON row.reference_capture_id=capture.id WHERE row.comparison_id=?)"
  },
  profiles: {
    table: "ariviso_capture_profiles",
    scope: "record.digest IN(SELECT capture.profile_digest FROM ariviso_captures capture JOIN ariviso_comparison_rows row ON row.candidate_capture_id=capture.id OR row.reference_capture_id=capture.id WHERE row.comparison_id=?)"
  },
  policies: {
    table: "ariviso_policies",
    scope: "record.digest IN(SELECT policy_digest FROM ariviso_comparisons WHERE id=?)"
  },
  tasks: {
    table: "work_tasks",
    scope: "record.id IN(SELECT id FROM ariviso_comparison_rows WHERE comparison_id=?)"
  }
};
function hash(value) {
  return createHash6("sha256").update(value).digest("hex");
}
__name(hash, "hash");
function encode3(value, maximum) {
  const bytes = new TextEncoder().encode(JSON.stringify(value));
  if (bytes.byteLength > maximum)
    throw new Error("History metadata exceeds the configured object bound.");
  return bytes;
}
__name(encode3, "encode");
async function readVerifiedHistoryObject(context2, reference) {
  const stored = await context2.images.get(reference.key);
  if (!stored || stored.size !== reference.bytes || stored.size > context2.budget.maximumObjectBytes) {
    await stored?.body.cancel();
    throw new Error("History object is missing or has an invalid size.");
  }
  const reader = stored.body.getReader();
  const chunks = [];
  let length = 0;
  try {
    while (true) {
      const next = await reader.read();
      if (next.done) break;
      length += next.value.byteLength;
      if (length > reference.bytes) throw new Error("History object exceeds its recorded size.");
      chunks.push(next.value);
    }
  } finally {
    await reader.cancel();
    reader.releaseLock();
  }
  const bytes = new Uint8Array(length);
  let offset = 0;
  for (const chunk of chunks) {
    bytes.set(chunk, offset);
    offset += chunk.length;
  }
  if (length !== reference.bytes || hash(bytes) !== reference.digest)
    throw new Error("History object integrity failed.");
  return JSON.parse(new TextDecoder("utf-8", { fatal: true }).decode(bytes));
}
__name(readVerifiedHistoryObject, "readVerifiedHistoryObject");
async function putVerified(context2, key2, value) {
  const encoded = encode3(value, context2.budget.maximumObjectBytes);
  const reference = { key: key2, digest: hash(encoded), bytes: encoded.byteLength };
  await context2.images.put(key2, encoded, {
    onlyIf: { etagDoesNotMatch: "*" },
    httpMetadata: { contentType: "application/json" }
  });
  await readVerifiedHistoryObject(context2, reference);
  return reference;
}
__name(putVerified, "putVerified");
async function readHistoryManifest(context2, runId) {
  const pointer = await context2.database.prepare("SELECT * FROM operations_run_archives WHERE run_id=? AND state='ready'").bind(runId).first();
  if (!pointer) return null;
  const prefix = historyPrefix(runId, pointer.generation);
  if (pointer.object_key !== `${prefix}manifest.json`)
    throw new Error("History root is outside its private namespace.");
  const manifest = parseHistoryManifest(
    await readVerifiedHistoryObject(context2, {
      key: pointer.object_key,
      digest: pointer.digest,
      bytes: pointer.bytes
    }),
    {
      runId,
      generation: pointer.generation,
      maximumObjectBytes: context2.budget.maximumObjectBytes
    }
  );
  if (manifest.pages.length !== pointer.page_count)
    throw new Error("History page count differs from its pointer.");
  return { pointer, manifest };
}
__name(readHistoryManifest, "readHistoryManifest");
async function readArchivedDocument(context2, runId, objectKey) {
  const root = await readHistoryManifest(context2, runId);
  if (!root) throw new Error("History source document is missing.");
  const chunks = /* @__PURE__ */ new Map();
  let expected;
  let collected = 0;
  for (const reference of root.manifest.pages) {
    if (reference.section !== "documents") continue;
    const page = parseHistoryPage(
      await readVerifiedHistoryObject(context2, reference),
      root.manifest,
      reference
    );
    for (const row of page.rows) {
      if (row.objectKey !== objectKey) continue;
      if (row.encoding !== "base64" || typeof row.chunk !== "number" || !Number.isSafeInteger(row.chunk) || row.chunk < 0 || typeof row.total !== "number" || !Number.isSafeInteger(row.total) || row.total < 1 || row.chunk >= row.total || typeof row.digest !== "string" || typeof row.bytes !== "number" || !Number.isSafeInteger(row.bytes) || row.bytes < 0 || row.bytes > context2.budget.maximumObjectBytes || typeof row.content !== "string" || chunks.has(row.chunk))
        throw new Error("Archived source document is inconsistent.");
      if (expected && (expected.digest !== row.digest || expected.bytes !== row.bytes || expected.total !== row.total))
        throw new Error("Archived source document identity changed.");
      expected = { digest: row.digest, bytes: row.bytes, total: row.total };
      const chunk = Buffer2.from(row.content, "base64");
      collected += chunk.byteLength;
      if (collected > expected.bytes)
        throw new Error("Archived source document exceeds its bound.");
      chunks.set(row.chunk, chunk);
    }
  }
  if (!expected || chunks.size !== expected.total || collected !== expected.bytes)
    throw new Error("Archived source document is incomplete.");
  const content = new Uint8Array(expected.bytes);
  let offset = 0;
  for (let index = 0; index < expected.total; index++) {
    const chunk = chunks.get(index);
    if (!chunk) throw new Error("Archived source document chunk is missing.");
    content.set(chunk, offset);
    offset += chunk.length;
  }
  if (hash(content) !== expected.digest)
    throw new Error("Archived source document integrity failed.");
  return content;
}
__name(readArchivedDocument, "readArchivedDocument");
function sourceKeys(section2) {
  switch (section2) {
    case "shards":
      return ["key"];
    case "profiles":
    case "policies":
      return ["digest"];
    case "provenance":
      return ["run_id"];
    case "manifests":
      return ["run_id", "shard_key"];
    case "lineage":
      return ["source_run_id", "target_run_id"];
    case "ancestry":
      return ["ancestor_sha"];
    case "snapshotImages":
    case "referenceSnapshotImages":
      return ["snapshot_id", "capture_id"];
    case "reservations":
      return ["project_id", "lineage_key", "item_key", "variant_key", "kind"];
    case "identityHistory":
      return ["project_id", "lineage_key", "item_key", "variant_key"];
    case "decisionReplacements":
      return ["source_decision_id", "replacement_decision_id", "scope_run_id"];
    default:
      return ["id"];
  }
}
__name(sourceKeys, "sourceKeys");
var sourceColumnCache = /* @__PURE__ */ new WeakMap();
async function sourceReadLimit(context2, input) {
  const cache2 = sourceColumnCache.get(context2.database) ?? /* @__PURE__ */ new Map();
  sourceColumnCache.set(context2.database, cache2);
  let columns = cache2.get(input.table);
  if (!columns) {
    const schema = await context2.database.prepare(`PRAGMA table_info(${input.table})`).all();
    columns = (schema.results ?? []).map((column) => column.name);
    if (!columns.length || columns.some((column) => !/^[a-z_][a-z0-9_]*$/u.test(column))) {
      throw new Error("History source columns are invalid.");
    }
    cache2.set(input.table, columns);
  }
  const fields = columns.map((column) => `'${column}',record.${column}`).join(",");
  const sizes = await context2.database.prepare(`SELECT length(CAST(json_object(${fields}) AS BLOB)) AS bytes
    FROM ${input.table} record WHERE ${input.predicate} ORDER BY ${input.order} LIMIT ?`).bind(...input.parameters, maximumHistoryRowsPerPage).all();
  const budget = Math.min(context2.budget.maximumObjectBytes, 1024 * 1024);
  let bytes = 0;
  let count = 0;
  for (const row of sizes.results ?? []) {
    if (!Number.isSafeInteger(row.bytes) || row.bytes < 1) {
      throw new Error("History source size is invalid.");
    }
    if (count && bytes + row.bytes > budget) break;
    bytes += row.bytes;
    count++;
    if (bytes >= budget) break;
  }
  return count;
}
__name(sourceReadLimit, "sourceReadLimit");
async function sourcePage(context2, {
  runId,
  section: section2,
  cursor,
  comparisonId
}) {
  if (comparisonId && !Object.hasOwn(comparisonSources2, section2)) return [];
  if (section2 === "acceptance") {
    const run = await new Service(context2.database).run(runId);
    const ids = run.comparison_id ? await new Service(context2.database).eligibleApprovalRowIds(run.comparison_id) : [];
    return ids.sort().filter((id) => id > cursor).slice(0, maximumHistoryRowsPerPage).map((id) => ({ _history_cursor: id, id }));
  }
  if (section2 === "documents") {
    const documents = await context2.database.prepare(
      `WITH owners AS (SELECT ? AS id UNION SELECT image.run_id FROM ariviso_images image JOIN ariviso_captures capture ON capture.image_id=image.id WHERE capture.run_id=?) SELECT plan_object_key AS object_key,run_id FROM ingest_run_provenance WHERE run_id IN(SELECT id FROM owners) UNION SELECT object_key,run_id FROM ingest_manifests WHERE run_id IN(SELECT id FROM owners) ORDER BY object_key,run_id LIMIT 1001`
    ).bind(runId, runId).all();
    const keys2 = documents.results ?? [];
    if (keys2.length > 1e3) throw new Error("History has too many source documents.");
    let documentIndex = Math.floor(Number(cursor || "0") / 1e6);
    let chunkIndex = Number(cursor || "0") % 1e6;
    while (documentIndex < keys2.length) {
      const document = keys2[documentIndex];
      if (!document) throw new Error("History document is missing.");
      const stored = await context2.quarantine.get(document.object_key);
      if (stored && stored.size > context2.budget.maximumObjectBytes) {
        await stored.body.cancel();
        throw new Error("History source document exceeds its bound.");
      }
      const content = stored ? new Uint8Array(await new Response(stored.body).arrayBuffer()) : await readArchivedDocument(context2, document.run_id, document.object_key);
      if (stored && content.byteLength !== stored.size)
        throw new Error("History source document length changed.");
      const chunkBytes = Math.min(
        128 * 1024,
        Math.floor((context2.budget.maximumObjectBytes - 2048) * 3 / 4)
      );
      if (chunkBytes < 1) throw new Error("History object bound cannot hold source metadata.");
      const total = Math.max(1, Math.ceil(content.length / chunkBytes));
      if (chunkIndex >= total) {
        documentIndex++;
        chunkIndex = 0;
        continue;
      }
      const digest2 = hash(content);
      return Array.from(
        { length: Math.min(total - chunkIndex, maximumHistoryRowsPerPage) },
        (_, index) => {
          const chunk = chunkIndex + index;
          return {
            _history_cursor: String(documentIndex * 1e6 + chunk + 1).padStart(12, "0"),
            objectKey: document.object_key,
            encoding: "base64",
            chunk,
            total,
            digest: digest2,
            bytes: content.byteLength,
            content: Buffer2.from(
              content.subarray(chunk * chunkBytes, (chunk + 1) * chunkBytes)
            ).toString("base64")
          };
        }
      );
    }
    return [];
  }
  const source = comparisonId ? comparisonSources2[section2] : sources[section2];
  if (!source) return [];
  const runParameters = (source.scope.match(/\?/gu) ?? []).map(() => comparisonId ?? runId);
  const keys = sourceKeys(section2);
  const columns = keys.map((key2) => `record.${key2}`);
  const encodedCursor = keys.length === 1 ? columns[0] : `json_array(${columns.join(",")})`;
  const boundary = keys.length === 1 ? `${columns[0]}>?` : `(${columns.join(",")})>(${keys.map((_, index) => `json_extract(?,'$[${index}]')`).join(",")})`;
  const cursorValues = keys.length === 1 ? [cursor] : keys.map(() => cursor || JSON.stringify(keys.map(() => "")));
  const limit = ["shards", "commands", "audit", "provenance", "tasks"].includes(section2) ? await sourceReadLimit(context2, {
    table: source.table,
    predicate: `(${source.scope}) AND ${boundary}`,
    order: columns.join(","),
    parameters: [...runParameters, ...cursorValues]
  }) : maximumHistoryRowsPerPage;
  if (!limit) return [];
  const page = await context2.database.prepare(
    `SELECT ${encodedCursor} AS _history_cursor,record.* FROM ${source.table} record WHERE (${source.scope}) AND ${boundary} ORDER BY ${columns.join(",")} LIMIT ?`
  ).bind(...runParameters, ...cursorValues, limit).all();
  const rows = page.results ?? [];
  if (section2 === "commands") {
    for (const command of rows) {
      if (typeof command.request_json !== "string") throw new Error("Command request is invalid.");
      command.request_digest = await commandRequestDigest(command.request_json);
    }
  }
  if (section2 === "captures") return hydrateHistoryCaptures(context2, rows);
  if (section2 !== "referenceCaptures") return rows;
  const owners = new Set(
    rows.flatMap((row) => typeof row.run_id === "string" ? [row.run_id] : [])
  );
  for (const owner of owners) {
    const root = await readHistoryManifest(context2, owner);
    if (!root) continue;
    const required = new Set(rows.filter((row) => row.run_id === owner).map((row) => row.id));
    for (const reference of root.manifest.pages) {
      if (reference.section !== "captures") continue;
      if (!rows.some(
        (row) => row.run_id === owner && required.has(row.id) && row._history_cursor >= reference.firstCursor && row._history_cursor <= reference.lastCursor
      ))
        continue;
      const saved = parseHistoryPage(
        await readVerifiedHistoryObject(context2, reference),
        root.manifest,
        reference
      );
      for (const capture of saved.rows) {
        if (!required.has(capture.id)) continue;
        const target = rows.findIndex((row) => row.id === capture.id);
        const original = rows[target];
        if (!original) throw new Error("Referenced capture identity is inconsistent.");
        rows[target] = { ...capture, _history_cursor: original._history_cursor };
        required.delete(capture.id);
      }
      if (!required.size) break;
    }
    if (required.size) throw new Error("Referenced capture history is incomplete.");
  }
  return hydrateHistoryCaptures(context2, rows);
}
__name(sourcePage, "sourcePage");
async function hydrateHistoryCaptures(context2, rows) {
  const captures = rows.map((row) => {
    if (typeof row.profile_digest !== "string" || typeof row.metadata_json !== "string")
      throw new Error("Capture history metadata is invalid.");
    return { ...row, profile_digest: row.profile_digest, metadata_json: row.metadata_json };
  });
  const hydrated = await hydrateCaptureMetadata(context2.database, captures);
  return hydrated.map((row) => ({
    ...row,
    metadata_json: canonicalJson(JSON.parse(row.metadata_json))
  }));
}
__name(hydrateHistoryCaptures, "hydrateHistoryCaptures");
function manifestFor(runId, generation, pages) {
  const counts = {};
  for (const page of pages) {
    counts[page.section] = (counts[page.section] ?? 0) + page.rows;
  }
  return { version: 1, runId, generation, pages, counts };
}
__name(manifestFor, "manifestFor");
async function claim(context2, runId, token) {
  const now = context2.now();
  const run = await context2.database.prepare(
    `SELECT run.revision,project.revision AS project_revision FROM ariviso_runs run JOIN ariviso_projects project ON project.id=run.project_id WHERE run.id=? AND (${archiveEligibilitySql("run")})`
  ).bind(runId).first();
  if (!run) return null;
  const existing = await context2.database.prepare("SELECT * FROM operations_run_archives WHERE run_id=?").bind(runId).first();
  if (existing?.state === "ready" || (existing?.lease_until ?? 0) > now) return null;
  const reusable = existing && existing.source_revision === run.revision && existing.project_revision === run.project_revision;
  const generation = reusable ? existing.generation : crypto.randomUUID();
  const progress = reusable ? existing.progress_json : JSON.stringify({ section: 0, cursor: "", pages: [] });
  const objectKey = `${historyPrefix(runId, generation)}manifest.json`;
  await atomic(context2.database, [
    assertion(
      context2.database,
      `EXISTS(SELECT 1 FROM ariviso_runs run JOIN ariviso_projects project ON project.id=run.project_id WHERE run.id=? AND run.revision=? AND project.revision=? AND (${archiveEligibilitySql("run")}))`,
      [runId, run.revision, run.project_revision]
    ),
    assertion(
      context2.database,
      "NOT EXISTS(SELECT 1 FROM operations_run_archives WHERE run_id=? AND (state='ready' OR lease_until>?))",
      [runId, now]
    ),
    context2.database.prepare(
      `INSERT INTO operations_run_archives(run_id,generation,state,source_revision,project_revision,object_key,progress_json,lease_token,lease_until,created_at) VALUES(?,?,'building',?,?,?,?,?,?,?) ON CONFLICT(run_id) DO UPDATE SET generation=excluded.generation,source_revision=excluded.source_revision,project_revision=excluded.project_revision,object_key=excluded.object_key,progress_json=excluded.progress_json,lease_token=excluded.lease_token,lease_until=excluded.lease_until,digest=NULL,bytes=NULL,page_count=0`
    ).bind(
      runId,
      generation,
      run.revision,
      run.project_revision,
      objectKey,
      progress,
      token,
      now + context2.budget.leaseMilliseconds,
      now
    )
  ]);
  return {
    runId,
    generation,
    sourceRevision: run.revision,
    projectRevision: run.project_revision,
    objectKey,
    progress: JSON.parse(progress)
  };
}
__name(claim, "claim");
async function saveProgress(context2, { runId, token, progress }) {
  const encoded = JSON.stringify(progress);
  if (new TextEncoder().encode(encoded).length > 1024 * 1024)
    throw new Error("History inventory exceeds its database bound.");
  await atomic(context2.database, [
    assertion(
      context2.database,
      "EXISTS(SELECT 1 FROM operations_run_archives WHERE run_id=? AND state='building' AND lease_token=? AND lease_until>?)",
      [runId, token, context2.now()]
    ),
    context2.database.prepare(
      "UPDATE operations_run_archives SET progress_json=?,page_count=?,lease_until=? WHERE run_id=? AND lease_token=?"
    ).bind(
      encoded,
      progress.pages.length,
      context2.now() + context2.budget.leaseMilliseconds,
      runId,
      token
    )
  ]);
}
__name(saveProgress, "saveProgress");
async function writeHistoryStep(context2, input) {
  const { progress, runId, generation } = input;
  let pagesWritten = 0;
  while (pagesWritten < input.limit && progress.section < historySections.length) {
    const section2 = historySections[progress.section];
    if (!section2) throw new Error("History section cursor is invalid.");
    const rows = await sourcePage(context2, {
      runId,
      section: section2,
      cursor: progress.cursor,
      comparisonId: input.comparisonId
    });
    if (!rows.length) {
      progress.section++;
      progress.cursor = "";
      continue;
    }
    const values = [];
    let lastCursor = progress.cursor;
    let encodedBytes = Buffer2.byteLength(
      JSON.stringify({ version: 1, runId, generation, section: section2, rows: [] }),
      "utf8"
    );
    for (const row of rows) {
      const { _history_cursor, ...value } = row;
      const rowBytes = Buffer2.byteLength(JSON.stringify(value), "utf8") + (values.length ? 1 : 0);
      if (encodedBytes + rowBytes > context2.budget.maximumObjectBytes) {
        if (!values.length) throw new Error("A history row exceeds the configured object bound.");
        break;
      }
      values.push(value);
      encodedBytes += rowBytes;
      lastCursor = _history_cursor;
    }
    if (progress.pages.length >= maximumHistoryPages)
      throw new Error("History has too many pages.");
    const key2 = `${historyPrefix(runId, generation)}${String(progress.pages.length).padStart(6, "0")}.json`;
    const saved = await putVerified(context2, key2, {
      version: 1,
      runId,
      generation,
      section: section2,
      rows: values
    });
    const first = rows[0];
    if (!first) throw new Error("History source page is empty.");
    progress.pages.push({
      ...saved,
      section: section2,
      rows: values.length,
      firstCursor: first._history_cursor,
      lastCursor
    });
    progress.cursor = lastCursor;
    await input.onPage(section2, values);
    pagesWritten++;
  }
  if (progress.section !== historySections.length) return { pagesWritten, root: null };
  const manifest = manifestFor(runId, generation, progress.pages);
  parseHistoryManifest(manifest, {
    runId,
    generation,
    maximumObjectBytes: context2.budget.maximumObjectBytes
  });
  progress.verifiedPages ??= 0;
  while (pagesWritten < input.limit && progress.verifiedPages < progress.pages.length) {
    const reference = progress.pages[progress.verifiedPages];
    if (!reference) throw new Error("History verification cursor is invalid.");
    parseHistoryPage(await readVerifiedHistoryObject(context2, reference), manifest, reference);
    progress.verifiedPages++;
    await input.onPage(reference.section, []);
    pagesWritten++;
  }
  if (progress.verifiedPages !== progress.pages.length) return { pagesWritten, root: null };
  const root = await putVerified(
    context2,
    `${historyPrefix(runId, generation)}manifest.json`,
    manifest
  );
  return { pagesWritten, root };
}
__name(writeHistoryStep, "writeHistoryStep");
async function archiveClosedRuns(context2) {
  const report = { completed: [], deferred: [], attention: [], hasMore: false };
  const candidates = await context2.database.prepare(
    `SELECT run.id FROM ariviso_runs run WHERE (${archiveEligibilitySql("run")}) AND NOT EXISTS(SELECT 1 FROM operations_run_archives archive WHERE archive.run_id=run.id AND (archive.state='ready' OR archive.lease_until>? OR archive.retry_at>?)) ORDER BY run.created_at,run.id LIMIT ?`
  ).bind(context2.now(), context2.now(), context2.budget.tasksPerStep).all();
  report.hasMore = (candidates.results?.length ?? 0) === context2.budget.tasksPerStep;
  let remaining = Math.min(context2.budget.objectsPerStep, 20);
  for (const candidate of candidates.results ?? []) {
    if (!remaining) {
      report.hasMore = true;
      break;
    }
    const token = crypto.randomUUID();
    try {
      const claimed = await claim(context2, candidate.id, token);
      if (!claimed) continue;
      const progress = claimed.progress;
      const written = await writeHistoryStep(context2, {
        runId: candidate.id,
        generation: claimed.generation,
        progress,
        limit: remaining,
        async onPage(section2, values) {
          if (section2 === "commands") {
            for (const command of values) {
              if (typeof command.id !== "string" || typeof command.request_json !== "string")
                throw new Error("Archived command identity is invalid.");
              await prepareArchivedCommandReplay(context2.database, {
                runId: candidate.id,
                generation: claimed.generation,
                token,
                sourceRevision: claimed.sourceRevision,
                projectRevision: claimed.projectRevision,
                commandId: command.id,
                requestJson: command.request_json,
                now: context2.now()
              });
            }
          }
          await saveProgress(context2, { runId: candidate.id, token, progress });
        }
      });
      remaining -= written.pagesWritten;
      if (written.root) {
        const verified = written.root;
        await compactRunHistory(context2.database, {
          runId: candidate.id,
          generation: claimed.generation,
          token,
          sourceRevision: claimed.sourceRevision,
          projectRevision: claimed.projectRevision,
          objectKey: claimed.objectKey,
          digest: verified.digest,
          bytes: verified.bytes,
          pageCount: progress.pages.length,
          now: context2.now()
        });
        report.completed.push(candidate.id);
        await resolveEvents(context2.database, "history", candidate.id, context2.now());
      } else {
        await saveProgress(context2, { runId: candidate.id, token, progress });
        report.deferred.push(candidate.id);
        report.hasMore = true;
      }
    } catch (error) {
      if (error instanceof ConflictError) {
        report.deferred.push(candidate.id);
      } else {
        report.attention.push(candidate.id);
        await context2.database.prepare(
          "UPDATE operations_run_archives SET attempts=attempts+1,retry_at=? WHERE run_id=? AND state='building' AND lease_token=?"
        ).bind(context2.now() + 60 * 60 * 1e3, candidate.id, token).run();
        await recordEvent(context2.database, {
          kind: "history",
          subject: candidate.id,
          code: "archive-failed",
          now: context2.now()
        });
      }
    } finally {
      await context2.database.prepare(
        "UPDATE operations_run_archives SET lease_token=NULL,lease_until=NULL WHERE run_id=? AND state='building' AND lease_token=?"
      ).bind(candidate.id, token).run();
    }
  }
  return report;
}
__name(archiveClosedRuns, "archiveClosedRuns");
async function* readArchivedSection(context2, runId, section2) {
  const root = await readHistoryManifest(context2, runId);
  if (!root) throw new Error("Run history is unavailable.");
  for (const reference of root.manifest.pages) {
    if (reference.section !== section2) continue;
    const page = parseHistoryPage(
      await readVerifiedHistoryObject(context2, reference),
      root.manifest,
      reference
    );
    yield page.rows;
  }
}
__name(readArchivedSection, "readArchivedSection");

// implementation/apps/web/src/operations/recovery.ts
async function sanitizeRestoredDatabase(database, now) {
  const tables = await database.prepare("SELECT name FROM sqlite_master WHERE type='table'").all();
  const names = new Set((tables.results ?? []).map((row) => row.name));
  const commands = [];
  for (const table2 of ["session", "verification", "ingest_review_sessions", "rateLimit"]) {
    if (names.has(table2)) commands.push(`DELETE FROM "${table2}"`);
  }
  if (names.has("account"))
    commands.push(
      "UPDATE account SET accessToken=NULL,refreshToken=NULL,idToken=NULL,accessTokenExpiresAt=NULL,refreshTokenExpiresAt=NULL"
    );
  for (const table2 of ["operations_run_archives", "operations_comparison_archives"]) {
    if (names.has(table2)) commands.push(`DELETE FROM "${table2}" WHERE state='building'`);
  }
  for (const table2 of [
    "operations_backup_members",
    "operations_backup_group_pages",
    "operations_backup_groups",
    "operations_backup_inventory",
    "operations_backup_objects"
  ]) {
    if (names.has(table2)) commands.push(`DELETE FROM "${table2}"`);
  }
  commands.push(
    // Old external writes cannot be proven settled by reading a backup. Keep them fenced.
    "UPDATE work_checks SET ambiguous=1",
    "UPDATE work_status_outbox SET state='obsolete' WHERE state!='complete'",
    "UPDATE operations_check_creations SET state='dead',last_error='restored-environment' WHERE state!='complete'",
    "UPDATE work_tasks SET state='dead',lease_token=NULL,lease_until=NULL,last_error='restored-environment' WHERE state!='complete'",
    "UPDATE ariviso_runs SET active=0,state=CASE WHEN state='accepted' THEN state ELSE 'failed' END",
    "UPDATE ariviso_snapshots SET state='revoked',reference_eligible=0 WHERE state='copying'",
    "DELETE FROM work_retention_pins WHERE reason IN ('recovery','promotion')",
    "DELETE FROM operations_backup_pages",
    "DELETE FROM operations_backup_required",
    "DELETE FROM operations_backups",
    "DELETE FROM operations_exports",
    "DELETE FROM operations_cursors"
  );
  await database.batch(commands.map((sql) => database.prepare(sql)));
  await database.prepare(
    "INSERT INTO operations_events(id,kind,subject_id,code,first_seen_at,last_seen_at) VALUES('restore:activation:secrets-required','restore','activation','secrets-required',?,?) ON CONFLICT(id) DO UPDATE SET resolved_at=NULL,last_seen_at=excluded.last_seen_at"
  ).bind(now, now).run();
  const violations = await database.prepare("PRAGMA foreign_key_check").all();
  if (violations.results?.length) throw new Error("Restored database contains broken references.");
}
__name(sanitizeRestoredDatabase, "sanitizeRestoredDatabase");

// stores.mjs
function prefixedStore(store, prefix, counts, label) {
  const record4 = /* @__PURE__ */ __name((method) => {
    counts[`${label}.${method}`] = (counts[`${label}.${method}`] ?? 0) + 1;
  }, "record");
  const key2 = /* @__PURE__ */ __name((value) => {
    if (typeof value !== "string" || !value || value.startsWith("/") || value.includes("..") || /[\u0000-\u001f]/u.test(value)) throw new Error("Unsafe diagnostic object key.");
    return prefix + value;
  }, "key");
  return {
    async get(value) {
      record4("get");
      return store.get(key2(value));
    },
    async put(value, ...args) {
      record4("put");
      return store.put(key2(value), ...args);
    },
    async delete(value) {
      record4("delete");
      return store.delete(Array.isArray(value) ? value.map(key2) : key2(value));
    },
    async list(options) {
      record4("list");
      const page = await store.list({ ...options, prefix: prefix + (options.prefix ?? "") });
      return { ...page, objects: page.objects.map((object2) => ({ ...object2, key: object2.key.slice(prefix.length) })) };
    },
    async createMultipartUpload(value, options) {
      record4("createMultipartUpload");
      return measuredUpload(await store.createMultipartUpload(key2(value), options), record4);
    },
    resumeMultipartUpload(value, id) {
      return measuredUpload(store.resumeMultipartUpload(key2(value), id), record4);
    }
  };
}
__name(prefixedStore, "prefixedStore");
function measuredUpload(upload, record4) {
  return { key: upload.key, uploadId: upload.uploadId, ...Object.fromEntries(["uploadPart", "complete", "abort"].map((method) => [method, async (...args) => {
    record4("multipart." + method);
    return upload[method](...args);
  }])) };
}
__name(measuredUpload, "measuredUpload");
function corpusKey(value) {
  let match = value.match(/^runs\/e0800000-0000-4000-8000-000000000001\/images\/e0800000-0000-4000-8001-(\d{12})$/u);
  let role = "original";
  if (!match) {
    match = value.match(/^baselines\/e0800000-0000-4000-8000-000000000005\/e0800000-0000-4000-8001-(\d{12})\.webp$/u);
    role = "baseline";
  }
  if (!match) return null;
  const index = Number(match[1]);
  if (!Number.isSafeInteger(index) || index < 0 || index >= 35820) throw new Error("Corpus index exceeds fixture bound.");
  const file = `image-${String(index).padStart(6, "0")}.webp`;
  return role === "original" ? `runs/e08-baseline/originals/${file}` : `baselines/e08-baseline-snapshot/${file}`;
}
__name(corpusKey, "corpusKey");
function sourceImages(corpus, overlay, counts) {
  return {
    ...overlay,
    async get(key2) {
      const mapped = corpusKey(key2);
      if (!mapped) return overlay.get(key2);
      counts["corpus.get"] = (counts["corpus.get"] ?? 0) + 1;
      return corpus.get(mapped);
    },
    async put(key2, ...args) {
      if (corpusKey(key2)) throw new Error("The corpus is read-only.");
      return overlay.put(key2, ...args);
    },
    async delete(keys) {
      if ((Array.isArray(keys) ? keys : [keys]).some(corpusKey)) throw new Error("The corpus is read-only.");
      return overlay.delete(keys);
    }
  };
}
__name(sourceImages, "sourceImages");
function measuredDatabase(database, queries) {
  const record4 = /* @__PURE__ */ __name((sql, result, start) => {
    queries.push({ sql: sql.slice(0, 120), milliseconds: performance.now() - start, meta: result.meta ?? null });
    return result;
  }, "record");
  const wrap = /* @__PURE__ */ __name((statement2, sql) => ({ native: statement2, sql, bind(...values) {
    return wrap(statement2.bind(...values), sql);
  }, async all() {
    const start = performance.now();
    return record4(sql, await statement2.all(), start);
  }, async first() {
    return (await this.all()).results?.[0] ?? null;
  }, async run() {
    const start = performance.now();
    return record4(sql, await statement2.run(), start);
  } }), "wrap");
  return { prepare(sql) {
    return wrap(database.prepare(sql), sql);
  }, async batch(statements) {
    const start = performance.now();
    const results = await database.batch(statements.map((statement2) => statement2.native));
    return results.map((result, index) => record4(statements[index].sql, result, start));
  } };
}
__name(measuredDatabase, "measuredDatabase");

// worker.mjs
var maximumObjectBytes = 2097152;
var maximumDatabaseBytes = 536870912;
function exportAttempt(value) {
  if (typeof value !== "string" || !/^[-a-f0-9]{36}$/u.test(value)) throw new Error("Invalid export attempt.");
  return value;
}
__name(exportAttempt, "exportAttempt");
function stagedKey(day, attempt) {
  if (typeof day !== "string" || !/^\d{4}-\d{2}-\d{2}$/u.test(day)) throw new Error("Invalid day.");
  return `drill/staged-${day}-${exportAttempt(attempt)}.sql`;
}
__name(stagedKey, "stagedKey");
var reviewRunId = "e0800000-0000-4000-8000-000000000002";
var json = /* @__PURE__ */ __name((value, status = 200) => Response.json(value, { status, headers: { "cache-control": "no-store" } }), "json");
async function authorized(request, token) {
  if (!token) return false;
  const values = await Promise.all([request.headers.get("authorization") ?? "", `Bearer ${token}`].map((value) => crypto.subtle.digest("SHA-256", new TextEncoder().encode(value))));
  const left = new Uint8Array(values[0]), right = new Uint8Array(values[1]);
  return left.reduce((value, byte, index) => value | byte ^ right[index], 0) === 0;
}
__name(authorized, "authorized");
function bindings(env, scenario, counts, queries, target = false) {
  const prefix = scenario + "/";
  const database = target ? scenario === "small" ? env.TARGET_SMALL : env.TARGET_LARGE : scenario === "small" ? env.SOURCE_SMALL : env.SOURCE_LARGE;
  const overlay = prefixedStore(target ? env.TARGET_IMAGES : env.OVERLAY, prefix, counts, target ? "targetImages" : "overlay");
  return { database: measuredDatabase(database, queries), nativeDatabase: database, images: target ? overlay : sourceImages(env.CORPUS, overlay, counts), quarantine: prefixedStore(target ? env.TARGET_PRIVATE : env.PRIVATE, prefix, counts, target ? "targetPrivate" : "private"), backups: prefixedStore(env.BACKUPS, prefix, counts, "backups") };
}
__name(bindings, "bindings");
function context(stores, offset = 0) {
  return { ...stores, budget: { tasksPerStep: 25, objectsPerStep: 1e3, leaseMilliseconds: 3e5, maxAttempts: 5, maximumObjectBytes, maximumDatabaseBytes, maximumExportEntries: 1e5 }, now: /* @__PURE__ */ __name(() => Date.now() + offset, "now"), comparisons: { async send() {
    throw new Error("No diagnostic queue publishing.");
  } }, github: { appId: "diagnostic", repositoryId: "diagnostic", repository: "diagnostic/diagnostic", async request() {
    throw new Error("No diagnostic GitHub writes.");
  } }, origin: "https://diagnostic.invalid" };
}
__name(context, "context");
async function archiveState(database) {
  const rows = await database.prepare("SELECT run_id,generation,state,page_count,progress_json FROM operations_run_archives ORDER BY run_id").all();
  return rows.results.map((row) => {
    const progress = JSON.parse(row.progress_json);
    return { runId: row.run_id, generation: row.generation, state: row.state, pages: row.page_count, section: progress.section ?? null, verifiedPages: progress.verifiedPages ?? 0 };
  });
}
__name(archiveState, "archiveState");
async function verifyStored(store, reference, maximum = maximumObjectBytes) {
  const object2 = await store.get(reference.key);
  if (!object2) throw new Error("Missing referenced object.");
  const result = await digestStream(object2.body, maximum);
  if (result.digest !== reference.digest || result.bytes !== reference.bytes) throw new Error("Referenced bytes differ.");
  return result;
}
__name(verifyStored, "verifyStored");
async function tableFingerprint(database, table2) {
  if (!/^[a-z_]+$/u.test(table2)) throw new Error("Invalid table.");
  const columns = await database.prepare(`PRAGMA table_info(${table2})`).all();
  if (!columns.results.length) throw new Error("Unknown table.");
  const key2 = columns.results.filter((row) => row.pk).sort((a, b) => a.pk - b.pk).map((row) => `"${row.name}"`).join(",") || "rowid";
  const hash2 = createHash7("sha256");
  let offset = 0, count = 0;
  while (true) {
    const page = await database.prepare(`SELECT * FROM ${table2} ORDER BY ${key2} LIMIT 500 OFFSET ?`).bind(offset).all();
    for (const row of page.results) {
      hash2.update(JSON.stringify(row));
      hash2.update("\n");
      count++;
    }
    if (page.results.length < 500) break;
    offset += page.results.length;
  }
  return { table: table2, count, digest: hash2.digest("hex") };
}
__name(tableFingerprint, "tableFingerprint");
var worker_default = { async fetch(request, env) {
  if (!await authorized(request, env.DRILL_TOKEN)) return json({ error: "unauthorized" }, 401);
  const url = new URL(request.url);
  const scenario = url.searchParams.get("scenario");
  if (!["small", "large"].includes(scenario)) return json({ error: "Invalid workload." }, 400);
  const counts = {}, queries = [];
  const started = performance.now();
  const source = bindings(env, scenario, counts, queries);
  const target = bindings(env, scenario, counts, queries, true);
  const report = /* @__PURE__ */ __name((value) => json({ ...value, milliseconds: performance.now() - started, counts, queries, colo: request.cf?.colo ?? null }), "report");
  try {
    if (url.pathname === "/health") return report({ diagnostic: true, scenario, secretEpoch: env.SECRET_EPOCH ?? "initial" });
    if (url.pathname === "/seed/object" && request.method === "PUT") {
      const key2 = safeKey(url.searchParams.get("key") ?? "");
      const store = url.searchParams.get("store");
      if (!["private", "overlay"].includes(store)) throw new Error("Invalid seed destination.");
      if (store === "overlay" && !key2.startsWith("history/") && !key2.startsWith("derived/")) throw new Error("Seed cannot write original corpus keys.");
      const destination = store === "private" ? source.quarantine : source.images;
      return report(await putBoundedStream(destination, key2, { body: request.body }, maximumObjectBytes));
    }
    if (url.pathname === "/source/verify" && request.method === "POST") {
      const input = await request.json();
      if (!Array.isArray(input.objects) || input.objects.length > 1e3) throw new Error("Invalid verification page.");
      const values = await mapConcurrent(input.objects, 6, (object2) => verifyStored(object2.bucket === "images" ? source.images : source.quarantine, object2));
      return report({ objects: values.length, bytes: values.reduce((sum, value) => sum + value.bytes, 0) });
    }
    if (url.pathname === "/source/summary") {
      const sample = await source.nativeDatabase.prepare("SELECT 1 AS sample").all();
      const tables = ["ariviso_runs", "ariviso_captures", "ariviso_images", "ariviso_comparison_rows", "ariviso_decisions", "ariviso_commands", "work_tasks", "ariviso_capture_profiles", "operations_run_archives", "operations_backup_groups"];
      const rows = {};
      for (const table2 of tables) rows[table2] = (await source.nativeDatabase.prepare(`SELECT COUNT(*) AS count FROM ${table2}`).first()).count;
      return report({ rows, physicalBytes: sample.meta.size_after, archive: await archiveState(source.database) });
    }
    if (url.pathname === "/archive/step" && request.method === "POST") {
      const before = await archiveState(source.database);
      const result = await archiveClosedRuns(context(source));
      const after = await archiveState(source.database);
      return report({ result, before, after });
    }
    if (url.pathname === "/backup/state") return report({ rows: (await source.database.prepare("SELECT id,state,format_version,source_kind,page_count,required_count,object_count,image_bytes,database_key,database_digest,database_bytes,created_at,completed_at FROM operations_backups ORDER BY created_at").all()).results });
    if (url.pathname === "/backup/step" && request.method === "POST") {
      const input = await request.json();
      const offset = input.offset ?? 0;
      if (![0, 864e5].includes(offset)) throw new Error("Invalid logical day.");
      const day = new Date(Date.now() + offset).toISOString().slice(0, 10);
      const attempt = exportAttempt(input.attempt);
      const result = await backupDaily2(context(source, offset), { async export() {
        await source.backups.put(`drill/export-request-${attempt}.json`, JSON.stringify({ day, attempt }), { onlyIf: { etagDoesNotMatch: "*" } });
        const until = Date.now() + 24e4;
        while (Date.now() < until) {
          const staged = await source.backups.get(stagedKey(day, attempt));
          if (staged) return { body: staged.body, bytes: staged.size };
          await setTimeout(2e3);
        }
        throw new Error("The local export controller did not stage SQL within the lease.");
      } });
      return report({ result, day, row: await source.database.prepare("SELECT * FROM operations_backups WHERE id=?").bind(day).first() });
    }
    if (url.pathname === "/backup/export-request") {
      const attempt = exportAttempt(url.searchParams.get("attempt"));
      const object2 = await source.backups.get(`drill/export-request-${attempt}.json`);
      return report({ request: object2 ? await new Response(object2.body).json() : null });
    }
    if (url.pathname === "/backup/stage-abort" && request.method === "POST") {
      const input = await request.json();
      await source.backups.resumeMultipartUpload(stagedKey(input.day, input.attempt), input.uploadId).abort();
      return report({ aborted: true });
    }
    if (url.pathname === "/backup/stage-start" && request.method === "POST") {
      const input = await request.json();
      if (!/^\d{4}-\d{2}-\d{2}$/u.test(input.day)) throw new Error("Invalid day.");
      const upload = await source.backups.createMultipartUpload(stagedKey(input.day, input.attempt), { httpMetadata: { contentType: "application/sql" } });
      return report({ uploadId: upload.uploadId });
    }
    if (url.pathname === "/backup/stage-part" && request.method === "PUT") {
      const day = url.searchParams.get("day"), part = Number(url.searchParams.get("part"));
      if (!/^\d{4}-\d{2}-\d{2}$/u.test(day) || !Number.isInteger(part) || part < 1 || part > 64) throw new Error("Invalid multipart part.");
      const bytes = new Uint8Array(await request.arrayBuffer());
      if (!bytes.length || bytes.length > 8388608) throw new Error("SQL part exceeds bound.");
      const upload = source.backups.resumeMultipartUpload(stagedKey(day, url.searchParams.get("attempt")), url.searchParams.get("uploadId"));
      return report(await upload.uploadPart(part, bytes));
    }
    if (url.pathname === "/backup/stage-complete" && request.method === "POST") {
      const input = await request.json();
      if (!/^\d{4}-\d{2}-\d{2}$/u.test(input.day) || !Array.isArray(input.parts) || input.parts.length > 64) throw new Error("Invalid staged export.");
      await source.backups.resumeMultipartUpload(stagedKey(input.day, input.attempt), input.uploadId).complete(input.parts);
      const object2 = await source.backups.get(stagedKey(input.day, input.attempt));
      if (!object2) throw new Error("Staged export missing.");
      return report(await digestStream(object2.body, maximumDatabaseBytes));
    }
    if (url.pathname === "/backup/object") {
      const key2 = safeKey(url.searchParams.get("key") ?? "");
      if (!key2.startsWith("backups/") && !key2.startsWith("backup-groups/")) throw new Error("Invalid backup namespace.");
      const object2 = await source.backups.get(key2);
      if (!object2) return json({ error: "not-found" }, 404);
      return new Response(object2.body, { headers: { "content-type": object2.httpMetadata?.contentType ?? "application/octet-stream", "content-length": String(object2.size), "cache-control": "no-store" } });
    }
    if (url.pathname === "/benchmark/cleanup" && request.method === "POST") {
      const input = await request.json();
      const id = exportAttempt(input.id);
      const bucket = input.store === "images" ? env.TARGET_IMAGES : input.store === "private" ? env.TARGET_PRIVATE : null;
      if (!bucket) throw new Error("Invalid benchmark bucket.");
      const page = await bucket.list({ prefix: `benchmark/${id}/`, limit: 1e3 });
      if (page.objects.length) await bucket.delete(page.objects.map((object2) => object2.key));
      return report({ deleted: page.objects.length, more: page.truncated });
    }
    if (url.pathname === "/rotation/proof") return report({ authSecretDigest: createHash7("sha256").update(env.AUTH_SECRET).digest("hex"), ingestSecretDigest: createHash7("sha256").update(env.INGEST_CAPABILITY_SECRET).digest("hex") });
    if (url.pathname === "/rotation/issue") return json({ token: await issueIngestCapability({ secret: env.INGEST_CAPABILITY_SECRET, issuer: "https://diagnostic.invalid", environment: "local" }, { runId: "diagnostic", repositoryId: "1", workflowRunId: "1", workflowAttempt: 1, testedSha: "a".repeat(40), planDigest: "b".repeat(64), shardKey: "diagnostic", jobId: "1", maximumBytes: 1, maximumImages: 1 }, 900) });
    if (url.pathname === "/rotation/verify" && request.method === "POST") {
      try {
        const { token } = await request.json();
        await verifyIngestCapability({ secret: env.INGEST_CAPABILITY_SECRET, issuer: "https://diagnostic.invalid", environment: "local" }, token);
        return json({ valid: true });
      } catch {
        return json({ valid: false }, 401);
      }
    }
    if (url.pathname === "/restore/import-state") {
      const marker = await target.database.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name='diagnostic_restore_marker'").first();
      return report({ marker: marker ? await target.database.prepare("SELECT digest FROM diagnostic_restore_marker LIMIT 1").first() : null });
    }
    if (url.pathname === "/restore/empty") {
      const tables = (await target.database.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE '_cf_%' AND name NOT LIKE 'sqlite_%'").all()).results;
      const images = await target.images.list({ limit: 1 }), privateObjects = await target.quarantine.list({ limit: 1 });
      return report({ empty: tables.length === 0 && !images.objects.length && !privateObjects.objects.length, tables });
    }
    if (url.pathname === "/restore/page" && request.method === "POST") {
      const input = await request.json();
      const group = parseGroupReference(input.group);
      const manifest = parseGroupManifest(await readBackupJson(source.backups, group), group);
      const reference = manifest.pages[input.page];
      if (!reference || !Number.isInteger(input.page) || input.page < 0) throw new Error("Invalid restore page.");
      const objects = parseBackupObjects(await readBackupJson(source.backups, reference), group.id, reference.objects);
      const restored = input.benchmark ? { images: prefixedStore(env.TARGET_IMAGES, `benchmark/${exportAttempt(input.benchmark)}/`, counts, "benchmarkImages"), quarantine: prefixedStore(env.TARGET_PRIVATE, `benchmark/${exportAttempt(input.benchmark)}/`, counts, "benchmarkPrivate") } : target;
      await mapConcurrent(objects, 6, (object2) => copyVerifiedObject({ source: source.backups, destination: object2.source === "images" ? restored.images : restored.quarantine, sourceKey: object2.backupKey, destinationKey: object2.key, maximum: maximumObjectBytes, expectedDigest: object2.digest, expectedBytes: object2.bytes }));
      return report({ objects: objects.length, bytes: objects.reduce((sum, object2) => sum + object2.bytes, 0) });
    }
    if (url.pathname === "/fingerprint") {
      const table2 = url.searchParams.get("table");
      const allowed = ["ariviso_decisions", "ariviso_decision_replacements", "ariviso_identity_history", "ariviso_reservations", "ariviso_lineage_edges", "ariviso_snapshots", "ariviso_images", "ariviso_snapshot_images", "ariviso_capture_profiles", "operations_run_archives", "operations_comparison_archives"];
      if (!allowed.includes(table2)) throw new Error("Unsupported fingerprint table.");
      return report(await tableFingerprint(url.searchParams.get("target") === "true" ? target.database : source.database, table2));
    }
    if (url.pathname === "/history/root") {
      const selected = url.searchParams.get("target") === "true" ? target : source;
      return report({ archive: await readHistoryManifest(context(selected), reviewRunId) });
    }
    if (url.pathname === "/history/section") {
      const selected = url.searchParams.get("target") === "true" ? target : source;
      const section2 = url.searchParams.get("section");
      const hash2 = createHash7("sha256");
      let rows = 0;
      for await (const page of readArchivedSection(context(selected), reviewRunId, section2)) {
        for (const row of page) {
          hash2.update(JSON.stringify(row));
          hash2.update("\n");
          rows++;
        }
      }
      return report({ section: section2, rows, digest: hash2.digest("hex") });
    }
    if (url.pathname === "/restore/references" && request.method === "POST") {
      const input = await request.json();
      const after = typeof input.after === "string" ? input.after : "";
      const kind = input.kind;
      let rows;
      if (kind === "originals") rows = (await target.database.prepare("SELECT object_key AS key,digest,bytes FROM ariviso_images WHERE bytes_present=1 AND object_key>? ORDER BY object_key LIMIT 1000").bind(after).all()).results;
      else if (kind === "snapshots") rows = (await target.database.prepare("SELECT copy.object_key AS key,copy.digest,image.bytes FROM ariviso_snapshot_images copy JOIN ariviso_images image ON image.id=copy.image_id WHERE copy.copied=1 AND copy.object_key>? ORDER BY copy.object_key LIMIT 1000").bind(after).all()).results;
      else if (kind === "archives") {
        rows = (await target.database.prepare("SELECT object_key AS key,digest,bytes,run_id,generation FROM operations_ready_history_archives WHERE object_key>? ORDER BY object_key LIMIT 20").bind(after).all()).results;
        for (const row of rows) {
          const manifest = parseHistoryManifest(await readBackupJson(target.images, row), { runId: row.run_id, generation: row.generation, maximumObjectBytes });
          await mapConcurrent(manifest.pages, 6, (reference) => verifyStored(target.images, reference));
        }
      } else throw new Error("Invalid reference kind.");
      await mapConcurrent(rows, 6, (row) => verifyStored(target.images, row));
      return report({ kind, objects: rows.length, bytes: rows.reduce((sum, row) => sum + row.bytes, 0), after: rows.at(-1)?.key ?? after, done: rows.length < (kind === "archives" ? 20 : 1e3) });
    }
    if (url.pathname === "/restore/sanitize" && request.method === "POST") {
      await sanitizeRestoredDatabase(target.database, Date.now());
      return report({ sanitized: true });
    }
    if (url.pathname === "/restore/report") {
      const foreignKeys = (await target.database.prepare("PRAGMA foreign_key_check").all()).results;
      const sessions = await target.database.prepare("SELECT COUNT(*) AS count FROM session").first();
      const tokens = await target.database.prepare("SELECT COUNT(*) AS count FROM account WHERE accessToken IS NOT NULL OR refreshToken IS NOT NULL OR idToken IS NOT NULL").first();
      const active = await target.database.prepare("SELECT COUNT(*) AS count FROM ariviso_runs WHERE active!=0").first();
      return report({ foreignKeys, sessions: sessions.count, tokens: tokens.count, active: active.count, archives: await archiveState(target.database) });
    }
    throw new Error("Unknown diagnostic operation.");
  } catch (error) {
    return json({ error: String(error), milliseconds: performance.now() - started, counts, queries }, 500);
  }
} };
export {
  worker_default as default
};
//# sourceMappingURL=worker.js.map
