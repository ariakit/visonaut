import { execFileSync } from "node:child_process";
import { createHash } from "node:crypto";
import { mkdir, readFile, writeFile } from "node:fs/promises";
import { createRequire } from "node:module";
import { dirname, resolve } from "node:path";
const require = createRequire(new URL("../../../package.json", import.meta.url));
const wrangler = resolve(dirname(require.resolve("wrangler/package.json")), "bin/wrangler.js");
execFileSync(process.execPath, ["prepare.mjs"], { stdio: "inherit", env: process.env });
await mkdir("results", { recursive: true });
const configuration = {
  name: "visonaut-e03-final-20260923",
  main: "worker.mjs",
  compatibility_date: "2026-09-22",
  compatibility_flags: ["nodejs_compat"],
  workers_dev: true,
  preview_urls: false,
  observability: { enabled: true, traces: { enabled: true } },
  d1_databases: [
    {
      binding: "DB",
      database_name: "visonaut-e03-final-20260923",
      database_id: "00000000-0000-0000-0000-000000000000",
      migrations_dir: "../../../apps/web/migrations",
    },
  ],
  r2_buckets: [{ binding: "IMAGES", bucket_name: "visonaut-e03-final-20260923-images" }],
  secrets: { required: ["PROBE_TOKEN"] },
  limits: { cpu_ms: 30000, subrequests: 10000 },
};
await writeFile("wrangler.example.json", `${JSON.stringify(configuration, null, 2)}\n`);
const fixturePaths = [
  "common.mjs",
  "scenarios.mjs",
  "status.mjs",
  "worker.mjs",
  "prepare.mjs",
  "build.mjs",
  "run-local.mjs",
  "run-hosted.mjs",
  "fixtures.json",
  "source-manifest.json",
  "probe-schema.sql",
];
const fixtureFiles = [];
for (const path of fixturePaths) {
  fixtureFiles.push({
    path,
    sha256: createHash("sha256")
      .update(await readFile(path))
      .digest("hex"),
  });
}
const fixtureProof = {
  digest: createHash("sha256").update(JSON.stringify(fixtureFiles)).digest("hex"),
  files: fixtureFiles,
};
await writeFile("fixture-manifest.json", `${JSON.stringify(fixtureProof, null, 2)}\n`);
const output = execFileSync(
  process.execPath,
  [wrangler, "deploy", "--dry-run", "--config", "wrangler.example.json", "--outdir", "dist"],
  {
    encoding: "utf8",
    env: {
      ...process.env,
      WRANGLER_SEND_METRICS: "false",
      WRANGLER_LOG_PATH: resolve("results/build.log"),
    },
    timeout: 60000,
  },
);
await writeFile("results/build.stdout", output);
const hash = (bytes) => createHash("sha256").update(bytes).digest("hex");
const files = [
  "common.mjs",
  "scenarios.mjs",
  "status.mjs",
  "run-hosted.mjs",
  "worker.mjs",
  "prepare.mjs",
  "build.mjs",
  "run-local.mjs",
  "fixtures.json",
  "source-manifest.json",
  "fixture-manifest.json",
  "probe-schema.sql",
  "wrangler.example.json",
  "dist/worker.js",
];
const hashes = [];
for (const path of files) {
  hashes.push({ path, sha256: hash(await readFile(path)) });
}
await writeFile(
  "results/build-manifest.json",
  `${JSON.stringify({ builtAt: new Date().toISOString(), wrangler: JSON.parse(await readFile(require.resolve("wrangler/package.json"), "utf8")).version, files: hashes }, null, 2)}\n`,
);
console.log(output);
