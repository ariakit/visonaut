import {
  claimStatus,
  deliverStatus,
  reconcileStatus,
  settleStatus,
  statusIntentStatements,
} from "../../../packages/service/src/work.ts";

function barrier() {
  let release;
  const promise = new Promise((resolve) => {
    release = resolve;
  });
  return { promise, release };
}

async function enteredBeforeCompletion(entered, operation, name) {
  await Promise.race([
    entered.promise,
    operation.then(() => {
      throw new Error(`${name}: delivery completed before the injected pause`);
    }),
  ]);
}

/** Run with a native D1 binding, or an instrumented delegate to that binding. */
export async function statusScenarios(context) {
  const { database } = context;
  const invocation = crypto.randomUUID();
  const assertions = [];
  const scenarios = [];

  function equal(actual, expected, name) {
    if (JSON.stringify(actual) !== JSON.stringify(expected)) {
      throw new Error(
        `${name}: expected ${JSON.stringify(expected)}, received ${JSON.stringify(actual)}`,
      );
    }
    assertions.push({ name, passed: true, actual, expected });
  }

  function createScenario(name) {
    const id = `e03:status:${invocation}:${name}`;
    let now = 100;
    const calls = [];
    const applied = [];
    let active = 0;
    let maximumActive = 0;
    const checkpoints = [];
    context.event?.(`status.${name}.start`, { checkId: id, githubTransport: "mocked" });

    async function intent(revision, conclusion) {
      await database.batch(
        statusIntentStatements(database, {
          checkId: id,
          revision,
          runId: `fixture:${id}`,
          attempt: 1,
          comparisonRevision: revision,
          sourceRevision: revision,
          conclusion,
          detailsUrl: `https://evidence.invalid/status/${id}`,
          maxAttempts: 3,
          now,
        }),
      );
    }

    async function snapshot(label) {
      const [check, outbox] = await Promise.all([
        database.prepare("SELECT * FROM work_checks WHERE id = ?").bind(id).first(),
        database
          .prepare("SELECT * FROM work_status_outbox WHERE check_id = ? ORDER BY revision")
          .bind(id)
          .all(),
      ]);
      const state = { label, logicalNow: now, check, outbox: outbox.results ?? [] };
      checkpoints.push(state);
      return state;
    }

    function beginSend(delivery) {
      const call = {
        sequence: calls.length + 1,
        revision: delivery.revision,
        conclusion: delivery.conclusion,
        startedAt: now,
        completedAt: null,
        outcome: "in-flight",
      };
      calls.push(call);
      active += 1;
      maximumActive = Math.max(maximumActive, active);
      return (outcome) => {
        call.completedAt = now;
        call.outcome = outcome;
        active -= 1;
        if (outcome === "delivered") {
          applied.push({ revision: delivery.revision, conclusion: delivery.conclusion, at: now });
        }
      };
    }

    async function send(delivery, isCurrent) {
      equal(await isCurrent(), true, `${name}: current immediately before mocked PATCH`);
      beginSend(delivery)("delivered");
    }

    async function claim(token, revision) {
      const claimed = await claimStatus(database, { id, token, now, leaseMs: 10 });
      equal(claimed?.revision ?? null, revision, `${name}: ${token} claimed revision`);
      return claimed;
    }

    function deliver(token, revision, sender = send) {
      return deliverStatus(database, { id, token, revision, now: () => now, send: sender });
    }

    async function finish(measurements) {
      const final = await snapshot("final");
      equal(final.check.lease_token, null, `${name}: final lease released`);
      equal(final.check.request_started, 0, `${name}: final request flag cleared`);
      equal(final.check.ambiguous, 0, `${name}: final ambiguity cleared`);
      equal(
        final.check.delivered_revision,
        final.check.desired_revision,
        `${name}: final delivered revision matches desired revision`,
      );
      equal(active, 0, `${name}: no mocked requests remain in flight`);
      const result = {
        name,
        checkId: id,
        githubTransport: "mocked",
        clock: "injected logical milliseconds; no wall-clock lease wait",
        measurements: {
          ...measurements,
          transportCalls: calls.length,
          appliedWrites: applied.length,
          maximumConcurrentRequests: maximumActive,
        },
        calls,
        applied,
        checkpoints,
      };
      scenarios.push(result);
      context.event?.(`status.${name}.complete`, result.measurements);
    }

    return {
      id,
      intent,
      snapshot,
      beginSend,
      claim,
      deliver,
      finish,
      calls,
      applied,
      now: () => now,
      advance(value) {
        now = value;
      },
    };
  }

  {
    const scenario = createScenario("stale-success-refusal");
    await scenario.intent(1, "success");
    await scenario.claim("old", 1);
    scenario.advance(101);
    await scenario.intent(2, "failure");
    const stale = await scenario.deliver("old", 1);
    equal(stale, "stale", "stale-success: obsolete success refused");
    equal(scenario.calls.length, 0, "stale-success: obsolete success made no transport call");
    const refused = await scenario.snapshot("obsolete-success-refused");
    equal(refused.outbox[0].state, "obsolete", "stale-success: old outbox row obsolete");
    await scenario.claim("current", 2);
    equal(await scenario.deliver("current", 2), "delivered", "stale-success: failure delivered");
    equal(
      scenario.applied.map((item) => item.conclusion),
      ["failure"],
      "stale-success: only current failure reached mocked remote",
    );
    await scenario.finish({ staleOutcome: stale, refusedBeforeTransport: true });
  }

  {
    const scenario = createScenario("delayed-in-flight-then-current-failure");
    const entered = barrier();
    const response = barrier();
    await scenario.intent(1, "success");
    await scenario.claim("old", 1);
    scenario.advance(101);
    const oldRequest = scenario.deliver("old", 1, async (delivery, isCurrent) => {
      equal(await isCurrent(), true, "delayed: old request was current before transport");
      const complete = scenario.beginSend(delivery);
      entered.release();
      await response.promise;
      complete("delivered");
    });
    let blockedClaim;
    let duplicateOutcome;
    try {
      await enteredBeforeCompletion(entered, oldRequest, "delayed");
      await scenario.intent(2, "failure");
      scenario.advance(120);
      await reconcileStatus(database, { now: scenario.now(), limit: 100 });
      const held = await scenario.snapshot("expired-in-flight-lock-held");
      equal(held.check.ambiguous, 1, "delayed: expired in-flight request needs attention");
      equal(held.check.lease_token, "old", "delayed: expired in-flight lock retained");
      equal(held.check.request_started, 1, "delayed: request remains marked as started");
      blockedClaim = await scenario.claim("premature-current", null);
      duplicateOutcome = await scenario.deliver("old", 1);
      equal(duplicateOutcome, "stale", "delayed: duplicate old send refused");
      equal(scenario.calls.length, 1, "delayed: exactly one request started during pause");
      equal(scenario.applied.length, 0, "delayed: mocked response has not yet applied");
    } finally {
      response.release();
      await oldRequest;
    }
    const oldOutcome = await oldRequest;
    equal(oldOutcome, "delivered", "delayed: old request settles after response barrier");
    const settled = await scenario.snapshot("old-response-settled");
    equal(settled.check.delivered_revision, 1, "delayed: old response records revision one");
    equal(settled.outbox[0].state, "obsolete", "delayed: old response is obsolete locally");
    await scenario.claim("current", 2);
    equal(await scenario.deliver("current", 2), "delivered", "delayed: current failure delivered");
    equal(
      scenario.applied.map((item) => item.conclusion),
      ["success", "failure"],
      "delayed: current failure follows the settled old success",
    );
    await scenario.finish({
      oldOutcome,
      duplicateOutcome,
      currentClaimBlockedDuringOldRequest: blockedClaim === null,
      injectedLeaseExpiryAt: 110,
      injectedReconciliationAt: 120,
    });
  }

  {
    const scenario = createScenario("ambiguous-transport-explicit-settlement");
    await scenario.intent(1, "success");
    await scenario.claim("ambiguous-owner", 1);
    scenario.advance(101);
    const ambiguousOutcome = await scenario.deliver(
      "ambiguous-owner",
      1,
      async (delivery, isCurrent) => {
        equal(await isCurrent(), true, "ambiguous: intent current before mocked request");
        scenario.beginSend(delivery)("connection-reset-without-confirmation");
        throw new Error("Injected mocked GitHub transport connection reset");
      },
    );
    equal(ambiguousOutcome, "ambiguous", "ambiguous: uncertain response recorded");
    await scenario.intent(2, "failure");
    scenario.advance(1000);
    await reconcileStatus(database, { now: scenario.now(), limit: 100 });
    await scenario.claim("lease-expiry-cannot-recover", null);
    const wrongSettlement = await settleStatus(database, {
      id: scenario.id,
      token: "wrong-owner",
      revision: 1,
      now: scenario.now(),
      outcome: "not-sent",
    });
    equal(wrongSettlement, false, "ambiguous: wrong token cannot settle lock");
    const blocked = await scenario.snapshot("ambiguous-after-expiry-and-wrong-token");
    equal(blocked.check.ambiguous, 1, "ambiguous: attention flag survives lease expiry");
    equal(blocked.check.lease_token, "ambiguous-owner", "ambiguous: owner lock survives expiry");
    equal(blocked.outbox[0].state, "sending", "ambiguous: old outbox remains sending");
    const settlementProof = {
      source: "injected mocked transport terminal state",
      cannotWriteAgain: true,
      remoteWasReadToInferSettlement: false,
      appliesToRealGitHubTransport: false,
    };
    const settlement = await settleStatus(database, {
      id: scenario.id,
      token: "ambiguous-owner",
      revision: 1,
      now: scenario.now(),
      outcome: "not-sent",
    });
    equal(settlement, true, "ambiguous: owning token explicitly settles stopped transport");
    await scenario.claim("recovered-current", 2);
    equal(
      await scenario.deliver("recovered-current", 2),
      "delivered",
      "ambiguous: current failure delivered after explicit settlement",
    );
    equal(
      scenario.applied.map((item) => item.conclusion),
      ["failure"],
      "ambiguous: only current failure applied in the controlled transport",
    );
    await scenario.finish({
      ambiguousOutcome,
      settlementProof,
      leaseExpiryAloneRecovered: false,
      wrongTokenSettled: wrongSettlement,
      ownerSettled: settlement,
    });
  }

  {
    const scenario = createScenario("current-check-after-credential-pause");
    const entered = barrier();
    const credentials = barrier();
    const currentChecks = [];
    let credentialLookups = 0;
    await scenario.intent(1, "success");
    await scenario.claim("credential-owner", 1);
    scenario.advance(101);
    const request = scenario.deliver("credential-owner", 1, async (delivery, isCurrent) => {
      currentChecks.push({ phase: "before-credentials", current: await isCurrent() });
      credentialLookups += 1;
      entered.release();
      await credentials.promise;
      const current = await isCurrent();
      currentChecks.push({ phase: "after-credentials-before-patch", current });
      if (!current) return "not-sent";
      scenario.beginSend(delivery)("delivered");
    });
    try {
      await enteredBeforeCompletion(entered, request, "credentials");
      scenario.advance(102);
      await scenario.intent(2, "failure");
      await scenario.snapshot("new-intent-during-credential-pause");
    } finally {
      credentials.release();
      await request;
    }
    const oldOutcome = await request;
    equal(oldOutcome, "stale", "credentials: old success refused after credentials return");
    equal(
      currentChecks.map((item) => item.current),
      [true, false],
      "credentials: current check changes while credentials are paused",
    );
    equal(scenario.calls.length, 0, "credentials: invalidated success never starts mocked PATCH");
    await scenario.claim("current", 2);
    equal(
      await scenario.deliver("current", 2),
      "delivered",
      "credentials: current failure delivered",
    );
    await scenario.finish({
      oldOutcome,
      credentialLookups,
      currentChecks,
      credentialTransport: "injected Promise barrier; no real credential request",
    });
  }

  {
    const scenario = createScenario("duplicate-serialized-sends");
    const entered = barrier();
    const response = barrier();
    await scenario.intent(1, "success");
    await scenario.claim("shared-owner", 1);
    scenario.advance(101);
    const sender = async (delivery, isCurrent) => {
      equal(await isCurrent(), true, "duplicate: winning intent current before mocked PATCH");
      const complete = scenario.beginSend(delivery);
      entered.release();
      await response.promise;
      complete("delivered");
    };
    const requests = [
      scenario.deliver("shared-owner", 1, sender),
      scenario.deliver("shared-owner", 1, sender),
    ];
    const both = Promise.all(requests);
    let firstOutcome;
    try {
      await enteredBeforeCompletion(entered, both, "duplicate");
      firstOutcome = await Promise.race(requests);
      equal(firstOutcome, "stale", "duplicate: competing call refuses before winner responds");
      equal(scenario.calls.length, 1, "duplicate: only one sender callback enters transport");
      await scenario.claim("competing-owner", null);
      const sending = await scenario.snapshot("duplicate-refused-while-winner-in-flight");
      equal(sending.check.request_started, 1, "duplicate: winning request remains started");
      equal(sending.outbox[0].attempts, 1, "duplicate: one outbox delivery attempt consumed");
    } finally {
      response.release();
      await both;
    }
    const outcomes = (await both).sort();
    equal(outcomes, ["delivered", "stale"], "duplicate: one delivery and one refusal");
    const replayOutcome = await scenario.deliver("shared-owner", 1);
    equal(replayOutcome, "stale", "duplicate: completed delivery cannot replay with old token");
    equal(scenario.calls.length, 1, "duplicate: repeated calls produce one mocked write");
    await scenario.finish({ concurrentCalls: 2, firstOutcome, outcomes, replayOutcome });
  }

  return {
    scope:
      "Standalone work.ts status delivery state transitions on the supplied native D1 database",
    githubTransport: "mocked; no GitHub HTTP requests or credential requests are performed",
    domainStatusPreparation:
      "Not exercised here; prepareStatusIntent is covered by the parent fixture",
    invocation,
    scenarioCount: scenarios.length,
    assertionCount: assertions.length,
    assertions,
    scenarios,
  };
}
