PRAGMA foreign_key_check;
SELECT id,scenario,passed,json_extract(receipt_json,'$.sourceTree') AS source_tree,json_extract(receipt_json,'$.deployment.id') AS worker_version FROM e03_probe_runs ORDER BY id;
SELECT count(*) AS original_image_records,sum(bytes) AS original_encoded_bytes FROM visonaut_images;
SELECT count(*) AS snapshot_image_records FROM visonaut_snapshot_images;
SELECT count(*) AS command_records FROM visonaut_commands;
SELECT count(*) AS audit_records FROM visonaut_audit;
SELECT byte_state,count(*) AS runs FROM work_retained_runs GROUP BY byte_state;
