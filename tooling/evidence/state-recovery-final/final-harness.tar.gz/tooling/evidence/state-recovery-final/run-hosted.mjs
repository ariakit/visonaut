import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import { mkdir, readFile, writeFile } from "node:fs/promises";
const origin = "https://visonaut-e03-final-20260923.ariakit.workers.dev";
const secret = JSON.parse(await readFile("/tmp/visonaut-e03-final-20260923-secrets.json", "utf8"));
const source = JSON.parse(await readFile("source-manifest.json", "utf8"));
const build = JSON.parse(await readFile("results/build-manifest.json", "utf8"));
for (const { path, sha256 } of build.files) {
  assert.equal(
    createHash("sha256")
      .update(await readFile(path))
      .digest("hex"),
    sha256,
    `Build artifact changed: ${path}`,
  );
}
const fixtureProof = JSON.parse(await readFile("fixture-manifest.json", "utf8"));
const deployment = JSON.parse(await readFile("results/deployment.json", "utf8"));
assert.equal(
  deployment.bundleSha256,
  build.files.find((entry) => entry.path === "dist/worker.js").sha256,
);
const file = "results/final-hosted-report.json";
const report = {
  mode: "hosted-cloudflare-native",
  origin,
  sourceTree: source.sourceTree,
  bundle: build.files.find((entry) => entry.path === "dist/worker.js"),
  startedAt: new Date().toISOString(),
  passed: false,
  scenarios: [],
};
await mkdir("results", { recursive: true });
const save = () => writeFile(file, `${JSON.stringify(report, null, 2)}\n`);
async function request(path, options = {}) {
  return fetch(`${origin}${path}`, {
    ...options,
    redirect: "error",
    headers: { Authorization: `Bearer ${secret.PROBE_TOKEN}`, ...options.headers },
    signal: AbortSignal.timeout(120000),
  });
}
try {
  assert.equal((await fetch(`${origin}/manifest`)).status, 401);
  assert.equal(
    (await request("/manifest", { headers: { Authorization: "Bearer wrong" } })).status,
    401,
  );
  report.authentication = { missing: 401, wrong: 401, tokenRecorded: false };
  const manifestResponse = await request("/manifest");
  assert.equal(manifestResponse.status, 200);
  const manifest = await manifestResponse.json();
  assert.equal(manifest.sourceTree, source.sourceTree);
  assert.deepEqual(manifest.sourceFiles, source.sourceFiles);
  assert.deepEqual(manifest.fixture, fixtureProof);
  assert.equal(manifest.deployment.id, deployment.versionId);
  report.deployment = manifest.deployment;
  report.fixtureDigest = manifest.fixture.digest;
  report.manifestVerified = true;
  const names = manifest.scenarios;
  assert.equal(names.length, 7);
  for (const name of names) {
    const prefix = `final20260923-${name.toLowerCase()}`;
    const started = performance.now();
    let response;
    let receipt;
    try {
      response = await request(`/run/${name}`, {
        method: "POST",
        body: JSON.stringify({ prefix }),
      });
      receipt = await response.json();
    } catch (error) {
      const recovered = await request(`/receipt/${prefix}`);
      receipt = await recovered.json();
      report.recovery = {
        scenario: name,
        transportError: error.name,
        receiptRecovered: !receipt.pending && receipt.scenario === name,
      };
      if (receipt.pending || receipt.scenario !== name)
        throw new Error(
          "Scenario response uncertain; inspect existing receipt, do not retry mutations",
        );
    }
    const observation = {
      ...receipt,
      controller: {
        durationMs: performance.now() - started,
        httpStatus: response?.status ?? null,
        ray: response?.headers.get("cf-ray") ?? null,
        date: response?.headers.get("date") ?? null,
      },
    };
    report.scenarios.push(observation);
    await writeFile(`results/final-hosted-${name}.json`, `${JSON.stringify(observation, null, 2)}\n`);
    await save();
    console.log(
      JSON.stringify({
        scenario: name,
        passed: receipt.passed,
        durationMs: observation.controller.durationMs,
        workerDurationMs: receipt.durationMs,
        d1: receipt.d1,
        r2: receipt.r2,
        error: receipt.error?.message,
      }),
    );
    assert.equal(receipt.passed, true, receipt.error?.message);
    const saved = await (await request(`/receipt/${prefix}`)).json();
    assert.deepEqual(saved, receipt);
    const replay = await request(`/run/${name}`, {
      method: "POST",
      body: JSON.stringify({ prefix }),
    });
    assert.equal(replay.status, 409);
  }
  report.passed = true;
} catch (error) {
  report.failure = { message: error.message, stack: error.stack };
  throw error;
} finally {
  report.completedAt = new Date().toISOString();
  await save();
}
