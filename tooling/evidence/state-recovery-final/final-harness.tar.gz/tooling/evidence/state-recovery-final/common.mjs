import { Service } from "../../../packages/service/src/service.ts";
import { compareImages } from "../../../packages/compare/src/compare.ts";
import fixtures from "./fixtures.json";

export function assert(value, message) {
  if (!value) throw new Error(`Assertion failed: ${message}`);
}

export function equal(actual, expected, message) {
  assert(
    JSON.stringify(actual) === JSON.stringify(expected),
    `${message}: ${JSON.stringify({ actual, expected })}`,
  );
}

export async function hash(bytes) {
  return [...new Uint8Array(await crypto.subtle.digest("SHA-256", bytes))]
    .map((value) => value.toString(16).padStart(2, "0"))
    .join("");
}

export class MeteredDatabase {
  constructor(native) {
    this.native = native;
    this.beforeBatch = null;
    this.metrics = {
      calls: 0,
      attemptedStatements: 0,
      statements: 0,
      rowsRead: 0,
      rowsWritten: 0,
      nativeDurationMs: 0,
    };
  }
  record(result) {
    this.metrics.statements += 1;
    this.metrics.rowsRead += result.meta?.rows_read ?? 0;
    this.metrics.rowsWritten += result.meta?.rows_written ?? 0;
    this.metrics.nativeDurationMs += result.meta?.duration ?? 0;
    return result;
  }
  prepare(sql) {
    return new MeteredStatement(this, this.native.prepare(sql));
  }
  async batch(statements) {
    const before = this.beforeBatch;
    this.beforeBatch = null;
    if (before) await before();
    this.metrics.calls += 1;
    this.metrics.attemptedStatements += statements.length;
    const results = await this.native.batch(statements.map((entry) => entry.native));
    return results.map((result) => this.record(result));
  }
}

class MeteredStatement {
  constructor(database, native) {
    this.database = database;
    this.native = native;
  }
  bind(...values) {
    return new MeteredStatement(this.database, this.native.bind(...values));
  }
  async all() {
    this.database.metrics.calls += 1;
    this.database.metrics.attemptedStatements += 1;
    return this.database.record(await this.native.all());
  }
  async first() {
    return (await this.all()).results?.[0] ?? null;
  }
  async run() {
    this.database.metrics.calls += 1;
    this.database.metrics.attemptedStatements += 1;
    return this.database.record(await this.native.run());
  }
}

export function context(env, prefix) {
  const database = new MeteredDatabase(env.DB);
  const service = new Service(database);
  const events = [];
  const id = (name) => `${prefix}-${name}`;
  const event = (name, details = {}) =>
    events.push({ name, wallTime: new Date().toISOString(), ...details });
  const objectMetrics = { puts: 0, gets: 0, deletes: 0, bytesWritten: 0 };
  const getImage = async (key) => {
    objectMetrics.gets += 1;
    const object = await env.IMAGES.get(key);
    assert(object, `R2 object exists: ${key}`);
    return new Uint8Array(await object.arrayBuffer());
  };
  const putImage = async (key, bytes) => {
    objectMetrics.puts += 1;
    objectMetrics.bytesWritten += bytes.length;
    await env.IMAGES.put(key, bytes, { httpMetadata: { contentType: "image/png" } });
  };
  const png = (color = "blue") => {
    const entry = fixtures[color];
    assert(entry, `known synthetic PNG: ${color}`);
    return { ...entry, bytes: Uint8Array.from(entry.bytes) };
  };
  const project = () => service.project(id("project"));
  const setup = async () => {
    await service.createPolicy({
      digest: id("policy"),
      policy: {
        id: "e03-zero-tolerance",
        channelThreshold: 0,
        maxChangedPixels: 0,
        maxChangedRatio: 0,
      },
    });
    await service.createProject({
      id: id("project"),
      repositoryId: id("synthetic-repository"),
      policyDigest: id("policy"),
    });
  };
  const fixture = async (input) => {
    const runId = id(input.name);
    const current = await project();
    const captures = input.captures ?? [
      { item: "dialog", variant: "light", color: input.color ?? "blue" },
    ];
    const snapshot = current.snapshot_id
      ? await database
          .prepare("SELECT tested_sha FROM visonaut_snapshots WHERE id=?")
          .bind(current.snapshot_id)
          .first()
      : null;
    await service.reserveRun({
      id: runId,
      projectId: current.id,
      externalRunId: id(input.external ?? input.name),
      attempt: input.attempt ?? 1,
      kind: input.kind ?? "main",
      testedSha: id(input.sha ?? `sha-${input.name}`),
      lineageKey: input.lineage ?? (input.kind === "pull_request" ? id(input.name) : "main"),
      plan: {
        digest: id("plan"),
        shards: [
          {
            key: "chromium",
            profileDigest: "synthetic-profile",
            tests: ["test"],
            captures: captures.map((entry) => ({
              itemKey: entry.item,
              variantKey: entry.variant,
              testId: "test",
            })),
          },
        ],
      },
      verifiedRelatedRunIds: (input.related ?? []).map(id),
      verifiedAncestorShas: snapshot ? [snapshot.tested_sha] : [],
      verificationDigest: "SYNTHETIC-TRUST-FIXTURE-NOT-GITHUB-OIDC",
      rerunShardKeys: ["chromium"],
      now: input.now ?? 100,
    });
    for (const [index, entry] of captures.entries()) {
      const image = png(entry.color ?? input.color ?? "blue");
      const objectKey = `runs/${runId}/${index}.png`;
      await putImage(objectKey, image.bytes);
      equal(await hash(await getImage(objectKey)), image.digest, "native R2 original digest");
      await service.registerImage({
        id: id(`image-${input.name}-${index}`),
        runId,
        digest: image.digest,
        objectKey,
        contentType: "image/png",
        bytes: image.bytes.length,
        width: 1,
        height: 1,
      });
    }
    await service.commitShard({
      runId,
      key: "chromium",
      manifestDigest: id(`manifest-${input.name}`),
      finalTestOutcomes: [{ testId: "test", retry: 0, status: "passed" }],
      captures: captures.map((entry, index) => ({
        id: id(`capture-${input.name}-${index}`),
        itemKey: entry.item,
        variantKey: entry.variant,
        ordinal: index,
        imageId: id(`image-${input.name}-${index}`),
        profileDigest: "synthetic-profile",
        environmentProfileDigest: "synthetic-profile",
        testId: "test",
        testRetry: 0,
        metadata: { name: entry.item },
      })),
      now: 101,
    });
    await service.sealRun({ runId, now: 102 });
    const comparisonId = id(`comparison-${input.name}`);
    await service.createComparison({
      id: comparisonId,
      runId,
      referenceSnapshotId: current.snapshot_id,
      now: 103,
      maxAttempts: 3,
    });
    for (const row of await service.comparisonRows(comparisonId)) {
      if (row.outcome !== "pending") continue;
      await service.claimComparisonTask({
        taskId: row.id,
        owner: id("comparison-worker"),
        now: 104,
        leaseMilliseconds: 100,
      });
      const task = await service.getComparisonTask(row.id);
      const pixels = async (image) => {
        assert(image, "comparison image exists");
        equal(
          await hash(await getImage(image.objectKey)),
          image.digest,
          "native R2 comparison bytes match digest",
        );
        const entry = Object.values(fixtures).find((value) => value.digest === image.digest);
        assert(entry, "comparison uses known synthetic PNG");
        // Only decoding is a fixture: the exact comparator receives the known
        // RGBA value of the checksum-verified one-pixel PNG stored in native R2.
        return { width: 1, height: 1, data: Uint8ClampedArray.from(entry.rgba) };
      };
      const result = compareImages(
        await pixels(task.reference),
        await pixels(task.candidate),
        task.policy,
      );
      await service.commitComparisonResult({
        taskId: row.id,
        leaseOwner: id("comparison-worker"),
        result,
        now: 105,
      });
    }
    await service.finalizeComparison({ comparisonId, now: 106 });
    return comparisonId;
  };
  const review = async (name, options = {}) => {
    const comparisonId = id(`comparison-${name}`);
    const rows = (await service.comparisonRows(comparisonId)).filter(
      (row) => row.outcome === "changed",
    );
    return service.review({
      commandId: id(`command-${crypto.randomUUID()}`),
      actorId: "synthetic-maintainer-1",
      sessionId: "synthetic-session",
      comparisonId,
      verdict: "approved",
      targets: rows.map((row) => ({ id: row.id, expectedRevision: row.decision_revision })),
      selection: {
        itemKey: rows[0]?.item_key ?? "dialog",
        variantKey: rows[0]?.variant_key ?? "light",
      },
      now: 110,
      ...options,
    });
  };
  const promote = async (name) => {
    const current = await project();
    const snapshotId = id(`snapshot-${name}`);
    const copies = await service.preparePromotion({
      snapshotId,
      comparisonId: id(`comparison-${name}`),
      prefix: `baselines/${id(name)}`,
      now: 120,
    });
    for (const copy of copies) {
      const bytes = await getImage(copy.source_object_key);
      equal(await hash(bytes), copy.digest, "promotion source digest");
      await putImage(copy.object_key, bytes);
      equal(
        await hash(await getImage(copy.object_key)),
        copy.digest,
        "protected native R2 copy digest",
      );
      await service.recordSnapshotCopy({
        snapshotId,
        captureId: copy.capture_id,
        objectKey: copy.object_key,
        digest: copy.digest,
      });
    }
    return service.promote({
      snapshotId,
      promotionId: id(`promotion-${name}`),
      expectedBaselineRevision: current.baseline_revision,
      now: 121,
    });
  };
  const seed = async (captures) => {
    await setup();
    await fixture({ name: "seed", captures });
    await promote("seed");
  };
  const counts = async () => {
    const result = {};
    const tables = await database
      .prepare(
        "SELECT name FROM sqlite_schema WHERE type='table' AND (name LIKE 'visonaut_%' OR name LIKE 'work_%' OR name LIKE 'operations_%') ORDER BY name",
      )
      .all();
    for (const { name } of tables.results) {
      assert(/^[a-z_]+$/u.test(name), "known production table identifier");
      const rows = (await database.prepare(`SELECT * FROM ${name}`).all()).results;
      const serialized = rows.map((row) => JSON.stringify(row)).sort();
      result[name] = {
        rows: rows.length,
        sha256: await hash(new TextEncoder().encode(JSON.stringify(serialized))),
      };
    }
    return result;
  };
  const conflict = async (operation, label) => {
    let error;
    try {
      await operation();
    } catch (caught) {
      error = caught;
    }
    assert(
      error?.code === "CONFLICT",
      `${label} returns CONFLICT (${error?.message ?? "no error"})`,
    );
    event(label, { code: error.code, message: error.message });
  };
  const undo = async (command, options = {}) =>
    service.undo({
      commandId: command.commandId,
      undoCommandId: id(`undo-${crypto.randomUUID()}`),
      actorId: "synthetic-maintainer-1",
      sessionId: "synthetic-session",
      expectedBaselineRevision: (await project()).baseline_revision,
      now: 130,
      ...options,
    });
  const assertions = [];
  const checkedAssert = (value, message) => {
    assert(value, message);
    assertions.push({ message, passed: true });
  };
  const checkedEqual = (actual, expected, message) => {
    equal(actual, expected, message);
    assertions.push({ message, actual, expected, passed: true });
  };
  return {
    assertions,
    database,
    service,
    images: env.IMAGES,
    id,
    event,
    events,
    objectMetrics,
    getImage,
    putImage,
    png,
    project,
    setup,
    fixture,
    review,
    promote,
    seed,
    counts,
    conflict,
    undo,
    assert: checkedAssert,
    equal: checkedEqual,
  };
}
