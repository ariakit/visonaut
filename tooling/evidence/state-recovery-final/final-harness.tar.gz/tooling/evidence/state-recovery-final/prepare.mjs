import { execFileSync } from "node:child_process";
import { createHash } from "node:crypto";
import { readFile, readdir, writeFile } from "node:fs/promises";
import { deflateSync } from "node:zlib";
import { resolve } from "node:path";
function chunk(type, data) {
  const content = Buffer.concat([Buffer.from(type), data]);
  let crc = 0xffffffff;
  for (const byte of content) {
    crc ^= byte;
    for (let bit = 0; bit < 8; bit += 1) {
      crc = (crc >>> 1) ^ (crc & 1 ? 0xedb88320 : 0);
    }
  }
  const size = Buffer.alloc(4);
  size.writeUInt32BE(data.length);
  const checksum = Buffer.alloc(4);
  checksum.writeUInt32BE((crc ^ 0xffffffff) >>> 0);
  return Buffer.concat([size, content, checksum]);
}
const fixtures = {};
for (const [color, rgba] of Object.entries({
  blue: [0, 0, 255, 255],
  red: [255, 0, 0, 255],
  green: [0, 255, 0, 255],
})) {
  const header = Buffer.alloc(13);
  header.writeUInt32BE(1);
  header.writeUInt32BE(1, 4);
  header[8] = 8;
  header[9] = 6;
  const bytes = Buffer.concat([
    Buffer.from("89504e470d0a1a0a", "hex"),
    chunk("IHDR", header),
    chunk("IDAT", deflateSync(Buffer.from([0, ...rgba]))),
    chunk("IEND", Buffer.alloc(0)),
  ]);
  fixtures[color] = {
    rgba,
    bytes: [...bytes],
    digest: createHash("sha256").update(bytes).digest("hex"),
  };
}
await writeFile("fixtures.json", `${JSON.stringify(fixtures, null, 2)}\n`);
const sourceTree = process.env.SOURCE_TREE ?? "a953a2b42eb293088ba895484861756610de4f40";
const sourceRepository = process.env.SOURCE_REPOSITORY ?? "/Users/diegohaz/Developer/ariviso";
const paths = [];
for (const dir of [
  "../../../packages/service/src",
  "../../../packages/protocol/src",
  "../../../packages/compare/src",
  "../../../apps/web/migrations",
]) {
  for (const file of (await readdir(dir)).sort()) {
    if (!file.endsWith(".ts") && !file.endsWith(".sql")) continue;
    if (file.endsWith(".test.ts")) continue;
    paths.push(`${dir}/${file}`);
  }
}
const hashes = [];
for (const file of paths) {
  const path = file.replace("../../../", "");
  const bytes = await readFile(file);
  const frozen = execFileSync("git", ["-C", sourceRepository, "show", `${sourceTree}:${path}`], {
    maxBuffer: 4 * 1024 * 1024,
  });
  if (!bytes.equals(frozen)) throw new Error(`Source differs from frozen tree: ${path}`);
  hashes.push({ path, sha256: createHash("sha256").update(bytes).digest("hex") });
}
await writeFile(
  "source-manifest.json",
  `${JSON.stringify({ sourceTree, verifiedAgainstGitTree: true, sourceFiles: hashes, generatedAt: new Date().toISOString() }, null, 2)}\n`,
);
