import assert from "node:assert/strict";
import { createHash, randomBytes } from "node:crypto";
import { mkdir, mkdtemp, readFile, readdir, rm, writeFile } from "node:fs/promises";
import { createRequire } from "node:module";
import { resolve } from "node:path";
const require = createRequire(new URL("../../../apps/web/package.json", import.meta.url));
const { Miniflare, convertV4MiniflareOptions } = await import(require.resolve("miniflare"));
const directory = await mkdtemp("/tmp/ariviso-e03-local-");
const token = randomBytes(32).toString("hex");
const options = convertV4MiniflareOptions({
  d1Persist: `${directory}/d1`,
  r2Persist: `${directory}/r2`,
  workers: [
    {
      name: "probe",
      modules: true,
      scriptPath: resolve("dist/worker.js"),
      compatibilityDate: "2026-09-22",
      compatibilityFlags: ["nodejs_compat"],
      d1Databases: ["DB"],
      r2Buckets: ["IMAGES"],
      bindings: { PROBE_TOKEN: token },
    },
  ],
});
for (const worker of options.workers) {
  worker.config.limits = { cpuMs: 30000, subrequests: 10000 };
}
const built = JSON.parse(await readFile("results/build-manifest.json", "utf8"));
for (const { path, sha256 } of built.files) {
  assert.equal(
    createHash("sha256")
      .update(await readFile(path))
      .digest("hex"),
    sha256,
    `Artifact differs from build manifest: ${path}`,
  );
}
const runtime = new Miniflare(options);
const report = {
  mode: "local-native-miniflare",
  startedAt: new Date().toISOString(),
  passed: false,
  scenarios: [],
  fixtureBoundary: "no hosted measurement or GitHub provenance/transport result",
};
await mkdir("results", { recursive: true });
try {
  const database = await runtime.getD1Database("DB", "probe");
  const migrations = (await readdir("../../../apps/web/migrations"))
    .filter((file) => file.endsWith(".sql"))
    .sort()
    .map((file) => `../../../apps/web/migrations/${file}`);
  for (const path of [...migrations, "probe-schema.sql"]) {
    const sql = (await readFile(path, "utf8")).replace(/^--.*$/gmu, "");
    let statement = "";
    for (const line of sql.split("\n")) {
      statement += `${line}\n`;
      if (!line.trimEnd().endsWith(";")) continue;
      await database.prepare(statement).run();
      statement = "";
    }
  }
  const request = (path, options = {}) =>
    runtime.dispatchFetch(`https://e03.local.test${path}`, {
      ...options,
      headers: { Authorization: `Bearer ${token}`, ...options.headers },
    });
  assert.equal((await runtime.dispatchFetch("https://e03.local.test/manifest")).status, 401);
  assert.equal(
    (await request("/manifest", { headers: { Authorization: "Bearer wrong" } })).status,
    401,
  );
  report.authentication = { missing: 401, wrong: 401, tokenStored: false };
  const manifest = await (await request("/manifest")).json();
  assert.deepEqual(manifest.fixture, JSON.parse(await readFile("fixture-manifest.json", "utf8")));
  assert.equal(
    (await request("/run/atomicCommands", { method: "POST", body: "null" })).status,
    400,
  );
  report.source = manifest;
  for (const scenario of manifest.scenarios.filter((name) => name !== "githubStatusLive")) {
    const prefix = `local-${scenario.toLowerCase()}`;
    const response = await request(`/run/${scenario}`, {
      method: "POST",
      body: JSON.stringify({ prefix }),
    });
    const receipt = await response.json();
    report.scenarios.push(receipt);
    await writeFile(`results/local-${scenario}.json`, `${JSON.stringify(receipt, null, 2)}\n`);
    console.log(
      JSON.stringify({
        scenario,
        status: response.status,
        passed: receipt.passed,
        durationMs: receipt.durationMs,
        d1: receipt.d1,
        error: receipt.error?.message,
      }),
    );
    assert.equal(response.status, 200, JSON.stringify(receipt.error));
    assert.equal(receipt.passed, true);
    assert.ok(
      receipt.d1.attemptedStatements + 2 < 1000,
      "Scenario must fit D1 per-invocation query bound including receipt bookkeeping",
    );
    const replay = await request(`/run/${scenario}`, {
      method: "POST",
      body: JSON.stringify({ prefix }),
    });
    assert.equal(replay.status, 409);
  }
  report.foreignKeyCheck = (await database.prepare("PRAGMA foreign_key_check").all()).results;
  assert.deepEqual(report.foreignKeyCheck, []);
  report.passed = true;
} catch (error) {
  report.failure = { message: error.message, stack: error.stack };
  throw error;
} finally {
  report.completedAt = new Date().toISOString();
  await writeFile("results/local-report.json", `${JSON.stringify(report, null, 2)}\n`);
  await runtime.dispose();
  await rm(directory, { recursive: true, force: true });
}
