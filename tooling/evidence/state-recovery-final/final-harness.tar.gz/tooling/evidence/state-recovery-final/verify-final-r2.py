#!/usr/bin/env python3
"""Read back every E03 image reference from the isolated remote R2 bucket."""

from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import subprocess
import tempfile

HERE = Path(__file__).resolve().parent
BUCKET = "visonaut-e03-final-20260923-images"
PREFIX = "final20260923-retentionraces"
WRANGLER = HERE / "../../../node_modules/wrangler/bin/wrangler.js"

references = json.loads((HERE / "results/final-r2-references.json").read_text())
assert len(references) == 1 and references[0]["success"]
rows = references[0]["results"]
assert len(rows) == 33
assert len({row["object_key"] for row in rows}) == len(rows)

blue = json.loads((HERE / "fixtures.json").read_text())["blue"]
for name in ["promotion-first", "rollback-pinned"]:
    rows.append({
        "object_key": f"runs/{PREFIX}-{name}/image.png",
        "digest": blue["digest"],
        "bytes": len(blue["bytes"]),
    })


def get_object(key, destination):
    command = [
        "node", str(WRANGLER), "r2", "object", "get", f"{BUCKET}/{key}",
        "--file", str(destination), "--remote", "--config", "deployment-config.json",
    ]
    return subprocess.run(command, cwd=HERE, text=True, capture_output=True, timeout=30)


def verify(item):
    index, row, directory = item
    key = row["object_key"]
    assert re.fullmatch(r"(?:runs|baselines)/[a-z0-9-]+/[a-z0-9.-]+", key)
    assert re.fullmatch(r"[0-9a-f]{64}", row["digest"])
    destination = directory / str(index)
    result = get_object(key, destination)
    assert result.returncode == 0, f"R2 read failed: {key}, exit {result.returncode}"
    data = destination.read_bytes()
    digest = hashlib.sha256(data).hexdigest()
    assert len(data) == row["bytes"], f"R2 size differs: {key}"
    assert digest == row["digest"], f"R2 digest differs: {key}"
    return {"objectKey": key, "bytes": len(data), "sha256": digest}


with tempfile.TemporaryDirectory(prefix="visonaut-e03-r2-readback-") as temporary:
    directory = Path(temporary)
    with ThreadPoolExecutor(max_workers=4) as executor:
        verified = list(executor.map(verify, ((i, row, directory) for i, row in enumerate(rows))))
    deleted_key = f"runs/{PREFIX}-gc-first/image.png"
    deleted = get_object(deleted_key, directory / "deleted")
    assert deleted.returncode != 0 and "The specified key does not exist" in deleted.stderr, (
        "The GC-first object unexpectedly exists or its absence could not be verified"
    )

receipt = {
    "bucket": BUCKET,
    "completedAt": datetime.now(timezone.utc).isoformat(),
    "referencedObjects": 33,
    "retainedSyntheticObjects": 2,
    "verifiedObjects": verified,
    "verifiedBytes": sum(item["bytes"] for item in verified),
    "gcFirstDeletedKey": deleted_key,
    "gcFirstReadRefused": True,
    "boundary": "Exact known objects were read by Wrangler; extra unreferenced objects were not enumerated.",
}
(HERE / "results/final-r2-readback.json").write_text(json.dumps(receipt, indent=2) + "\n")
print(json.dumps({key: value for key, value in receipt.items() if key != "verifiedObjects"}, indent=2))
