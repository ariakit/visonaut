import { context } from "./common.mjs";
import {
  atomicCommands,
  currentAndStaleUndo,
  rollbackHistory,
  acceptanceStatus,
  restoration,
  retentionRaces,
} from "./scenarios.mjs";
import { statusScenarios } from "./status.mjs";
import fixtureProof from "./fixture-manifest.json";
import source from "./source-manifest.json";
const scenarios = {
  atomicCommands,
  currentAndStaleUndo,
  rollbackHistory,
  acceptanceStatus,
  restoration,
  retentionRaces,
  statusScenarios,
};
async function authenticated(request, env) {
  const supplied = request.headers.get("Authorization");
  if (!env.PROBE_TOKEN || !supplied) return false;
  const encoder = new TextEncoder();
  const key = await crypto.subtle.importKey(
    "raw",
    encoder.encode(env.PROBE_TOKEN),
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["sign", "verify"],
  );
  const signature = await crypto.subtle.sign(
    "HMAC",
    key,
    encoder.encode(`Bearer ${env.PROBE_TOKEN}`),
  );
  return crypto.subtle.verify("HMAC", key, signature, encoder.encode(supplied));
}
async function boundedText(request) {
  if (!request.body) return "";
  const reader = request.body.getReader();
  const chunks = [];
  let total = 0;
  while (true) {
    const { value, done } = await reader.read();
    if (done) break;
    total += value.length;
    if (total > 1024) {
      await reader.cancel();
      return null;
    }
    chunks.push(value);
  }
  const bytes = new Uint8Array(total);
  let offset = 0;
  for (const chunk of chunks) {
    bytes.set(chunk, offset);
    offset += chunk.length;
  }
  return new TextDecoder().decode(bytes);
}
export default {
  async fetch(request, env) {
    if (!(await authenticated(request, env)))
      return Response.json({ error: "unauthorized" }, { status: 401 });
    const url = new URL(request.url);
    if (url.pathname === "/manifest" && request.method === "GET")
      return Response.json({
        ...source,
        fixture: fixtureProof,
        deployment: env.VERSION ?? null,
        scenarios: Object.keys(scenarios),
      });
    const receiptMatch = /^\/receipt\/([a-z][a-z0-9-]{1,55})$/u.exec(url.pathname);
    if (receiptMatch && request.method === "GET") {
      const row = await env.DB.prepare(
        "SELECT scenario,started_at,passed,receipt_json FROM e03_probe_runs WHERE id=?",
      )
        .bind(receiptMatch[1])
        .first();
      if (!row) return Response.json({ error: "not-found" }, { status: 404 });
      return Response.json(
        row.receipt_json
          ? JSON.parse(row.receipt_json)
          : { pending: true, scenario: row.scenario, startedAt: row.started_at },
      );
    }
    const match = /^\/run\/([A-Za-z]+)$/u.exec(url.pathname);
    if (!match || request.method !== "POST" || !Object.hasOwn(scenarios, match[1]))
      return Response.json({ error: "not-found" }, { status: 404 });
    const text = await boundedText(request);
    if (text === null) return Response.json({ error: "oversize" }, { status: 413 });
    let input;
    try {
      input = JSON.parse(text);
    } catch {
      return Response.json({ error: "invalid-json" }, { status: 400 });
    }
    if (!input || typeof input !== "object" || !/^[a-z][a-z0-9-]{1,55}$/u.test(input.prefix ?? ""))
      return Response.json({ error: "invalid-prefix" }, { status: 400 });
    const startedAt = new Date().toISOString();
    const started = Date.now();
    const name = match[1];
    try {
      await env.DB.prepare("INSERT INTO e03_probe_runs(id,scenario,started_at) VALUES(?,?,?)")
        .bind(input.prefix, name, startedAt)
        .run();
    } catch {
      return Response.json({ error: "prefix-already-used" }, { status: 409 });
    }
    const fixture = context(env, input.prefix);
    let result;
    let error;
    try {
      result = await scenarios[name](fixture, env);
    } catch (caught) {
      error = { name: caught.name, message: caught.message, stack: caught.stack };
    }
    const receipt = {
      scenario: name,
      prefix: input.prefix,
      sourceTree: source.sourceTree,
      deployment: env.VERSION ?? null,
      startedAt,
      completedAt: new Date().toISOString(),
      durationMs: Date.now() - started,
      passed: !error,
      result,
      error,
      events: fixture.events,
      assertions: fixture.assertions,
      d1: fixture.database.metrics,
      r2: fixture.objectMetrics,
      boundaries: {
        runtime: "same Worker bundle for local Miniflare and hosted Cloudflare",
        source: "exact a953a2b final-source service, work, retention, lineage, comparator algorithms",
        identity: "synthetic trusted metadata and maintainers, no OAuth/OIDC/webhook",
        captures: "synthetic 1x1 PNGs in native R2; RGBA decode fixture after SHA-256 verification",
        clock: "explicit injected logical clocks; wall time measured separately",
        github: "Recorded callbacks only; no outbound GitHub request or check route",
        metrics:
          "D1 calls/attemptedStatements count attempts; other D1 metadata sums successful returned results only, excludes failed-batch metadata and probe bookkeeping. R2 meters explicit fixture puts/gets/deletes, excludes HEAD and control-plane operations.",
      },
    };
    await env.DB.prepare("UPDATE e03_probe_runs SET passed=?,receipt_json=? WHERE id=?")
      .bind(receipt.passed ? 1 : 0, JSON.stringify(receipt), input.prefix)
      .run();
    return Response.json(receipt, { status: error ? 500 : 200 });
  },
};
