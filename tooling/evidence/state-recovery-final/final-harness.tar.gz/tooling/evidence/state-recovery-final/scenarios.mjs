import {
  claimStatus,
  deliverStatus,
  closedRunRetentionMs,
  claimExpiredRun,
  retainedRunStatement,
  retentionPinStatement,
  releaseRetentionPinStatement,
  claimPromotionLease,
  releasePromotionLeaseStatement,
  completeRunDeletion,
} from "../../../packages/service/src/work.ts";
import { retireSnapshot } from "../../../packages/service/src/retention.ts";
import { hash } from "./common.mjs";

export async function atomicCommands(context) {
  const {
    database,
    service,
    id,
    seed,
    fixture,
    review,
    undo,
    counts,
    conflict,
    equal,
    assert,
    event,
  } = context;
  const captures = ["light", "dark"].map((variant) => ({ item: "dialog", variant, color: "blue" }));
  await seed(captures);
  await fixture({
    name: "changed",
    captures: captures.map((entry) => ({ ...entry, color: "red" })),
  });
  const rows = await service.comparisonRows(id("comparison-changed"));
  const stale = {
    commandId: id("whole-stale"),
    wholeItemKey: "dialog",
    targets: rows.map((row) => ({ id: row.id, expectedRevision: row.decision_revision })),
  };
  let afterCompeting;
  database.beforeBatch = async () => {
    await review("changed", {
      commandId: id("competing"),
      actorId: "synthetic-maintainer-2",
      sessionId: "second-session",
      verdict: "rejected",
      targets: [{ id: rows[1].id, expectedRevision: rows[1].decision_revision }],
    });
    afterCompeting = await counts();
    event("injected competing native D1 review immediately before whole-item atomic batch", {
      target: rows[1].id,
    });
  };
  await conflict(() => review("changed", stale), "stale whole-item command refuses all writes");
  equal(
    await counts(),
    afterCompeting,
    "stale command leaves audit, outbox, decisions, commands, promotions unchanged",
  );
  const resultRows = await service.comparisonRows(id("comparison-changed"));
  equal(resultRows[0].decision_id, null, "untouched variant receives no partial decision");
  const options = {
    commandId: id("whole-approve"),
    wholeItemKey: "dialog",
    targets: resultRows.map((row) => ({ id: row.id, expectedRevision: row.decision_revision })),
  };
  const command = await review("changed", options);
  const committed = await counts();
  equal(
    await review("changed", options),
    command,
    "exact command replay returns same saved result",
  );
  equal(await counts(), committed, "command replay makes no writes");
  await undo(command);
  equal(
    (await service.status(id("changed"))).status,
    "rejected",
    "whole-item Undo restores prior rejection",
  );
  const afterUndo = await service.comparisonRows(id("comparison-changed"));
  equal(afterUndo[0].decision_id, null, "whole-item Undo restores first unreviewed target");
  assert(afterUndo[1].decision_id, "whole-item Undo restores competing target decision");
  event("whole-item atomic save, replay and Undo passed", { targets: rows.length });
  return {
    targets: rows.length,
    guards: [
      "real competing command before native batch",
      "zero partial writes",
      "idempotent replay",
      "whole-item prior verdict restoration",
    ],
  };
}

export async function rollbackHistory(context) {
  const {
    service,
    database,
    id,
    seed,
    fixture,
    review,
    promote,
    undo,
    project,
    counts,
    conflict,
    assert,
    equal,
    event,
    getImage,
  } = context;
  await seed();
  await fixture({
    name: "mixed",
    captures: [
      { item: "dialog", variant: "light", color: "red" },
      { item: "dialog", variant: "dark", color: "red" },
    ],
  });
  let rows = await service.comparisonRows(id("comparison-mixed"));
  const human = rows.find((row) => row.variant_key === "light");
  const automatic = rows.find((row) => row.variant_key === "dark");
  assert(human && automatic?.decision_id, "mixed fixture has human change and automatic addition");
  await review("mixed", { targets: [{ id: human.id, expectedRevision: human.decision_revision }] });
  await promote("mixed");
  const protectedBefore = await counts();
  await conflict(
    () =>
      review("mixed", {
        verdict: "rejected",
        wholeItemKey: "dialog",
        expectedPromotionId: id("promotion-mixed"),
        expectedBaselineRevision: 2,
      }),
    "protected automatic target refuses whole-item rejection",
  );
  equal(await counts(), protectedBefore, "protected whole-item rejection makes no partial writes");
  equal(
    (await project()).snapshot_id,
    id("snapshot-mixed"),
    "protected rejection preserves current baseline",
  );
  const noop = await review("mixed");
  equal(noop.noop, true, "approval of accepted history is a no-op");
  equal(
    await counts(),
    protectedBefore,
    "accepted-history approval creates no Undo/audit/outbox work",
  );
  await conflict(
    () => retireSnapshot(database, { snapshotId: id("snapshot-mixed"), now: 140, graceMs: 0 }),
    "current snapshot retirement is refused",
  );
  await conflict(
    () => retireSnapshot(database, { snapshotId: id("snapshot-seed"), now: 140, graceMs: 0 }),
    "rollback predecessor retirement is refused",
  );
  database.beforeBatch = async () => {
    equal(
      await claimExpiredRun(database, {
        id: id("seed"),
        token: "gc-before-rollback",
        now: closedRunRetentionMs + 1000,
        leaseMs: 100,
      }),
      null,
      "GC cannot claim rollback predecessor during review save",
    );
    event("injected native GC claim immediately before D26 rollback batch", { claim: null });
  };
  rows = await service.comparisonRows(id("comparison-mixed"));
  const currentHuman = rows.find((row) => row.id === human.id);
  const rejection = await review("mixed", {
    verdict: "rejected",
    actorId: "synthetic-maintainer-2",
    sessionId: "after-reload",
    targets: [{ id: human.id, expectedRevision: currentHuman.decision_revision }],
    expectedPromotionId: id("promotion-mixed"),
    expectedBaselineRevision: 2,
  });
  equal(
    (await project()).snapshot_id,
    id("snapshot-seed"),
    "D26 rollback restores complete prior baseline",
  );
  equal((await project()).baseline_revision, 3, "rollback advances baseline revision");
  equal(
    (
      await database
        .prepare("SELECT revoked FROM visonaut_decisions WHERE id=?")
        .bind(automatic.decision_id)
        .first()
    ).revoked,
    0,
    "mixed rollback preserves automatic acceptance",
  );
  const originals = await service.snapshotCopies(id("snapshot-seed"));
  for (const image of originals) {
    equal(
      await hash(await getImage(image.object_key)),
      image.digest,
      "rollback predecessor native R2 bytes remain intact",
    );
  }
  const restored = await undo(rejection, {
    actorId: "synthetic-maintainer-2",
    sessionId: "after-reload",
  });
  equal((await project()).snapshot_id, id("snapshot-mixed"), "Undo D26 restores snapshot");
  equal(restored.baselineRevision, 4, "Undo D26 advances revision");
  assert(restored.promotionId !== id("promotion-mixed"), "Undo D26 creates new promotion identity");
  const beforeStale = await counts();
  const restoredHuman = (await service.comparisonRows(id("comparison-mixed"))).find(
    (row) => row.id === human.id,
  );
  await conflict(
    () =>
      review("mixed", {
        verdict: "rejected",
        targets: [{ id: human.id, expectedRevision: restoredHuman.decision_revision }],
        expectedPromotionId: id("promotion-mixed"),
        expectedBaselineRevision: 4,
      }),
    "restoring a snapshot does not revive its old promotion guard",
  );
  await conflict(
    () => undo(rejection, { actorId: "synthetic-maintainer-2", sessionId: "after-reload" }),
    "completed rejection Undo cannot be revived with a new command ID",
  );
  equal(await counts(), beforeStale, "stale history commands make no partial writes");
  return {
    mixedTargets: 2,
    finalBaselineRevision: (await project()).baseline_revision,
    protectedNativeCopiesVerified: originals.length,
    guards: [
      "automatic history",
      "whole-item protection",
      "D26 rollback",
      "D26 Undo new promotion",
      "stale promotion and Undo",
      "native R2 rollback pin",
    ],
  };
}

export async function currentAndStaleUndo(context) {
  const {
    database,
    service,
    id,
    seed,
    fixture,
    review,
    promote,
    undo,
    project,
    counts,
    conflict,
    equal,
  } = context;
  await seed();
  await fixture({ name: "red", color: "red" });
  const redApproval = await review("red");
  await promote("red");
  await fixture({ name: "green", color: "green" });
  const greenApproval = await review("green");
  await promote("green");
  const before = await counts();
  await conflict(() => undo(redApproval), "D22 old approval Undo refuses after later promotion");
  await conflict(
    () =>
      review("red", {
        verdict: "rejected",
        expectedPromotionId: id("promotion-red"),
        expectedBaselineRevision: 3,
      }),
    "D26 old human rejection refuses after later promotion",
  );
  equal(await counts(), before, "stale D22/D26 leave every production table unchanged");
  equal(
    (await project()).snapshot_id,
    id("snapshot-green"),
    "stale commands preserve later baseline",
  );
  await undo(greenApproval);
  equal(
    (await project()).snapshot_id,
    id("snapshot-red"),
    "D22 current approval Undo restores predecessor",
  );
  equal((await project()).baseline_revision, 4, "D22 current Undo increments baseline revision");
  equal(
    (await service.status(id("green"))).status,
    "needs-review",
    "D22 revokes effective approval",
  );
  equal(
    (
      await database
        .prepare("SELECT reference_eligible FROM visonaut_snapshots WHERE id=?")
        .bind(id("snapshot-green"))
        .first()
    ).reference_eligible,
    0,
    "D22 revokes snapshot reference eligibility",
  );
  return {
    finalBaselineRevision: 4,
    guards: [
      "stale D22 Undo",
      "stale D26 rejection",
      "current D22 rollback",
      "complete native D1 state hashes",
    ],
  };
}

export async function acceptanceStatus(context) {
  const {
    database,
    service,
    id,
    seed,
    fixture,
    review,
    undo,
    project,
    conflict,
    assert,
    equal,
    event,
  } = context;
  await seed();
  await fixture({ name: "source", kind: "pull_request", lineage: id("pr-1"), color: "red" });
  await review("source");
  const sourceRow = (await service.comparisonRows(id("comparison-source")))[0];
  await fixture({ name: "dependent", color: "red", related: ["source"] });
  equal(
    (await service.status(id("dependent"))).status,
    "passed",
    "exact verified-related acceptance is reused",
  );
  const reused = (await service.comparisonRows(id("comparison-dependent")))[0];
  equal(
    reused.source_decision_id,
    sourceRow.decision_id,
    "reuse references specific original source decision",
  );
  equal(reused.decision_id, null, "reuse creates no detached decision");
  const checkId = id("check");
  const statusParams = {
    runId: id("dependent"),
    checkId,
    detailsUrl: "https://example.invalid/synthetic-fixture",
    maxAttempts: 3,
    now: 200,
  };
  const queued = await service.prepareStatusIntent(statusParams);
  equal(queued.conclusion, "success", "exact acceptance initially queues success");
  assert(
    await claimStatus(database, { id: checkId, token: "old", now: 200, leaseMs: 100 }),
    "old success has native outbox lease",
  );
  event("injected source rejection after status claim and before delivery", {
    queuedRevision: queued.revision,
  });
  const rejection = await review("source", { verdict: "rejected" });
  equal(
    (await service.status(id("dependent"))).status,
    "needs-review",
    "source rejection invalidates dependent acceptance",
  );
  const desired = (
    await database
      .prepare("SELECT desired_revision FROM work_checks WHERE id=?")
      .bind(checkId)
      .first()
  ).desired_revision;
  assert(
    desired !== queued.revision,
    "source rejection atomically advances native desired status revision",
  );
  const sent = [];
  equal(
    await deliverStatus(database, {
      id: checkId,
      token: "old",
      revision: queued.revision,
      now: () => 201,
      send: async (intent) => {
        sent.push(intent.conclusion);
      },
    }),
    "stale",
    "delayed success is refused before mock sender",
  );
  equal(sent, [], "no stale transport invocation");
  await conflict(
    () =>
      service.preparePromotion({
        snapshotId: id("blocked"),
        comparisonId: id("comparison-dependent"),
        prefix: `baselines/${id("blocked")}`,
        now: 202,
      }),
    "source rejection prevents baseline promotion",
  );
  const fresh = await service.prepareStatusIntent({ ...statusParams, now: 203 });
  equal(fresh.conclusion, "failure", "fresh domain status is failure");
  assert(
    await claimStatus(database, { id: checkId, token: "fresh", now: 204, leaseMs: 100 }),
    "fresh failure claim",
  );
  equal(
    await deliverStatus(database, {
      id: checkId,
      token: "fresh",
      revision: fresh.revision,
      now: () => 205,
      send: async (intent) => {
        sent.push(intent.conclusion);
      },
    }),
    "delivered",
    "fresh failure reaches mock sender",
  );
  equal(sent, ["failure"], "only current failure was recorded");
  await undo(rejection);
  equal(
    (await service.status(id("dependent"))).status,
    "passed",
    "source rejection Undo restores exact acceptance eligibility",
  );
  await fixture({ name: "unrelated", kind: "pull_request", color: "red" });
  equal(
    (await service.status(id("unrelated"))).status,
    "needs-review",
    "unrelated equal bytes cannot borrow acceptance",
  );
  equal((await project()).snapshot_id, id("snapshot-seed"), "fixture leaves baseline at seed");
  return {
    oldRevision: queued.revision,
    invalidatedRevision: desired,
    newRevision: fresh.revision,
    transport: "synthetic send recorder; no GitHub request",
    sent,
    guards: [
      "exact source reference",
      "source invalidation",
      "source Undo",
      "unrelated-lineage refusal",
      "delayed status freshness",
    ],
  };
}

export async function restoration(context) {
  const { database, service, id, seed, fixture, promote, review, counts, conflict, assert, equal } =
    context;
  await seed([
    { item: "dialog", variant: "light", color: "blue" },
    { item: "menu", variant: "light", color: "blue" },
  ]);
  const seedMenu = (await service.comparisonRows(id("comparison-seed"))).find(
    (row) => row.item_key === "menu",
  );
  assert(seedMenu?.decision_id, "seed menu has original automatic acceptance");
  await fixture({ name: "removed" });
  const removed = (await service.comparisonRows(id("comparison-removed"))).find(
    (row) => row.item_key === "menu",
  );
  assert(
    removed?.decision_id && !removed.candidate_capture_id,
    "confirmed removal has automatic acceptance and retained row",
  );
  await promote("removed");
  const before = await counts();
  await conflict(
    () =>
      review("removed", {
        verdict: "rejected",
        targets: [{ id: removed.id, expectedRevision: removed.decision_revision }],
        expectedPromotionId: id("promotion-removed"),
        expectedBaselineRevision: 2,
      }),
    "automatic removal promoted history stays protected",
  );
  equal(await counts(), before, "protected removal makes no partial writes");
  await fixture({
    name: "restored",
    related: ["seed"],
    captures: [
      { item: "dialog", variant: "light", color: "blue" },
      { item: "menu", variant: "light", color: "blue" },
    ],
  });
  const exact = (await service.comparisonRows(id("comparison-restored"))).find(
    (row) => row.item_key === "menu",
  );
  equal(
    exact?.source_decision_id,
    seedMenu.decision_id,
    "exact restoration reuses specific original eligible decision",
  );
  equal(exact?.decision_id, null, "restoration creates no detached decision");
  equal((await service.status(id("restored"))).status, "passed", "exact restoration passes");
  await fixture({
    name: "drifted",
    related: ["seed"],
    captures: [
      { item: "dialog", variant: "light", color: "blue" },
      { item: "menu", variant: "light", color: "red" },
    ],
  });
  const drifted = (await service.comparisonRows(id("comparison-drifted"))).find(
    (row) => row.item_key === "menu",
  );
  assert(
    !drifted.source_decision_id && !drifted.decision_id,
    "drifted restoration receives no automatic/reused decision",
  );
  equal(
    (await service.status(id("drifted"))).status,
    "needs-review",
    "changed restoration needs review",
  );
  equal(
    (
      await database
        .prepare("SELECT revoked FROM visonaut_decisions WHERE id=?")
        .bind(removed.decision_id)
        .first()
    ).revoked,
    0,
    "protected removal retains decision metadata",
  );
  return { exactRestoration: "passed", driftedRestoration: "needs-review", protectedRemoval: true };
}

export async function retentionRaces(context) {
  const { database, images, id, png, putImage, getImage, assert, equal, event, objectMetrics } =
    context;
  const image = png();
  const now = closedRunRetentionMs + 100;
  const create = async (name) => {
    const runId = id(name);
    await retainedRunStatement(database, {
      id: runId,
      objectPrefix: `runs/${runId}/`,
      closedAt: 100,
    }).run();
    await putImage(`runs/${runId}/image.png`, image.bytes);
    return runId;
  };
  const first = await create("promotion-first");
  const promotion = {
    id: first,
    owner: id("promotion-owner"),
    token: "promotion-old",
    now: 100,
    leaseMs: 10,
  };
  equal(
    await claimPromotionLease(database, promotion),
    true,
    "promotion obtains native retained-byte lease",
  );
  event("injected 30-day elapsed clock with expired promotion lease", { now });
  equal(
    await claimExpiredRun(database, { id: first, token: "gc", now, leaseMs: 100 }),
    null,
    "expired promotion lease still pins bytes against GC",
  );
  await releasePromotionLeaseStatement(database, { ...promotion, now }).run();
  equal(
    await claimExpiredRun(database, { id: first, token: "gc", now, leaseMs: 100 }),
    null,
    "stale owner cannot release promotion pin",
  );
  const recovered = { ...promotion, token: "promotion-recovered", now, leaseMs: 100 };
  equal(
    await claimPromotionLease(database, recovered),
    true,
    "fresh owner recovers expired promotion lease",
  );
  equal(
    await hash(await getImage(`runs/${first}/image.png`)),
    image.digest,
    "promotion-first R2 bytes remain",
  );
  await releasePromotionLeaseStatement(database, recovered).run();
  assert(
    await claimExpiredRun(database, { id: first, token: "gc-after-release", now, leaseMs: 100 }),
    "GC becomes eligible only after explicit promotion settlement",
  );
  const second = await create("gc-first");
  const deletion = { id: second, token: "gc-first", now, leaseMs: 10 };
  assert(await claimExpiredRun(database, deletion), "GC wins native claim");
  equal(
    await claimPromotionLease(database, {
      id: second,
      owner: id("late-promotion"),
      token: "late",
      now,
      leaseMs: 10,
    }),
    false,
    "GC-first blocks late promotion",
  );
  let pinError;
  try {
    await retentionPinStatement(database, {
      runId: second,
      owner: id("late-rollback"),
      reason: "rollback",
    }).run();
  } catch (error) {
    pinError = error;
  }
  assert(
    /not available/u.test(pinError?.message ?? ""),
    "GC-first refuses late rollback reference",
  );
  event("injected GC pause after native claim and before R2 delete", {
    runId: second,
    latePromotion: false,
    lateRollback: "refused",
  });
  assert(
    await claimExpiredRun(database, { ...deletion, token: "gc-recovered", now: now + 10 }),
    "new deletion token recovers expired native lease",
  );
  equal(
    await completeRunDeletion(database, { ...deletion, now: now + 11 }),
    false,
    "stale deletion token cannot settle",
  );
  objectMetrics.deletes += 1;
  await images.delete(`runs/${second}/image.png`);
  equal(await images.head(`runs/${second}/image.png`), null, "native R2 object was deleted");
  equal(
    await completeRunDeletion(database, { id: second, token: "gc-recovered", now: now + 11 }),
    true,
    "current token settles deleted bytes",
  );
  const rollback = await create("rollback-pinned");
  const pin = { runId: rollback, owner: id("rollback-owner"), reason: "rollback" };
  await retentionPinStatement(database, pin).run();
  equal(
    await claimExpiredRun(database, { id: rollback, token: "gc", now, leaseMs: 10 }),
    null,
    "existing rollback pin blocks GC",
  );
  equal(
    await hash(await getImage(`runs/${rollback}/image.png`)),
    image.digest,
    "rollback R2 bytes remain",
  );
  await releaseRetentionPinStatement(database, pin).run();
  assert(
    await claimExpiredRun(database, { id: rollback, token: "gc-after-rollback", now, leaseMs: 10 }),
    "released rollback pin permits GC",
  );
  return {
    injectedClock: now,
    boundary:
      "synthetic retained-run rows; exact native D1 lease/pin algorithms plus native R2 bytes",
    guards: [
      "promotion-first",
      "expired promotion pin",
      "GC-first",
      "late rollback refusal",
      "stale deletion token",
      "rollback-first",
    ],
  };
}
