CREATE TABLE e03_probe_runs (
 id TEXT PRIMARY KEY,
 scenario TEXT NOT NULL,
 started_at TEXT NOT NULL,
 passed INTEGER,
 receipt_json TEXT
);
