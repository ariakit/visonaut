#!/usr/bin/env python3
"""Reconstruct frozen receipts and check arithmetic locally in a new directory."""

import argparse
import ast
import gzip
import hashlib
import io
import json
import math
from pathlib import Path, PurePosixPath
import tarfile


def digest(data):
    return hashlib.sha256(data).hexdigest()


def checked_path(root, name):
    relative = PurePosixPath(name)
    if relative.is_absolute() or not relative.parts or ".." in relative.parts:
        raise ValueError(f"Unsafe evidence path: {name}")
    return root.joinpath(*relative.parts)


def read_json(path):
    return json.loads(path.read_text())


def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2) + "\n")


def put(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(data)


def checked_bytes(root, record):
    data = checked_path(root, record["path"]).read_bytes()
    if len(data) != record["bytes"] or digest(data) != record["sha256"]:
        raise ValueError(f"Stored evidence differs: {record['path']}")
    if record["compression"] == "gzip":
        data = gzip.decompress(data)
    elif record["compression"] is not None:
        raise ValueError("Unsupported evidence compression")
    if len(data) != record["originalBytes"] or digest(data) != record["originalSha256"]:
        raise ValueError(f"Original evidence differs: {record['path']}")
    return data


def filtered(data, phases):
    return b"".join(
        line for line in data.splitlines(keepends=True)
        if line.strip() and json.loads(line).get("phase") in phases
    )


def equal(actual, expected, label="value"):
    if isinstance(actual, dict) and isinstance(expected, dict):
        if set(actual) != set(expected):
            raise ValueError(f"Different fields at {label}: {set(actual) ^ set(expected)}")
        for key in actual:
            equal(actual[key], expected[key], f"{label}.{key}")
    elif isinstance(actual, list) and isinstance(expected, list):
        if len(actual) != len(expected):
            raise ValueError(f"Different list length at {label}")
        for index, (left, right) in enumerate(zip(actual, expected)):
            equal(left, right, f"{label}[{index}]")
    elif isinstance(actual, (int, float)) and isinstance(expected, (int, float)):
        if not math.isfinite(actual) or not math.isfinite(expected):
            raise ValueError(f"Non-finite number at {label}")
        if isinstance(actual, int) and isinstance(expected, int):
            matches = actual == expected
        else:
            matches = math.isclose(actual, expected, rel_tol=1e-12, abs_tol=1e-8)
        if not matches:
            raise ValueError(f"Different number at {label}: {actual} != {expected}")
    elif actual != expected:
        raise ValueError(f"Different value at {label}")


def load_frozen(path, declarations_only=False, **settings):
    # Never import from disk or run a historical CLI entry point. This executes
    # the retained calculator definitions without creating Python cache files.
    tree = ast.parse(path.read_text(), filename=str(path))
    if declarations_only:
        tree.body = [node for node in tree.body if isinstance(
            node, (ast.Import, ast.ImportFrom, ast.FunctionDef)
        ) or (isinstance(node, ast.Assign) and all(
            isinstance(target, ast.Name) and target.id in {"INSPECTION", "ELIGIBILITY"}
            for target in node.targets
        ))]
    namespace = {"__name__": "frozen_numeric_calculator", "__file__": str(path)}
    exec(compile(tree, str(path), "exec"), namespace)
    namespace.update(settings)
    return namespace


def resolve_historical(recorded, name):
    name = name.replace("/private/tmp/", "/tmp/", 1)
    for old, new in (
        ("/tmp/ariviso-v3-cost-model/", "cost-model/"),
        ("/tmp/ariviso-v3-drill/tooling/v3/", "drill/"),
    ):
        if name.startswith(old):
            return checked_path(recorded, new + name[len(old):])
    raise ValueError(f"Unmapped historical path: {name}")


def check_measurement_inputs(recorded, path, allow_sql=False):
    checked, omitted = [], []
    allowed_sql = {
        f"/tmp/ariviso-v3-drill/tooling/v3/results/{size}/{phase}-source.sql"
        for size in ("small", "large") for phase in ("cold", "warm")
    }
    for name, value in read_json(path).items():
        expected = value if isinstance(value, dict) else {"sha256": value}
        source = expected.get("exactInputSnapshot", name)
        target = resolve_historical(recorded, source)
        if not target.exists():
            if allow_sql and name.replace("/private/tmp/", "/tmp/", 1) in allowed_sql:
                omitted.append({"sourcePath": name, "recordedIdentity": expected})
                continue
            raise ValueError(f"Missing measured input: {name}")
        data = target.read_bytes()
        if digest(data) != expected["sha256"] or (
            "bytes" in expected and len(data) != expected["bytes"]
        ):
            raise ValueError(f"Measured input differs: {name}")
        checked.append(name)
    if allow_sql and len(omitted) != 4:
        raise ValueError("Expected exactly four intentionally omitted backup SQL bodies")
    return {"verified": checked, "sqlBodiesNotRehashed": omitted}


def metrics(raw):
    if raw.get("status") != 200 or raw["result"].get("errors"):
        raise ValueError("Metric response did not succeed")
    rows = [row for account in raw["result"]["data"]["viewer"]["accounts"]
            for row in account["workersInvocationsAdaptive"]]
    return {
        "returnedGroups": len(rows),
        "estimatedRequests": sum(row["sum"]["requests"] for row in rows),
        "reportedErrors": sum(row["sum"]["errors"] for row in rows),
        "estimatedCPUMilliseconds": sum(row["sum"]["cpuTimeUs"] for row in rows) / 1000,
        "maximumSampledCPUMilliseconds": max(row["max"]["cpuTime"] for row in rows) / 1000,
        "maximumSampledMemoryBytes": max(row["max"]["memoryUsageBytes"] for row in rows),
        "maximumSampledWallMilliseconds": max(row["max"]["wallTime"] for row in rows) / 1000,
        "sampleIntervals": sorted({row["avg"]["sampleInterval"] for row in rows}),
    }


def reconstruct(here, repository, destination):
    manifest = read_json(here / "INPUTS.json")
    dependency_path = checked_path(here, manifest["dependencyManifest"])
    if digest(dependency_path.read_bytes()) != manifest["dependencyManifestSha256"]:
        raise ValueError("Small dependency manifest differs")
    dependencies = read_json(dependency_path)
    originals = {entry["recordedPath"]: checked_bytes(here, entry)
                 for entry in manifest["files"]}
    if len(originals) != len(manifest["files"]):
        raise ValueError("Duplicate recorded path")
    small = {entry["path"]: checked_bytes(repository, entry)
             for entry in dependencies["files"]}
    if len(small) != len(dependencies["files"]):
        raise ValueError("Duplicate dependency path")
    destination.mkdir(parents=True, exist_ok=False)
    recorded = destination / "recorded"
    for name, content in originals.items():
        put(checked_path(recorded, name), content)
    cost, drill = recorded / "cost-model", recorded / "drill"
    results = drill / "results"
    received = cost / "large-backup/completed-01/received-json"
    small_prefix = "docs/evidence/v3-small/receipts/"
    for path, data in small.items():
        if path.startswith(small_prefix):
            name = path[len(small_prefix):]
            if name.endswith(".json") and name != "frozen-implementation.json":
                put(results / "small" / name, data)
    original_map = small[small_prefix + "frozen-implementation.json"]
    put(results / "frozen-implementation.json", original_map)
    put(received / "frozen-implementation.json", original_map)
    for name in ("archive-root.json", "cold-backup-manifest.json", "cold-checkpoint.json",
                 "cold-source-snapshot.json", "cold-staging.json", "cold-summary.json",
                 "warm-backup-manifest.json", "warm-checkpoint.json", "warm-source-snapshot.json",
                 "warm-staging.json", "warm-summary.json"):
        put(received / "small" / name, small[small_prefix + name])
    for source in (received / "large").glob("*.json"):
        put(results / "large" / source.name, source.read_bytes())
    put(received / "preserved-hashes.json", (cost / "large-backup/preserved-hashes.json").read_bytes())
    progress_map = (received / "frozen-implementation-progress.json").read_bytes()
    put(results / "frozen-implementation-progress.json", progress_map)
    events = small[small_prefix + "events.jsonl.gz"]
    put(results / "small/events.jsonl", filtered(events, {"archive", "cold", "warm"}))
    put(cost / "large-archive/small-archive.events.jsonl", filtered(events, {"archive"}))
    put(cost / "large-backup/completed-01/small-events.jsonl", filtered(events, {"cold", "warm"}))
    times = filtered(small[small_prefix + "phase-timings.jsonl"], {"cold", "warm"})
    put(results / "small/phase-timings.jsonl", times)
    put(cost / "large-backup/completed-01/small-phase-timings.jsonl", times)
    put(results / "large/events.jsonl", (cost / "large-archive/large-archive.events.jsonl").read_bytes()
        + (cost / "large-backup/completed-01/large-events.jsonl").read_bytes())
    put(results / "large/phase-timings.jsonl", (cost / "large-backup/completed-01/large-phase-timings.jsonl").read_bytes())
    base_hashes = json.loads(original_map)
    required = {"controller/implementation/" + name: "implementation/" + name for name in base_hashes}
    required.update({"controller/" + name: name for name in ("run.mjs", "phases.mjs", "worker.mjs", "stores.mjs")})
    tar_data = small["tooling/evidence/v3-small/inputs/frozen-replay.tar.gz"]
    with tarfile.open(fileobj=io.BytesIO(tar_data), mode="r:") as archive:
        members = archive.getmembers()
        if len({member.name for member in members}) != len(members):
            raise ValueError("Duplicate archive member")
        for member in members:
            checked_path(drill, member.name)
            if not member.isfile():
                raise ValueError("Frozen archive contains a non-regular file")
            if member.name in required:
                put(checked_path(drill, required[member.name]), archive.extractfile(member).read())
    new_hashes = json.loads(progress_map)
    changes = []
    if len(base_hashes) != 77 or set(base_hashes) != set(new_hashes):
        raise ValueError("Frozen source inventory differs")
    for name, expected in base_hashes.items():
        original = checked_path(drill / "implementation", name).read_bytes()
        if digest(original) != expected:
            raise ValueError(f"Frozen base source differs: {name}")
        progress = checked_path(drill / "implementation-progress", name)
        if not progress.exists():
            put(progress, original)
        if digest(progress.read_bytes()) != new_hashes[name]:
            raise ValueError(f"Frozen progress source differs: {name}")
        if expected != new_hashes[name]:
            changes.append({"path": name, "before": expected, "after": new_hashes[name]})
    equal(sorted(changes, key=lambda item: item["path"]),
          sorted(read_json(results / "progress-only-delta.json"), key=lambda item: item["path"]),
          "progress source delta")
    if len(changes) != 3:
        raise ValueError("Expected exactly three frozen progress changes")
    return recorded, manifest, dependencies


def check_archive(cost, results, output):
    reference = read_json(cost / "large-archive/comparison.json")
    target = output / "archive-calculator-output"
    target.mkdir()
    calculator = load_frozen(cost / "large-archive/analyze.py", declarations_only=True, BASE=results, OUT=target)
    values = {}
    for name, captures in (("small", 3582), ("large", 35820)):
        value = calculator["scenario"](name, captures)
        expected = reference[name].copy()
        expected["archive_event_snapshot"] = value["archive_event_snapshot"]
        equal(value, expected, "archive." + name)
        values[name] = value
    small, large = values["small"], values["large"]
    ratios = {key: large[key] / small[key] for key in (
        "page_count", "root_bytes", "page_bytes", "controller_elapsed_ms", "physical_before_bytes",
        "physical_after_bytes", "sql_before_bytes", "sql_after_bytes")}
    ratios.update({"application_" + key: large["application"][key] / small["application"][key]
                   for key in ("queries", "reads", "writes", "sql_ms")})
    ratios.update({"total_" + key: large["total"][key] / small["total"][key]
                   for key in ("invocations", "handler_wall_ms", "sql_ms")})
    equal(ratios, reference["ratios_large_over_small"], "archive ratios")
    raw = read_json(results / "worker-metrics-2026-09-22T11-44-00Z.json")
    checked = metrics(raw)
    rows = raw["result"]["data"]["viewer"]["accounts"][0]["workersInvocationsAdaptive"]
    window = reference["large_worker_window"].copy()
    recomputed = dict(window, start=raw["start"], end=raw["end"], groups=checked["returnedGroups"],
        weighted_requests=checked["estimatedRequests"], weighted_errors=checked["reportedErrors"],
        weighted_cpu_us=sum(row["sum"]["cpuTimeUs"] for row in rows),
        sample_intervals=checked["sampleIntervals"], maximum_sampled_cpu_us=max(row["max"]["cpuTime"] for row in rows),
        maximum_sampled_wall_us=max(row["max"]["wallTime"] for row in rows),
        maximum_sampled_memory_bytes=checked["maximumSampledMemoryBytes"],
        earliest_group=min(row["dimensions"]["datetime"] for row in rows),
        latest_group=max(row["dimensions"]["datetime"] for row in rows))
    equal(recomputed, window, "archive adaptive metrics")
    old, new = read_json(results / "frozen-implementation.json"), read_json(results / "frozen-implementation-progress.json")
    changes = {key: {"small": old[key], "large": new[key]} for key in old if old[key] != new[key]}
    equal(changes, reference["implementation_delta"], "archive source delta")
    save(output / "recomputed-archive.json", dict(values, ratios_large_over_small=ratios,
                                                   large_worker_window=recomputed, implementation_delta=changes))


def check_backup(cost, results, output):
    reference = read_json(cost / "large-backup/completed-01/analysis.json")
    calculator = load_frozen(cost / "large-backup/analyze.py")
    values = {}
    for name in ("small", "large"):
        value, _, _ = calculator["scenario"](results, name)
        expected = json.loads(json.dumps(reference[name]))
        for phase in ("cold", "warm"):
            actual = value["phases"][phase]
            saved_sql = expected["phases"][phase]["verifiedSQLFile"]
            equal(saved_sql, {"sha256": actual["sourceSnapshot"]["digest"],
                              "bytes": actual["sourceSnapshot"]["bytes"]}, "recorded SQL identity")
            if actual["verifiedSQLFile"] is not None:
                raise ValueError("Unexpected SQL body in numeric-only reconstruction")
            expected["phases"][phase]["verifiedSQLFile"] = None
            if not actual["completionGate"]["complete"] or actual["accounting"]["accountingIssues"]:
                raise ValueError(f"Incomplete or unaccounted backup receipts: {name}/{phase}")
        equal(value, expected, "backup." + name)
        values[name] = value
    equal(calculator["calibrate"](values["small"]), reference["calibration"], "small calibration")
    equal(calculator["source_evidence"](results), read_json(cost / "large-backup/completed-01/source-evidence.json"),
          "backup frozen dependencies")
    ratios = {}
    for phase in ("cold", "warm"):
        small, large = (values[name]["phases"][phase] for name in ("small", "large"))
        ratios[phase] = {key: large["accounting"]["kernel"][key] / small["accounting"]["kernel"][key]
                         for key in ("r2A", "r2B", "d1Reads", "d1Writes", "sqlMilliseconds")}
        ratios[phase].update(objects=large["manifest"]["objects"] / small["manifest"]["objects"],
            bytes=large["manifest"]["bytes"] / small["manifest"]["bytes"],
            handlerWall=large["accounting"]["raw"]["handlerWallMilliseconds"] / small["accounting"]["raw"]["handlerWallMilliseconds"])
    equal(ratios, reference["completedPhaseRatios"], "backup ratios")
    save(output / "recomputed-backup.json", dict(values, completedPhaseRatios=ratios,
         sqlBodyVerification="Unavailable: SQL bodies are intentionally omitted; recorded identities agree."))
    return values


def check_cadence(cost, backups, output):
    reference = read_json(cost / "cadence-sensitivity/projection.json")
    rates = read_json(cost / "model.json")["rates"]
    equal(reference["rates"], {
        "r2StorageGBMonth": rates["r2"]["storageGBMonth"], "r2AperMillion": rates["r2"]["classAPerMillion"],
        "r2BperMillion": rates["r2"]["classBPerMillion"], "d1ReadsPerMillion": rates["d1"]["readsPerMillion"],
        "d1WritesPerMillion": rates["d1"]["writesPerMillion"],
    }, "cadence recorded rates")
    for record in reference["inputs"]:
        path = resolve_historical(cost.parent, record["path"])
        if digest(path.read_bytes()) != record["sha256"]:
            raise ValueError("Cadence source input differs")
    calculator = load_frozen(cost / "cadence-sensitivity/calculate.py")
    fixtures = {}
    for name in ("small", "large"):
        phases = backups[name]["phases"]
        row = {"groups": phases["warm"]["manifest"]["groups"], "cadences": {}}
        for hours in (24, 12):
            projected = calculator["project"](phases["warm"], 30 * 24 // hours)
            kernel = projected["knownLengthWarmKernel"]
            projected["sqlOnlyStorageRateValueAtConstantOccupancy"] = (
                projected["sqlBytesAtConstantMeasuredSize"] / 1e9 * rates["r2"]["storageGBMonth"])
            projected["kernelOperationRateValue"] = (
                kernel["r2A"] * rates["r2"]["classAPerMillion"] + kernel["r2B"] * rates["r2"]["classBPerMillion"]
                + kernel["d1Reads"] * rates["d1"]["readsPerMillion"] + kernel["d1Writes"] * rates["d1"]["writesPerMillion"]
            ) / 1e6
            row["cadences"][str(hours)] = projected
        elapsed = phases["cold"]["wall"]["endToEndMillisecondsIncludingFailuresAndGaps"]
        row["measuredColdMillisecondsIncludingFailureAndGaps"] = elapsed
        row["illustrative12HourCadencePlusMeasuredColdHours"] = 12 + elapsed / 3600000
        fixtures[name] = row
    equal(fixtures, reference["fixtures"], "constant-dataset cadence")
    save(output / "recomputed-cadence.json", {"days": 30, "rates": reference["rates"], "fixtures": fixtures})


def check_metrics(cost, output):
    root = cost / "large-backup/metrics-01"
    reference = read_json(root / "SUMMARY.json")
    values = {}
    for phase, expected in reference["phases"].items():
        raw = checked_path(root, expected["input"]).read_bytes()
        if digest(raw) != expected["sha256"]:
            raise ValueError("Backup metric input differs")
        data = json.loads(raw)
        equal({key: data[key] for key in ("start", "end")},
              {key: expected[key] for key in ("start", "end")}, "metric window")
        value = metrics(data)
        equal(value, {key: expected[key] for key in value}, "backup adaptive metrics." + phase)
        values[phase] = value
    save(output / "recomputed-metrics.json", values)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repository", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    here = Path(__file__).resolve().parent
    repository, output = args.repository.resolve(), args.out.resolve()
    if output.exists() or output.is_relative_to(repository) or output.is_relative_to(here / "originals"):
        raise ValueError("Choose a new output directory outside the repository and original artifacts")
    recorded, manifest, dependencies = reconstruct(here, repository, output)
    cost, results = recorded / "cost-model", recorded / "drill/results"
    archive_inputs = check_measurement_inputs(recorded, cost / "large-archive/measurement-inputs.json")
    backup_inputs = check_measurement_inputs(recorded, cost / "large-backup/completed-01/measurement-inputs.json", allow_sql=True)
    check_archive(cost, results, output)
    backups = check_backup(cost, results, output)
    check_cadence(cost, backups, output)
    check_metrics(cost, output)
    summary = {
        "status": "Local numeric checks passed; no independent review or hosted replay claim",
        "originalFilesVerified": len(manifest["files"]), "smallDependencyFilesVerified": len(dependencies["files"]),
        "frozenBaseSourceFilesVerified": 77, "frozenProgressSourceFilesVerified": 77, "progressSourceChanges": 3,
        "archiveMeasurementInputs": archive_inputs, "backupMeasurementInputs": backup_inputs,
        "limitations": manifest["omittedInputs"],
        "restoreAndBenchmarkEvidence": "Not included; pending separate curation and review",
    }
    save(output / "VERIFICATION.json", summary)
    print(json.dumps({key: summary[key] for key in ("status", "originalFilesVerified", "smallDependencyFilesVerified")}, indent=2))


if __name__ == "__main__":
    main()
