import {createHash} from 'node:crypto';
import {issueIngestCapability,verifyIngestCapability} from './implementation-progress/packages/security/src/capabilities.ts';
import {setTimeout} from 'node:timers/promises';
import {backupDaily} from './implementation-progress/apps/web/src/operations/backups.ts';
import {parseBackupObjects,parseGroupManifest,parseGroupReference,readBackupJson} from './implementation-progress/apps/web/src/operations/backup-format.ts';
import {archiveClosedRuns,readHistoryManifest,readArchivedSection} from './implementation-progress/apps/web/src/operations/history.ts';
import {parseHistoryManifest} from './implementation-progress/apps/web/src/operations/history-format.ts';
import {copyVerifiedObject,digestStream,mapConcurrent,safeKey} from './implementation-progress/apps/web/src/operations/common.ts';
import {putBoundedStream} from './implementation-progress/apps/web/src/operations/object-stream.ts';
import {sanitizeRestoredDatabase} from './implementation-progress/apps/web/src/operations/recovery.ts';
import {prefixedStore,sourceImages,measuredDatabase} from './stores.mjs';

const maximumObjectBytes=2097152;
const maximumDatabaseBytes=536870912;
function exportAttempt(value){if(typeof value!=='string'||!/^[-a-f0-9]{36}$/u.test(value))throw new Error('Invalid export attempt.');return value;}
function stagedKey(day,attempt){if(typeof day!=='string'||!/^\d{4}-\d{2}-\d{2}$/u.test(day))throw new Error('Invalid day.');return `drill/staged-${day}-${exportAttempt(attempt)}.sql`;}
const reviewRunId='e0800000-0000-4000-8000-000000000002';
const json=(value,status=200)=>Response.json(value,{status,headers:{'cache-control':'no-store'}});
async function authorized(request,token){if(!token)return false;const values=await Promise.all([request.headers.get('authorization')??'',`Bearer ${token}`].map(value=>crypto.subtle.digest('SHA-256',new TextEncoder().encode(value))));const left=new Uint8Array(values[0]),right=new Uint8Array(values[1]);return left.reduce((value,byte,index)=>value|(byte^right[index]),0)===0;}
function bindings(env,scenario,counts,queries,target=false){
 const prefix=scenario+'/';
 const database=target?(scenario==='small'?env.TARGET_SMALL:env.TARGET_LARGE):(scenario==='small'?env.SOURCE_SMALL:env.SOURCE_LARGE);
 const overlay=prefixedStore(target?env.TARGET_IMAGES:env.OVERLAY,prefix,counts,target?'targetImages':'overlay');
 return {database:measuredDatabase(database,queries),nativeDatabase:database,images:target?overlay:sourceImages(env.CORPUS,overlay,counts),quarantine:prefixedStore(target?env.TARGET_PRIVATE:env.PRIVATE,prefix,counts,target?'targetPrivate':'private'),backups:prefixedStore(env.BACKUPS,prefix,counts,'backups')};
}
function context(stores,offset=0){return {...stores,budget:{tasksPerStep:25,objectsPerStep:1000,leaseMilliseconds:300000,maxAttempts:5,maximumObjectBytes,maximumDatabaseBytes,maximumExportEntries:100000},now:()=>Date.now()+offset,comparisons:{async send(){throw new Error('No diagnostic queue publishing.');}},github:{appId:'diagnostic',repositoryId:'diagnostic',repository:'diagnostic/diagnostic',async request(){throw new Error('No diagnostic GitHub writes.');}},origin:'https://diagnostic.invalid'};}
async function archiveState(database){const rows=await database.prepare('SELECT run_id,generation,state,page_count,progress_json FROM operations_run_archives ORDER BY run_id').all();return rows.results.map(row=>{const progress=JSON.parse(row.progress_json);return {runId:row.run_id,generation:row.generation,state:row.state,pages:row.page_count,section:progress.section??null,verifiedPages:progress.verifiedPages??0};});}
async function verifyStored(store,reference,maximum=maximumObjectBytes){const object=await store.get(reference.key);if(!object)throw new Error('Missing referenced object.');const result=await digestStream(object.body,maximum);if(result.digest!==reference.digest||result.bytes!==reference.bytes)throw new Error('Referenced bytes differ.');return result;}
async function tableFingerprint(database,table){if(!/^[a-z_]+$/u.test(table))throw new Error('Invalid table.');const columns=await database.prepare(`PRAGMA table_info(${table})`).all();if(!columns.results.length)throw new Error('Unknown table.');const key=columns.results.filter(row=>row.pk).sort((a,b)=>a.pk-b.pk).map(row=>`"${row.name}"`).join(',')||'rowid';const hash=createHash('sha256');let offset=0,count=0;while(true){const page=await database.prepare(`SELECT * FROM ${table} ORDER BY ${key} LIMIT 500 OFFSET ?`).bind(offset).all();for(const row of page.results){hash.update(JSON.stringify(row));hash.update('\n');count++;}if(page.results.length<500)break;offset+=page.results.length;}return {table,count,digest:hash.digest('hex')};}
export default {async fetch(request,env){
 if(!await authorized(request,env.DRILL_TOKEN))return json({error:'unauthorized'},401);
 const url=new URL(request.url);const scenario=url.searchParams.get('scenario');if(!['small','large'].includes(scenario))return json({error:'Invalid workload.'},400);
 const counts={},queries=[];const started=performance.now();
 const source=bindings(env,scenario,counts,queries);const target=bindings(env,scenario,counts,queries,true);
 const report=value=>json({...value,milliseconds:performance.now()-started,counts,queries,colo:request.cf?.colo??null});
 try{
  if(url.pathname==='/health')return report({diagnostic:true,scenario,secretEpoch:env.SECRET_EPOCH??'initial'});
  if(url.pathname==='/seed/object'&&request.method==='PUT'){
   const key=safeKey(url.searchParams.get('key')??'');const store=url.searchParams.get('store');if(!['private','overlay'].includes(store))throw new Error('Invalid seed destination.');
   if(store==='overlay'&&!key.startsWith('history/')&&!key.startsWith('derived/'))throw new Error('Seed cannot write original corpus keys.');
   const destination=store==='private'?source.quarantine:source.images;
   return report(await putBoundedStream(destination,key,{body:request.body},maximumObjectBytes));
  }
  if(url.pathname==='/source/verify'&&request.method==='POST'){
   const input=await request.json();if(!Array.isArray(input.objects)||input.objects.length>1000)throw new Error('Invalid verification page.');
   const values=await mapConcurrent(input.objects,6,object=>verifyStored(object.bucket==='images'?source.images:source.quarantine,object));
   return report({objects:values.length,bytes:values.reduce((sum,value)=>sum+value.bytes,0)});
  }
  if(url.pathname==='/source/summary'){
   const sample=await source.nativeDatabase.prepare('SELECT 1 AS sample').all();
   const tables=['ariviso_runs','ariviso_captures','ariviso_images','ariviso_comparison_rows','ariviso_decisions','ariviso_commands','work_tasks','ariviso_capture_profiles','operations_run_archives','operations_backup_groups'];
   const rows={};for(const table of tables)rows[table]=(await source.nativeDatabase.prepare(`SELECT COUNT(*) AS count FROM ${table}`).first()).count;
   return report({rows,physicalBytes:sample.meta.size_after,archive:await archiveState(source.database)});
  }
  if(url.pathname==='/archive/step'&&request.method==='POST'){
   const before=await archiveState(source.database);const result=await archiveClosedRuns(context(source));const after=await archiveState(source.database);
   return report({result,before,after});
  }
  if(url.pathname==='/backup/state')return report({rows:(await source.database.prepare('SELECT id,state,format_version,source_kind,page_count,required_count,object_count,image_bytes,database_key,database_digest,database_bytes,created_at,completed_at FROM operations_backups ORDER BY created_at').all()).results});
  if(url.pathname==='/backup/step'&&request.method==='POST'){
   const input=await request.json();const offset=input.offset??0;if(![0,86400000].includes(offset))throw new Error('Invalid logical day.');
   const day=new Date(Date.now()+offset).toISOString().slice(0,10);const attempt=exportAttempt(input.attempt);
   const result=await backupDaily(context(source,offset),{async export(){
    await source.backups.put(`drill/export-request-${attempt}.json`,JSON.stringify({day,attempt}),{onlyIf:{etagDoesNotMatch:'*'}});
    const until=Date.now()+240000;
    while(Date.now()<until){const staged=await source.backups.get(stagedKey(day,attempt));if(staged)return {body:staged.body,bytes:staged.size};await setTimeout(2000);}
    throw new Error('The local export controller did not stage SQL within the lease.');
   }});
   return report({result,day,row:await source.database.prepare('SELECT * FROM operations_backups WHERE id=?').bind(day).first()});
  }
  if(url.pathname==='/backup/export-request'){const attempt=exportAttempt(url.searchParams.get('attempt'));const object=await source.backups.get(`drill/export-request-${attempt}.json`);return report({request:object?await new Response(object.body).json():null});}
  if(url.pathname==='/backup/stage-abort'&&request.method==='POST'){const input=await request.json();await source.backups.resumeMultipartUpload(stagedKey(input.day,input.attempt),input.uploadId).abort();return report({aborted:true});}
  if(url.pathname==='/backup/stage-start'&&request.method==='POST'){
   const input=await request.json();if(!/^\d{4}-\d{2}-\d{2}$/u.test(input.day))throw new Error('Invalid day.');
   const upload=await source.backups.createMultipartUpload(stagedKey(input.day,input.attempt),{httpMetadata:{contentType:'application/sql'}});return report({uploadId:upload.uploadId});
  }
  if(url.pathname==='/backup/stage-part'&&request.method==='PUT'){
   const day=url.searchParams.get('day'),part=Number(url.searchParams.get('part'));if(!/^\d{4}-\d{2}-\d{2}$/u.test(day)||!Number.isInteger(part)||part<1||part>64)throw new Error('Invalid multipart part.');
   const bytes=new Uint8Array(await request.arrayBuffer());if(!bytes.length||bytes.length>8388608)throw new Error('SQL part exceeds bound.');
   const upload=source.backups.resumeMultipartUpload(stagedKey(day,url.searchParams.get('attempt')),url.searchParams.get('uploadId'));return report(await upload.uploadPart(part,bytes));
  }
  if(url.pathname==='/backup/stage-complete'&&request.method==='POST'){
   const input=await request.json();if(!/^\d{4}-\d{2}-\d{2}$/u.test(input.day)||!Array.isArray(input.parts)||input.parts.length>64)throw new Error('Invalid staged export.');
   await source.backups.resumeMultipartUpload(stagedKey(input.day,input.attempt),input.uploadId).complete(input.parts);
   const object=await source.backups.get(stagedKey(input.day,input.attempt));if(!object)throw new Error('Staged export missing.');return report(await digestStream(object.body,maximumDatabaseBytes));
  }
  if(url.pathname==='/backup/object'){
   const key=safeKey(url.searchParams.get('key')??'');if(!key.startsWith('backups/')&&!key.startsWith('backup-groups/'))throw new Error('Invalid backup namespace.');const object=await source.backups.get(key);if(!object)return json({error:'not-found'},404);return new Response(object.body,{headers:{'content-type':object.httpMetadata?.contentType??'application/octet-stream','content-length':String(object.size),'cache-control':'no-store'}});
  }
  if(url.pathname==='/benchmark/cleanup'&&request.method==='POST'){
   const input=await request.json();const id=exportAttempt(input.id);const bucket=input.store==='images'?env.TARGET_IMAGES:input.store==='private'?env.TARGET_PRIVATE:null;if(!bucket)throw new Error('Invalid benchmark bucket.');const page=await bucket.list({prefix:`benchmark/${id}/`,limit:1000});if(page.objects.length)await bucket.delete(page.objects.map(object=>object.key));return report({deleted:page.objects.length,more:page.truncated});
  }
  if(url.pathname==='/rotation/proof')return report({authSecretDigest:createHash('sha256').update(env.AUTH_SECRET).digest('hex'),ingestSecretDigest:createHash('sha256').update(env.INGEST_CAPABILITY_SECRET).digest('hex')});
  if(url.pathname==='/rotation/issue')return json({token:await issueIngestCapability({secret:env.INGEST_CAPABILITY_SECRET,issuer:'https://diagnostic.invalid',environment:'local'},{runId:'diagnostic',repositoryId:'1',workflowRunId:'1',workflowAttempt:1,testedSha:'a'.repeat(40),planDigest:'b'.repeat(64),shardKey:'diagnostic',jobId:'1',maximumBytes:1,maximumImages:1},900)});
  if(url.pathname==='/rotation/verify'&&request.method==='POST'){try{const {token}=await request.json();await verifyIngestCapability({secret:env.INGEST_CAPABILITY_SECRET,issuer:'https://diagnostic.invalid',environment:'local'},token);return json({valid:true});}catch{return json({valid:false},401);}}
  if(url.pathname==='/restore/import-state'){
   const marker=await target.database.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name='diagnostic_restore_marker'").first();
   return report({marker:marker?await target.database.prepare('SELECT digest FROM diagnostic_restore_marker LIMIT 1').first():null});
  }
  if(url.pathname==='/restore/empty'){
   const tables=(await target.database.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE '_cf_%' AND name NOT LIKE 'sqlite_%'").all()).results;
   const images=await target.images.list({limit:1}),privateObjects=await target.quarantine.list({limit:1});return report({empty:tables.length===0&&!images.objects.length&&!privateObjects.objects.length,tables});
  }
  if(url.pathname==='/restore/page'&&request.method==='POST'){
   const input=await request.json();const group=parseGroupReference(input.group);const manifest=parseGroupManifest(await readBackupJson(source.backups,group),group);
   const reference=manifest.pages[input.page];if(!reference||!Number.isInteger(input.page)||input.page<0)throw new Error('Invalid restore page.');
   const objects=parseBackupObjects(await readBackupJson(source.backups,reference),group.id,reference.objects);
   const restored=input.benchmark?{images:prefixedStore(env.TARGET_IMAGES,`benchmark/${exportAttempt(input.benchmark)}/`,counts,'benchmarkImages'),quarantine:prefixedStore(env.TARGET_PRIVATE,`benchmark/${exportAttempt(input.benchmark)}/`,counts,'benchmarkPrivate')}:target;
   await mapConcurrent(objects,6,object=>copyVerifiedObject({source:source.backups,destination:object.source==='images'?restored.images:restored.quarantine,sourceKey:object.backupKey,destinationKey:object.key,maximum:maximumObjectBytes,expectedDigest:object.digest,expectedBytes:object.bytes}));
   return report({objects:objects.length,bytes:objects.reduce((sum,object)=>sum+object.bytes,0)});
  }
  if(url.pathname==='/fingerprint'){
   const table=url.searchParams.get('table');const allowed=['ariviso_decisions','ariviso_decision_replacements','ariviso_identity_history','ariviso_reservations','ariviso_lineage_edges','ariviso_snapshots','ariviso_images','ariviso_snapshot_images','ariviso_capture_profiles','operations_run_archives','operations_comparison_archives'];if(!allowed.includes(table))throw new Error('Unsupported fingerprint table.');
   return report(await tableFingerprint(url.searchParams.get('target')==='true'?target.database:source.database,table));
  }
  if(url.pathname==='/history/root'){
   const selected=url.searchParams.get('target')==='true'?target:source;return report({archive:await readHistoryManifest(context(selected),reviewRunId)});
  }
  if(url.pathname==='/history/section'){
   const selected=url.searchParams.get('target')==='true'?target:source;const section=url.searchParams.get('section');const hash=createHash('sha256');let rows=0;
   for await(const page of readArchivedSection(context(selected),reviewRunId,section)){for(const row of page){hash.update(JSON.stringify(row));hash.update('\n');rows++;}}
   return report({section,rows,digest:hash.digest('hex')});
  }
  if(url.pathname==='/restore/references'&&request.method==='POST'){
   const input=await request.json();const after=typeof input.after==='string'?input.after:'';const kind=input.kind;let rows;
   if(kind==='originals')rows=(await target.database.prepare("SELECT object_key AS key,digest,bytes FROM ariviso_images WHERE bytes_present=1 AND object_key>? ORDER BY object_key LIMIT 1000").bind(after).all()).results;
   else if(kind==='snapshots')rows=(await target.database.prepare("SELECT copy.object_key AS key,copy.digest,image.bytes FROM ariviso_snapshot_images copy JOIN ariviso_images image ON image.id=copy.image_id WHERE copy.copied=1 AND copy.object_key>? ORDER BY copy.object_key LIMIT 1000").bind(after).all()).results;
   else if(kind==='archives'){
    rows=(await target.database.prepare("SELECT object_key AS key,digest,bytes,run_id,generation FROM operations_ready_history_archives WHERE object_key>? ORDER BY object_key LIMIT 20").bind(after).all()).results;
    for(const row of rows){const manifest=parseHistoryManifest(await readBackupJson(target.images,row),{runId:row.run_id,generation:row.generation,maximumObjectBytes});await mapConcurrent(manifest.pages,6,reference=>verifyStored(target.images,reference));}
   }else throw new Error('Invalid reference kind.');
   await mapConcurrent(rows,6,row=>verifyStored(target.images,row));return report({kind,objects:rows.length,bytes:rows.reduce((sum,row)=>sum+row.bytes,0),after:rows.at(-1)?.key??after,done:rows.length<(kind==='archives'?20:1000)});
  }
  if(url.pathname==='/restore/sanitize'&&request.method==='POST'){await sanitizeRestoredDatabase(target.database,Date.now());return report({sanitized:true});}
  if(url.pathname==='/restore/report'){
   const foreignKeys=(await target.database.prepare('PRAGMA foreign_key_check').all()).results;
   const sessions=await target.database.prepare('SELECT COUNT(*) AS count FROM session').first();const tokens=await target.database.prepare('SELECT COUNT(*) AS count FROM account WHERE accessToken IS NOT NULL OR refreshToken IS NOT NULL OR idToken IS NOT NULL').first();const active=await target.database.prepare('SELECT COUNT(*) AS count FROM ariviso_runs WHERE active!=0').first();return report({foreignKeys,sessions:sessions.count,tokens:tokens.count,active:active.count,archives:await archiveState(target.database)});
  }
  throw new Error('Unknown diagnostic operation.');
 }catch(error){return json({error:String(error),milliseconds:performance.now()-started,counts,queries},500);}
}};
