#!/usr/bin/env python3
"""Read local v3 backup receipts; never contact a service or modify prior evidence."""
import argparse
import hashlib
import json
import math
from collections import Counter, defaultdict
from datetime import datetime
from pathlib import Path

HERE = Path(__file__).resolve().parent
DEFAULT_RESULTS = Path('/tmp/ariviso-v3-drill/tooling/v3/results')
INSPECTION = 'SELECT * FROM operations_backups WHERE id=?'
JSON_SNAPSHOTS = {}
PREFIXES = {
    'claim': 'UPDATE operations_backups SET lease_token=?,lease_until=?',
    'inventory': 'INSERT INTO operations_backup_group_pages(',
    'cursor': 'UPDATE operations_backup_groups SET cursor=?,page_count=page_count+?',
    'group_ready': "UPDATE operations_backup_groups SET state='ready',manifest_key=",
    'membership': 'INSERT INTO operations_backup_pages(',
    'membership_cursor': 'UPDATE operations_backups SET cursor=?,source_kind=?,completed_at=',
    'pin': 'INSERT INTO work_retention_pins(run_id,owner,reason) SELECT id,',
    'event': 'INSERT INTO operations_events(',
    'failures': 'UPDATE operations_backups SET failures=failures+1,',
    'resolve': 'UPDATE operations_events SET resolved_at=',
}


def file_digest(path):
    digest = hashlib.sha256()
    size = 0
    with path.open('rb') as source:
        for chunk in iter(lambda: source.read(1024 * 1024), b''):
            digest.update(chunk)
            size += len(chunk)
    return {'sha256': digest.hexdigest(), 'bytes': size}


def load(path):
    path = path.resolve()
    if path not in JSON_SNAPSHOTS:
        JSON_SNAPSHOTS[path] = path.read_bytes() if path.exists() else None
    raw = JSON_SNAPSHOTS[path]
    return json.loads(raw) if raw is not None else None


def timestamp(value):
    return round(datetime.fromisoformat(value.replace('Z', '+00:00')).timestamp() * 1000)


def read_lines(path, phases):
    values, raw, incomplete = [], [], 0
    if not path.exists():
        return values, b'', incomplete
    with path.open('rb') as source:
        for line in source:
            if not line.strip():
                continue
            try:
                value = json.loads(line)
            except json.JSONDecodeError:
                if not line.endswith(b'\n'):
                    incomplete += 1
                    continue
                raise
            if value.get('phase') in phases:
                values.append(value)
                raw.append(line if line.endswith(b'\n') else line + b'\n')
    return values, b''.join(raw), incomplete


def usage(counts):
    return {
        'r2A': sum(v for k, v in counts.items() if k.split('.')[-1] in ('put', 'list', 'createMultipartUpload', 'uploadPart', 'complete')),
        'r2B': sum(v for k, v in counts.items() if k.split('.')[-1] in ('get', 'head')),
    }


def aggregate(events):
    counts, total, inspections = Counter(), Counter(), Counter()
    queries = defaultdict(Counter)
    handshake = []
    issues = []
    for event in events:
        counts.update(event.get('counts', {}))
        total['invocations'] += 1
        total['handlerWallMilliseconds'] += event.get('milliseconds', 0)
        statement_list = event.get('queries', [])
        for index, query in enumerate(statement_list):
            meta = query.get('meta') or {}
            values = dict(queries=1, d1Reads=meta.get('rows_read', 0), d1Writes=meta.get('rows_written', 0),
                          sqlMilliseconds=meta.get('timings', {}).get('sql_duration_ms', meta.get('duration', 0)),
                          reportedInternalAttempts=meta.get('total_attempts', 1), changes=meta.get('changes', 0))
            total.update(values)
            queries[query['sql']].update(values)
            if index == len(statement_list) - 1 and query['sql'] == INSPECTION:
                inspections.update(values)
        if event.get('step') != 'request-failure' and (not statement_list or statement_list[-1]['sql'] != INSPECTION):
            issues.append(f"Endpoint inspection not identified for step {event.get('step')!r}.")
        if event.get('step') == 'request-failure' and not statement_list:
            issues.append('A request failure lacks returned D1 counters; recorded work is a lower bound.')
        if event.get('step') == 'export':
            source = event.get('counts', {})
            if source.get('backups.put', 0) < 2 or source.get('backups.get', 0) < 2 or not event.get('row', {}).get('database_digest'):
                issues.append('Export handshake cannot be separated using the verified one-marker/one-readback path.')
                continue
            handshake.append({
                'at': event['at'], 'handlerWallMilliseconds': event.get('milliseconds', 0),
                'removeExportRequestMarkerPuts': 1,
                'removeStagingPollAndSourceGets': source['backups.get'] - 1,
                'retainProductionSQLReadbackGets': 1,
                'rawCounts': source,
            })
    raw_usage = {**usage(counts), **{k: total[k] for k in ('d1Reads', 'd1Writes')}}
    removal = dict(r2A=sum(h['removeExportRequestMarkerPuts'] for h in handshake),
                   r2B=sum(h['removeStagingPollAndSourceGets'] for h in handshake),
                   d1Reads=inspections['d1Reads'], d1Writes=inspections['d1Writes'])
    kernel = {k: raw_usage[k] - removal[k] for k in raw_usage}
    kernel.update(queries=total['queries'] - inspections['queries'],
                  sqlMilliseconds=total['sqlMilliseconds'] - inspections['sqlMilliseconds'])
    return dict(rawCounts=counts, raw=total, rawUsage=raw_usage, identifiedHarnessRemoval=removal,
                rowInspection=inspections, exportHandshakes=handshake, kernel=kernel,
                accountingIssues=issues, queryPrefixes=[dict(sql=k, **v) for k, v in queries.items()])


def selected_query_total(aggregated, prefix):
    return sum((Counter({k: v for k, v in query.items() if k != 'sql'})
                for query in aggregated['queryPrefixes'] if query['sql'].startswith(prefix)), Counter())


def completion(events, summary, manifest, attempts):
    missing = []
    if not summary or not isinstance(summary.get('completedAt'), int):
        missing.append('completed phase summary')
    if not manifest or manifest.get('version') != 3:
        missing.append('version 3 completed backup manifest')
    if summary and manifest and summary.get('manifest') != manifest:
        missing.append('matching summary and separately saved manifest')
    final = events[-1] if events else None
    if not final or final.get('row', {}).get('state') != 'complete' or not final.get('result', {}).get('completed'):
        missing.append('final complete-state event and completion report')
    if not attempts or attempts[-1].get('exitCode') != 0:
        missing.append('successful final phase-command exit receipt')
    elif summary and attempts[-1]['completedAt'] < summary.get('completedAt', math.inf):
        missing.append('phase exit after the saved completion summary')
    if final and manifest:
        row = final.get('row') or {}
        if manifest['id'] not in final.get('result', {}).get('completed', []) or row.get('id') != manifest['id']:
            missing.append('matching backup identity at completion')
    return dict(complete=not missing, missing=missing)


def write_equation(params):
    return (21 + 3 * params['L'] + 5 * params['G'] + 6 * params['Q'] + 2 * params['S']
            + 3 * params['E'] + 19 * params['Gc'] + 5 * params['I'] + 3 * params['X'])


def phase(directory, name, events, attempts, archive):
    checkpoint = load(directory / f'{name}-checkpoint.json')
    summary = load(directory / f'{name}-summary.json')
    manifest = load(directory / f'{name}-backup-manifest.json')
    staging = load(directory / f'{name}-staging.json')
    snapshot = load(directory / f'{name}-source-snapshot.json')
    aggregated = aggregate(events)
    gate = completion(events, summary, manifest, attempts)
    sequence = [e['step'] for e in events if isinstance(e.get('step'), int)]
    if sequence and sequence != list(range(1, max(sequence) + 1)):
        aggregated['accountingIssues'].append('Numeric step receipts have gaps or duplicates; all receipts are retained.')
    if gate['complete'] and summary.get('steps') != len(sequence):
        aggregated['accountingIssues'].append('Completed summary step count differs from the numeric event ledger.')
    start_values = [a['startedAt'] for a in attempts]
    if checkpoint:
        start_values.append(checkpoint['startedAt'])
    start = min(start_values) if start_values else None
    last_at = timestamp(events[-1]['at']) if events else None
    end = attempts[-1]['completedAt'] if gate['complete'] else last_at
    wall = {
        'originalControllerStartedAt': start,
        'preservedCheckpointStartedAt': checkpoint.get('startedAt') if checkpoint else None,
        'observedThrough': end,
        'endToEndMillisecondsIncludingFailuresAndGaps': end - start if end is not None and start is not None else None,
        'summaryMillisecondsFromOriginalCheckpoint': summary['completedAt'] - summary['startedAt'] if summary else None,
        'sumClosedCommandAttemptMilliseconds': sum(a['completedAt'] - a['startedAt'] for a in attempts),
        'commandAttempts': attempts,
        'handlerWallMillisecondsSumIncludingFailures': aggregated['raw']['handlerWallMilliseconds'],
        'note': 'Handler wall includes the diagnostic export handshake and is not Worker CPU. Pending phases can lack the open command attempt receipt. No pause or failure time is removed.',
    }
    failed = []
    for index, event in enumerate(events):
        if not event.get('result', {}).get('attention') and not event.get('error') and event.get('step') != 'request-failure':
            continue
        next_event = next((e for e in events[index + 1:] if isinstance(e.get('step'), int)), None)
        value = dict(step=event.get('step'), at=event['at'], row=event.get('row'), observed=aggregate([event]))
        if next_event:
            value['nextRecordedNumericStep'] = dict(step=next_event['step'], at=next_event['at'], row=next_event.get('row'), observed=aggregate([next_event]))
            value['receiptGapMilliseconds'] = timestamp(next_event['at']) - timestamp(event['at'])
            value['sameActiveGroup'] = event.get('row', {}).get('active_group_id') == next_event.get('row', {}).get('active_group_id')
            prior = next((e for e in reversed(events[:index])
                          if isinstance(e.get('step'), int) and not e.get('result', {}).get('attention')
                          and e.get('row', {}).get('active_group_id') == event.get('row', {}).get('active_group_id')
                          and e.get('counts', {}).get('corpus.get') == next_event.get('counts', {}).get('corpus.get')
                          and any(q['sql'].startswith(PREFIXES['inventory']) for q in e.get('queries', []))), None)
            if prior and value['sameActiveGroup'] and any(q['sql'].startswith(PREFIXES['inventory']) for q in next_event.get('queries', [])):
                pair = Counter(event.get('counts', {})) + Counter(next_event.get('counts', {}))
                actual, baseline = usage(pair), usage(prior.get('counts', {}))
                value['priorSuccessfulPageComparison'] = dict(priorStep=prior['step'], priorCounts=prior['counts'],
                    failedPlusResumedCounts=pair, classAApiDifference=actual['r2A'] - baseline['r2A'],
                    classBApiDifference=actual['r2B'] - baseline['r2B'],
                    scope='Comparison with the prior successful source page having the same corpus GET count and active group. It is not a billed-meter delta or proof of the failure cause.')
        failed.append(value)
    source_sql = None
    sql_path = directory / f'{name}-source.sql'
    if snapshot and sql_path.exists():
        source_sql = file_digest(sql_path)
        if source_sql['sha256'] != snapshot['digest'] or source_sql['bytes'] != snapshot['bytes']:
            aggregated['accountingIssues'].append('Actual source SQL differs from its saved digest/size receipt.')
    if manifest and snapshot and (manifest['database']['digest'] != snapshot['digest'] or manifest['database']['bytes'] != snapshot['bytes']):
        aggregated['accountingIssues'].append('Manifest SQL identity differs from the source snapshot.')
    if staging and snapshot and (staging['digest'] != snapshot['digest'] or staging['bytes'] != snapshot['bytes']):
        aggregated['accountingIssues'].append('Staged SQL identity differs from the source snapshot.')
    outside = {
        'staging': {
            'recordedParts': staging['parts'],
            'classAForRecordedAttempt': staging['parts'] + 2,
            'classBStageVerification': 1,
            'completeReceipt': staging,
            'note': 'Multipart create + each uploadPart + complete, plus staged-object digest GET; outside backup-step events. Earlier overwritten staging attempts, if any, are not reconstructed.',
        } if staging else None,
        'completedManifestGetMinimum': 1 if manifest else 0,
        'unrecordedExportRequestPollGets': True,
        'unrecordedBackupStateQueriesPerControllerAttempt': True,
        'failedSourceVerification': load(directory / 'failed-page-source-verification.json') if name == 'cold' else None,
        'failedPageGroupQuery': load(directory / 'failed-page-group-query-corrected.json') if name == 'cold' else None,
        'failedPageErroneousQueryReceipt': load(directory / 'failed-page-group-query.json') if name == 'cold' else None,
    }
    formulas = None
    if gate['complete']:
        q = {key: selected_query_total(aggregated, prefix) for key, prefix in PREFIXES.items()}
        params = dict(L=q['pin']['d1Writes'] / 2, G=manifest['groups'], Q=q['membership']['queries'],
                      S=q['claim']['queries'], E=q['membership_cursor']['queries'] - q['membership']['queries'],
                      Gc=q['group_ready']['queries'], I=q['inventory']['queries'], X=q['cursor']['queries'] - q['inventory']['queries'])
        extra = {key: q[key]['d1Writes'] for key in ('event', 'failures', 'resolve')}
        clean_writes = write_equation(params)
        formulas = dict(parameters=params, successfulPathWriteEquation='21 + 3L + 5G + 6Q + 2S + 3E + 19Gc + 5I + 3X',
                        successfulPathWrites=clean_writes, separatelyObservedFailureAndResolutionWrites=extra,
                        expectedWithObservedFailureWrites=clean_writes + sum(extra.values()),
                        writeResidual=aggregated['kernel']['d1Writes'] - clean_writes - sum(extra.values()),
                        parameterNote='S includes every recorded lease attempt, including failed steps. Gc/I/X reflect successful group/inventory/cursor saves. L uses the two successful pin queries on this frozen path.')
        if params['Q'] != len(manifest['pages']):
            aggregated['accountingIssues'].append('Membership query count differs from final manifest pages.')
        new_objects = manifest['objects'] if params['Gc'] == params['G'] else 0 if params['Gc'] == 0 else None
        traversal = None
        if new_objects == 0:
            traversal = 0
        elif archive:
            pages = archive['archive']['manifest']['pages']
            images = [p for p in pages if p['section'] == 'images']
            traversal = 2 * len(images) + math.ceil((len(pages) + 1) / 1000)
        if new_objects is not None and traversal is not None:
            expected_a = new_objects + params['I'] + params['Gc'] + params['Q'] + 2
            expected_b = 3 * new_objects + params['I'] + params['Gc'] + params['Q'] + 2 + traversal
            formulas['r2SuccessfulPath'] = dict(newObjectEntries=new_objects, traversalGets=traversal,
                traversalScope='Only the measured single-archive, no-derived-object fixture; 2 × archived image pages plus archive membership traversal. Not a general workload formula.',
                classA=expected_a, classB=expected_b,
                classAEquation='Nnew + I + Gc + Q + 2', classBEquation='3Nnew + I + Gc + Q + 2 + H',
                recordedClassAResidual=aggregated['kernel']['r2A'] - expected_a,
                recordedClassBResidual=aggregated['kernel']['r2B'] - expected_b,
                residualMeaning='Retained retry/partial work or unmodeled source operations. These residuals are reported, never subtracted from the observed kernel.')
        else:
            formulas['r2SuccessfulPath'] = {'unavailable': 'Mixed reused/new groups require their separate inventory receipts to identify Nnew and H.'}
    return dict(status='complete-receipts-present' if gate['complete'] else 'incomplete' if events else 'not-started',
                completionGate=gate, accounting=aggregated, wall=wall, failures=failed, checkpoint=checkpoint,
                summary=summary, manifest=manifest, sourceSnapshot=snapshot, verifiedSQLFile=source_sql,
                outsideEventLedger=outside, formulas=formulas)


def scenario(results, name):
    directory = results / name
    events, raw, partial = read_lines(directory / 'events.jsonl', {'cold', 'warm'})
    attempts, timings_raw, timing_partial = read_lines(directory / 'phase-timings.jsonl', {'cold', 'warm'})
    archive = load(directory / 'archive-root.json')
    phases = {kind: phase(directory, kind, [e for e in events if e['phase'] == kind],
                          [a for a in attempts if a['phase'] == kind], archive) for kind in ('cold', 'warm')}
    return dict(scenario=name, phases=phases, ignoredIncompleteTrailingEventLines=partial,
                ignoredIncompleteTrailingTimingLines=timing_partial), raw, timings_raw


def source_evidence(results):
    evidence = {}
    for name in ('frozen-implementation.json', 'frozen-implementation-progress.json'):
        path = results / name
        mapping = load(path)
        folder = results.parent / ('implementation-progress' if 'progress' in name else 'implementation')
        relevant = {key: value for key, value in (mapping or {}).items()
                    if key.endswith(('/backups.ts', '/backup-groups.ts', '/backup-format.ts', '/common.ts', '/object-stream.ts', '/0011_backup_groups.sql'))}
        if len(relevant) != 6:
            raise ValueError(f'{path}: expected six frozen backup/schema dependencies, found {len(relevant)}')
        verified = {key: file_digest(folder / key)['sha256'] == value for key, value in relevant.items()}
        evidence[name] = dict(file=file_digest(path), relevantHashes=relevant, verifiedAgainstStoredSource=verified)
    return evidence


def calibrate(small):
    expected = {'cold': dict(r2A=7561, r2B=22714, d1Reads=18903, d1Writes=530),
                'warm': dict(r2A=3, r2B=3, d1Reads=220, d1Writes=76)}
    for name, units in expected.items():
        value = small['phases'][name]
        assert value['completionGate']['complete'], name
        assert not value['accounting']['accountingIssues'], value['accounting']['accountingIssues']
        assert {k: value['accounting']['kernel'][k] for k in units} == units, name
        assert value['formulas']['writeResidual'] == 0, name
        assert value['formulas']['r2SuccessfulPath']['recordedClassAResidual'] == 0, name
        assert value['formulas']['r2SuccessfulPath']['recordedClassBResidual'] == 0, name
    return {'status': 'passed', 'exactSmallKernelUnits': expected}


def render(report):
    lines = ['# Large v3 backup receipt analysis', '', report['status'], '',
             'This report counts returned diagnostic API receipts. It does not measure billed account meters, admission, sustained workload capacity, hosted RTO, or a monthly workload mean.', '',
             'All failed steps, retry work and original elapsed time remain in the totals. Only identified export-marker/staging-source calls and final endpoint inspection queries are removed from the application kernel.', '']
    for phase_name in ('cold', 'warm'):
        value = report['large']['phases'][phase_name]
        small = report['small']['phases'][phase_name]
        ledger = value['accounting']
        lines += [f'## {phase_name.capitalize()}: {value["status"]}', '']
        if not value['completionGate']['complete']:
            lines += ['Completion is not established. Missing: ' + '; '.join(value['completionGate']['missing']) + '.', '']
        lines += ['| Recorded unit | Small completed kernel | Large raw to date | Removed harness | Large kernel to date |', '| --- | ---: | ---: | ---: | ---: |']
        for unit in ('r2A', 'r2B', 'd1Reads', 'd1Writes'):
            lines.append(f'| {unit} | {small["accounting"]["kernel"][unit]:,} | {ledger["rawUsage"][unit]:,} | {ledger["identifiedHarnessRemoval"][unit]:,} | {ledger["kernel"][unit]:,} |')
        lines += ['', f'Recorded handler wall: {ledger["raw"]["handlerWallMilliseconds"] / 1000:,.3f} seconds. Application SQL: {ledger["kernel"]["sqlMilliseconds"] / 1000:,.6f} seconds. These are not CPU.', '',
                  'The export handshake itemization keeps the production SQL PUT and readback, removes one diagnostic request-marker PUT, and removes staged-source/poll GETs. All handler wall remains; production latency cannot be recovered by subtracting the handshake duration.', '']
        for handshake in ledger['exportHandshakes']:
            lines.append(f'- Export at {handshake["at"]}: remove {handshake["removeExportRequestMarkerPuts"]} marker PUT and {handshake["removeStagingPollAndSourceGets"]} staging/poll GETs; retain {handshake["retainProductionSQLReadbackGets"]} SQL readback GET. Full handler time {handshake["handlerWallMilliseconds"] / 1000:.3f} seconds.')
        lines += ['', f'Endpoint inspection removal: {ledger["rowInspection"]["queries"]:,} queries, {ledger["rowInspection"]["d1Reads"]:,} reads, and {ledger["rowInspection"]["sqlMilliseconds"] / 1000:.6f} seconds of SQL.', '',
                  'Original wall and all closed command attempts:', '', '```json', json.dumps(value['wall'], indent=2), '```', '']
        if value['failures']:
            lines += ['Failure and next recorded retry:', '']
            for failure in value['failures']:
                retry = failure.get('nextRecordedNumericStep')
                lines.append(f'- Step {failure["step"]} at {failure["at"]}: {json.dumps(failure["observed"]["rawCounts"])}.')
                if retry:
                    lines.append(f'- Next numeric step {retry["step"]} at {retry["at"]}: {json.dumps(retry["observed"]["rawCounts"])}. Receipt gap {failure["receiptGapMilliseconds"] / 1000:.3f} seconds; same active group: {failure["sameActiveGroup"]}. The gap includes control/network time and is not removed.')
                if failure.get('priorSuccessfulPageComparison'):
                    comparison = failure['priorSuccessfulPageComparison']
                    lines.append(f'- Compared with successful step {comparison["priorStep"]} of the same corpus page size, failure plus resume adds {comparison["classAApiDifference"]:,} Class A API calls and {comparison["classBApiDifference"]:,} Class B API calls. This is a receipt comparison, not a billed-meter delta or failure-cause finding.')
            lines += ['']
        if value['formulas']:
            lines += ['Completed-phase equations and recorded residuals:', '', '```json', json.dumps(value['formulas'], indent=2), '```', '']
            ratios = report['completedPhaseRatios'].get(phase_name)
            lines += ['Large/small ratios for these two specific fixtures only:', '', '```json', json.dumps(ratios, indent=2), '```', '']
        else:
            lines += ['No completed-phase scaling or full-run formula is asserted while this phase is unfinished.', '']
        lines += ['Outside the event ledger: multipart staging create/parts/complete and its verification GET, the final manifest GET, controller export-request polling and backup-state queries. The retained source-verification and diagnostic-query receipts are itemized separately in analysis.json; they are not deducted from the backup kernel.', '']
        if ledger['accountingIssues']:
            lines += ['Accounting issues: ' + '; '.join(ledger['accountingIssues']), '']
    lines += ['## Interpretation and limits', '',
              'API counters increment before R2 calls and therefore include attempted calls that can fail. D1 wrappers retain counters only for returned results; thrown queries can lack receipts. D1 rows_written already includes reported index work. Do not multiply it by index counts again. Internal D1 retry metadata is recorded separately and does not establish extra billed rows beyond the returned metrics.', '',
              'The successful-path write equation is `21 + 3L + 5G + 6Q + 2S + 3E + 19Gc + 5I + 3X`: live pinned runs L, all groups G, membership pages Q, recorded lease attempts S, empty membership pages E, newly completed groups Gc, inventory pages I, and empty source pages X. Failure-event, failure-counter and resolution writes are added from their exact receipts. Residuals are displayed, not discarded.', '',
              'R2 successful-path formulas use `A = Nnew + I + Gc + Q + 2` and `B = 3Nnew + I + Gc + Q + 2 + H`. They apply only when copied-object count Nnew and traversal H are established for the measured group shape. Retries remain in the observed total. Reused groups need no object recopy, while each new daily snapshot still saves SQL, membership and the completed root.', '',
              'The two-run fixtures inherit candidate originals and contain one protected baseline plus a fixed review-history shape. Do not extrapolate a fixture object mean or monthly capacity. Future restoration inputs must keep fresh originals, derived artifacts, every protected snapshot copy (including older snapshots held by review references), pinned run/comparison history, acceptance metadata, and SQL roots as explicit variables. Current plus rollback is not a safe general upper bound on retained copies. The separate 774 × 3,582 SQL-only ownership fixture omits these copies, archives and acceptance.', '',
              'The warm backup uses a logical +86,400,000 ms clock offset on the same physical day. It proves reuse under that simulated next-day identity; it is not an observed 24-hour schedule interval. Keep snapshot cadence an explicit cost/recovery input.', '',
              'Strict 24-hour RPO remains unproven. The frozen implementation uses one immutable daily backup ID and takes its SQL snapshot before object copying. While the next daily copy is unfinished, the latest completed recovery point can exceed 24 hours. Keep snapshot cadence and copy duration explicit in recovery and cost models; daily completion alone does not establish a strict 24-hour bound.', '',
              'This analyzer selects no launch cap. A completion receipt is evidence that the diagnostic phase exited successfully, not a launch approval. See source-evidence.json and measurement-inputs.json for frozen source/root/SQL/event identities.', '']
    return '\n'.join(lines)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--results', type=Path, default=DEFAULT_RESULTS)
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--require-complete', action='store_true')
    args = parser.parse_args()
    destination = args.out.resolve()
    if not destination.is_relative_to(HERE) or destination == HERE:
        raise SystemExit('Output must be a NEW child directory of large-backup.')
    if destination.exists():
        raise SystemExit('Output directory already exists; choose a new version to preserve evidence.')
    preserved = load(HERE / 'preserved-hashes.json')
    assert all(file_digest(HERE.parent / name)['sha256'] == sha for name, sha in preserved.items())
    small, small_events, small_timings = scenario(args.results, 'small')
    calibration = calibrate(small)
    large, large_events, large_timings = scenario(args.results, 'large')
    complete = all(v['completionGate']['complete'] for v in large['phases'].values())
    if args.require_complete and not complete:
        print(json.dumps({'status': 'incomplete; no output directory created', 'missing': {k: v['completionGate']['missing'] for k, v in large['phases'].items()}}, indent=2))
        return 2
    ratios = {}
    for name, value in large['phases'].items():
        if value['completionGate']['complete']:
            baseline = small['phases'][name]
            ratios[name] = {key: value['accounting']['kernel'][key] / baseline['accounting']['kernel'][key] for key in ('r2A', 'r2B', 'd1Reads', 'd1Writes', 'sqlMilliseconds')}
            ratios[name].update(objects=value['manifest']['objects'] / baseline['manifest']['objects'],
                                bytes=value['manifest']['bytes'] / baseline['manifest']['bytes'],
                                handlerWall=value['accounting']['raw']['handlerWallMilliseconds'] / baseline['accounting']['raw']['handlerWallMilliseconds'])
    report = dict(status='Both diagnostic phases have complete receipts; no launch or billing claim.' if complete else 'INCOMPLETE LARGE BACKUP SNAPSHOT; NO COMPLETION/PASS CLAIM.',
                  calibration=calibration, small=small, large=large, completedPhaseRatios=ratios)
    sources = source_evidence(args.results)
    assert all(all(v['verifiedAgainstStoredSource'].values()) for v in sources.values())
    destination.mkdir()
    for name, value in {'small-events.jsonl': small_events, 'large-events.jsonl': large_events, 'small-phase-timings.jsonl': small_timings, 'large-phase-timings.jsonl': large_timings}.items():
        (destination / name).write_bytes(value)
    for name, value in {'analysis.json': report, 'source-evidence.json': sources}.items():
        (destination / name).write_text(json.dumps(value, indent=2) + '\n')
    (destination / 'REPORT.md').write_text(render(report))
    inputs = {}
    for scenario_name in ('small', 'large'):
        for phase_name in ('cold', 'warm'):
            sql = report[scenario_name]['phases'][phase_name]['verifiedSQLFile']
            if sql: inputs[str(args.results / scenario_name / f'{phase_name}-source.sql')] = sql
    for path, raw in JSON_SNAPSHOTS.items():
        if raw is None:
            continue
        relative = path.relative_to(args.results.resolve()) if path.is_relative_to(args.results.resolve()) else Path('preserved-hashes.json')
        copy = destination / 'received-json' / relative
        copy.parent.mkdir(parents=True, exist_ok=True)
        copy.write_bytes(raw)
        inputs[str(path)] = dict(sha256=hashlib.sha256(raw).hexdigest(), bytes=len(raw), exactInputSnapshot=str(copy))
    for name in ('run.mjs', 'phases.mjs', 'worker.mjs', 'worker-progress.mjs', 'stores.mjs'):
        path = args.results.parent / name
        inputs[str(path)] = file_digest(path)
    for path in destination.glob('*.jsonl'):
        inputs[str(path)] = file_digest(path)
    (destination / 'measurement-inputs.json').write_text(json.dumps(inputs, indent=2) + '\n')
    assert all(file_digest(HERE.parent / name)['sha256'] == sha for name, sha in preserved.items())
    print(json.dumps({'output': str(destination), 'status': report['status'], 'smallCalibration': calibration,
                      'largeStatus': {k: v['status'] for k, v in large['phases'].items()}, 'preservedFiles': len(preserved)}, indent=2))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
