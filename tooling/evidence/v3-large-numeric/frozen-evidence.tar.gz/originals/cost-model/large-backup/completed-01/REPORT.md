# Large v3 backup receipt analysis

Both diagnostic phases have complete receipts; no launch or billing claim.

This report counts returned diagnostic API receipts. It does not measure billed account meters, admission, sustained workload capacity, hosted RTO, or a monthly workload mean.

All failed steps, retry work and original elapsed time remain in the totals. Only identified export-marker/staging-source calls and final endpoint inspection queries are removed from the application kernel.

## Cold: complete-receipts-present

| Recorded unit | Small completed kernel | Large raw to date | Removed harness | Large kernel to date |
| --- | ---: | ---: | ---: | ---: |
| r2A | 7,561 | 75,284 | 1 | 75,283 |
| r2B | 22,714 | 229,443 | 49 | 229,394 |
| d1Reads | 18,903 | 186,959 | 523 | 186,436 |
| d1Writes | 530 | 2,940 | 0 | 2,940 |

Recorded handler wall: 4,872.897 seconds. Application SQL: 2.022148 seconds. These are not CPU.

The export handshake itemization keeps the production SQL PUT and readback, removes one diagnostic request-marker PUT, and removes staged-source/poll GETs. All handler wall remains; production latency cannot be recovered by subtracting the handshake duration.

- Export at 2026-09-22T12:21:09.781Z: remove 1 marker PUT and 49 staging/poll GETs; retain 1 SQL readback GET. Full handler time 125.888 seconds.

Endpoint inspection removal: 523 queries, 523 reads, and 0.147978 seconds of SQL.

Original wall and all closed command attempts:

```json
{
  "originalControllerStartedAt": 1790079542923,
  "preservedCheckpointStartedAt": 1790079543324,
  "observedThrough": 1790085315582,
  "endToEndMillisecondsIncludingFailuresAndGaps": 5772659,
  "summaryMillisecondsFromOriginalCheckpoint": 5772245,
  "sumClosedCommandAttemptMilliseconds": 5506884,
  "commandAttempts": [
    {
      "scenario": "large",
      "phase": "cold",
      "startedAt": 1790079542923,
      "completedAt": 1790080486273,
      "exitCode": 1
    },
    {
      "scenario": "large",
      "phase": "cold",
      "startedAt": 1790080752048,
      "completedAt": 1790085315582,
      "exitCode": 0
    }
  ],
  "handlerWallMillisecondsSumIncludingFailures": 4872897,
  "note": "Handler wall includes the diagnostic export handshake and is not Worker CPU. Pending phases can lack the open command attempt receipt. No pause or failure time is removed."
}
```

Failure and next recorded retry:

- Step 18 at 2026-09-22T12:34:46.266Z: {"corpus.get": 1000, "backups.get": 1999, "backups.put": 999}.
- Next numeric step 19 at 2026-09-22T12:39:36.958Z: {"corpus.get": 1000, "backups.get": 2001, "backups.put": 2}. Receipt gap 290.692 seconds; same active group: True. The gap includes control/network time and is not removed.
- Compared with successful step 17 of the same corpus page size, failure plus resume adds 0 Class A API calls and 2,999 Class B API calls. This is a receipt comparison, not a billed-meter delta or failure-cause finding.

Completed-phase equations and recorded residuals:

```json
{
  "parameters": {
    "L": 2.0,
    "G": 7,
    "Q": 1,
    "S": 523,
    "E": 0,
    "Gc": 7,
    "I": 78,
    "X": 433
  },
  "successfulPathWriteEquation": "21 + 3L + 5G + 6Q + 2S + 3E + 19Gc + 5I + 3X",
  "successfulPathWrites": 2936.0,
  "separatelyObservedFailureAndResolutionWrites": {
    "event": 2,
    "failures": 1,
    "resolve": 1
  },
  "expectedWithObservedFailureWrites": 2940.0,
  "writeResidual": 0.0,
  "parameterNote": "S includes every recorded lease attempt, including failed steps. Gc/I/X reflect successful group/inventory/cursor saves. L uses the two successful pin queries on this frozen path.",
  "r2SuccessfulPath": {
    "newObjectEntries": 75195,
    "traversalGets": 722,
    "traversalScope": "Only the measured single-archive, no-derived-object fixture; 2 \u00d7 archived image pages plus archive membership traversal. Not a general workload formula.",
    "classA": 75283,
    "classB": 226395,
    "classAEquation": "Nnew + I + Gc + Q + 2",
    "classBEquation": "3Nnew + I + Gc + Q + 2 + H",
    "recordedClassAResidual": 0,
    "recordedClassBResidual": 2999,
    "residualMeaning": "Retained retry/partial work or unmodeled source operations. These residuals are reported, never subtracted from the observed kernel."
  }
}
```

Large/small ratios for these two specific fixtures only:

```json
{
  "r2A": 9.956751752413702,
  "r2B": 10.099233952628335,
  "d1Reads": 9.86277310479818,
  "d1Writes": 5.547169811320755,
  "sqlMilliseconds": 15.23027439603052,
  "objects": 9.972811671087532,
  "bytes": 10.241853499399816,
  "handlerWall": 10.964868027272114
}
```

Outside the event ledger: multipart staging create/parts/complete and its verification GET, the final manifest GET, controller export-request polling and backup-state queries. The retained source-verification and diagnostic-query receipts are itemized separately in analysis.json; they are not deducted from the backup kernel.

## Warm: complete-receipts-present

| Recorded unit | Small completed kernel | Large raw to date | Removed harness | Large kernel to date |
| --- | ---: | ---: | ---: | ---: |
| r2A | 3 | 4 | 1 | 3 |
| r2B | 3 | 48 | 45 | 3 |
| d1Reads | 220 | 224 | 4 | 220 |
| d1Writes | 76 | 76 | 0 | 76 |

Recorded handler wall: 111.415 seconds. Application SQL: 0.016241 seconds. These are not CPU.

The export handshake itemization keeps the production SQL PUT and readback, removes one diagnostic request-marker PUT, and removes staged-source/poll GETs. All handler wall remains; production latency cannot be recovered by subtracting the handshake duration.

- Export at 2026-09-22T13:57:07.344Z: remove 1 marker PUT and 45 staging/poll GETs; retain 1 SQL readback GET. Full handler time 110.521 seconds.

Endpoint inspection removal: 4 queries, 4 reads, and 0.001229 seconds of SQL.

Original wall and all closed command attempts:

```json
{
  "originalControllerStartedAt": 1790085315583,
  "preservedCheckpointStartedAt": 1790085315974,
  "observedThrough": 1790085431138,
  "endToEndMillisecondsIncludingFailuresAndGaps": 115555,
  "summaryMillisecondsFromOriginalCheckpoint": 115148,
  "sumClosedCommandAttemptMilliseconds": 115555,
  "commandAttempts": [
    {
      "scenario": "large",
      "phase": "warm",
      "startedAt": 1790085315583,
      "completedAt": 1790085431138,
      "exitCode": 0
    }
  ],
  "handlerWallMillisecondsSumIncludingFailures": 111415,
  "note": "Handler wall includes the diagnostic export handshake and is not Worker CPU. Pending phases can lack the open command attempt receipt. No pause or failure time is removed."
}
```

Completed-phase equations and recorded residuals:

```json
{
  "parameters": {
    "L": 2.0,
    "G": 7,
    "Q": 1,
    "S": 4,
    "E": 0,
    "Gc": 0,
    "I": 0,
    "X": 0
  },
  "successfulPathWriteEquation": "21 + 3L + 5G + 6Q + 2S + 3E + 19Gc + 5I + 3X",
  "successfulPathWrites": 76.0,
  "separatelyObservedFailureAndResolutionWrites": {
    "event": 0,
    "failures": 0,
    "resolve": 0
  },
  "expectedWithObservedFailureWrites": 76.0,
  "writeResidual": 0.0,
  "parameterNote": "S includes every recorded lease attempt, including failed steps. Gc/I/X reflect successful group/inventory/cursor saves. L uses the two successful pin queries on this frozen path.",
  "r2SuccessfulPath": {
    "newObjectEntries": 0,
    "traversalGets": 0,
    "traversalScope": "Only the measured single-archive, no-derived-object fixture; 2 \u00d7 archived image pages plus archive membership traversal. Not a general workload formula.",
    "classA": 3,
    "classB": 3,
    "classAEquation": "Nnew + I + Gc + Q + 2",
    "classBEquation": "3Nnew + I + Gc + Q + 2 + H",
    "recordedClassAResidual": 0,
    "recordedClassBResidual": 0,
    "residualMeaning": "Retained retry/partial work or unmodeled source operations. These residuals are reported, never subtracted from the observed kernel."
  }
}
```

Large/small ratios for these two specific fixtures only:

```json
{
  "r2A": 1.0,
  "r2B": 1.0,
  "d1Reads": 1.0,
  "d1Writes": 1.0,
  "sqlMilliseconds": 1.7028571428571417,
  "objects": 9.972811671087532,
  "bytes": 10.241853499399816,
  "handlerWall": 5.761752081501784
}
```

Outside the event ledger: multipart staging create/parts/complete and its verification GET, the final manifest GET, controller export-request polling and backup-state queries. The retained source-verification and diagnostic-query receipts are itemized separately in analysis.json; they are not deducted from the backup kernel.

## Interpretation and limits

API counters increment before R2 calls and therefore include attempted calls that can fail. D1 wrappers retain counters only for returned results; thrown queries can lack receipts. D1 rows_written already includes reported index work. Do not multiply it by index counts again. Internal D1 retry metadata is recorded separately and does not establish extra billed rows beyond the returned metrics.

The successful-path write equation is `21 + 3L + 5G + 6Q + 2S + 3E + 19Gc + 5I + 3X`: live pinned runs L, all groups G, membership pages Q, recorded lease attempts S, empty membership pages E, newly completed groups Gc, inventory pages I, and empty source pages X. Failure-event, failure-counter and resolution writes are added from their exact receipts. Residuals are displayed, not discarded.

R2 successful-path formulas use `A = Nnew + I + Gc + Q + 2` and `B = 3Nnew + I + Gc + Q + 2 + H`. They apply only when copied-object count Nnew and traversal H are established for the measured group shape. Retries remain in the observed total. Reused groups need no object recopy, while each new daily snapshot still saves SQL, membership and the completed root.

The two-run fixtures inherit candidate originals and contain one protected baseline plus a fixed review-history shape. Do not extrapolate a fixture object mean or monthly capacity. Future restoration inputs must keep fresh originals, derived artifacts, every protected snapshot copy (including older snapshots held by review references), pinned run/comparison history, acceptance metadata, and SQL roots as explicit variables. Current plus rollback is not a safe general upper bound on retained copies. The separate 774 × 3,582 SQL-only ownership fixture omits these copies, archives and acceptance.

The warm backup uses a logical +86,400,000 ms clock offset on the same physical day. It proves reuse under that simulated next-day identity; it is not an observed 24-hour schedule interval. Keep snapshot cadence an explicit cost/recovery input.

Strict 24-hour RPO remains unproven. The frozen implementation uses one immutable daily backup ID and takes its SQL snapshot before object copying. While the next daily copy is unfinished, the latest completed recovery point can exceed 24 hours. Keep snapshot cadence and copy duration explicit in recovery and cost models; daily completion alone does not establish a strict 24-hour bound.

This analyzer selects no launch cap. A completion receipt is evidence that the diagnostic phase exited successfully, not a launch approval. See source-evidence.json and measurement-inputs.json for frozen source/root/SQL/event identities.
