# Large backup analysis handoff

This directory adds local analysis for the large hosted cold and warm backup drill. It does not edit service code, call a service, or change the initial cost report or the audited large-archive report. This analyzer and the completed-01 report have local checks and a bounded independent numeric PASS. AUDIT.json records the exact reviewed files and scope.

Run this after both large phases finish:

```sh
python3 -B /tmp/ariviso-v3-cost-model/large-backup/analyze.py \
  --out /tmp/ariviso-v3-cost-model/large-backup/completed-01 \
  --require-complete
```

Use a new output name for each run. Existing output directories are refused. The command returns 2 and creates no output if either phase lacks its matching summary, version 3 manifest, final complete event, or successful phase-command exit. Use the same command without `--require-complete` to write a clearly marked partial snapshot. Read any `accountingIssues` and formula residuals before using a result; phase completion alone is not an accounting audit or launch approval.

The local test command is:

```sh
python3 -B /tmp/ariviso-v3-cost-model/large-backup/test_analyze.py
```

The analyzer first checks the hashes of 43 preserved initial and archive files. It calibrates against completed small receipts: cold Class A/B API calls 7,561/22,714, D1 reads/writes 18,903/530; warm 3/3 and 220/76. Small formula residuals must be zero. It checks the same preserved hashes again after writing results.

Each output contains `analysis.json`, `REPORT.md`, source hashes, measurement inputs, filtered event/phase-exit ledgers, and exact JSON input snapshots. Receipt files are read once per invocation so that a changing checkpoint cannot change the report after it was read. Source SQL is hashed in 1 MiB chunks. Partial trailing JSONL writes are counted and excluded. A complete malformed JSONL record is an error.

`preview-02` is a historical checked partial snapshot. `completed-01` is the reviewed completed report. It retains failed cold step 18, resumed step 19, the original start, their 290.692-second receipt gap, all failed/retry operations, and the separate 1,000-object source-verification receipt. Their combined API count exceeds the prior successful same-size page by 2,999 Class B calls and zero Class A calls. This is not a billed-meter delta or a finding about the failure cause.

Only the identified export request marker, staging/poll GETs, and last endpoint inspection query in each receipt are removed from kernel totals. The SQL object write and readback remain. Multipart staging, controller polling, final manifest retrieval, and source-verification diagnostics are separate. Unrecorded controller calls and thrown D1 queries are not assigned invented counts. Whole handler wall and original elapsed wall remain; neither is Worker CPU. This analyzer does not ingest adaptive CPU metrics.

Completed phases get group/page formulas and large/small ratios for these specific fixtures. Observed retry work remains in the totals and residuals. The completed large manifest records75,195 objects, matching the earlier external structural estimate. The analyzer takes its completed object count from that manifest.

The warm drill uses a logical +86,400,000 ms offset on the same physical day. It does not observe a real one-day schedule. Strict 24-hour RPO is unproven: the immutable daily ID and SQL snapshot before copying can leave a completed recovery point older than 24 hours during the next copy window. Keep snapshot cadence and copy duration explicit in later cost and recovery models.

No fixture object mean, sustained capacity, admission limit, full restore, or RTO claim follows from these backup receipts. Future models must keep fresh original ownership, derived objects, protected snapshot copies (including older copies retained by review references), pinned histories, archive objects, acceptance metadata, and SQL roots separate. Current plus rollback alone is not a safe upper bound. The separate 774 × 3,582 SQL-only ownership measurement omits these additional rows and bytes.
