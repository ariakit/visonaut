import copy
import importlib.util
import json
import tempfile
import unittest
from pathlib import Path

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('analyzer', HERE / 'analyze.py')
a = importlib.util.module_from_spec(spec)
spec.loader.exec_module(a)


class ReceiptTests(unittest.TestCase):
    def setUp(self):
        a.JSON_SNAPSHOTS.clear()

    def complete_inputs(self):
        manifest = {'version': 3, 'id': 'backup-1'}
        summary = {'completedAt': 100, 'manifest': manifest}
        events = [{'row': {'state': 'complete', 'id': 'backup-1'}, 'result': {'completed': ['backup-1']}}]
        attempts = [{'exitCode': 0, 'completedAt': 101}]
        return events, summary, manifest, attempts

    def test_complete_gate_requires_every_receipt(self):
        inputs = self.complete_inputs()
        self.assertTrue(a.completion(*inputs)['complete'])
        for index in range(4):
            modified = copy.deepcopy(inputs)
            modified = list(modified)
            modified[index] = [] if index in (0, 3) else None
            self.assertFalse(a.completion(*modified)['complete'])

    def test_complete_gate_rejects_wrong_identity_state_or_exit(self):
        for mutation in ('manifest', 'identity', 'state', 'exit', 'exit_before_summary'):
            events, summary, manifest, attempts = copy.deepcopy(self.complete_inputs())
            if mutation == 'manifest': summary['manifest'] = {'wrong': True}
            if mutation == 'identity': events[0]['row']['id'] = 'other'
            if mutation == 'state': events[0]['row']['state'] = 'copying'
            if mutation == 'exit': attempts[-1]['exitCode'] = 1
            if mutation == 'exit_before_summary': attempts[-1]['completedAt'] = 99
            self.assertFalse(a.completion(events, summary, manifest, attempts)['complete'], mutation)

    def test_only_final_endpoint_inspection_is_removed(self):
        queries = [{'sql': a.INSPECTION, 'meta': {'rows_read': count, 'rows_written': 0}} for count in (7, 1)]
        result = a.aggregate([{'step': 1, 'queries': queries, 'counts': {}}])
        self.assertEqual(result['rawUsage']['d1Reads'], 8)
        self.assertEqual(result['identifiedHarnessRemoval']['d1Reads'], 1)
        self.assertEqual(result['kernel']['d1Reads'], 7)
        self.assertEqual(result['kernel']['queries'], 1)

    def test_export_separation_keeps_sql_write_readback_and_wall(self):
        event = {'step': 'export', 'at': '2026-09-22T00:00:00Z', 'milliseconds': 123,
                 'row': {'database_digest': 'sha'}, 'counts': {'backups.put': 2, 'backups.get': 50},
                 'queries': [{'sql': a.INSPECTION, 'meta': {'rows_read': 1}}]}
        result = a.aggregate([event])
        self.assertEqual(result['kernel']['r2A'], 1)
        self.assertEqual(result['kernel']['r2B'], 1)
        self.assertEqual(result['raw']['handlerWallMilliseconds'], 123)
        self.assertEqual(result['identifiedHarnessRemoval']['r2B'], 49)

    def test_unmetered_failure_stays_flagged(self):
        result = a.aggregate([{'step': 'request-failure', 'counts': {'backups.get': 1}}])
        self.assertEqual(result['kernel']['r2B'], 1)
        self.assertTrue(result['accountingIssues'])

    def test_input_snapshot_does_not_change_during_analysis(self):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / 'input.json'
            path.write_text('{"steps":18}')
            self.assertEqual(a.load(path)['steps'], 18)
            path.write_text('{"steps":19}')
            self.assertEqual(a.load(path)['steps'], 18)
            self.assertEqual(json.loads(a.JSON_SNAPSHOTS[path.resolve()])['steps'], 18)

    def test_read_lines_ignores_only_partial_trailing_json(self):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / 'events.jsonl'
            path.write_bytes(b'{"phase":"cold","step":1}\n{"phase":')
            values, raw, partial = a.read_lines(path, {'cold'})
            self.assertEqual([v['step'] for v in values], [1])
            self.assertEqual(partial, 1)
            self.assertTrue(raw.endswith(b'\n'))
            path.write_bytes(b'{bad json}\n')
            with self.assertRaises(json.JSONDecodeError): a.read_lines(path, {'cold'})

    def test_completed_small_receipts_calibrate_exactly(self):
        small, _, _ = a.scenario(a.DEFAULT_RESULTS, 'small')
        self.assertEqual(a.calibrate(small)['status'], 'passed')
        self.assertEqual(small['phases']['cold']['formulas']['r2SuccessfulPath']['traversalGets'], 73)

    def test_real_failure_resume_preserve_extra_calls_and_gap(self):
        large, _, _ = a.scenario(a.DEFAULT_RESULTS, 'large')
        failures = [v for v in large['phases']['cold']['failures'] if v['step'] == 18]
        self.assertEqual(len(failures), 1)
        failure = failures[0]
        self.assertEqual(failure['nextRecordedNumericStep']['step'], 19)
        self.assertEqual(failure['receiptGapMilliseconds'], 290692)
        self.assertEqual(failure['priorSuccessfulPageComparison']['classAApiDifference'], 0)
        self.assertEqual(failure['priorSuccessfulPageComparison']['classBApiDifference'], 2999)
        self.assertEqual(large['phases']['cold']['outsideEventLedger']['failedSourceVerification']['counts']['corpus.get'], 1000)

    def test_stored_source_maps_include_all_expected_dependencies(self):
        maps = a.source_evidence(a.DEFAULT_RESULTS)
        self.assertTrue(all(len(v['relevantHashes']) == 6 for v in maps.values()))
        self.assertTrue(all(all(v['verifiedAgainstStoredSource'].values()) for v in maps.values()))


if __name__ == '__main__':
    unittest.main(verbosity=2)
