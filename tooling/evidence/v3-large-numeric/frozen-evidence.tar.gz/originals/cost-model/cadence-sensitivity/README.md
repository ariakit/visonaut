# Snapshot cadence sensitivity

This derivative keeps the measured daily-ID drill unchanged. It compares 30 and 60 successful SQL snapshots over 30 days for each **fixed, seven-group test dataset**. The 12-hour schedule uses two UTC slots per day in the later implementation. That schedule has not been exercised by this frozen drill.

```sh
python3 calculate.py
```

The calculator reads the completed cold/warm report and the previously recorded official rates. Each warm backup reused all object groups. The projection therefore multiplies SQL exports, membership writes, completion roots and warm control operations by the number of slots. It does not multiply the retained image/archive group bytes by 60. New original ownership, new protected snapshots and new archive generations still need their first backup copy.

`projection.json` contains the exact inputs, hashes and arithmetic. The calculation uses the measured warm SQL size as a constant. New backup bookkeeping, the longer slot ID, changes in application data and different numbers of groups can change that size and the D1 cost. This is a cadence sensitivity, not a full service cost forecast.

The SQL-only storage value assumes that the stated number of same-sized files is present for the entire billing interval. It uses decimal GB and the published excess rate. It excludes included account usage, billing-unit rounding, group inventories, image/archive objects, failed attempts, CPU, requests, logs, queues, database export API work and recovery. Thus it is a partial rate value, not an invoice. The first month of accumulating snapshots also has a different time-weighted occupancy.

About 60 completed sets fit a 30-day retention window at two slots per day. Exact boundaries, completion delay and collector delay can temporarily retain more. A failed or in-progress export can leave additional SQL files until the applicable collection step; these need a separate allowance. The v3 expiry wrapper does collect failed prefixes after 30 days. The projection does not assume that every slot or export attempt succeeds.

The known-length SQL stream is the path measured by these two backups. The separately measured 1,182,101,421-byte unknown-length stream used 141 multipart parts: one create, 141 part writes and one completion, or 143 A calls for the SQL object before membership/root writes. Use the actual stream mode and file size in a full model. Do not apply the three-A-call warm coefficient to an unknown-length SQL export.

The recovery-point condition is:

```text
12 hours + start delay + time to publish the complete backup <= 24 hours
```

The JSON includes 12 hours plus each measured cold elapsed time only as an illustration. The large time includes its failed page, retry and operator gap. This does not bound future delay, copy duration or contention, and does not prove a strict 24-hour RPO. The immutable SQL snapshot and all required object groups must be complete before a recovery point is usable.

Rates are from the recorded primary sources: [R2 pricing](https://developers.cloudflare.com/r2/pricing/) and [D1 pricing](https://developers.cloudflare.com/d1/platform/pricing/). Prior rate verification and account-usage limitations remain in the parent report. This derivative has local arithmetic checks and a bounded independent PASS. The review record is ../large-backup/AUDIT.json; it covers the calculations and scope, not launch readiness.
