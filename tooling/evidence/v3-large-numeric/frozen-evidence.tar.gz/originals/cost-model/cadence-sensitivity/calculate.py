"""Project snapshot cadence only; do not infer a fresh monthly workload."""
from pathlib import Path
import hashlib
import json

HERE = Path(__file__).resolve().parent
SOURCE = HERE.parent / "large-backup/completed-01/analysis.json"
RATES = HERE.parent / "model.json"


def project(warm, roots):
    if not warm["completionGate"]["complete"]:
        raise ValueError("Warm backup receipts are incomplete")
    kernel = warm["accounting"]["kernel"]
    return {
        "completedRoots": roots,
        "sqlBytesAtConstantMeasuredSize": roots * warm["manifest"]["database"]["bytes"],
        "membershipPageWrites": roots * len(warm["manifest"]["pages"]),
        "completionRootWrites": roots,
        "knownLengthWarmKernel": {
            key: roots * kernel[key]
            for key in ["r2A", "r2B", "d1Reads", "d1Writes"]
        },
        "newObjectCopyEntries": 0,
    }


def main():
    data = json.loads(SOURCE.read_text())
    rates = json.loads(RATES.read_text())["rates"]
    output = {
        "status": "Constant-dataset cadence sensitivity, not a monthly service forecast or launch pass",
        "days": 30,
        "inputs": [
            {"path": str(path), "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}
            for path in [SOURCE, RATES]
        ],
        "rates": {
            "r2StorageGBMonth": rates["r2"]["storageGBMonth"],
            "r2AperMillion": rates["r2"]["classAPerMillion"],
            "r2BperMillion": rates["r2"]["classBPerMillion"],
            "d1ReadsPerMillion": rates["d1"]["readsPerMillion"],
            "d1WritesPerMillion": rates["d1"]["writesPerMillion"],
        },
        "fixtures": {},
    }
    for name in ["small", "large"]:
        phases = data[name]["phases"]
        row = {"groups": phases["warm"]["manifest"]["groups"], "cadences": {}}
        for hours in [24, 12]:
            projection = project(phases["warm"], 30 * 24 // hours)
            kernel = projection["knownLengthWarmKernel"]
            projection["sqlOnlyStorageRateValueAtConstantOccupancy"] = (
                projection["sqlBytesAtConstantMeasuredSize"] / 1_000_000_000
                * rates["r2"]["storageGBMonth"]
            )
            projection["kernelOperationRateValue"] = (
                kernel["r2A"] * rates["r2"]["classAPerMillion"]
                + kernel["r2B"] * rates["r2"]["classBPerMillion"]
                + kernel["d1Reads"] * rates["d1"]["readsPerMillion"]
                + kernel["d1Writes"] * rates["d1"]["writesPerMillion"]
            ) / 1_000_000
            row["cadences"][str(hours)] = projection
        row["measuredColdMillisecondsIncludingFailureAndGaps"] = phases["cold"]["wall"][
            "endToEndMillisecondsIncludingFailuresAndGaps"
        ]
        row["illustrative12HourCadencePlusMeasuredColdHours"] = (
            12 + row["measuredColdMillisecondsIncludingFailureAndGaps"] / 3_600_000
        )
        output["fixtures"][name] = row
    (HERE / "projection.json").write_text(json.dumps(output, indent=2) + "\n")


if __name__ == "__main__":
    main()
