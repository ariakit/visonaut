#!/usr/bin/env python3
"""Read the completed archive phases and write only this versioned directory."""
import hashlib
import json
import math
from collections import Counter, defaultdict
from pathlib import Path

OUT = Path(__file__).resolve().parent
BASE = Path('/tmp/ariviso-v3-drill/tooling/v3/results')
INSPECTION = 'SELECT run_id,generation,state,page_count,progress_json FROM operations_run_archives ORDER BY run_id'
ELIGIBILITY = (
    'SELECT run.id FROM ariviso_runs run WHERE',
    'SELECT run.revision,project.revision AS project_revision',
    'INSERT INTO ariviso_assertions (valid) VALUES (CASE WHEN (EXISTS(SELECT 1 FROM ariviso_runs run JOIN ariviso_projects pr',
)


def read(path):
    return json.loads(path.read_text())


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2) + '\n')


def aggregate(events):
    total = Counter()
    counts = Counter()
    queries = defaultdict(Counter)
    for event in events:
        total['invocations'] += 1
        total['handler_wall_ms'] += event['milliseconds']
        counts.update(event['counts'])
        for query in event['queries']:
            meta = query.get('meta') or {}
            values = dict(queries=1, reads=meta.get('rows_read', 0), writes=meta.get('rows_written', 0),
                          sql_ms=meta.get('timings', {}).get('sql_duration_ms', meta.get('duration', 0)))
            total.update(values)
            queries[query['sql']].update(values)
    inspection = queries.get(INSPECTION, Counter())
    eligibility = sum((v for k, v in queries.items() if k.startswith(ELIGIBILITY)), Counter())
    return dict(total=total, counts=counts, inspection=inspection, eligibility=eligibility,
                application={k: total[k] - inspection[k] for k in ('queries', 'reads', 'writes', 'sql_ms')},
                query_prefixes=[dict(sql_prefix=k, **v) for k, v in sorted(queries.items(), key=lambda p: -p[1]['reads'])])


def scenario(size, captures):
    raw = b''.join(line for line in (BASE / size / 'events.jsonl').read_bytes().splitlines(keepends=True)
                   if line.strip() and json.loads(line).get('phase') == 'archive')
    snapshot = OUT / f'{size}-archive.events.jsonl'
    snapshot.write_bytes(raw)
    events = [json.loads(line) for line in raw.splitlines()]
    assert [e['step'] for e in events] == list(range(len(events)))
    assert all(not e['result']['attention'] for e in events)
    assert events[-1]['after'][0]['state'] == 'ready'
    summary = read(BASE / size / 'archive-summary.json')
    root_result = read(BASE / size / 'archive-root.json')
    root = root_result['archive']
    manifest = root['manifest']
    pages = manifest['pages']
    assert len(pages) == root['pointer']['page_count']
    assert len(events) == math.ceil(2 * len(pages) / 20) == summary['steps']
    assert manifest['counts']['captures'] == manifest['counts']['tasks'] == captures
    assert root['pointer']['bytes'] == len(json.dumps(manifest, separators=(',', ':'), ensure_ascii=False).encode())
    sections = defaultdict(Counter)
    for page in pages:
        sections[page['section']].update(pages=1, rows=page['rows'], bytes=page['bytes'])
    group = aggregate(events)
    assert group['inspection']['queries'] == group['inspection']['reads'] == 2 * len(events)
    assert group['counts']['overlay.put'] == len(pages) + 1
    assert group['counts']['overlay.get'] == 2 * len(pages) + 1
    stages = defaultdict(list)
    reread_pages = 0
    transition = None
    for event in events:
        before = (event['before'] or [{}])[0]
        after = event['after'][0]
        written = after['pages'] - before.get('pages', 0)
        verified_before = before.get('verifiedPages', 0)
        verified_after = len(pages) if after['state'] == 'ready' else after['verifiedPages']
        verified = verified_after - verified_before
        assert 0 <= written + verified <= 20
        reread_pages += verified
        kind = 'write_and_final_reread' if written and verified else 'write_only' if written else 'final_reread_only'
        stages[kind].append(event)
        if kind == 'write_and_final_reread':
            transition = dict(step=event['step'], pages_written=written, pages_reread=verified)
    assert reread_pages == len(pages)
    group.update(
        candidate_captures=captures, first_completed_at=events[0]['at'], ready_at=events[-1]['at'],
        controller_elapsed_ms=summary['completedAt'] - summary['startedAt'],
        before_rows=summary['before']['rows'], after_rows=summary['after']['rows'],
        physical_before_bytes=summary['before']['physicalBytes'], physical_after_bytes=summary['after']['physicalBytes'],
        sql_before_bytes=read(BASE / size / 'before-archive-sql.json')['bytes'],
        sql_after_bytes=read(BASE / size / 'after-archive-sql.json')['bytes'],
        root_bytes=root['pointer']['bytes'], page_count=len(pages), page_bytes=sum(p['bytes'] for p in pages),
        sections=sections, final_reread_pages=reread_pages, transition=transition,
        stages={name: aggregate(values) for name, values in stages.items()},
        outside_event_ledger={
            'before_and_after_summary_inspections': [summary['before']['queries'], summary['after']['queries']],
            'root_inspection_counts': root_result['counts'], 'root_inspection_queries': root_result['queries'],
            'warning': 'SQL export/controller polling and unlogged statistics queries are not included in application counters.'},
        archive_event_snapshot=str(snapshot), archive_event_sha256=digest(snapshot))
    group['r2_class_a_calls'] = group['counts']['overlay.put']
    group['r2_class_b_calls'] = group['counts']['overlay.get'] + group['counts']['private.get']
    group['partial_unrounded_excess_rate_usd'] = {
        'd1_reads': group['application']['reads'] / 1e6 * .001,
        'd1_writes': group['application']['writes'] / 1e6,
        'r2_class_a': group['r2_class_a_calls'] / 1e6 * 4.5,
        'r2_class_b': group['r2_class_b_calls'] / 1e6 * .36,
    }
    group['partial_unrounded_excess_rate_usd']['sum'] = sum(group['partial_unrounded_excess_rate_usd'].values())
    return group


small = scenario('small', 3582)
large = scenario('large', 35820)
old = read(BASE / 'frozen-implementation.json')
new = read(BASE / 'frozen-implementation-progress.json')
changes = {k: dict(small=old.get(k), large=new.get(k)) for k in old.keys() | new.keys() if old.get(k) != new.get(k)}
assert len(old) == len(new) == 77 and len(changes) == 3
for relative, sha in new.items():
    assert digest(BASE.parent / 'implementation-progress' / relative) == sha, relative
metrics_path = BASE / 'worker-metrics-2026-09-22T11-44-00Z.json'
metrics = read(metrics_path)
groups = metrics['result']['data']['viewer']['accounts'][0]['workersInvocationsAdaptive']
cpu = dict(source=str(metrics_path), start=metrics['start'], end=metrics['end'], groups=len(groups),
           weighted_requests=sum(g['sum']['requests'] for g in groups),
           weighted_errors=sum(g['sum']['errors'] for g in groups),
           weighted_cpu_us=sum(g['sum']['cpuTimeUs'] for g in groups),
           sample_intervals=sorted(set(g['avg']['sampleInterval'] for g in groups)),
           maximum_sampled_cpu_us=max(g['max']['cpuTime'] for g in groups),
           maximum_sampled_wall_us=max(g['max']['wallTime'] for g in groups),
           maximum_sampled_memory_bytes=max(g['max']['memoryUsageBytes'] for g in groups),
           earliest_group=min(g['dimensions']['datetime'] for g in groups),
           latest_group=max(g['dimensions']['datetime'] for g in groups),
           scope='Adaptive diagnostic Worker window, including possible before/after inspection calls; not an exact archive-only total or continuous memory peak.')
ratios = {key: large[key] / small[key] for key in ('page_count', 'root_bytes', 'page_bytes', 'controller_elapsed_ms', 'physical_before_bytes', 'physical_after_bytes', 'sql_before_bytes', 'sql_after_bytes')}
ratios.update({f'application_{key}': large['application'][key] / small['application'][key] for key in ('queries', 'reads', 'writes', 'sql_ms')})
ratios.update({f'total_{key}': large['total'][key] / small['total'][key] for key in ('invocations', 'handler_wall_ms', 'sql_ms')})
report = dict(status='LOCAL CROSS-CHECK COMPLETE; INDEPENDENT REVIEW PENDING; NOT LAUNCH READINESS',
              scope='Completed mostly unchanged, inherited-original small and large archive drills. No large backup/restore, all-changed, CLI admission, sustained capacity, or launch claim.',
              small=small, large=large, ratios_large_over_small=ratios,
              implementation_delta=changes, large_worker_window=cpu)
write('comparison.json', report)
inputs = [BASE / filename for filename in ('frozen-implementation.json', 'frozen-implementation-progress.json')]
inputs += [BASE / size / filename for size in ('small', 'large') for filename in ('archive-summary.json', 'archive-root.json', 'before-archive-sql.json', 'after-archive-sql.json')]
inputs += [metrics_path, OUT / 'small-archive.events.jsonl', OUT / 'large-archive.events.jsonl']
write('measurement-inputs.json', {str(p): digest(p) for p in inputs})
unchanged = read(OUT / 'initial-artifact-hashes.json')
assert all(digest(OUT.parent / name) == sha for name, sha in unchanged.items())
print(json.dumps(dict(large_total=large['total'], large_application=large['application'], ratios=ratios,
                     stages={k: v['total'] for k, v in large['stages'].items()}, cpu=cpu,
                     initial_artifacts_unchanged=len(unchanged)), indent=2))
