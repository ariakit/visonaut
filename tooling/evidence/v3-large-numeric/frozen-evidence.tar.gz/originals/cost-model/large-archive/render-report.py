#!/usr/bin/env python3
import json
from pathlib import Path

OUT = Path(__file__).resolve().parent
d = json.loads((OUT / 'comparison.json').read_text())
s, l, r = d['small'], d['large'], d['ratios_large_over_small']


def n(v):
    return f'{v:,.0f}' if isinstance(v, int) else f'{v:,.3f}'


rows = [
    ('Candidate captures', s['candidate_captures'], l['candidate_captures']),
    ('Archive pages', s['page_count'], l['page_count']),
    ('Root bytes', s['root_bytes'], l['root_bytes']),
    ('Page bytes', s['page_bytes'], l['page_bytes']),
    ('Invocations', s['total']['invocations'], l['total']['invocations']),
    ('Application D1 reads', s['application']['reads'], l['application']['reads']),
    ('D1 writes, with index units', s['application']['writes'], l['application']['writes']),
    ('Application SQL seconds', s['application']['sql_ms']/1000, l['application']['sql_ms']/1000),
    ('Raw SQL seconds, including inspection', s['total']['sql_ms']/1000, l['total']['sql_ms']/1000),
    ('Handler wall seconds', s['total']['handler_wall_ms']/1000, l['total']['handler_wall_ms']/1000),
    ('Controller phase seconds', s['controller_elapsed_ms']/1000, l['controller_elapsed_ms']/1000),
    ('Physical D1 bytes before', s['physical_before_bytes'], l['physical_before_bytes']),
    ('Physical D1 bytes after', s['physical_after_bytes'], l['physical_after_bytes']),
    ('SQL export bytes before', s['sql_before_bytes'], l['sql_before_bytes']),
    ('SQL export bytes after', s['sql_after_bytes'], l['sql_after_bytes']),
]
table = '\n'.join(f'| {name} | {n(a)} | {n(b)} | {b/a:.3f}× |' for name, a, b in rows)
names = [
    'Candidate eligibility', 'Claim revision and eligibility', 'Claim assertion and eligibility',
    'Original/image ownership pages', 'Reference image pages', 'Reference capture pages',
    'Task page size queries', 'Task row page queries', 'Comparison-row pages',
    'Candidate capture pages', 'Document-owner pages',
]
smallqueries = {q['sql_prefix']: q for q in s['query_prefixes']}
queries = '\n'.join(
    f"| {label} | {q['queries']:,} | {q['reads']:,} | {q['sql_ms']/1000:.3f} | {q['reads']/smallqueries[q['sql_prefix']]['reads']:.2f}× |"
    for label, q in zip(names, l['query_prefixes'][:11]))
stages = '\n'.join(
    f"| {name} | {v['total']['invocations']} | {v['application']['reads']:,} | {v['application']['writes']:,} | {v['application']['sql_ms']/1000:.3f} | {v['total']['handler_wall_ms']/1000:.3f} |"
    for name, v in l['stages'].items())
sections = '\n'.join(f"| {name} | {s['sections'].get(name, {}).get('pages', 0)} | {v['pages']} | {v['rows']:,} | {v['bytes']:,} |" for name, v in l['sections'].items())
cost = '\n'.join(f"| {key} | ${s['partial_unrounded_excess_rate_usd'][key]:.9f} | ${l['partial_unrounded_excess_rate_usd'][key]:.9f} |" for key in l['partial_unrounded_excess_rate_usd'])

report = f'''# Hosted large archive measurement, 2026-09-22

The 35,820-capture archive reached `ready` at 12:18:26.792 UTC. It used 341 steps, 3,408 pages and a 1,505,216-byte root. Ten times as many captures required **90.57 times as many application D1 reads** and **73.00 times as much application SQL time** as the small drill. Archive bytes grew about tenfold. The repeated eligibility and source-page scans explain the larger query growth.

This derivative has passed local calculation and source checks. An independent read-only audit verified its totals, sources, scope, and sampling limits. Its single wording finding was corrected; see [AUDIT.json](./AUDIT.json). The initial PR report and its audit remain unchanged. This report does not approve launch or claim large backup/restore, sustained capacity, actual CLI admission, or all-changed archive capacity.

The fixture has two runs, 35,820 original ownership rows, and 71,640 capture records before compaction. The candidate inherits originals and contains 359 deliberately changed/reviewed captures. The fixed baseline decision stress is separate from the candidate. The fixture does not establish an observed 1% change rate, a fresh-original monthly workload, or a worst-case metadata size.

| Measure | Small | Large | Large / small |
| --- | ---: | ---: | ---: |
{table}

Controller phase time is 2,050.323 seconds (34 minutes 10.323 seconds), including its before-export and inspection work. Handler wall totals are sums of invocation measurements. Neither is Worker CPU or a production scheduled completion guarantee. Physical size fell by {l['physical_before_bytes']-l['physical_after_bytes']:,} bytes and SQL export size by {l['sql_before_bytes']-l['sql_after_bytes']:,} bytes in this fixture. This observation is not a guarantee that each deletion reduces D1 physical storage by that amount.

The raw archive event ledger has 421,489,788 reads, 141,749 writes, 31,250 query calls and 478.297458 seconds of SQL. It includes two harness `archiveState` inspections per invocation. Removing those 682 queries, 682 reads and 4.232144 seconds of SQL leaves 421,489,106 application reads, 30,568 queries and 474.065314 seconds of SQL. Writes already contain reported D1 index units; do not add index multipliers again.

The separate before/after summary inspections and the final root inspection are outside that event ledger. The root inspection adds one R2 GET. SQL export, controller polling, and some statistics queries are also outside it. Thus the application ledger is not the complete diagnostic bill. Exact counters and inspection receipts are in [comparison.json](./comparison.json).

## Query work

| Query group | Large calls | Large reads | Large SQL seconds | Read ratio |
| --- | ---: | ---: | ---: | ---: |
{queries}

The three eligibility/revision/claim checks use 183,228,506 reads ({l['eligibility']['reads']/l['application']['reads']:.1%} of application reads) and 204.886718 SQL seconds ({l['eligibility']['sql_ms']/l['application']['sql_ms']:.1%} of application SQL time). The claim revision and assertion each read `5 * C + 8` rows per step: `179108` at `C = 35820`, versus `17918` at `C = 3582`. They run at every step, including page rereads. With a fixed 20-page action budget, this source path has a capture-count-times-step-count component, which is quadratic for this family of fixtures. Its measured read growth is about 94.7 times.

For example, capture pages use this source query:

```sql
SELECT record.id AS _history_cursor, record.*
FROM ariviso_captures record
WHERE record.run_id = ? AND record.id > ?
ORDER BY record.id
LIMIT 100;
```

The previously recorded local query plan uses the run-only index and a temporary sort. Task size, task row and reference queries also rebuild large scope lists. An outer `LIMIT 100` limits returned rows, not all scanned rows. The actual large receipts now confirm the scan growth; the earlier [local plans](../archive-query-plans.json) remain supporting evidence, not hosted query plans. Timing ratios also depend on D1 placement, caching and runtime conditions: small receipts were served from EWR and large receipts from IAD. Do not infer an arbitrary-size latency curve from these two samples.

## Write, readback and final verification

Each page is written and read back once. After all sections are complete, every page is read again before the root is written and read back. Therefore, for `P` pages, overlay calls are `P + 1` PUTs and `2P + 1` GETs. The large receipts exactly match **3,409 PUTs and 6,817 overlay GETs**. Another 292 GETs read private documents, for 7,109 recorded Class B calls. Small receipts contain 358 PUTs, 715 overlay GETs and 36 private-document GETs.

| Large invocation stage | Steps | Application reads | Writes | Application SQL seconds | Handler wall seconds |
| --- | ---: | ---: | ---: | ---: | ---: |
{stages}

Steps 0–169 write 3,400 pages. Step 170 writes the last eight and rereads the first 12. Steps 171–340 reread the remaining 3,396 pages; the last step also publishes the root and compacts D1 detail. Final-reread-only steps contain 91,345,590 eligibility reads and 102.714158 seconds of eligibility SQL. Their write count includes the final capture/task/comparison deletion work, so it must not be described as verification bookkeeping alone. The small transition writes 17 pages and rereads three, then uses 18 final-reread-only steps. Both step counts equal `ceil(2 * P / 20)`.

The large progress update query ran 7,156 times and reported 14,312 write units. This equals the 6,816 page write/reread actions plus 340 unfinished-step saves, with two write units each. The final step deletes 35,820 completed tasks, 35,820 candidate captures and 35,461 unretained comparison rows. Retained candidate decisions and comparison roots are separate from this deletion count.

## Worker sampling and limits

The [Worker metrics window](/tmp/ariviso-v3-drill/tooling/v3/results/worker-metrics-2026-09-22T11-44-00Z.json) covers 11:44:00–12:18:30 UTC. It contains 312 time/status groups, a weighted 357 requests, weighted 78.546216 seconds of CPU and no weighted errors. Sampling intervals are 1 and 10. Groups extend from 11:44:05 to 12:18:27 and can include controller before/after inspections. These are adaptive window estimates, not exact archive-only totals. No CPU ratio is inferred against the differently sampled small window.

The maximum sampled CPU is 845,892 microseconds; maximum sampled wall time is 18,332,926 microseconds. Maximum sampled memory is **133,656,086 bytes** (127.464 MiB), at 12:10:08 UTC with sampling interval 1. It does not establish a continuous peak or adequate memory headroom. Cloudflare lists 128 MB of memory per isolate; this sample merits a separate bound review before a capacity claim. [Workers limits](https://developers.cloudflare.com/workers/platform/limits/)

## Rate weighting, not a bill

For comparison only, apply the current excess rates without account allowances or R2 rounding: $0.001 per million D1 reads, $1 per million D1 writes, $4.50 per million R2 Standard Class A operations and $0.36 per million Class B operations. The source rates were checked on 2026-09-22. [D1 pricing](https://developers.cloudflare.com/d1/platform/pricing/), [R2 pricing](https://developers.cloudflare.com/r2/pricing/)

| Partial excess-rate component | Small | Large |
| --- | ---: | ---: |
{cost}

This calculation omits storage, CPU, requests, queues, logs and out-of-ledger diagnostics. API call counts are not a billing meter. Allowances apply at account level; R2 also rounds excess units. Do not multiply these figures by 774 to claim a monthly bill: the large fixture is a tenfold stress case and the ordinary monthly workload has different ownership, retained-history and account-baseline variables. The large archive stores {l['page_bytes']+l['root_bytes']:,} bytes before any protected backup copy. Lifetime history growth remains a separate sensitivity from the preserved initial report.

## Measured section sizes

| Section | Small pages | Large pages | Large rows | Large bytes |
| --- | ---: | ---: | ---: | ---: |
{sections}

## Source and reproduction

The source hash map is [frozen-implementation-progress.json](/tmp/ariviso-v3-drill/tooling/v3/results/frozen-implementation-progress.json). All 77 files match the `implementation-progress` snapshot. Only `history.ts`, `history-format.ts` and `history-supplement.ts` differ from the small source map. Those changes replace the 1 MiB progress-record cap with a shared 1,900,000-byte cap. The query algorithm and 4,096-page limit are unchanged. The schema remains frozen through migration 0012; later root changes are outside this sample.

The 3,408-page result fits the measured build's page limit with this inherited, mostly unchanged fixture. It does **not** prove the separately reported all-changed fixture, which can exceed that page limit. No result from its pending fix is included.

```sh
python3 -B /tmp/ariviso-v3-cost-model/large-archive/analyze.py
python3 -B /tmp/ariviso-v3-cost-model/large-archive/render-report.py
```

The analyzer snapshots only `phase=archive` rows so ongoing cold-backup events cannot enter these totals. It checks sequential steps, the ready result, page and row counts, exact root JSON length, all final rereads, the R2 operation identities, the source hashes, and preservation of all 32 initial top-level artifacts. Input hashes are in [measurement-inputs.json](./measurement-inputs.json). The initial [AUDIT.json](../AUDIT.json) does not review this derivative.
'''
(OUT / 'REPORT.md').write_text(report)
