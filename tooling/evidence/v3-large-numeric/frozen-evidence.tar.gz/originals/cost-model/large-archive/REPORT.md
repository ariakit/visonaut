# Hosted large archive measurement, 2026-09-22

The 35,820-capture archive reached `ready` at 12:18:26.792 UTC. It used 341 steps, 3,408 pages and a 1,505,216-byte root. Ten times as many captures required **90.57 times as many application D1 reads** and **73.00 times as much application SQL time** as the small drill. Archive bytes grew about tenfold. The repeated eligibility and source-page scans explain the larger query growth.

This derivative has passed local calculation and source checks. An independent read-only audit verified its totals, sources, scope, and sampling limits. Its single wording finding was corrected; see [AUDIT.json](./AUDIT.json). The initial PR report and its audit remain unchanged. This report does not approve launch or claim large backup/restore, sustained capacity, actual CLI admission, or all-changed archive capacity.

The fixture has two runs, 35,820 original ownership rows, and 71,640 capture records before compaction. The candidate inherits originals and contains 359 deliberately changed/reviewed captures. The fixed baseline decision stress is separate from the candidate. The fixture does not establish an observed 1% change rate, a fresh-original monthly workload, or a worst-case metadata size.

| Measure | Small | Large | Large / small |
| --- | ---: | ---: | ---: |
| Candidate captures | 3,582 | 35,820 | 10.000× |
| Archive pages | 357 | 3,408 | 9.546× |
| Root bytes | 156,567 | 1,505,216 | 9.614× |
| Page bytes | 29,818,366 | 298,489,917 | 10.010× |
| Invocations | 36 | 341 | 9.472× |
| Application D1 reads | 4,653,568 | 421,489,106 | 90.573× |
| D1 writes, with index units | 14,337 | 141,749 | 9.887× |
| Application SQL seconds | 6.494 | 474.065 | 73.004× |
| Raw SQL seconds, including inspection | 6.552 | 478.297 | 73.003× |
| Handler wall seconds | 139.467 | 1,911.849 | 13.708× |
| Controller phase seconds | 159.390 | 2,050.323 | 12.864× |
| Physical D1 bytes before | 40,873,984 | 402,579,456 | 9.849× |
| Physical D1 bytes after | 27,164,672 | 265,048,064 | 9.757× |
| SQL export bytes before | 31,579,967 | 315,612,825 | 9.994× |
| SQL export bytes after | 20,489,275 | 204,622,771 | 9.987× |

Controller phase time is 2,050.323 seconds (34 minutes 10.323 seconds), including its before-export and inspection work. Handler wall totals are sums of invocation measurements. Neither is Worker CPU or a production scheduled completion guarantee. Physical size fell by 137,531,392 bytes and SQL export size by 110,990,054 bytes in this fixture. This observation is not a guarantee that each deletion reduces D1 physical storage by that amount.

The raw archive event ledger has 421,489,788 reads, 141,749 writes, 31,250 query calls and 478.297458 seconds of SQL. It includes two harness `archiveState` inspections per invocation. Removing those 682 queries, 682 reads and 4.232144 seconds of SQL leaves 421,489,106 application reads, 30,568 queries and 474.065314 seconds of SQL. Writes already contain reported D1 index units; do not add index multipliers again.

The separate before/after summary inspections and the final root inspection are outside that event ledger. The root inspection adds one R2 GET. SQL export, controller polling, and some statistics queries are also outside it. Thus the application ledger is not the complete diagnostic bill. Exact counters and inspection receipts are in [comparison.json](./comparison.json).

## Query work

| Query group | Large calls | Large reads | Large SQL seconds | Read ratio |
| --- | ---: | ---: | ---: | ---: |
| Candidate eligibility | 341 | 61,076,850 | 67.950 | 94.67× |
| Claim revision and eligibility | 341 | 61,075,828 | 68.104 | 94.68× |
| Claim assertion and eligibility | 341 | 61,075,828 | 68.833 | 94.68× |
| Original/image ownership pages | 360 | 45,118,881 | 19.551 | 97.33× |
| Reference image pages | 360 | 38,786,240 | 62.108 | 95.67× |
| Reference capture pages | 360 | 25,891,040 | 34.653 | 94.87× |
| Task page size queries | 360 | 25,891,040 | 41.355 | 94.87× |
| Task row page queries | 359 | 25,783,579 | 41.452 | 98.35× |
| Comparison-row pages | 360 | 19,329,201 | 17.463 | 97.35× |
| Candidate capture pages | 360 | 19,328,481 | 10.881 | 97.38× |
| Document-owner pages | 147 | 15,840,867 | 12.585 | 77.26× |

The three eligibility/revision/claim checks use 183,228,506 reads (43.5% of application reads) and 204.886718 SQL seconds (43.2% of application SQL time). The claim revision and assertion each read `5 * C + 8` rows per step: `179108` at `C = 35820`, versus `17918` at `C = 3582`. They run at every step, including page rereads. With a fixed 20-page action budget, this source path has a capture-count-times-step-count component, which is quadratic for this family of fixtures. Its measured read growth is about 94.7 times.

For example, capture pages use this source query:

```sql
SELECT record.id AS _history_cursor, record.*
FROM ariviso_captures record
WHERE record.run_id = ? AND record.id > ?
ORDER BY record.id
LIMIT 100;
```

The previously recorded local query plan uses the run-only index and a temporary sort. Task size, task row and reference queries also rebuild large scope lists. An outer `LIMIT 100` limits returned rows, not all scanned rows. The actual large receipts now confirm the scan growth; the earlier [local plans](../archive-query-plans.json) remain supporting evidence, not hosted query plans. Timing ratios also depend on D1 placement, caching and runtime conditions: small receipts were served from EWR and large receipts from IAD. Do not infer an arbitrary-size latency curve from these two samples.

## Write, readback and final verification

Each page is written and read back once. After all sections are complete, every page is read again before the root is written and read back. Therefore, for `P` pages, overlay calls are `P + 1` PUTs and `2P + 1` GETs. The large receipts exactly match **3,409 PUTs and 6,817 overlay GETs**. Another 292 GETs read private documents, for 7,109 recorded Class B calls. Small receipts contain 358 PUTs, 715 overlay GETs and 36 private-document GETs.

| Large invocation stage | Steps | Application reads | Writes | Application SQL seconds | Handler wall seconds |
| --- | ---: | ---: | ---: | ---: | ---: |
| write_only | 170 | 326,544,831 | 17,606 | 356.293 | 1392.300 |
| write_and_final_reread | 1 | 2,355,250 | 93 | 2.879 | 8.062 |
| final_reread_only | 170 | 92,589,025 | 124,050 | 114.893 | 511.487 |

Steps 0–169 write 3,400 pages. Step 170 writes the last eight and rereads the first 12. Steps 171–340 reread the remaining 3,396 pages; the last step also publishes the root and compacts D1 detail. Final-reread-only steps contain 91,345,590 eligibility reads and 102.714158 seconds of eligibility SQL. Their write count includes the final capture/task/comparison deletion work, so it must not be described as verification bookkeeping alone. The small transition writes 17 pages and rereads three, then uses 18 final-reread-only steps. Both step counts equal `ceil(2 * P / 20)`.

The large progress update query ran 7,156 times and reported 14,312 write units. This equals the 6,816 page write/reread actions plus 340 unfinished-step saves, with two write units each. The final step deletes 35,820 completed tasks, 35,820 candidate captures and 35,461 unretained comparison rows. Retained candidate decisions and comparison roots are separate from this deletion count.

## Worker sampling and limits

The [Worker metrics window](/tmp/ariviso-v3-drill/tooling/v3/results/worker-metrics-2026-09-22T11-44-00Z.json) covers 11:44:00–12:18:30 UTC. It contains 312 time/status groups, a weighted 357 requests, weighted 78.546216 seconds of CPU and no weighted errors. Sampling intervals are 1 and 10. Groups extend from 11:44:05 to 12:18:27 and can include controller before/after inspections. These are adaptive window estimates, not exact archive-only totals. No CPU ratio is inferred against the differently sampled small window.

The maximum sampled CPU is 845,892 microseconds; maximum sampled wall time is 18,332,926 microseconds. Maximum sampled memory is **133,656,086 bytes** (127.464 MiB), at 12:10:08 UTC with sampling interval 1. It does not establish a continuous peak or adequate memory headroom. Cloudflare lists 128 MB of memory per isolate; this sample merits a separate bound review before a capacity claim. [Workers limits](https://developers.cloudflare.com/workers/platform/limits/)

## Rate weighting, not a bill

For comparison only, apply the current excess rates without account allowances or R2 rounding: $0.001 per million D1 reads, $1 per million D1 writes, $4.50 per million R2 Standard Class A operations and $0.36 per million Class B operations. The source rates were checked on 2026-09-22. [D1 pricing](https://developers.cloudflare.com/d1/platform/pricing/), [R2 pricing](https://developers.cloudflare.com/r2/pricing/)

| Partial excess-rate component | Small | Large |
| --- | ---: | ---: |
| d1_reads | $0.004653568 | $0.421489106 |
| d1_writes | $0.014337000 | $0.141749000 |
| r2_class_a | $0.001611000 | $0.015340500 |
| r2_class_b | $0.000270360 | $0.002559240 |
| sum | $0.020871928 | $0.581137846 |

This calculation omits storage, CPU, requests, queues, logs and out-of-ledger diagnostics. API call counts are not a billing meter. Allowances apply at account level; R2 also rounds excess units. Do not multiply these figures by 774 to claim a monthly bill: the large fixture is a tenfold stress case and the ordinary monthly workload has different ownership, retained-history and account-baseline variables. The large archive stores 299,995,133 bytes before any protected backup copy. Lifetime history growth remains a separate sensitivity from the preserved initial report.

## Measured section sizes

| Section | Small pages | Large pages | Large rows | Large bytes |
| --- | ---: | ---: | ---: | ---: |
| run | 1 | 1 | 1 | 37,085 |
| project | 1 | 1 | 1 | 433 |
| shards | 1 | 4 | 72 | 3,396,161 |
| images | 36 | 359 | 35,820 | 13,953,408 |
| captures | 36 | 359 | 35,820 | 55,300,894 |
| comparisons | 1 | 1 | 1 | 481 |
| comparisonRows | 36 | 359 | 35,820 | 49,607,257 |
| decisions | 1 | 4 | 359 | 336,596 |
| commands | 1 | 4 | 359 | 532,965 |
| audit | 1 | 4 | 360 | 164,820 |
| referenceSnapshots | 1 | 1 | 1 | 511 |
| referenceCaptures | 36 | 359 | 35,820 | 55,304,125 |
| referenceImages | 36 | 359 | 35,820 | 13,956,639 |
| referenceSnapshotImages | 36 | 359 | 35,820 | 14,850,023 |
| provenance | 1 | 1 | 2 | 916 |
| manifests | 1 | 2 | 144 | 47,950 |
| profiles | 1 | 1 | 1 | 974 |
| policies | 1 | 1 | 1 | 345 |
| lineage | 1 | 1 | 1 | 335 |
| ancestry | 1 | 1 | 1 | 332 |
| reservations | 36 | 359 | 35,820 | 6,274,348 |
| identityHistory | 36 | 359 | 35,820 | 3,839,665 |
| acceptance | 1 | 4 | 359 | 53,708 |
| documents | 18 | 146 | 432 | 55,454,946 |
| tasks | 36 | 359 | 35,820 | 25,375,000 |

## Source and reproduction

The source hash map is [frozen-implementation-progress.json](/tmp/ariviso-v3-drill/tooling/v3/results/frozen-implementation-progress.json). All 77 files match the `implementation-progress` snapshot. Only `history.ts`, `history-format.ts` and `history-supplement.ts` differ from the small source map. Those changes replace the 1 MiB progress-record cap with a shared 1,900,000-byte cap. The query algorithm and 4,096-page limit are unchanged. The schema remains frozen through migration 0012; later root changes are outside this sample.

The 3,408-page result fits the measured build's page limit with this inherited, mostly unchanged fixture. It does **not** prove the separately reported all-changed fixture, which can exceed that page limit. No result from its pending fix is included.

```sh
python3 -B /tmp/ariviso-v3-cost-model/large-archive/analyze.py
python3 -B /tmp/ariviso-v3-cost-model/large-archive/render-report.py
```

The analyzer snapshots only `phase=archive` rows so ongoing cold-backup events cannot enter these totals. It checks sequential steps, the ready result, page and row counts, exact root JSON length, all final rereads, the R2 operation identities, the source hashes, and preservation of all 32 initial top-level artifacts. Input hashes are in [measurement-inputs.json](./measurement-inputs.json). The initial [AUDIT.json](../AUDIT.json) does not review this derivative.
