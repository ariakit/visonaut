# Large v3 numeric evidence handoff

This package preserves the inputs needed to check the recorded large archive and backup numbers. It supports local numeric verification. It does not contain a full hosted replay or establish completion of the large restore or benchmark work.

The selected original files are retained under `originals`. Their original content is unchanged. `INPUTS.json` identifies the files and records both the stored bytes and the original bytes, with their sizes and SHA-256 hashes. Files larger than 100,000 bytes use deterministic gzip. Decompression must reproduce the recorded original hash. Compression does not change the measurements or source content.

The original analysis scripts are archived evidence. Their historical commands, absolute paths, and resource configuration are not portable replay instructions. Use the separate `verify.py` script for the local package check. It makes no service calls.

Run the verifier from this package directory:

```sh
python3 -B verify.py --repository /path/to/ariviso --out /path/to/new-output
```

The output path must be new and must not already exist. It must be outside the repository and this package's `originals` directory. The repository path must contain the existing `docs/evidence/v3-small` and `tooling/evidence/v3-small` evidence. This package depends on those files and does not duplicate the full small drill.

The dependency records identify the exact repository inputs. They support reconstruction of the filtered small-drill events and the 77 frozen base source files. Three progress-source files then supply the large-drill changes. The verifier checks the reconstructed identities against the recorded hashes. A later repository version is suitable only if the required dependency bytes still match.

The frozen large drill uses the schema through migration 0012. Its source identity consists of the frozen base and the three progress-source changes. Later changes in the repository root are outside this measurement. The recorded archive and backup numbers must not be presented as measurements of those later changes.

The package omits SQL bodies, including the four small and large cold/warm exports. The local check therefore does not rehash those bodies. Original receipts retain their recorded SQL identities, but this handoff cannot independently establish the omitted bytes. The private object corpus and the resources, credentials, and setup needed for a full hosted replay are also outside this package.

The original analyzers also checked that 32 and 43 prior cost-model artifacts were unchanged. Their historical hash lists remain in the package. Unrelated prior artifact bodies are omitted, so the portable verifier does not repeat those preservation checks. It checks the retained package inputs and the explicit small-bundle dependencies instead.

The backup IDs use daily identities. The warm drill uses a logical clock offset of one day on the same physical test day. These records show the measured warm behavior; they do not prove an unattended 12-hour schedule or a maximum recovery-point age.

The cadence calculations hold the inventory at seven groups. They show the result of the stated root counts under that fixed assumption. They are not a monthly workload forecast and do not predict object growth, capture volume, retry rates, or future storage use.

The Worker metrics describe complete diagnostic windows and use adaptive sampling. CPU estimates and sampled memory from those windows cannot be assigned to the backup kernel alone. Sampled memory does not establish a continuous peak or a safe memory margin. Platform error counts also do not replace the application failure receipts.

Successful local verification is a package self-check. It is not an independent review, a new hosted run, or proof of large restore or benchmark completion. Any review wording preserved in original artifacts retains its original scope and does not apply automatically to this handoff.

`SELF-CHECK.json` and `CURATION.json` record the author's local checks. `SHA256.json` inventories package files other than itself. These records do not replace independent inspection of the new verifier.
