"""Read private local evidence and emit only aggregate counts and source hashes.

This script does not decrypt archives, read keys, or write files. It requires
already authenticated, extracted Chromium, Firefox, and WebKit evidence and the exact
local comparator snapshot. Redirect stdout to save the aggregate receipt.
"""

import base64
import collections
import hashlib
import json
from pathlib import Path
import subprocess
import tarfile
import zipfile

RESULTS = Path('/tmp/ariviso-ariakit-measurement-results')
ANALYSIS = Path('/tmp/ariviso-measure-comparator')
PRODUCT = Path('/Users/diegohaz/Developer/ariviso')
BROWSERS = ('chromium', 'firefox', 'webkit')
RUN = '35738622418'
SHA = '5a1e13790a21658179475a52257eed178a192049'
CAPTURE = 'application/vnd.ariviso.capture+json'
STARTED = 'application/vnd.ariviso.capture-started+json'


def sha256(data):
    return hashlib.sha256(data).hexdigest()


def file_hash(path):
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()


def read_json(path):
    return json.loads(path.read_text())


def identity(capture):
    return capture['capture']['itemKey'], capture['capture']['variant']['key']


def profile_digest(profile):
    return sha256(json.dumps(profile, sort_keys=True, separators=(',', ':'), ensure_ascii=False).encode())


receipt = {
    'schemaVersion': 1,
    'workflowRunId': RUN,
    'testedSha': SHA,
    'auditSourceSha256': file_hash(Path(__file__)),
    'authority': 'Independent local read-only audit of previously authenticated private browser evidence',
    'fullThreeBrowserMatrix': False,
    'priorTwoBrowserReceiptSha256': file_hash(Path(__file__).with_name('receipt.json')),
    'sourceHashes': {},
    'browsers': [],
    'limitations': [
        'The completed matrix covers the configured Chromium, Firefox, and WebKit visual collections for this run. Cross-browser images are not compared against one another.',
        'Each browser used one runner job and measured environment. These results do not establish variation across fresh runners or future image rollouts.',
        'Archive authentication is an input prerequisite. This audit checks saved ciphertext/archive hashes and every extracted regular file, but does not decrypt or read a key.',
        'The WASM run executes locally in Node. CPU, elapsed time, process RSS, and WASM linear memory are not hosted Worker CPU or authoritative Worker peak memory.',
        'Full capture profiles include per-capture clip rectangles. Environment compatibility is checked after excluding clip; full capture digests are not claimed to be service-allowlisted.',
        'Repeated unchanged-source pairs share images and are not independent statistical samples or intentional defect injections.',
        'The existing synthetic corpus report is checked for policy arithmetic; its synthetic mutations are not rerun here.',
        'No hosted upload, webhook provenance, Container fallback, or codeowner approval gate is closed by this receipt.',
    ],
}

for browser in BROWSERS:
    directory = RESULTS / browser
    raw = directory / 'raw'
    verified = read_json(directory / 'verification.json')
    aggregate = read_json(directory / 'analysis-validated-originals/aggregate.json')
    summary = read_json(directory / 'summary.json')
    source = read_json(raw / 'source.json')
    assert read_json(raw / 'summary.json') == summary
    for record in (verified, aggregate, summary, source):
        assert record['browser'] == browser
        assert record['workflowRunId'] == RUN and record['testedSha'] == SHA
    assert summary['complete'] and aggregate['complete'] and verified['verified']
    assert source['source'] == verified['sourceHashes']
    for name, expected in aggregate['sourceHashes'].items():
        assert file_hash(ANALYSIS / name) == expected
        receipt['sourceHashes'][name] = expected
        if name.startswith('compare/src/'):
            assert (ANALYSIS / name).read_bytes() == (PRODUCT / 'packages' / name).read_bytes()
    for name in ('analyze.mjs', 'verify-evidence.mjs', 'audit-attempts.py'):
        receipt['sourceHashes'][name] = file_hash(ANALYSIS / name)
    assert file_hash(raw / 'environment.json') == summary['environmentSha256'] == verified['environmentSha256']
    assert file_hash(directory / 'evidence.enc') == verified['encryptedEvidenceSha256']
    assert file_hash(directory / 'evidence.tar.gz') == verified['authenticatedTarSha256']
    archive_files = 0
    with tarfile.open(directory / 'evidence.tar.gz', 'r:gz') as archive:
        for entry in archive:
            relative = Path(entry.name)
            assert not relative.is_absolute() and '..' not in relative.parts
            assert entry.isdir() or entry.isfile()
            assert relative.suffix not in ('.pem', '.key')
            if entry.isfile():
                assert archive.extractfile(entry).read() == (raw / relative).read_bytes()
                archive_files += 1
    environment = read_json(raw / 'environment.json')
    passes = []
    captures_by_pass = []
    tests_by_pass = []
    for number in range(1, 4):
        pass_root = raw / f'pass-{number}'
        report = read_json(pass_root / 'captures.json')
        tests = {test['id']: test for test in report['tests']}
        selected = {identity(capture): capture for capture in report['captures']}
        assert report['complete'] and not report['errors']
        assert len(tests) == len(report['tests']) and len(tests) > 0
        assert len(selected) == len(report['captures']) and len(selected) > 0
        saved_pass = next(item for item in summary['passes'] if item['iteration'] == number)
        assert saved_pass['tests'] == len(tests) and saved_pass['captures'] == len(selected)
        assert saved_pass['complete'] and saved_pass['exitCode'] == 0
        assert all(test['expectedStatus'] == 'passed' and test['attempts'][-1]['status'] == 'passed' and not test['attempts'][-1]['errors'] for test in tests.values())
        assert set(tests) == {capture['capture']['testId'] for capture in selected.values()}
        assert {capture['image']['digest'] for capture in selected.values()} == {file.stem for file in (pass_root / 'images').glob('*.png')}
        for capture in selected.values():
            assert capture['path'] == f"images/{capture['image']['digest']}.png"
            data = (pass_root / capture['path']).read_bytes()
            assert sha256(data) == capture['image']['digest'] and len(data) == capture['image']['bytes']
            profile = capture['profile']['profile']
            assert profile_digest(profile) == capture['profile']['digest'] == capture['capture']['profileDigest']
            compatible = [entry['profile'] for entry in environment['environmentProfiles'] if all(profile[key] == entry['profile'][key] for key in profile if key != 'captureOptions')]
            assert any(all(value == entry['captureOptions'].get(key) for key, value in profile['captureOptions'].items() if key != 'clip') for entry in compatible)
            final = tests[capture['capture']['testId']]['attempts'][-1]
            assert capture['capture']['testRetry'] == final['retry']
        attempts = {}
        with zipfile.ZipFile(pass_root / 'all-attempts.zip') as archive:
            for name in archive.namelist():
                if not name.endswith('.jsonl'):
                    continue
                for line in archive.open(name):
                    record = json.loads(line)
                    data = record.get('params', {})
                    method = record.get('method')
                    if method == 'onTestBegin':
                        result = data['result']
                        assert result['id'] not in attempts
                        attempts[result['id']] = {'testId': data['testId'], 'retry': result['retry'], 'attachments': []}
                    elif method == 'onAttach':
                        attempts[data['resultId']]['attachments'].extend(data['attachments'])
                    elif method == 'onTestEnd':
                        attempts[data['result']['id']]['status'] = data['result']['status']
            actual = {(attempt['testId'], attempt['retry']): attempt['status'] for attempt in attempts.values()}
            expected = {(test['id'], attempt['retry']): attempt['status'] for test in tests.values() for attempt in test['attempts']}
            assert len(actual) == len(attempts) and actual == expected
            marker_pngs = 0
            failed_marker_pngs = 0
            selected_payloads = 0
            for attempt in attempts.values():
                attachments = attempt['attachments']
                starts = [json.loads(base64.b64decode(att['base64']))['attemptToken'] for att in attachments if att['contentType'] == STARTED]
                assert len(set(starts)) == len(starts)
                completed_tokens = set()
                for attachment in attachments:
                    if attachment['contentType'] != CAPTURE:
                        continue
                    capture = json.loads(base64.b64decode(attachment['base64']))
                    assert capture['attemptToken'] in starts and capture['attemptToken'] not in completed_tokens
                    completed_tokens.add(capture['attemptToken'])
                    assert capture['capture']['testId'] == attempt['testId'] and capture['capture']['testRetry'] == attempt['retry']
                    pngs = [att for att in attachments if att['name'] == capture['imageAttachment'] and att['contentType'] == 'image/png']
                    assert len(pngs) == 1
                    png = pngs[0]
                    image_bytes = base64.b64decode(png['base64']) if 'base64' in png else archive.read(png['path'])
                    assert sha256(image_bytes) == capture['image']['digest'] and len(image_bytes) == capture['image']['bytes']
                    marker_pngs += 1
                    chosen = selected[identity(capture)]
                    if attempt['status'] == 'passed':
                        assert {key: value for key, value in chosen.items() if key != 'path'} == capture
                        assert image_bytes == (pass_root / chosen['path']).read_bytes()
                        selected_payloads += 1
                    else:
                        assert chosen['capture']['testRetry'] > capture['capture']['testRetry']
                        failed_marker_pngs += 1
                if attempt['status'] == 'passed':
                    assert completed_tokens == set(starts)
            assert selected_payloads == len(selected)
        passes.append({
            'pass': number,
            'tests': len(tests),
            'captures': len(selected),
            'attempts': len(attempts),
            'failedAttempts': sum(attempt['status'] != 'passed' for attempt in attempts.values()),
            'finalFailures': 0,
            'markerPngJoinsAndHashesVerified': marker_pngs,
            'failedMarkerPngJoinsAndHashesVerified': failed_marker_pngs,
            'selectedPayloadsAndOriginalBytesVerified': selected_payloads,
            'profilePayloadDigestsVerified': len(selected),
            'zeroCaptureTests': 0,
        })
        captures_by_pass.append(selected)
        tests_by_pass.append(set(tests))
    for left, right in ((0, 1), (1, 2), (0, 2)):
        assert tests_by_pass[left] == tests_by_pass[right]
        assert captures_by_pass[left].keys() == captures_by_pass[right].keys()
        for key, capture in captures_by_pass[left].items():
            other = captures_by_pass[right][key]
            assert capture['profile'] == other['profile']
            assert capture['capture']['profileDigest'] == other['capture']['profileDigest']
            assert (capture['image']['width'], capture['image']['height']) == (other['image']['width'], other['image']['height'])
    receipt['browsers'].append({
        'browser': browser,
        'completeForThisBrowser': True,
        'archiveRegularFilesVerified': archive_files,
        'localSourceHashesMatch': True,
        'localReceiptHashesAtAuditTime': {name: file_hash(directory / name) for name in ('summary.json', 'verification.json', 'attempt-coverage.json', 'analysis-validated-originals/aggregate.json')},
        'evidenceHashes': {
            'encryptedEvidenceSha256': verified['encryptedEvidenceSha256'],
            'authenticatedTarSha256': verified['authenticatedTarSha256'],
            'environmentSha256': verified['environmentSha256'],
        },
        'sameTestCaptureInventoryProfilesAndDimensionsAcrossPasses': True,
        'environmentFieldsAndCaptureOptionsMatchExceptPerCaptureClip': True,
        'passes': passes,
    })

wasm_source = r'''
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { createRequire } from 'node:module';
import { validateImage, decodeImage, compareImages } from '/tmp/ariviso-measure-comparator/compare/src/index.ts';
import { nodeCodecs } from '/tmp/ariviso-measure-comparator/compare/test/codecs.ts';
const digest = bytes => createHash('sha256').update(bytes).digest('hex');
const require = createRequire('file:///tmp/ariviso-measure-comparator/compare/package.json');
const codecFiles = {};
for (const name of ['@jsquash/png/codec/pkg/squoosh_png_bg.wasm', '@jsquash/webp/codec/dec/webp_dec.wasm']) {
  codecFiles[name] = digest(await readFile(require.resolve(name)));
}
const started = performance.now();
const cpuStarted = process.cpuUsage();
const codecs = await nodeCodecs();
const browsers = [];
for (const browser of ['chromium', 'firefox', 'webkit']) {
  const root = `/tmp/ariviso-ariakit-measurement-results/${browser}`;
  const expected = JSON.parse(await readFile(`${root}/analysis-validated-originals/aggregate.json`, 'utf8'));
  const verification = JSON.parse(await readFile(`${root}/verification.json`, 'utf8'));
  assert.deepEqual(codecFiles, verification.localCodecFiles);
  const policies = expected.policies;
  let selectedCapturesValidated = 0;
  const passes = [];
  const acceptedImageProfiles = {};
  const read = async (pass, capture, selectedCapture = false) => {
    const bytes = await readFile(`${root}/raw/pass-${pass}/${capture.path}`);
    assert.equal(digest(bytes), capture.image.digest);
    assert.equal(bytes.length, capture.image.bytes);
    const image = await validateImage(bytes);
    assert.equal(image.digest, capture.image.digest);
    assert.equal(image.width, capture.image.width);
    assert.equal(image.height, capture.image.height);
    assert(Object.hasOwn(expected.passes.find(item => item.pass === pass).acceptedImageProfiles, image.profile));
    if (selectedCapture) acceptedImageProfiles[image.profile] = (acceptedImageProfiles[image.profile] ?? 0) + 1;
    assert.deepEqual(Buffer.from(image.original), bytes);
    const pixels = await decodeImage(image, codecs);
    assert.deepEqual(Buffer.from(image.original), bytes);
    return pixels;
  };
  for (let pass = 1; pass <= 3; pass++) {
    const report = JSON.parse(await readFile(`${root}/raw/pass-${pass}/captures.json`, 'utf8'));
    passes.push(new Map(report.captures.map(capture => [JSON.stringify([capture.capture.itemKey, capture.capture.variant.key]), capture])));
    for (const capture of report.captures) {
      await read(pass, capture, true);
      selectedCapturesValidated++;
    }
  }
  const totals = Object.fromEntries(policies.map(policy => [policy.id, { compared: 0, changed: 0, changedPixels: 0, sizeChanged: 0 }]));
  for (const [left, right] of [[1, 2], [2, 3], [1, 3]]) {
    const pairTotals = Object.fromEntries(policies.map(policy => [policy.id, { compared: 0, changed: 0, changedPixels: 0, sizeChanged: 0 }]));
    for (const [key, capture] of passes[left - 1]) {
      const other = passes[right - 1].get(key);
      assert(other);
      assert.equal(capture.capture.profileDigest, other.capture.profileDigest);
      const original = await read(left, capture);
      const candidate = capture.image.digest === other.image.digest ? original : await read(right, other);
      for (const policy of policies) {
        const compared = compareImages(original, candidate, policy);
        for (const target of [totals[policy.id], pairTotals[policy.id]]) {
          target.compared++;
          target.changed += Number(compared.outcome === 'changed');
          target.changedPixels += compared.changedPixels;
          target.sizeChanged += Number(compared.sizeChanged);
        }
      }
    }
    const saved = expected.comparisons.find(pair => pair.left === left && pair.right === right);
    for (const policy of policies) {
      for (const key of Object.keys(pairTotals[policy.id])) assert.equal(pairTotals[policy.id][key], saved.policyOutcomes[policy.id][key]);
    }
  }
  const savedImageProfiles = {};
  for (const pass of expected.passes) {
    for (const [profile, count] of Object.entries(pass.acceptedImageProfiles)) savedImageProfiles[profile] = (savedImageProfiles[profile] ?? 0) + count;
  }
  assert.deepEqual(acceptedImageProfiles, savedImageProfiles);
  browsers.push({ browser, selectedCapturesValidated, acceptedImageProfiles, originalBytesEqualBeforeAndAfterWasmDecode: true, policyTotalsMatchSavedPairs: true, policyTotals: totals });
}
const cpu = process.cpuUsage(cpuStarted);
console.log(JSON.stringify({
  date: new Date().toISOString(),
  runtime: { node: process.version, platform: process.platform, architecture: process.arch },
  codecBinaryHashes: codecFiles,
  browsers,
  localMeasurementsOnly: { elapsedMs: performance.now() - started, cpuMs: (cpu.user + cpu.system) / 1000, processMaximumResidentKiB: process.resourceUsage().maxRSS, wasmLinearMemoryBytes: codecs.wasmMemoryBytes() },
}));
'''
receipt['freshWasmRun'] = json.loads(subprocess.run(['node', '--input-type=module'], input=wasm_source, text=True, check=True, capture_output=True).stdout)
study = read_json(PRODUCT / 'packages/compare/evidence/corpus-study.json')
receipt['corpusStudySha256'] = file_hash(PRODUCT / 'packages/compare/evidence/corpus-study.json')
receipt['intentionalDefectPolicyArithmetic'] = {
    policy: {'total': sum(group['total'] for name, group in groups.items() if name.endswith('-defect')), 'missed': sum(group['missed'] for name, group in groups.items() if name.endswith('-defect'))}
    for policy, groups in study['outcomes'].items()
}
assert receipt['intentionalDefectPolicyArithmetic'] == {
    'visible-exact-v1': {'total': 100, 'missed': 0},
    'study-one-level': {'total': 100, 'missed': 50},
    'study-legacy-ratio': {'total': 100, 'missed': 98},
}
receipt['totals'] = {key: sum(item[key] for browser in receipt['browsers'] for item in browser['passes']) for key in ('tests', 'captures', 'attempts', 'failedAttempts', 'markerPngJoinsAndHashesVerified', 'failedMarkerPngJoinsAndHashesVerified', 'selectedPayloadsAndOriginalBytesVerified', 'profilePayloadDigestsVerified')}
assert receipt['totals']['markerPngJoinsAndHashesVerified'] == receipt['totals']['selectedPayloadsAndOriginalBytesVerified'] + receipt['totals']['failedMarkerPngJoinsAndHashesVerified']
assert receipt['totals']['selectedPayloadsAndOriginalBytesVerified'] == receipt['totals']['captures']
assert sum(browser['selectedCapturesValidated'] for browser in receipt['freshWasmRun']['browsers']) == receipt['totals']['captures']
receipt['fullThreeBrowserMatrix'] = {browser['browser'] for browser in receipt['browsers'] if browser['completeForThisBrowser']} == set(BROWSERS)
receipt['verdict'] = 'The configured Chromium, Firefox, and WebKit capture matrix is complete for this run. Original-byte preservation, retry selection, profile joins, and local WASM policy results are supported. No evidence correction is required. This does not establish hosted execution or variation across runner instances.'
print(json.dumps(receipt, indent=2))
