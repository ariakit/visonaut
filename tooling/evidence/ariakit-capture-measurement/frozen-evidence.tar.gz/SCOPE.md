# Capture scope and workload target

The measured scope is the complete **currently configured Ariakit desktop visual suite**, not every Ariakit test or every example in the repository. The unchanged upstream `.github/workflows/app.yml` visual jobs select `chrome firefox` on Ubuntu and `safari` on macOS, and pass `--grep @visual`. The separate nonvisual jobs include desktop and mobile projects with `--grep-invert @visual`. The measurement preserves the intended desktop capture matrix as Ubuntu 24.04 Chromium/Firefox and macOS 15 WebKit. A mobile viewport in a desktop browser is not a native mobile-browser measurement.

At the exact measurement source, this fresh local collection command produced no errors:

```sh
CI=true VISUAL_TEST=true playwright test \
  --config app/playwright.config.ts --list \
  --project chrome firefox safari --grep @visual --reporter=json
```

The unchanged upstream config collects 307 test callbacks across 33 source files: 106 Chromium, 106 Firefox, and 95 WebKit. Full test title paths and repository-relative filenames from the actual reports of all three browsers match that collection with zero missing or extra tests. `scope.json` preserves the command, counts, source hashes, private inventory hash, and measured dimension counts.

The trusted executor uses the same project kinds, such as `chrome` and `browser`, and the `@visual` title filter. Its string glob patterns match the current upstream collection. This proves parity for this source revision; it does not prove that every possible future filename extension will match both patterns. New collection conventions must preserve full upstream visual coverage.

## Expanded calls within the selected tests

The independent existing source ledger in `packages/compare/evidence/ariakit-source-capture-count.json` enumerates authored capture calls, page sections, viewport/style loops, color-scheme loops, and current preview discovery. It predicts:

| Browser | Page-section calls | State calls | Generic preview calls | Total |
| --- | ---: | ---: | ---: | ---: |
| Chromium | 984 | 230 | 16 | 1,230 |
| Firefox | 984 | 230 | 16 | 1,230 |
| WebKit | 926 | 180 | 16 | 1,122 |
| Total | 2,894 | 640 | 48 | 3,582 |

All three browser invocations match their predicted totals. The normal named page set has 463 sections. Each section receives two color schemes in each browser. Chromium and Firefox also include the authored forced-colors page collection. State tests apply only their authored viewport, contrast, forced-colors, and interaction combinations. The environment allowlist records permitted profiles; its length is not a capture multiplier.

`withFramework` discovers the frameworks implemented for each selected preview, and uses React for Next.js cases. Generic preview discovery follows the existing preview index, which excludes sandbox entries. The current index contains four framework paths from three examples. Each path receives two viewports and two color schemes, yielding 16 generic preview captures per browser. Selected sandbox visual tests remain included through their authored `@visual` callbacks; the generic index is not a promise to capture every sandbox automatically.

Chromium and Firefox each have these actual dimensions in one pass:

| Dimension | Actual counts |
| --- | --- |
| Framework | React 1,226; Solid 4 |
| Color scheme | Light 617; dark 613 |
| Contrast preference | No preference 1,224; more 6 |
| Forced colors | None 1,118; active 112 |
| Viewport key | Default 10; desktop 1,174; mobile 12; wide 22; narrow 12 |
| Style key | Default 10; light 610; dark 610 |

WebKit has React 1,118 and Solid 4; light 563 and dark 559; contrast no preference 1,116 and more 6; forced colors none 1,118 and active 4. Its viewport keys are default 10, desktop 1,066, mobile 12, wide 22, and narrow 12. These are distributions of authored calls, not a Cartesian product applied to every item. Framework, color scheme, contrast, forced colors, viewport, and style remain explicit variant metadata. The capture adapter performs one prepared call for each variant selected by Ariakit's helpers.

## Meaning of 10,580

Issue #1 describes 1,058 old lossless WebP files, many containing composite captures, and asks the implementation to plan for approximately ten times that count after splitting composites and adding examples. Thus `1,058 × 10 = 10,580` is an expanded design workload. It is not an enumerated test collection with 10,580 existing states.

The actual current split collection is expected to be 3,582. Ten times that current collection is 35,820. These are separate scenarios: current authored visual coverage, the issue's expanded 10,580 target, and a conservative tenfold-current 35,820 stress workload. Neither the measurement workflow nor this report silently replaces the expanded capacity target with the smaller current collection.

E07 may use the completed actual matrix's encoded-byte and pixel distributions as inputs to a clearly labeled expanded-workload model. Repeating or sampling those distributions to 10,580 or 35,820 captures is a capacity experiment, not evidence of that many distinct authored Ariakit states. Future examples can have different size distributions. The measured pass-1 full-matrix mean is 17,559.71 encoded bytes and 142,443.96 pixels per capture. Storage/compute budgets still need their separate measured platform evidence.
