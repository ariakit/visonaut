import collections
import base64
import json
from pathlib import Path
import sys
import zipfile

browser=sys.argv[1]
assert browser in ['chromium','firefox','webkit']
root=Path('/tmp/ariviso-ariakit-measurement-results')/browser/'raw'
output=[]
for number in range(1,4):
    report=json.loads((root/f'pass-{number}/captures.json').read_text())
    attempts={}
    with zipfile.ZipFile(root/f'pass-{number}/all-attempts.zip') as archive:
        for name in archive.namelist():
            if not name.endswith('.jsonl'): continue
            with archive.open(name) as stream:
                for line in stream:
                    record=json.loads(line); data=record.get('params',{}); method=record.get('method')
                    if method=='onTestBegin':
                        attempts[data['result']['id']]={'testId':data['testId'],'retry':data['result']['retry'],'types':collections.Counter(),'captures':[]}
                    elif method=='onAttach':
                        attempts[data['resultId']]['types'].update(a['contentType'] for a in data['attachments'])
                        for attachment in data['attachments']:
                            if attachment['contentType']=='application/vnd.ariviso.capture+json':
                                attempts[data['resultId']]['captures'].append(json.loads(base64.b64decode(attachment['base64'])))
                    elif method=='onTestEnd':
                        attempts[data['result']['id']]['status']=data['result']['status']
    expected={(t['id'],a['retry']):a['status'] for t in report['tests'] for a in t['attempts']}
    actual={(a['testId'],a['retry']):a['status'] for a in attempts.values()}
    assert actual==expected
    failed=[a for a in attempts.values() if a['status']!='passed']
    final={test['id']:test['attempts'][-1] for test in report['tests']}
    for capture in report['captures']:
        assert final[capture['capture']['testId']]['status']=='passed'
        assert capture['capture']['testRetry']==final[capture['capture']['testId']]['retry']
    selected={(capture['capture']['itemKey'],capture['capture']['variant']['key']):capture for capture in report['captures']}
    failed_captures=[capture for attempt in failed for capture in attempt['captures']]
    for capture in failed_captures:
        chosen=selected[(capture['capture']['itemKey'],capture['capture']['variant']['key'])]
        assert chosen['capture']['testRetry']>capture['capture']['testRetry']
    output.append({'pass':number,'testAttempts':len(attempts),'everyAttemptMatchesReport':True,'finalSelectionMatchesLastSuccessfulAttempt':True,'failedCapturesReplacedByLaterSuccessfulRetry':len(failed_captures),'failedAttempts':len(failed),'failedStatuses':dict(collections.Counter(a['status'] for a in failed)),'failedCaptureAttachments':sum(a['types']['application/vnd.ariviso.capture+json'] for a in failed),'failedStartedAttachments':sum(a['types']['application/vnd.ariviso.capture-started+json'] for a in failed),'failedPngAttachments':sum(a['types']['image/png'] for a in failed),'allCaptureAttachments':sum(a['types']['application/vnd.ariviso.capture+json'] for a in attempts.values()),'selectedCaptures':len(report['captures'])})
(root.parent/'attempt-coverage.json').write_text(json.dumps(output,indent=2))
print(json.dumps(output,indent=2))
