import pathlib
import shutil
import sys
import tarfile

archive = pathlib.Path(sys.argv[1])
root = pathlib.Path(sys.argv[2]).resolve()
root.mkdir(mode=0o700, parents=True, exist_ok=True)
with tarfile.open(archive, 'r:gz') as stream:
    entries = stream.getmembers()
    if len(entries) > 100_000 or sum(entry.size for entry in entries) > 10 * 1024**3:
        raise ValueError('Archive exceeds private evidence bounds')
    for entry in entries:
        relative = pathlib.PurePosixPath(entry.name)
        if relative.is_absolute() or '..' in relative.parts or not (entry.isdir() or entry.isreg()):
            raise ValueError('Archive has an unsafe member')
    for entry in entries:
        target = root.joinpath(*pathlib.PurePosixPath(entry.name).parts)
        if entry.isdir():
            target.mkdir(mode=0o700, parents=True, exist_ok=True)
            continue
        target.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
        source = stream.extractfile(entry)
        if source is None:
            raise ValueError('Missing regular member')
        with source, target.open('xb') as output:
            target.chmod(0o600)
            shutil.copyfileobj(source, output, 1024 * 1024)
print('Private regular-file extraction complete')
