import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { readFile, writeFile, mkdir, readdir } from 'node:fs/promises';
import path from 'node:path';
import { compareImages, decodeImage, validateImage, engineVersion, codecVersion, imageLimits } from './compare/src/index.ts';
import { nodeCodecs } from './compare/test/codecs.ts';

const policies = [
  { id: 'visible-exact-v1', channelThreshold: 0, maxChangedPixels: 0, maxChangedRatio: 0 },
  { id: 'study-one-level', channelThreshold: 1, maxChangedPixels: 0, maxChangedRatio: 0 },
  { id: 'study-legacy-ratio', channelThreshold: 0, maxChangedPixels: Number.MAX_SAFE_INTEGER, maxChangedRatio: 0.0005 },
];
const digest = (bytes) => createHash('sha256').update(bytes).digest('hex');
const identity = (capture) => JSON.stringify([capture.capture.itemKey, capture.capture.variant.key]);
const statistics = (values) => {
  const sorted = values.toSorted((left, right) => left - right);
  return { count: sorted.length, total: values.reduce((sum, item) => sum + item, 0), mean: values.length ? values.reduce((sum, item) => sum + item, 0) / values.length : null, p50: sorted[Math.floor(sorted.length * 0.5)] ?? null, p95: sorted[Math.floor(sorted.length * 0.95)] ?? null, max: sorted.at(-1) ?? null };
};

async function sourceHashes() {
  const files = ['analyze.mjs', 'compare/package.json', 'compare/test/codecs.ts', 'tested-pnpm-lock.yaml'];
  for (const name of await readdir(new URL('./compare/src/', import.meta.url))) {
    if (name.endsWith('.ts')) files.push(`compare/src/${name}`);
  }
  return Object.fromEntries(await Promise.all(files.sort().map(async (file) => [file, digest(await readFile(new URL(file, import.meta.url)))])));
}

export async function analyze(directory, output) {
  const started = performance.now();
  const cpuStarted = process.cpuUsage();
  const captureSummary = JSON.parse(await readFile(path.join(directory, 'summary.json'), 'utf8'));
  const codecs = await nodeCodecs();
  const report = {
    schemaVersion: 1,
    date: new Date().toISOString(),
    runtime: { node: process.version, platform: process.platform, architecture: process.arch },
    authority: 'Offline analysis of real GitHub capture-only evidence; no OIDC, service upload, or hosted comparator execution',
    browser: captureSummary.browser,
    testedSha: captureSummary.testedSha,
    workflowRunId: captureSummary.workflowRunId,
    workflowAttempt: captureSummary.workflowAttempt,
    engineVersion, codecVersion, imageLimits, policies,
    captureComplete: captureSummary.complete === true,
    capturePasses: captureSummary.passes,
    sourceHashes: await sourceHashes(),
    passes: [], comparisons: [],
    complete: false,
    limitations: [
      'Repeated unchanged-source captures measure observed rendering variation; they are not injected intentional defects or proof against all future noise.',
      'Incomplete passes, every failed attempt, missing inventory, incompatible profiles, and validation errors remain explicit; none establishes a complete clean matrix.',
      'WASM codecs, validation and comparison execute locally in Node; timings and process RSS are not Cloudflare Worker CPU or authoritative peak memory.',
    ],
  };
  const privateDetails = { passFailures: [], validationFailures: [], comparisons: [] };
  const captures = [];
  const readCapture = async (pass, capture) => {
    assert.match(capture.image.digest, /^[a-f0-9]{64}$/);
    assert.equal(capture.path, `images/${capture.image.digest}.png`);
    const bytes = await readFile(path.join(directory, `pass-${pass}`, capture.path));
    assert.equal(digest(bytes), capture.image.digest);
    assert.equal(bytes.length, capture.image.bytes);
    const image = await validateImage(bytes);
    assert.equal(image.digest, capture.image.digest);
    assert.equal(image.width, capture.image.width);
    assert.equal(image.height, capture.image.height);
    assert.deepEqual(Buffer.from(image.original), bytes);
    const pixels = await decodeImage(image, codecs);
    assert.deepEqual(Buffer.from(image.original), bytes);
    return { image, pixels };
  };
  for (let pass = 1; pass <= 3; pass++) {
    let captured;
    try {
      captured = JSON.parse(await readFile(path.join(directory, `pass-${pass}`, 'captures.json'), 'utf8'));
    } catch (error) {
      report.passes.push({ pass, complete: false, reportMissing: true });
      privateDetails.passFailures.push({ pass, error: String(error) });
      captures.push(null);
      continue;
    }
    captures.push(captured);
    const metadata = {
      pass, complete: captured.complete === true, tests: captured.tests.length, captures: captured.captures.length,
      failedAttempts: captured.tests.flatMap((test) => test.attempts).filter((attempt) => attempt.status !== 'passed').length,
      finalFailures: captured.tests.filter((test) => test.attempts.at(-1)?.status !== 'passed').length,
      recoveredTests: captured.tests.filter((test) => test.attempts.length > 1 && test.attempts.at(-1)?.status === 'passed').length,
      encodedBytes: statistics(captured.captures.map((capture) => capture.image.bytes)),
      pixels: statistics(captured.captures.map((capture) => capture.image.width * capture.image.height)),
      uniqueImages: new Set(captured.captures.map((capture) => capture.image.digest)).size,
      uniqueImageBytes: statistics([...new Map(captured.captures.map((capture) => [capture.image.digest, capture.image.bytes])).values()]),
      acceptedImageProfiles: {},
      validatedCaptures: 0, validationFailures: 0,
    };
    privateDetails.passFailures.push({ pass, errors: captured.errors, tests: captured.tests.filter((test) => test.attempts.some((attempt) => attempt.status !== 'passed')) });
    for (const capture of captured.captures) {
      try {
        const validated = await readCapture(pass, capture);
        metadata.acceptedImageProfiles[validated.image.profile] = (metadata.acceptedImageProfiles[validated.image.profile] ?? 0) + 1;
        metadata.validatedCaptures++;
      } catch (error) {
        metadata.validationFailures++;
        privateDetails.validationFailures.push({ pass, identity: identity(capture), digest: capture.image.digest, error: String(error) });
      }
    }
    report.passes.push(metadata);
  }
  for (const [left, right] of [[1, 2], [2, 3], [1, 3]]) {
    const first = captures[left - 1];
    const second = captures[right - 1];
    const result = { left, right, completePasses: first?.complete === true && second?.complete === true, inventoryEqual: false, common: 0, added: 0, removed: 0, profileChanged: 0, validationFailures: 0, policyOutcomes: Object.fromEntries(policies.map((policy) => [policy.id, { compared: 0, unchanged: 0, changed: 0, sizeChanged: 0, changedPixels: 0, maximumRatio: 0 }])) };
    report.comparisons.push(result);
    if (!first || !second) continue;
    result.inventoryEqual = JSON.stringify(first.tests.map((test) => test.id).sort()) === JSON.stringify(second.tests.map((test) => test.id).sort());
    const prior = new Map(first.captures.map((capture) => [identity(capture), capture]));
    assert.equal(prior.size, first.captures.length);
    const seen = new Set();
    for (const capture of second.captures) {
      const key = identity(capture);
      assert(!seen.has(key));
      seen.add(key);
      const before = prior.get(key);
      prior.delete(key);
      if (!before) { result.added++; continue; }
      result.common++;
      if (before.capture.profileDigest !== capture.capture.profileDigest) { result.profileChanged++; continue; }
      try {
        const original = await readCapture(left, before);
        const candidate = before.image.digest === capture.image.digest ? original : await readCapture(right, capture);
        const outcomes = {};
        for (const policy of policies) {
          const compared = compareImages(original.pixels, candidate.pixels, policy);
          const totals = result.policyOutcomes[policy.id];
          totals.compared++;
          totals[compared.outcome]++;
          totals.sizeChanged += Number(compared.sizeChanged);
          totals.changedPixels += compared.changedPixels;
          totals.maximumRatio = Math.max(totals.maximumRatio, compared.ratio);
          outcomes[policy.id] = { outcome: compared.outcome, sizeChanged: compared.sizeChanged, changedPixels: compared.changedPixels, ratio: compared.ratio };
        }
        privateDetails.comparisons.push({ left, right, identity: key, originalDigest: before.image.digest, candidateDigest: capture.image.digest, outcomes });
      } catch (error) {
        result.validationFailures++;
        privateDetails.validationFailures.push({ left, right, identity: key, error: String(error) });
      }
    }
    result.removed = prior.size;
  }
  report.complete = report.captureComplete && report.passes.length === 3 && report.passes.every((pass) => pass.complete && pass.validationFailures === 0) && report.comparisons.every((pair) => pair.completePasses && pair.inventoryEqual && pair.added === 0 && pair.removed === 0 && pair.profileChanged === 0 && pair.validationFailures === 0);
  const cpu = process.cpuUsage(cpuStarted);
  report.localExecution = { elapsedMs: performance.now() - started, cpuMs: (cpu.user + cpu.system) / 1000, processMaximumResidentKiB: process.resourceUsage().maxRSS, wasmLinearMemoryBytes: codecs.wasmMemoryBytes?.() };
  await mkdir(output, { recursive: true, mode: 0o700 });
  await writeFile(path.join(output, 'private-details.json'), JSON.stringify(privateDetails, null, 2), { mode: 0o600 });
  await writeFile(path.join(output, 'aggregate.json'), JSON.stringify(report, null, 2));
  console.log(JSON.stringify({ browser: report.browser, complete: report.complete, captureComplete: report.captureComplete, passes: report.passes, comparisons: report.comparisons, localExecution: report.localExecution }));
  return report;
}

if (import.meta.main) {
  if (process.argv.length !== 4) throw Error('Usage: node analyze.mjs <private-decrypted-directory> <output-directory>');
  await analyze(path.resolve(process.argv[2]), path.resolve(process.argv[3]));
}
