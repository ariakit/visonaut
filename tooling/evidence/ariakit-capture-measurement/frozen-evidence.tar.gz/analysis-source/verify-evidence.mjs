import assert from 'node:assert/strict';
import { readFile, writeFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { createReadStream } from 'node:fs';
import { createRequire } from 'node:module';
import path from 'node:path';
const browser = process.argv[2];
assert(['chromium', 'firefox', 'webkit'].includes(browser));
const root = `/tmp/ariviso-ariakit-measurement-results/${browser}`;
const source = JSON.parse(await readFile(path.join(root, 'raw/source.json'), 'utf8'));
const summary = JSON.parse(await readFile(path.join(root, 'summary.json'), 'utf8'));
const digest = (bytes) => createHash('sha256').update(bytes).digest('hex');
async function digestFile(file) { const hash = createHash('sha256'); for await (const chunk of createReadStream(file)) hash.update(chunk); return hash.digest('hex'); }
assert.deepEqual(JSON.parse(await readFile(path.join(root, 'raw/summary.json'), 'utf8')), summary);
assert.equal(source.testedSha, '5a1e13790a21658179475a52257eed178a192049');
assert.equal(source.workflowRunId, '35738622418');
assert.equal(source.node, 'v24.18.0');
const checkout = '/private/tmp/ariakit-ariviso-measurement';
for (const [file, expected] of Object.entries(source.source)) {
 const location = file === 'executorLock' ? '.github/ariviso/package-lock.json' : `.github/ariviso-measure/${file}`;
 assert.equal(digest(await readFile(path.join(checkout, location))), expected);
}
assert.equal(digest(await readFile(path.join(root, 'raw/environment.json'))), summary.environmentSha256);
const require = createRequire(new URL('./compare/package.json', import.meta.url));
const codecFiles = {};
for (const specifier of ['@jsquash/png/codec/pkg/squoosh_png_bg.wasm', '@jsquash/webp/codec/dec/webp_dec.wasm']) {
 codecFiles[specifier] = digest(await readFile(require.resolve(specifier)));
}
const verified = { browser, testedSha: source.testedSha, workflowRunId: source.workflowRunId, node: source.node, sourceHashes: source.source, environmentSha256: summary.environmentSha256, encryptedEvidenceSha256: await digestFile(path.join(root, 'evidence.enc')), authenticatedTarSha256: await digestFile(path.join(root, 'evidence.tar.gz')), localCodecFiles: codecFiles, verified: true };
await writeFile(path.join(root, 'verification.json'), JSON.stringify(verified, null, 2));
console.log(JSON.stringify({ browser, sourceAndEnvironmentVerified: true }));
