# Repeated Ariakit browser captures

This measured E01 record covers three complete invocations of the currently configured Ariakit desktop visual suite. All three browsers finished, and all 10,746 selected capture instances passed local validation and exact original-byte checks. The capture-only workflow and separate local service-comparator analysis are distinct evidence. See `SCOPE.md` for the current visual selection and its relation to the expanded workload targets.

## Source and authority

The capture-only [PR 7583](https://github.com/ariakit/ariakit/pull/7583) runs the full actual visual inventory three times in separate Playwright processes against one build. The [GitHub run](https://github.com/ariakit/ariakit/actions/runs/35738622418) tests merge revision [`5a1e137`](https://github.com/ariakit/ariakit/commit/5a1e13790a21658179475a52257eed178a192049), from reviewed head [`e54ebc3`](https://github.com/ariakit/ariakit/commit/e54ebc3491e06e273f64120f2b383a2b3b22c04e). The matrix is Ubuntu 24.04 Chromium and Firefox, and macOS 15 WebKit. The workflow uses `contents: read` only and makes no OIDC or Ariviso service requests. The trusted integration workflows, executor pins, plan, and profile allowlists remain unchanged.

The public measurement artifacts contain encrypted evidence and aggregate metrics. The raw screenshots, profiles, logs, traces, test identities, and every Playwright attempt are retained in the authenticated private archive. The operator holds the private key locally. Source hashes, codec binary hashes, ciphertext hashes, authenticated archive hashes, and environment hashes are in each browser's `verification.json`. The aggregate record contains no raw screenshots or capture identities.

An unchanged legacy probe workflow also ran on this PR. It briefly published its usual raw environment artifacts. The operator preserved those artifacts privately and deleted all three public copies; a subsequent artifact listing returned zero. Do not infer that those separate legacy probe profiles were always private.

## Completed capture measurements

| Browser | Tests per pass | Captures per pass | Pass times (seconds) | Failed attempts, by pass | Final failed tests |
| --- | ---: | ---: | --- | --- | ---: |
| Chromium | 106 | 1,230 | 661.586 / 655.640 / 655.095 | 0 / 0 / 0 | 0 |
| Firefox | 106 | 1,230 | 374.854 / 375.600 / 383.481 | 1 / 1 / 2 | 0 |
| WebKit | 95 | 1,122 | 1,295.702 / 1,182.029 / 1,164.525 | 0 / 0 / 0 | 0 |

All three passes have equal test and capture inventories, equal profile identities, and equal dimensions within each browser. The four failed Firefox attempts reached the 120-second test timeout. Their retained errors include cleanup attempts on closed pages; this does not establish the underlying timeout cause.

The corrected attempt audit joins Playwright blob `onTestBegin`, `onAttach`, and `onTestEnd` records by result ID. It verifies every test ID, retry number, and outcome against the selected capture report. Firefox retained **four PNG capture attachments from failed attempts**, two in pass 1 and two in pass 3. Every such capture was replaced by its later successful retry. All selected captures belong to the last successful attempt. An earlier audit read the wrong blob field and incorrectly said failures happened before capture; that claim is withdrawn. Use `attempt-coverage.json`.

## Exact service codec and comparison results

After authenticated decryption, the operator ran the exact source-hashed Ariviso `validateImage`, WASM `decodeImage`, and `compareImages` implementations locally in Node 24.18.0. Every selected capture was validated independently. Its original encoded bytes matched its recorded digest and remained equal before and after decoding. All 10,746 capture instances passed validation, with no decode or profile errors. Chromium and Firefox use `srgb-unprofiled-v1`; WebKit uses `srgb-explicit-v1`.

Chromium and Firefox each have 3,690 pair comparisons, and WebKit has 3,366: pass 1 to 2, 2 to 3, and 1 to 3. These pairs share images and are not independent statistical samples. All three invocations for a browser use one runner job and one measured environment; this does not measure variation across fresh runner instances or future image rollouts.

| Policy | Chromium changed image pairs / pixels | Firefox changed image pairs / pixels | WebKit changed image pairs / pixels |
| --- | ---: | ---: | ---: |
| `visible-exact-v1`: channel 0, pixels 0, ratio 0 | 12 / 86 | 0 / 0 | 0 / 0 |
| One-level channel threshold, pixels 0, ratio 0 | 8 / 70 | 0 / 0 | 0 / 0 |
| Previous ratio reference: channel 0, ratio 0.0005 | 0 / 86 | 0 / 0 | 0 / 0 |

The last row reports comparator outcomes separately from changed-pixel counts: the ratio policy records changed pixels but accepts the pair as unchanged. Strict Chromium outcomes by pair are 4, 6, and 2 changed images. The largest observed changed-pixel ratio is 0.00006538340830630819. Six distinct capture identities vary. Private pixel inspection locates changes at rounded input focus edges, native checkbox edges, and isolated corner pixels. The unchanged source and pixel locations support rendering noise as an inference; they do not prove every future difference at these locations is harmless.

The existing `packages/compare/evidence/corpus-study.json` separately tests 100 intentional small defects across four classes. Strict comparison misses none, the one-level policy misses 50, and the previous ratio reference misses 98. Synthetic noise and intentional defects are separate groups. The real captures here were not altered to produce synthetic defects.

The conservative policy recommendation remains:

```json
{ "id": "visible-exact-v1", "channelThreshold": 0, "maxChangedPixels": 0, "maxChangedRatio": 0 }
```

This recommendation accepts the observed small review burden instead of using a tolerance that hides measured small defects. It is not a zero-noise claim, and it does not quantify all future runner variation.

## Workload measurements

| Browser, pass 1 | Total encoded bytes | Mean bytes | p95 bytes | Maximum bytes | Mean pixels | Maximum pixels |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| Chromium | 19,173,317 | 15,588.06 | 35,079 | 190,439 | 141,521.50 | 1,547,520 |
| Firefox | 21,074,427 | 17,133.68 | 40,331 | 194,921 | 141,558.57 | 1,547,520 |
| WebKit | 22,651,149 | 20,188.19 | 48,587 | 210,157 | 144,425.85 | 1,547,520 |
| Full configured matrix | 62,898,893 | 17,559.71 | 41,137 | 210,157 | 142,443.96 | 1,547,520 |

These are actual split captures, not the old composite corpus. Duplicate image identities within a pass still count as captures. Pass 1 contains 3,491 distinct encoded PNG digests totaling 60,876,246 bytes; the report also records each browser separately. `workload.json` supplies exact statistics for all three complete passes. These values can inform an explicitly modeled expanded workload; they are not a measurement of 10,580 or 35,820 distinct authored states.

## Limits and reproduction

Each `<browser>/summary.json` is the runner's raw-RGBA aggregate. `<browser>/comparator.json` is the separate local exact-service analysis, including source hashes and runtime bounds. `<browser>/attempt-coverage.json` is the corrected full-attempt audit. The root `summary.json` combines the verified matrix counts and policy outcomes. The scripts in `analysis-source` preserve the exact analysis source used. The separate `independent-audit` receipt reproduces the policy results and checks every capture-to-PNG join, including the four failed Firefox captures. Their existing local paths describe the original private evidence layout; the raw archive and key are deliberately absent from this portable record.

Local batch CPU, RSS, and WASM memory are recorded as local measurements only. They are not Cloudflare Worker CPU or authoritative Worker peak memory. This work does not close the hosted memory or Container fallback gate, trusted Ariviso upload cycle, webhook provenance, or codeowner review. PNG byte preservation here supplements, but does not replace, the separate lossless WebP, color, alpha, corrupt-file, dimension-limit, and tolerated-drift evidence.
