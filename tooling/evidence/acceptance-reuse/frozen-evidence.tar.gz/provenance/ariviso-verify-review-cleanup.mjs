import assert from 'node:assert/strict';
import { readFile, writeFile, access } from 'node:fs/promises';
const fixture = 'e06-1f64609b-a679-4d22-ac94-5d5f32aae5de';
const toml = await readFile('/Users/diegohaz/Library/Preferences/.wrangler/config/default.toml', 'utf8');
const token = /^oauth_token\s*=\s*"([^"]+)"/m.exec(toml)?.[1];
assert(token);
const response = await fetch('https://api.cloudflare.com/client/v4/accounts/b04f3af3f0f10a6b9481bc23ba974eca/d1/database/f7030b0b-7697-49db-a7f8-63f92dea5b5d/query', {
  method: 'POST', headers: {Authorization: `Bearer ${token}`, 'Content-Type': 'application/json'},
  body: JSON.stringify({sql: 'SELECT (SELECT count(*) FROM session WHERE userId=?) AS sessions, (SELECT count(*) FROM account WHERE userId=?) AS accounts, (SELECT count(*) FROM user WHERE id=?) AS users', params: [fixture, fixture, fixture]}),
  redirect: 'error', signal: AbortSignal.timeout(30000),
});
const result = await response.json();
assert(response.ok && result.success);
const counts = result.result[0].results[0];
assert.deepEqual(counts, {sessions: 0, accounts: 0, users: 0});
let localSessionFileRemoved = false;
try { await access('/tmp/ariviso-diagnostic-review-session.json'); } catch (error) { if (error.code !== 'ENOENT') throw error; localSessionFileRemoved = true; }
assert(localSessionFileRemoved);
const receipt = {checkedAt: new Date().toISOString(), fixture, counts, localSessionFileRemoved, scope: 'Read-only exact synthetic identity absence check after cleanup; no auth credentials included.'};
await writeFile('/tmp/ariviso-acceptance-reuse-evidence/cleanup-verification.json', JSON.stringify(receipt, null, 2), {mode: 0o600, flag: 'wx'});
console.log(JSON.stringify(receipt));
