import assert from 'node:assert/strict';
import { readFile, writeFile } from 'node:fs/promises';
const [externalRunId, label] = process.argv.slice(2);
assert(/^\d{8,16}$/.test(externalRunId ?? ''));
assert(/^[a-z0-9-]{1,60}$/.test(label ?? ''));
const configuration = await readFile('/Users/diegohaz/Library/Preferences/.wrangler/config/default.toml', 'utf8');
const token = /^oauth_token\s*=\s*"([^"]+)"/m.exec(configuration)?.[1];
assert(token);
const endpoint = 'https://api.cloudflare.com/client/v4/accounts/b04f3af3f0f10a6b9481bc23ba974eca/d1/database/f7030b0b-7697-49db-a7f8-63f92dea5b5d/query';
const queries = {
  runs: 'SELECT id,project_id,external_run_id,attempt,kind,tested_sha,lineage_key,plan_digest,state,active,comparison_id,revision,sealed_at,closed_at,created_at FROM ariviso_runs WHERE external_run_id=? ORDER BY attempt LIMIT 10',
  shards: 'SELECT s.* FROM ariviso_shards s JOIN ariviso_runs r ON r.id=s.run_id WHERE r.external_run_id=? ORDER BY r.attempt,s.key LIMIT 20',
  manifests: 'SELECT m.* FROM ingest_manifests m JOIN ariviso_runs r ON r.id=m.run_id WHERE r.external_run_id=? ORDER BY r.attempt,m.shard_key LIMIT 20',
  captures: 'SELECT c.id,c.run_id,c.shard_key,c.item_key,c.variant_key,c.ordinal,c.image_id,c.profile_digest,c.test_id,c.test_retry,i.run_id AS image_owner_run_id,i.digest,i.bytes,i.width,i.height,i.bytes_present,i.validated FROM ariviso_captures c JOIN ariviso_runs r ON r.id=c.run_id JOIN ariviso_images i ON i.id=c.image_id WHERE r.external_run_id=? ORDER BY r.attempt,c.ordinal LIMIT 40',
  comparisonRows: 'SELECT cr.id,cr.comparison_id,cr.item_key,cr.variant_key,cr.reference_capture_id,cr.candidate_capture_id,cr.outcome,cr.result_json,cr.decision_id,cr.source_decision_id FROM ariviso_comparison_rows cr JOIN ariviso_comparisons cmp ON cmp.id=cr.comparison_id JOIN ariviso_runs r ON r.id=cmp.run_id WHERE r.external_run_id=? ORDER BY r.attempt,cr.ordinal LIMIT 40',
  checks: 'SELECT id,external_run_id FROM ariviso_checks WHERE external_run_id=? LIMIT 10',
};
const report = { checkedAt: new Date().toISOString(), externalRunId, label, sourceCommit:'43552ce5196448f6dee82da665c5b06863638b08', webVersion:'9ea84f79-9a30-46d4-81ab-5bea048cbd76', compareVersion:'09893c22-08b0-4ef1-ba39-6f44ae670298', datasets:{} };
for (const [name, sql] of Object.entries(queries)) {
  const response = await fetch(endpoint, {method:'POST', headers:{Authorization:`Bearer ${token}`,'Content-Type':'application/json'},body:JSON.stringify({sql,params:[externalRunId]}),redirect:'error',signal:AbortSignal.timeout(30000)});
  const body = await response.json();
  assert(response.ok && body.success, `${name}: HTTP ${response.status}`);
  report.datasets[name]=body.result[0].results;
}
const path=`/tmp/ariviso-hosted-run-${externalRunId}-${label}.json`;
await writeFile(path,JSON.stringify(report,null,2),{mode:0o600,flag:'wx'});
console.log(JSON.stringify({path,runStates:report.datasets.runs.map(r=>({id:r.id,attempt:r.attempt,state:r.state,active:r.active,sealedAt:r.sealed_at})),shards:report.datasets.shards.map(s=>({runId:s.run_id,key:s.key,state:s.state,sourceRun:s.source_run_id,sourceAttempt:s.source_attempt})),captures:report.datasets.captures.length,rows:report.datasets.comparisonRows.length,checks:report.datasets.checks}));
