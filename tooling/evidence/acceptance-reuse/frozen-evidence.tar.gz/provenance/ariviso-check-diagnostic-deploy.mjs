import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { createRequire } from 'node:module';
import { assertInfrastructure } from '/Users/diegohaz/Developer/ariviso/.github/workflows/scripts/deploy-version.mjs';
const root='/Users/diegohaz/Developer/ariviso';
const require=createRequire(`${root}/package.json`);
const {unstable_readConfig}=await import(require.resolve('wrangler'));
const token=(await readFile('/tmp/ariviso-cloudflare-deployment-token','utf8')).trim();
const account='b04f3af3f0f10a6b9481bc23ba974eca';
const report=[];
for(const [config,env,name] of [['apps/web/dist/server/wrangler.json',undefined,'ariviso-diagnostics'],['apps/compare/wrangler.jsonc','diagnostics','ariviso-diagnostics-compare']]){
 const local=unstable_readConfig({config:`${root}/${config}`,env});
 assert.equal(local.name,name);
 const results=[];
 for(const path of ['settings','schedules']){
  const response=await fetch(`https://api.cloudflare.com/client/v4/accounts/${account}/workers/scripts/${name}/${path}`,{headers:{Authorization:`Bearer ${token}`},redirect:'error',signal:AbortSignal.timeout(20000)});
  assert(response.ok,`${name}/${path}: HTTP ${response.status}`);
  const body=await response.json();assert.equal(body.success,true);results.push(body.result);
 }
 assertInfrastructure(local,...results);
 report.push({worker:name,bindingsAndCronsMatch:true});
}
console.log(JSON.stringify(report));
