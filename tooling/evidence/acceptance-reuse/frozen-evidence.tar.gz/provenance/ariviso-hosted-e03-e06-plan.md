# Hosted E03/E06 execution plan

This plan was prepared by read-only inspection on September 22, 2026. No test described below was dispatched during planning. The root agent owns later execution and authorization. Genuine GitHub provenance must come from the real workflow, signed OIDC, successful jobs, and independent receipts.

## Existing trusted entry point

The diagnostic repository main is [`24f508c`](https://github.com/ariakit/ariviso-diagnostics/commit/24f508cc65c91867d747a8046d4aef6348418ced). Its caller uses the immutable reusable workflow at [`dcf4278`](https://github.com/ariakit/ariviso-diagnostics/commit/dcf42788b6c284a1affb4d2df65954672b04bae0), which reads executor files from [`4c16e46`](https://github.com/ariakit/ariviso-diagnostics/commit/4c16e466025df6553dae4e512e1fe1225d5bd58e). Expected jobs are `capture / chromium-1` and `capture / chromium-2`.

Scheduled reconciliation already verifies this fixture without an automatic App webhook. The webhook remains necessary for genuine merge-group metadata and lifecycle events.

## Preconditions

Wait for the root agent's final diagnostic deployment signal. Record Web and comparator versions and source hashes. Refresh the expired bootstrap URLs using the exact package hashes expected by the pinned executor. These packages predate the latest CLI correction, so the receipt must state that limit. Verify that the measured runner environment still matches the trusted plan; do not relax its allowlist.

Review mutations can use a renewed synthetic diagnostic session with a live repository-permission check. Label this mechanism accurately; it does not establish OAuth login. Clean up its identity and session when the probe ends.

## Genuine failed-job inheritance

Create a scenario-only diagnostic PR from the trusted main revision. Preserve all workflows, executor files, and plan files. Use:

```json
{
  "color": "blue",
  "failSecondShardOnFirstAttempt": true,
  "retrySecondTestOnce": false
}
```

Attempt 1 must leave shard 1 successfully verified and shard 2 failed. Wait for reconciliation to record those results and a non-successful Ariviso check. Then use the supported failed-job rerun:

```sh
gh run rerun RUN_ID --failed --repo ariakit/ariviso-diagnostics
```

GitHub documents that reruns use the original SHA and ref. See [Re-running workflows and jobs](https://docs.github.com/en/actions/how-tos/manage-workflow-runs/re-run-workflows-and-jobs).

Preserve actual job metadata, artifact metadata, and bounded D1 observations. Require the same tested SHA, plan, and per-shard profile identity; shard 1's original job ID and `source_attempt=1`; shard 2's successful replacement job and `source_attempt=2`; both final captures; and sealing only after complete successful evidence. Missing shard 2 must not become a removal. Keep this intentional failure fixture out of the merge queue.

## Source invalidation and attempt supersession

Use existing diagnostic PR7 after verifying that both variants remain approved. Record the original decision IDs and current active run. A reviewed PR body edit triggers the existing `pull_request: edited` event without changing candidate source. Wait for this run to finish before another trigger, because the caller cancels in-progress runs in the same concurrency group.

Require the same actual merge SHA, image bytes, and profile identities. Require the new run's `source_decision_id` references to identify the original decisions. Fully rerun this new workflow once. Both shards must come from the new attempt; the old attempt must become inactive and superseded; valid acceptance must remain effective.

Reject one approved variant on the still-active original PR7 run. The dependent active run and its actual App check must lose success. Undo this rejection through the same fresh review session. Verify decision revisions, source provenance, dependent status, and final checks. Baseline revision 1 must remain unchanged.

This sequence needs one failure-scenario PR attempt, its failed-job rerun, one body-triggered PR7 run, and one full rerun. It starts seven capture-job executions. It does not change trusted main or workflow code.

## Cases that need controlled instrumentation

The existing executor fails shard 2 only when `GITHUB_RUN_ATTEMPT === "1"`. It cannot deterministically fail an explicitly rerun previously successful shard. A single-job rerun followed by genuine workflow cancellation can supply a cancelled-rerun case only if reservation occurs before cancellation and GitHub confirms that the job did not succeed. A race that completes successfully supplies no negative evidence. [GitHub's REST API](https://docs.github.com/en/rest/actions/workflow-runs#re-run-a-job-from-a-workflow-run) supports single-job reruns, including dependent jobs.

The fixed CLI does not preserve its real CI capability for later replay. Existing locally minted capability probes therefore do not establish superseded late CI upload refusal. These deterministic cases need a reviewed fixture extension or a separately identified hosted service fixture. They do not need a new account grant.

## Delayed status race

Rapid approve/reject calls alone cannot prove the outbound race. The current public routes have no pause point. Use a bounded authenticated hosted harness with frozen production `claimStatus`, `deliverStatus`, and `sendGitHubCheck` logic and an actual diagnostic App check. Pause before the final freshness check, change the relevant source revision, then release. Require `not-sent` and no stale PATCH.

Add an in-flight case: issue the old request, hold its real response, change the desired state, and show that lease expiry cannot authorize another writer. After confirmed settlement, send the current failure and verify GitHub's actual final check. Distinguish a confirmed response from an ambiguous transport failure. The existing hosted queue probe has no GitHub binding and does not close this case.

## Retained bytes, rollback, and GC

Use final-source service and operations fixtures in isolated hosted D1/R2 with an authenticated harness. Use an explicit test clock; do not backdate live diagnostic rows. Measure the 30-day boundary, archive-before-delete rule, active/manual/baseline/rollback/recovery pins, exact-prefix deletion, retained identity and acceptance history, and both orders of the GC-versus-new-reference race. Verify actual R2 bytes and digests and atomic D1 outcomes.

The same harness can cover D22/D26 current/stale rollback, Undo, and mixed automatic/human protection with real protected copies. Label its run provenance as fixture data, not GitHub OIDC. No new Cloudflare permission grant is needed for the existing authorized products, but the root agent must select the isolated resources and deployment scope.

## Genuine blockers

- Merge-group capture, PR closure or target-change webhook retirement, and installation/OAuth revocation need automatic signed App webhook delivery. Manual ping does not establish these requirements.
- Full GitHub main rollback needs a changed main capture with a human approval. The current blue baseline was automatically accepted and cannot supply that rollback target. The existing required merge queue is blocked by missing genuine merge-group metadata. Do not bypass it.
- The full Ariakit cycle and cutover still need the separate codeowner approval for PR7582.
- Diagnostic OAuth login still needs callback registration behind App settings access.

## Evidence boundaries

Tie each result to the deployed source, trusted refs, tested SHA, real job and attempt IDs, independent receipt digests, service run/comparison/decision IDs, and App check IDs. Preserve before/after state and exact assertions. Keep seeded sessions, fixture provenance, test-clock measurements, and real GitHub authorization evidence separate. Do not describe pending cases as passed.
