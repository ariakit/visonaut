import datetime, hashlib, http.client, json, os, platform, signal, socket, subprocess, time
from pathlib import Path
base=Path('/tmp/ariviso-worker-process-peak')
binary=Path('/Users/diegohaz/Developer/ariviso/node_modules/.pnpm/@cloudflare+workerd-darwin-arm64@1.20260921.1/node_modules/@cloudflare/workerd-darwin-arm64/bin/workerd')
fixtures=json.loads((base/'source-manifest.json').read_text())['fixtures']
report={'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'platform':platform.platform(),'machine':platform.machine(),'measurement':'kernel wait4 child rusage, Darwin ru_maxrss bytes; complete fresh native workerd process lifetime','invocations':'Real sequential HTTP POST /probe requests in one native workerd service with one isolate; fresh process per case/repeat, SIGTERM after successful response validation','runtime':subprocess.check_output([binary,'--version'],text=True).strip(),'runtimeSha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'workerBundleSha256':hashlib.sha256((base/'serve.js').read_bytes()).hexdigest(),'results':[]}
for fixture in fixtures:
 for runs in [1,25]:
  for repeat in range(3):
   case=f'{fixture["name"]}-{runs}'
   output=base/f'http-{case}-{repeat}.log'
   data=(base/fixture['name']).read_bytes()
   assert hashlib.sha256(data).hexdigest()==fixture['sha256']
   with socket.socket() as port_socket:
    port_socket.bind(('127.0.0.1',0));port=port_socket.getsockname()[1]
   started=time.monotonic();samples=[];failure=None
   with output.open('wb') as handle:
    child=subprocess.Popen([str(binary),'serve','-I/',f'-shttp=127.0.0.1:{port}',str(base/'serve.capnp')],stdout=handle,stderr=subprocess.STDOUT)
    try:
     for _ in range(100):
      try:
       with socket.create_connection(('127.0.0.1',port),timeout=.1): pass
       break
      except OSError: time.sleep(.01)
     else: raise RuntimeError('workerd socket did not open')
     connection=http.client.HTTPConnection('127.0.0.1',port,timeout=10)
     for index in range(runs):
      connection.request('POST','/probe',body=data,headers={'Authorization':'Bearer local-memory-probe','Content-Type':'application/octet-stream'})
      response=connection.getresponse();result=json.loads(response.read())
      assert response.status==200,(response.status,result)
      assert result['rgbaDigest']==fixture['decodedSha256'],result
      assert result['originalDigest']==fixture['sha256'],result
      assert result['outcome']=='unchanged' and result['changedPixels']==0,result
      samples.append({'index':index,**result})
     connection.close()
    except Exception as error: failure=repr(error)
    finally:
     child.send_signal(signal.SIGTERM)
     waited,status,usage=os.wait4(child.pid,0)
     child.returncode=os.waitstatus_to_exitcode(status)
   item={'case':case,'repeat':repeat,'expectedExitSignal':'SIGTERM','exitCode':child.returncode,'peakRssBytes':usage.ru_maxrss,'userCpuSeconds':usage.ru_utime,'systemCpuSeconds':usage.ru_stime,'totalCpuSeconds':usage.ru_utime+usage.ru_stime,'wallSeconds':time.monotonic()-started,'majorPageFaults':usage.ru_majflt,'swaps':usage.ru_nswap,'samples':samples,'log':output.name,'error':failure}
   report['results'].append(item)
   (base/'http-measurements.json').write_text(json.dumps(report,indent=2)+'\n')
   print(json.dumps({k:v for k,v in item.items() if k not in ['samples','log']}),flush=True)
   if failure:raise RuntimeError(failure)
