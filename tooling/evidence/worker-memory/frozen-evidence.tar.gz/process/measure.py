import datetime, hashlib, json, os, platform, subprocess, sys, time
from pathlib import Path
base=Path('/tmp/ariviso-worker-process-peak')
binary=Path('/Users/diegohaz/Developer/ariviso/node_modules/.pnpm/@cloudflare+workerd-darwin-arm64@1.20260921.1/node_modules/@cloudflare/workerd-darwin-arm64/bin/workerd')
report={'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'platform':platform.platform(),'machine':platform.machine(),'measurement':'kernel wait4 child rusage, Darwin ru_maxrss bytes; complete fresh native workerd process lifetime','runtime':subprocess.check_output([binary,'--version'],text=True).strip(),'runtimeSha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'results':[]}
cases=[f'calibration-{kind}' for kind in ['empty','arraybuffer','wasm']]+[f'{fixture}-{runs}' for fixture in ['largest.webp','largest.png','supported-limit.png'] for runs in [1,25]]
for case in cases:
    for repeat in range(3):
        output=base/f'{case}-{repeat}.log'
        started=time.monotonic()
        with output.open('wb') as handle:
            child=subprocess.Popen([str(binary),'test','-I/',str(base/f'{case}.capnp')],stdout=handle,stderr=subprocess.STDOUT)
            waited,status,usage=os.wait4(child.pid,0)
            child.returncode=os.waitstatus_to_exitcode(status)
        lines=output.read_text().splitlines()
        payloads=[json.loads(line) for line in lines if line.startswith('{')]
        item={'case':case,'repeat':repeat,'exitCode':child.returncode,'peakRssBytes':usage.ru_maxrss,'userCpuSeconds':usage.ru_utime,'systemCpuSeconds':usage.ru_stime,'totalCpuSeconds':usage.ru_utime+usage.ru_stime,'wallSeconds':time.monotonic()-started,'majorPageFaults':usage.ru_majflt,'swaps':usage.ru_nswap,'payloads':payloads,'log':output.name}
        report['results'].append(item)
        (base/'measurements.json').write_text(json.dumps(report,indent=2)+'\n')
        print(json.dumps({k:v for k,v in item.items() if k not in ['payloads','log']}),flush=True)
        if child.returncode: raise SystemExit('workerd failure; see '+str(output))
