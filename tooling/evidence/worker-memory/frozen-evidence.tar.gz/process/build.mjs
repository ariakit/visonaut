import { build } from '/Users/diegohaz/Developer/ariviso/node_modules/.pnpm/esbuild@0.27.7/node_modules/esbuild/lib/main.js';
import { readFile, writeFile, copyFile, mkdir } from 'node:fs/promises';
import { createHash } from 'node:crypto';
const root='/Users/diegohaz/Developer/ariviso';
const dir='/tmp/ariviso-worker-process-peak';
await mkdir(dir,{recursive:true});
const entry=`import probe from '${root}/apps/compare/src/probe.ts';
export default { async test(ctrl,env) {
const samples=[];
for(let i=0;i<Number(env.RUNS);i++) {
const request=new Request('http://probe/probe',{method:'POST',headers:{Authorization:'Bearer local-memory-probe'},body:env.INPUT});
const response=await probe.fetch(request,{PROBE_TOKEN:'local-memory-probe'});
const result=await response.json();
if(response.status!==200 || result.rgbaDigest!==env.EXPECTED || result.outcome!=='unchanged' || result.changedPixels!==0) throw new Error(JSON.stringify({status:response.status,result}));
samples.push({index:i,...result});
}
console.log(JSON.stringify({kind:'codec-results',samples}));
}};`;
await writeFile(`${dir}/entry.ts`,entry);
const wasmFiles=[];
const bundle=await build({entryPoints:[`${dir}/entry.ts`],bundle:true,format:'esm',platform:'browser',target:'es2022',outfile:`${dir}/worker.js`,metafile:true,plugins:[{name:'wasm',setup(build){build.onResolve({filter:/\.wasm$/},async args=>{if(args.pluginData?.skip) return; const resolved=await build.resolve(args.path,{resolveDir:args.resolveDir,kind:args.kind,pluginData:{skip:true}});const name=args.path.includes('webp')?'webp.wasm':'png.wasm';wasmFiles.push({name,path:resolved.path});return {path:`./${name}`,external:true};});}}]});
for(const file of wasmFiles) await copyFile(file.path,`${dir}/${file.name}`);
const fixtureIndex=JSON.parse(await readFile('/tmp/ariviso-e01-container/fixtures/index.json','utf8'));
const fixtures=fixtureIndex.fixtures.filter(f=>['largest.png','largest.webp','supported-limit.png'].includes(f.name));
const capnpSchema=`${root}/node_modules/.pnpm/workerd@1.20260921.1/node_modules/workerd/workerd.capnp`;
for(const fixture of fixtures){
 await copyFile(`/tmp/ariviso-e01-container/fixtures/${fixture.name}`,`${dir}/${fixture.name}`);
 for(const runs of [1,25]) {
  const config=`using Workerd = import "${capnpSchema}";
const config :Workerd.Config = (services = [(name = "codec", worker = (
 compatibilityDate = "2026-09-21",
 modules = [(name = "worker.js", esModule = embed "worker.js"), (name = "png.wasm", wasm = embed "png.wasm"), (name = "webp.wasm", wasm = embed "webp.wasm")],
 bindings = [(name = "INPUT", data = embed "${fixture.name}"),(name="EXPECTED",text="${fixture.decodedSha256}"),(name="RUNS",text="${runs}")]
))]);`;
 await writeFile(`${dir}/${fixture.name}-${runs}.capnp`,config);
 }
}
await writeFile(`${dir}/calibration.js`,`globalThis.held=[]; export default { async test(ctrl,env) { const n=Number(env.BYTES); if(env.KIND==='arraybuffer')held.push(new Uint8Array(n).fill(1)); if(env.KIND==='wasm'){const memory=new WebAssembly.Memory({initial:n/65536});new Uint8Array(memory.buffer).fill(1);held.push(memory);} console.log(JSON.stringify({kind:'calibration',type:env.KIND,bytes:n,retained:held.length})); } };`);
for(const kind of ['empty','arraybuffer','wasm']) await writeFile(`${dir}/calibration-${kind}.capnp`,`using Workerd=import "${capnpSchema}";const config :Workerd.Config=(services=[(name="calibration",worker=(compatibilityDate="2026-09-21",modules=[(name="calibration.js",esModule=embed "calibration.js")],bindings=[(name="KIND",text="${kind}"),(name="BYTES",text="67108864")]))]);`);
const hashes={};for(const file of [...Object.keys(bundle.metafile.inputs),...wasmFiles.map(f=>f.path)]){const bytes=await readFile(file);hashes[file]=createHash('sha256').update(bytes).digest('hex');}
await writeFile(`${dir}/source-manifest.json`,JSON.stringify({createdAt:new Date().toISOString(),fixtures,hashes,metafile:bundle.metafile},null,2)+'\n');
await build({entryPoints:[`${root}/apps/compare/src/probe.ts`],bundle:true,format:'esm',platform:'browser',target:'es2022',outfile:`${dir}/serve.js`,plugins:[{name:'wasm',setup(build){build.onResolve({filter:/\.wasm$/},args=>({path:args.path.includes('webp')?'./webp.wasm':'./png.wasm',external:true}));}}]});
await writeFile(`${dir}/serve.capnp`,`using Workerd=import "${capnpSchema}";const config :Workerd.Config=(services=[(name="codec",worker=(compatibilityDate="2026-09-21",modules=[(name="serve.js",esModule=embed "serve.js"),(name="png.wasm",wasm=embed "png.wasm"),(name="webp.wasm",wasm=embed "webp.wasm")],bindings=[(name="PROBE_TOKEN",text="local-memory-probe")]))],sockets=[(name="http",address="127.0.0.1:0",http=(),service="codec")]);`);
