# Worker memory measurement boundary and local process peaks

Result: a true local workerd process resident-memory high-water mark is measurable with the kernel. A hosted Worker isolate memory peak is still not available from the tested interfaces. These results do not close E01 or prove that the production comparator fits the hosted memory limit.

No repository source, cloud resource, cloud permission, or deployment changed. The localhost listener required one automatically approved sandbox exception. All HTTP traffic remained on 127.0.0.1.

## Measurement

Collected on 2026-09-22 on macOS 26.6.2 arm64 with workerd 1.20260921.1, Node 24.18.0, and esbuild 0.27.7. The runtime binary SHA-256 is `d93f68bd50a50de5511721ea962727f00c04a95e77c902140f0e8be330467d9a`. The HTTP Worker bundle SHA-256 is `3b4d76a3515556b602fd661f2bb8721b70396a57fd418b00a6b772d0ff6a3028`.

`build.mjs` bundles the existing `apps/compare/src/probe.ts` without changing its behavior. The served process contains one Worker service, no Miniflare controller, no inspector, and no fixture binding. A Python client sends real HTTP requests to that process. Each request performs bounded input read, validation, two decodes, exact comparison, thumbnail encoding, mask encoding, original digest, and decoded-pixel digest. The client checks HTTP 200, both digests, unchanged outcome, and zero changed pixels.

A fresh process runs either one request or 25 sequential requests. This gives exact process affinity and one active codec request. Each case has three fresh-process repetitions. The process handles SIGTERM and exits with status zero after all response checks pass. The Python parent calls `os.wait4` for that child. On this Darwin host, `ru_maxrss` is bytes, as the installed `getrusage(2)` manual states. Apple kernel source assigns it from `task_info.resident_size_max`; it is not a polling maximum. CPU is kernel user time plus system time for the complete process lifetime, including startup, codec initialization, helper threads, and shutdown. It is not the hosted per-invocation CPU measurement.

[Apple kernel accounting source](https://github.com/apple-oss-distributions/xnu/blob/main/bsd/kern/kern_resource.c) supports this interpretation. The older Apple archived iPhone manual labels the RSS units as kilobytes and does not describe this host's current interface; the local manual and 64 MiB calibration establish the unit used here.

| Input | Requests per process | Responses checked | Maximum process peak RSS, bytes | Maximum process lifetime CPU, ms |
| --- | ---: | ---: | ---: | ---: |
| Largest existing WebP, 1248 × 1650 | 1 | 3 | 128,729,088 | 86.654 |
| Largest existing WebP, 1248 × 1650 | 25 | 75 | 632,324,096 | 824.773 |
| Lossless PNG of that image, 1248 × 1650 | 1 | 3 | 142,540,800 | 135.143 |
| Lossless PNG of that image, 1248 × 1650 | 25 | 75 | 197,017,600 | 1,649.895 |
| Supported decoded limit PNG, 1400 × 1500 | 1 | 3 | 170,721,280 | 212.313 |
| Supported decoded limit PNG, 1400 × 1500 | 25 | 75 | 260,210,688 | 3,603.855 |

All 234 HTTP responses passed parity and result checks. The decoded limit fixture has 2,100,000 pixels and 1,668,228 encoded bytes. It is the seeded two-color image prepared for the Container probe. Source/fixture hashes and original fixture metadata are in `source-manifest.json`. Every response and raw kernel measurement is in `http-measurements.json`; `http-summary.json` contains the table values.

The separate kernel calibration held and touched 64 MiB in a Uint8Array or a WebAssembly.Memory. Empty process peak RSS was 29,786,112–29,884,416 bytes. Uint8Array peak RSS was 96,944,128–97,058,816 bytes. WASM peak RSS was 97,058,816–97,206,272 bytes. Thus this measurement detects resident WASM memory that the prior inspector backingStorageSize calibration missed. Raw calibration is in `calibration-measurements.json`.

## Why this cannot certify hosted isolate peak

- RSS covers the entire native process, including runtime code and native allocations. It measures physical resident pages, not the hosted platform's isolate accounting. A difference from an empty-process measurement is not an exact isolate peak. No baseline subtraction was used.
- Local workerd explicitly constructs `NullIsolateLimitEnforcer`. In the pinned version it returns default V8 create parameters, does not customize the isolate, reports no metrics, and never reports excessive heap use. [Pinned workerd source](https://github.com/cloudflare/workerd/blob/v1.20260921.1/src/workerd/server/server.c%2B%2B) contains this class and its construction. Therefore the local 25-request WebP high-water mark does not prove a hosted Worker failure. Local GC, memory pressure, and limit enforcement differ.
- An RSS value below 128 MiB would bound resident pages for that process run, but would still not prove that all hosted isolate allocations remain below the platform limit. Untouched, compressed, or nonresident allocations and different native/runtime accounting prevent that inference. The above-limit process values likewise do not establish a hosted isolate overrun.
- The probe includes the codec pipeline. It does not include production R2, D1, queue metadata, two separately validated originals, other accepted input shapes, or simultaneous non-codec invocations. It compares the fixture to itself, so the data do not establish the maximum over differing input pairs and output masks.
- [Hosted Workers metrics](https://developers.cloudflare.com/workers/observability/metrics-and-analytics/) describe isolate memory at invocation time. Taking their maximum does not convert those samples into an intra-invocation peak. [Cloudflare's memory profiling guide](https://developers.cloudflare.com/workers/observability/dev-tools/memory-usage/) recommends local snapshots and warns that local behavior can differ from production. A paused snapshot or allocation profile can aid diagnosis but does not provide a continuous complete runtime high-water mark.

The codec's retained WASM capacity can be measured exactly as a separate quantity: its memory instances are created once, retained, and grow. Their buffer lengths cannot shrink during this implementation's lifetime, so the final sum is the peak linear-memory capacity of those instances. That does not include JavaScript buffers or runtime/native allocations and cannot close the total-isolate peak requirement. The existing code already uses the correct narrow `wasmMemoryBytes` label.

## Practical next step

There is no justified relabeling of the available counters that closes the hosted peak requirement. The bounded choices are:

1. Obtain a Cloudflare runtime counter or provider-assisted measurement that explicitly covers the hosted isolate's complete intra-invocation high-water mark, with WASM included, then run the real queue path at the supported bounds.
2. Use the already planned Cloudflare Container fallback and measure a dedicated comparison process or container with a kernel high-water counter in that hosted runtime, while also proving native codec parity, queue behavior, lifecycle, and cost. This task did not authorize or grant the pending Container permission and did not deploy anything.

The existing hosted CPU measurements remain useful. The local kernel CPU results here add repeatable local evidence but cannot replace them. E01 should remain open until its required hosted resource/fallback evidence is supplied or the user changes that acceptance requirement.

## Reproduction

Run from the repository directory with the current installed dependencies and the prepared fixture directory available:

```sh
node /tmp/ariviso-worker-process-peak/build.mjs
python3 /tmp/ariviso-worker-process-peak/measure.py
python3 /tmp/ariviso-worker-process-peak/measure-http.py
```

The last command needs permission to bind a localhost socket. The `measure.py` codec cases are earlier direct test-handler diagnostics; use `http-measurements.json` for the reported HTTP results. Its calibration cases remain valid and are copied to `calibration-measurements.json`.
