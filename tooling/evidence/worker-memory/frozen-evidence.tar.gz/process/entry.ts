import probe from '/Users/diegohaz/Developer/ariviso/apps/compare/src/probe.ts';
export default { async test(ctrl,env) {
const samples=[];
for(let i=0;i<Number(env.RUNS);i++) {
const request=new Request('http://probe/probe',{method:'POST',headers:{Authorization:'Bearer local-memory-probe'},body:env.INPUT});
const response=await probe.fetch(request,{PROBE_TOKEN:'local-memory-probe'});
const result=await response.json();
if(response.status!==200 || result.rgbaDigest!==env.EXPECTED || result.outcome!=='unchanged' || result.changedPixels!==0) throw new Error(JSON.stringify({status:response.status,result}));
samples.push({index:i,...result});
}
console.log(JSON.stringify({kind:'codec-results',samples}));
}};