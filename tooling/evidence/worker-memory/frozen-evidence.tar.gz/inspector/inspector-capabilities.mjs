import { convertV4MiniflareOptions, Miniflare } from '/Users/diegohaz/Developer/ariviso/node_modules/.pnpm/miniflare@5.20260921.0-alpha_@types+node@24.13.6/node_modules/miniflare/dist/src/index.js';
import { writeFile } from 'node:fs/promises';
const mf = new Miniflare(convertV4MiniflareOptions({ workers:[{ name:'peak-calibration', modules:true, script: `globalThis.held=[]; export default {async fetch(request) { const phase=new URL(request.url).pathname; if(phase==='/arraybuffer') {held.push(new Uint8Array(16*1024*1024).fill(1));} if(phase==='/wasm') {held.push(new WebAssembly.Memory({initial:256,maximum:512})); new Uint8Array(held.at(-1).buffer).fill(1);} if(phase==='/release') held=[]; return Response.json({phase,length:held.length});}}`, compatibilityDate:'2026-09-21'}], inspectorPort:0 }));
const report={timestamp:new Date().toISOString(),node:process.version,versions:{miniflare:'5.20260921.0-alpha',workerd:'1.20260921.1'},commands:[]};
let ws;
try {
 await mf.ready; const url=await mf.getInspectorURL(); report.inspectorUrl=String(url); if(url.protocol==='ws:') url.protocol='http:';
 const targets=await fetch(new URL('/json/list',url)).then(r=>r.json());
 report.targets=targets;
 const target=targets.find(t=>t.title.includes('peak-calibration'))??targets[0];
 ws=new WebSocket(target.webSocketDebuggerUrl);
 await new Promise((resolve,reject)=>{ws.onopen=resolve; ws.onerror=reject;});
 let id=0; const pending=new Map();
 ws.onmessage=e=>{const m=JSON.parse(e.data);if(m.id){pending.get(m.id)?.(m); pending.delete(m.id);}};
 async function call(method,params={}) {const request={id:++id,method,params}; const response=await new Promise((resolve,reject)=>{const timer=setTimeout(()=>{pending.delete(request.id);reject(new Error('timeout '+method));},10000);pending.set(request.id,m=>{clearTimeout(timer);resolve(m);});ws.send(JSON.stringify(request));}); report.commands.push({request,response});return response;}
 await call('Runtime.enable');
 await call('Schema.getDomains');
 await call('Runtime.getHeapUsage');
 for (const phase of ['arraybuffer','wasm','release']) {const result=await mf.dispatchFetch('http://probe/'+phase).then(r=>r.json());report.commands.push({phase,result}); await call('Runtime.getHeapUsage');}
 await call('HeapProfiler.enable');
 await call('HeapProfiler.startTrackingHeapObjects',{trackAllocations:true});
 await mf.dispatchFetch('http://probe/arraybuffer');
 await call('HeapProfiler.stopTrackingHeapObjects',{reportProgress:false});
 await call('HeapProfiler.startSampling',{samplingInterval:32768,includeObjectsCollectedByMajorGC:true,includeObjectsCollectedByMinorGC:true});
 await mf.dispatchFetch('http://probe/wasm');
 await call('HeapProfiler.stopSampling');
 await call('Memory.getDOMCounters');
 await call('Performance.getMetrics');
} catch(error) { report.error={name:error.name,message:error.message,stack:error.stack}; }
finally {ws?.close();await mf.dispose();await writeFile('/tmp/ariviso-worker-peak-probe/inspector-capabilities.json',JSON.stringify(report,null,2));console.log(JSON.stringify(report,null,2));}
