# Native Worker memory inspector calibration

Status: calibration completed, not a peak-memory or codec result. No root source or cloud resources changed.

Node24.18.0, Miniflare5.20260921.0-alpha, workerd1.20260921.1. The harness uses convertV4MiniflareOptions, waits for mf.ready, and converts the inspector discovery URL from ws to http. It attaches directly to the named synthetic Worker target.

A filled16MiB Uint8Array increased Runtime.getHeapUsage.backingStorageSize by exactly16,777,216 bytes. Adding and filling a separate16MiB WebAssembly.Memory did not change that counter. usedSize increased only by small wrapper allocations. Thus this counter does not cover the WASM linear memory used by the comparator. Heap tracking commands are supported, but the allocation sampling profile for the WASM allocation was empty. Memory.getDOMCounters and Performance.getMetrics are unavailable. No counter here is a continuous total-isolate peak.

Raw requests/responses: inspector-capabilities.json. Harness: inspector-capabilities.mjs. These contain synthetic buffers and localhost endpoints only. The successful run began2026-09-22T13:56:02.678Z. Earlier initialization failures are not measurements.

This calibration rules out treating one Runtime.getHeapUsage maximum as the required peak measurement. Adding codec-reported WASM bytes can form a phase observation, but still does not establish continuous peak allocation or production memory. E01 remains open. Official Cloudflare memory guide https://developers.cloudflare.com/workers/observability/dev-tools/memory-usage/ recommends paused snapshots and cautions that local behavior may differ; hosted metrics https://developers.cloudflare.com/workers/observability/metrics-and-analytics/ are invocation-time samples.
